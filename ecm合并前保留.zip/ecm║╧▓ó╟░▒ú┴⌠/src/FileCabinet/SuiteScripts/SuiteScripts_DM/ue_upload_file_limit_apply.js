/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * version      date            author      remark
 * 1.0          2023/02/20      Doris       【ID1018427】01-01 限额申请附件上传
 */
define(['N/file', 'N/record', 'N/search', 'N/https', 'N/runtime', '/SuiteScripts/tools/common_api.js', '/SuiteScripts/tools/hc_edi_interface_tool.js', '/SuiteScripts/tools/moment.js', '/SuiteScripts/tools/ramda.min.js', '/SuiteScripts/SuiteScripts_DM/environment_check.js'],
    /**
     * @param{file} file
     * @param{record} record
     * @param{search} search
     * @param{https} https
     * @param{runtime} runtime
     */
    (file, record, search, https, runtime, commonApi, interfaceTool, moment, ramda, enume) => {
        const LC_LIMIT_APPLY_TYPE = 'customrecord_ecm_sinosure_lc_quotaapply';// LC限额申请记录id
        const NO_LC_LIMIT_APPLY_TYPE = 'customrecord_ecm_sinosure_nlc_quotaapply';// 非LC限额申请记录id
        const LOG_TYPE = 'customrecord_hc_edi_interface_log';// 日志类型
        const IMETHOD = 'doEdiFileUpload';// 接口method
        const LC_FIELD_MAPPING = {
            'filenum' : 'custrecord_eslcq_filenum',    // 附件个数
            'postsinosure' : 'custrecord_eslcq_docs_postsinosure',    // 附件推送中信保
            'posterromsg' : 'custrecord_eslcq_docs_posterromsg',    // 附件推送失败原因
            'attachment' : 'custrecord_eslcq_attachment',    // 附件
            'errorMsg': 'custrecord_eslcq_errormsg',    // 错误描述
        };
        const NO_LC_FIELD_MAPPING = {
            'filenum' : 'custrecord_esncq_filenum',    // 附件个数
            'postsinosure' : 'custrecord_esncq_docs_postsino',    // 附件推送中信保
            'posterromsg' : 'custrecord_esncq_docs_posterro',    // 附件推送失败原因
            'attachment' : 'custrecord_esncq_attachment',    // 附件
            'errorMsg': 'custrecord_esncq_errormsg',    // 错误描述
        }
        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed before record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const beforeSubmit = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {
            if(['delete','xedit'].includes(scriptContext.type)) return ;
            let logUpdVal = {
                custrecord_hc_inf_process_msg: '',
                custrecord_hc_inf_errorflag: false
            };

            let newRec = scriptContext.newRecord;
            if (NO_LC_LIMIT_APPLY_TYPE == newRec.type){
                log.debug('NO_LC')
                sendData(newRec, NO_LC_FIELD_MAPPING, '010101', logUpdVal);
            }else if(LC_LIMIT_APPLY_TYPE == newRec.type){
                log.debug('LC')
                sendData(newRec, LC_FIELD_MAPPING, '010102', logUpdVal);
            }
        }

        /**
         * 附件上传接口
         * @param newRec
         * @param FIELD_MAPPING
         * @param dataType
         * @param logUpdVal
         */
        const sendData = (newRec, FIELD_MAPPING, dataType, logUpdVal) => {
            let rtnData = {};
            let lcRec = record.load({type:newRec.type, id:newRec.id});
            let fileNum = lcRec.getValue(FIELD_MAPPING.filenum);
            let attachment = lcRec.getValue(FIELD_MAPPING.attachment);
            let postsinosure = lcRec.getValue(FIELD_MAPPING.postsinosure);
            let posterromsg = lcRec.getValue(FIELD_MAPPING.posterromsg);
            let srcCorpserialno = lcRec.getValue('name');
            try{
                if ('' != fileNum && false == postsinosure && '' == posterromsg && '' != attachment){
                    let fileObj = file.load({
                        id:attachment
                    });
                    let size = Number(fileObj.size);

                    if (Number(20971520) < size){
                        lcRec.setValue({fieldId: FIELD_MAPPING.posterromsg, value: '文件大小已超过20M，不可超过20M，请压缩后重新上传'});
                        lcRec.save({enableSourcing:true, ignoreMandatoryFields:true});
                    }else {
                        let fileString = fileObj.getContents();
                        log.debug('getCon', fileString)

                        let fileByte = stringToByte(fileString);
                        // let reader = new FileReader();
                        // reader.readAsArrayBuffer(fileObj, 'GB18030');
                        // reader.onload = function (){
                        //
                        // }

                        // let fileByte = new Array(fileObj)
                        let fileName = fileObj.name;
                        let type = dataType;
                        let datas = [];
                        let dataJson = {};
                        dataJson.filename = fileName;
                        dataJson.corpserialno = attachment;
                        dataJson.srcCorpserialno = srcCorpserialno;
                        dataJson.filebyte = fileByte;
                        dataJson.type = type;
                        datas.push(dataJson);
                        log.debug('filebyte', {fileObjtype:typeof fileByte,fileObj:fileByte})
                        log.debug('datas', datas);
                        let body = {};
                        body.datas = datas;
                        body.imethod = IMETHOD;
                        log.debug('body',body)
                        try {
                            // rtnData = interfaceTool.requestEdiServer(body, enume.getAll().ECM_INTERFACE_TYPE_FILE_UPLOAD);// 接口类型：附件上传  // TODO
                            rtnData = requestEdiServer(body, enume.getAll().ECM_INTERFACE_TYPE_FILE_UPLOAD);// 接口类型：附件上传  // TODO
                            log.debug('rtnData', rtnData)
                            record.submitFields({
                                type: LOG_TYPE,
                                id: rtnData.logId,
                                values: logUpdVal
                            });
                            if (rtnData){
                                log.debug('error-file try')

                                if (true == rtnData.valid && '' == rtnData.data.errormsg){
                                    lcRec.setValue({fieldId: FIELD_MAPPING.postsinosure, value: true});
                                    lcRec.setValue({fieldId: FIELD_MAPPING.posterromsg, value: ''});
                                    lcRec.save({enableSourcing: true, ignoreMandatoryFields: true});
                                }else {
                                    log.debug('error-file try else')
                                    lcRec.setValue({fieldId:FIELD_MAPPING.postsinosure, value: false});
                                    lcRec.setValue({fieldId:FIELD_MAPPING.posterromsg, value: rtnData.data.errormsg});
                                    lcRec.save({enableSourcing:true, ignoreMandatoryFields:true});
                                }
                            }

                        }catch (ex){
                            // logUpdVal.custrecord_hc_inf_process_msg = e.message;
                            // logUpdVal.custrecord_hc_inf_errorflag = true;
                            // record.submitFields({
                            //     type: LOG_TYPE,
                            //     id: rtnData.logId,
                            //     values: logUpdVal
                            // });
                            if (rtnData) {
                                log.debug('error-file catch')
                                lcRec.setValue({fieldId: FIELD_MAPPING.postsinosure, value: false});
                                lcRec.setValue({fieldId: FIELD_MAPPING.posterromsg, value: ex});
                                lcRec.save({enableSourcing: true, ignoreMandatoryFields: true});
                            }
                        }
                    }
                }
            }catch (e){
                logUpdVal.custrecord_hc_inf_process_msg = e.message;
                logUpdVal.custrecord_hc_inf_errorflag = true;
                // record.submitFields({
                //     type: LOG_TYPE,
                //     id: rtnData.logId,
                //     values: logUpdVal
                // });
                log.error('附件上传error===>' + newRec.id, e);
                lcRec.setValue({fieldId:FIELD_MAPPING.errorMsg, value:e.message});
                lcRec.save({enableSourcing:true, ignoreMandatoryFields:true});
            }
        }

        /**
         * stringToByte  字符串格式转byte[]
         * @param {String} str
         */
        function stringToByte(str) {
            var bytes = new Array();
            var len, c;
            len = str.length;
            for (var i = 0; i < len; i++) {
                c = str.charCodeAt(i);
                if (c >= 0x010000 && c <= 0x10FFFF) {
                    bytes.push(((c >> 18) & 0x07) | 0xF0);
                    bytes.push(((c >> 12) & 0x3F) | 0x80);
                    bytes.push(((c >> 6) & 0x3F) | 0x80);
                    bytes.push((c & 0x3F) | 0x80);
                } else if (c >= 0x000800 && c <= 0x00FFFF) {
                    bytes.push(((c >> 12) & 0x0F) | 0xE0);
                    bytes.push(((c >> 6) & 0x3F) | 0x80);
                    bytes.push((c & 0x3F) | 0x80);
                } else if (c >= 0x000080 && c <= 0x0007FF) {
                    bytes.push(((c >> 6) & 0x1F) | 0xC0);
                    bytes.push((c & 0x3F) | 0x80);
                } else {
                    bytes.push(c & 0xFF);
                }
            }
            return bytes;
        }


        function interfaceParams() {
            var ediUrl = 'https://ediserver.echemi.co/ediserver/gateway.do';//请求地址
            var method = 'POST';
            //JW 生产环境待补充
            if('SANDBOX' != runtime.envType) {
                ediUrl = '';
                method = '';
            }
            return {
                url: ediUrl,
                method: method
            };
        }

        /**
         * 请求中信保EDI接口
         * @param body                  请求Body
         * @param itype                 接口类型
         * @return {{valid: boolean}}       {valid：是否请求成功true/false；data：接口返回数据（json）；logId：日志id，后续数据解析用}
         */
        function requestEdiServer(body, itype) {
            var infParams = interfaceParams();
            var headers = [];
            headers['Content-Type'] = 'application/json; charset=utf-8';
            var rtn = https.post({
                url: infParams.url,
                headers: headers,
                body: JSON.stringify(body)
            });
            log.debug('rtn===', rtn);
            var rtnData = {
                valid: false,
                logId: false
            };
            if(200 == rtn.code && rtn.body) {
                rtnData.valid = true;
                rtnData.data = JSON.parse(rtn.body);
            }
            rtnData.logId = createIntfaceLog(body.attachment, itype, rtn);
            return rtnData;
        }

        /**
         * 创建接口日志
         * @param reqData           请求报文
         * @param itype             接口类型id
         * @param rtn               返回数据
         * @return {number}
         */
        function createIntfaceLog(reqData, itype, rtn) {
            var obj = record.create({type: LOG_TYPE});
            obj.setValue({fieldId: 'custrecord_hc_inf_type', value: itype});
            obj.setValue({fieldId: 'custrecord_hc_inf_reqdata', value: JSON.stringify(reqData)});
            obj.setValue({fieldId: 'custrecord_hc_inf_rtndata', value: JSON.stringify(rtn)});
            var logId = obj.save({ignoreMandatoryFields: true});
            return logId;
        }

        return {beforeLoad, beforeSubmit, afterSubmit}

    });
