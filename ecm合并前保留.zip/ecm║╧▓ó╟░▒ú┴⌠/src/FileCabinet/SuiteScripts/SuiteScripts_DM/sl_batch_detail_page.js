/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 * version      date            author      remark
 * 1.0          2023/03/02      Doris       【ID1018570】SP仓库发货时创建IT单---批次信息页面
 * 2.0          2023/03/15      Doris       测试修改
 * 3.0          2023/03/17      Doris       测试修改，库存数量校验变更为检验现有数量
 */
define(['N/record', 'N/search', 'N/ui/serverWidget', 'N/url', 'N/config', '/SuiteScripts/SuiteScripts_DM/environment_check.js', '/SuiteScripts/tools/common_api.js'],
    /**
     * @param{record} record
     * @param{search} search
     * @param{serverWidget} serverWidget
     * @param{url} url
     * @param{config} config
     */
    (record, search, serverWidget, url, config, enume, commonApi) => {
        /**
         * Defines the Suitelet script trigger point.
         * @param {Object} scriptContext
         * @param {ServerRequest} scriptContext.request - Incoming request
         * @param {ServerResponse} scriptContext.response - Suitelet response
         * @since 2015.2
         */
        const onRequest = (scriptContext) => {
            let request = scriptContext.request;
            let response = scriptContext.response;
            let params = request.parameters;
            try {
                let form = createForm(params);
                response.writePage(form);
            }catch (e){
                log.error('选择批次信息页面有误', e);
            }
        }

        const createForm = (params) => {
            let form = serverWidget.createForm({title: 'Batch Info', hideNavBar: true});
            form.clientScriptModulePath = '/SuiteScripts/SuiteScripts_DM/cs_batch_details_page.js';
            form.addButton({id: 'custpage_btn_submit', label: 'Submit', functionName: 'submitDetail'});
            form.addButton({id: 'custpage_btn_cancel', label: 'Cancel', functionName: 'doCancel'});

            let itemGroup = form.addFieldGroup({id: 'custpage_item_group', label: 'Item Information'});
            let itemField = form.addField({id: 'custpage_subitem', label: 'Item', type: 'select', source: 'item', container: 'custpage_item_group'}).updateDisplayType({displayType: serverWidget.FieldDisplayType.DISABLED});
            if(params.item) {
                itemField.defaultValue = params.item;
            }
            let scdField = form.addField({id: 'custpage_scdid', label: 'SCD Line', type: 'select', source: 'customrecord_ecm_scd_line', container: 'custpage_item_group'}).updateDisplayType({displayType: serverWidget.FieldDisplayType.HIDDEN});
            if(params.scdlineid) {
                scdField.defaultValue = params.scdlineid;
            }
            let lineField = form.addField({id: 'custpage_line', label: 'Line', type: 'text', container: 'custpage_item_group'}).updateDisplayType({displayType: serverWidget.FieldDisplayType.HIDDEN});
            if(params.line) {
                lineField.defaultValue = params.line;
            }
            let locationField = form.addField({id: 'custpage_location', label: 'Location', type: 'text', container: 'custpage_item_group'}).updateDisplayType({displayType: serverWidget.FieldDisplayType.HIDDEN});
            if(params.location) {
                locationField.defaultValue = params.location;
            }
            let totalField = form.addField({id: 'custpage_total', label: 'Total', type: 'text', container: 'custpage_item_group'}).updateDisplayType({displayType: serverWidget.FieldDisplayType.ENTRY});
            totalField.updateDisplayType({displayType:serverWidget.FieldDisplayType.DISABLED});
            if (params.total){
                totalField.defaultValue = params.total;
            }
            let mainTotal = 0;//整单合计
            //language-提示信息区分用
            let langField = form.addField({id: 'custpage_lang', label: 'Language', type: 'text', container: 'custpage_item_group'}).updateDisplayType({displayType: serverWidget.FieldDisplayType.HIDDEN});
            let configObj = config.load({type: config.Type.USER_PREFERENCES});
            let lang = configObj.getValue({fieldId: 'LANGUAGE'});
            langField.defaultValue = lang;
            let dataList = form.addSublist({id: 'line_data', type: 'INLINEEDITOR', label: 'Batch Details'});
            dataList.addField({id: `custpage_select_batch`, type: serverWidget.FieldType.CHECKBOX, label: 'Select Batch'});
            let batchNumField = dataList.addField({id: `custpage_item_batch_name`, type: 'select', label: 'Batch Num'});
            batchNumField.addSelectOption({value: '', text: ''});

            let availableQtyField = dataList.addField({id: `custpage_item_available_qty`, type: 'text', label: 'Available Qty'});
            availableQtyField.updateDisplayType({displayType: serverWidget.FieldDisplayType.ENTRY});
            availableQtyField.updateDisplayType({displayType: serverWidget.FieldDisplayType.DISABLED});
            let transferQtyField = dataList.addField({id: `custpage_line_transfer_qty`, type: 'integer', label: 'Transfer Qty'});
            transferQtyField.updateDisplayType({displayType: serverWidget.FieldDisplayType.ENTRY});


            let thisLineInvetnroryData = formatThisSCDLineInventoryDatails(params.scdlineid);
            let inventoryArr = getItemInventory(params.item, params.location, thisLineInvetnroryData);
            if (inventoryArr && Object.keys(inventoryArr).length > 0){
                let noShippedQty = getNoShippedInv(inventoryArr, params.scdlineid, params.location);
                for (const invId in inventoryArr) {
                    let invValue = inventoryArr[invId]; // {inventorynumber:'',quantityavailable:0}
                    if (noShippedQty && noShippedQty.length) {
                        for (let j = 0; j < noShippedQty.length; j++) {
                            if(invId == noShippedQty[j].inventorynumber){
                                let quantityavailable = Number(invValue.quantityavailable).sub(noShippedQty[j].quantityavailable);
                                if (Number(0) < Number(quantityavailable)){
                                    invValue.quantityavailable = quantityavailable;
                                }else {
                                    delete inventoryArr[invId];
                                }
                            }
                        }
                    }
                }
            }
            if (inventoryArr && Object.keys(inventoryArr).length > 0){
                let lineId = 0;
                for (const inventoryArrKey in inventoryArr) {
                    dataList.setSublistValue({id:'custpage_select_batch', value:'T', line:lineId});
                    dataList.setSublistValue({id:'custpage_item_batch_name', value:inventoryArrKey, line:lineId});
                    dataList.setSublistValue({id:'custpage_item_batch_id', value:inventoryArrKey, line:lineId});
                    let qty = Number(inventoryArr[inventoryArrKey].quantityavailable);
                    dataList.setSublistValue({id:'custpage_item_available_qty', value:Math.floor(qty) === qty ? qty.toFixed(0) : qty, line:lineId});

                    if (thisLineInvetnroryData && Object.keys(thisLineInvetnroryData).length > 0){
                        for (const thisLineInvetnroryDataKey in thisLineInvetnroryData) {
                            if (thisLineInvetnroryDataKey == inventoryArrKey){
                                let transferQty = Number(thisLineInvetnroryData[thisLineInvetnroryDataKey]);
                                dataList.setSublistValue({id:'custpage_line_transfer_qty', value:Number(transferQty).toFixed(0), line:lineId});
                            }
                        }
                    }
                    lineId++;
                }
            }
            for (const invId in inventoryArr) {
                batchNumField.addSelectOption({value:invId, text:inventoryArr[invId].inventorynumber});
            }

            return form;
        }

        /**
         * 查询该行明细批次数据
         * @param scdLineId         SCD行id
         * @return {{}}             {invId: qty}
         */
        const formatThisSCDLineInventoryDatails = (scdLineId) => {
            let invData = {};//该行绑定批次数据：[{invId:qty}]

            let myFilters = [];
            myFilters.push(['internalid', 'anyof', scdLineId]);
            let myColumns = [];
            myColumns.push({name:'custrecord_id_seriallot', join: 'CUSTRECORD_ID_SPLINE'});   // 批次号
            myColumns.push({name:'custrecord_id_quantity', join: 'CUSTRECORD_ID_SPLINE'});   // 数量
            let mySearch = search.create({
                type:'customrecord_ecm_scd_line',
                filters:myFilters,
                columns:myColumns
            });
            let myResult = mySearch.run().getRange({start:0, end:1000});
            if (myResult && myResult.length > 0){
                for (let i = 0; i < myResult.length; i++){
                    let inventorynumber = myResult[i].getValue(myColumns[0]);
                    if (inventorynumber){
                        invData[inventorynumber] = myResult[i].getValue(myColumns[1]);
                    }
                }
            }
            log.debug('该行批次数据=====>' + scdLineId, invData)
            return invData;
        }

        /**
         * 查询该批次除了本单外未出运的数量
         * @param inventoryArr
         * @param scdLineId
         * @returns {[]}
         */
        const getNoShippedInv = (inventoryArr, scdLineId, location) => {
            let myFilters = [];
            let invIdArr = Object.keys(inventoryArr);
            myFilters.push(['custrecord_id_spline.custrecord_id_seriallot', 'anyof', invIdArr]);
            myFilters.push('and');
            myFilters.push(['custrecord_scdline_sp.custrecord_sp_status', 'anyof', enume.getAll().ECM_SHIPPING_STATUS_NOT_SHIPPED, enume.getAll().ECM_SHIPPING_BOOKING_SUCCEED, enume.getAll().ECM_SHIPPING_ESTIMATED_COST_SUBMITTED]);    // sp状态未出运、订舱成功、预估费用已提交
            myFilters.push('and');
            myFilters.push(['custrecord_scdline_sp.custrecord_sp_location', 'anyof', location]);//同一批次同一仓库
            myFilters.push('and');
            myFilters.push(['internalid', 'noneof', scdLineId]);
            let myColumns = [];
            myColumns.push({name:'custrecord_id_seriallot', join: 'CUSTRECORD_ID_SPLINE', summary:'GROUP', sort:'ASC'});   // 批次号
            myColumns.push({name:'custrecord_id_quantity', join: 'CUSTRECORD_ID_SPLINE', summary:'SUM'});   // 数量
            let mySearch = search.create({
                type:'customrecord_ecm_scd_line',
                filters:myFilters,
                columns:myColumns
            });
            let myResult = mySearch.run().getRange({start:0, end:1000});
            let inventArr = [];
            if (myResult && myResult.length > 0){
                for (let i = 0; i < myResult.length; i++){
                    let inventJson = {};
                    inventJson.inventorynumber = myResult[i].getValue(myColumns[0]);
                    inventJson.quantityavailable = myResult[i].getValue(myColumns[1]);
                    inventArr.push(inventJson);
                }
            }
            log.debug('占用库存数据',inventArr)
            return inventArr;
        }


        /**
         * 获取当前货品该地点的库存可用数量
         * @param itemId
         * @param location
         * @param thisLineInventoryData
         * @returns {{}}
         */
        const getItemInventory = (itemId, location, thisLineInventoryData) => {
            let inventArr = {};
            let thisInvIdArray = Object.keys(thisLineInventoryData);
            if(!thisInvIdArray || 0 == thisInvIdArray.length) {
                return inventArr;
            }
            var myFilters = [];
            myFilters.push(['item.internalid', 'anyof', itemId]);
            myFilters.push('and');
            myFilters.push(['location', 'anyof', location]);
            myFilters.push('and');
            myFilters.push(['quantityonhand', 'greaterthan', '0']);
            myFilters.push('and');
            myFilters.push(['internalid', 'anyof', thisInvIdArray]);

            let myColumns = [];
            myColumns.push('inventorynumber');   // 批次号
            myColumns.push('quantityonhand');   // 现有
            myColumns.push('internalid');
            let mySearch = search.create({
                type:'inventorynumber',
                filters:myFilters,
                columns:myColumns
            });
            let myResult = mySearch.run().getRange({start:0, end:1000});
            if (myResult && myResult.length > 0){
                for (var i = 0; i < myResult.length; i++){
                    let invId = myResult[i].getValue(myColumns[2]);
                    let inventorynumber = myResult[i].getValue(myColumns[0]) || '';
                    let quantityavailable = Number(myResult[i].getValue(myColumns[1]) || 0);
                    // 取相同批次id下上次的数据，如果没有就给默认值，没有就是''
                    inventArr[invId] = inventArr[invId] || {inventorynumber:'',quantityavailable:0};
                    // 上次累加后的数量与本次数量相加
                    inventArr[invId].quantityavailable = Number(inventArr[invId].quantityavailable ).add(quantityavailable);
                    inventArr[invId].inventorynumber = inventArr[invId].inventorynumber || inventorynumber;
                }
            }
            log.debug('批次实时库存数量', inventArr)
            return inventArr;
        }


        return {onRequest}

    })