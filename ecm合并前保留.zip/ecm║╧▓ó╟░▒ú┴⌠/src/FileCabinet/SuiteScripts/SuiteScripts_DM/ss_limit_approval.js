/**
 * @NApiVersion 2.1
 * @NScriptType ScheduledScript
 * version      date            author      remark
 * 1.0          2023/02/17      Doris       【ID1018424】02 限额申请批复
 */
define(['N/record', 'N/search', 'N/format', '/SuiteScripts/tools/common_api.js', '/SuiteScripts/tools/hc_edi_interface_tool.js', '/SuiteScripts/tools/moment.js', '/SuiteScripts/tools/ramda.min.js', '/SuiteScripts/SuiteScripts_DM/environment_check.js'],
    /**
     * @param{record} record
     * @param{search} search
     * @param{format} format
     */
    (record, search, format, commonApi, interfaceTool, moment, ramda, enume) => {
        const QUOTA_BALANCE_TYPE = 'customrecord_ecm_creditline_approveinfo';// 限额批复/变更/退回通知记录id
        const LC_LIMIT_APPLY_TYPE = 'customrecord_ecm_sinosure_lc_quotaapply';
        const NO_LC_LIMIT_APPLY_TYPE = 'customrecord_ecm_sinosure_nlc_quotaapply';
        const LOG_TYPE = 'customrecord_hc_edi_interface_log';// 日志类型
        const IMETHOD = 'getEdiQuotaApproveInfo';// 接口method
        const FIELD_MAPPING_ARR = [
            {
                'fieldId': 'custrecord_eca_noticeserialno',
                'interfaceId' : 'noticeSerialNo',
                'fieldType' : 'value',
                'fieldName' : '信保通知序号（唯一）',
                'flag' : '1',
            },
            {
                'fieldId': 'custrecord_eca_corpserialno',
                'interfaceId' : 'corpSerialNo',
                'fieldType' : 'value',
                'fieldName' : '企业内部限额唯一标识[即流水号]',
                'flag' : '1',
            },
            {
                'fieldId': 'custrecord_eca_iflc',
                'interfaceId' : 'ifLc',
                'fieldType' : 'value',
                'fieldName' : '是否LC申请',
                'flag' : '1',
            },
            {
                'fieldId': 'custrecord_eca_approveflag',
                'interfaceId' : 'approveFlag',
                'fieldType' : 'value',
                'fieldName' : '审批标志',
                'flag' : '1',
            },
            {
                'fieldId': 'custrecord_eca_unacceptcode',
                'interfaceId' : 'unAcceptCode',
                'fieldType' : 'value',
                'fieldName' : '错误信息代码',
                'flag' : '1',
            },
            {
                'fieldId': 'custrecord_eca_unacceptreason',
                'interfaceId' : 'unAcceptReason',
                'fieldType' : 'value',
                'fieldName' : '申请退回/不通过原因',
                'flag' : '1',
            },
            {
                'fieldId': 'custrecord_eca_notifytime',
                'interfaceId' : 'notifyTime',
                'fieldType' : 'text',
                'fieldName' : '最新通知时间',
                'flag' : '1',
            },
            {
                'fieldId': 'custrecord_eca_buyerquotainfo',
                'interfaceId' : 'BuyerQuotaInfo',
                'fieldType' : 'value',  // TODO
                'fieldName' : '买方限额详细信息',
                'flag' : '0',
            },
            {
                'fieldId': 'custrecord_eca_clientno',
                'interfaceId' : 'clientNo',
                'interfaceParentId' : 'BuyerQuotaInfo',
                'fieldType' : 'value',
                'fieldName' : '客户标识信保通编号',
                'flag' : '0',
            },
            {
                'fieldId': 'custrecord_eca_policyno',
                'interfaceId' : 'policyNo',
                'interfaceParentId' : 'BuyerQuotaInfo',
                'fieldType' : 'value',
                'fieldName' : '保险单号',
                'flag' : '0',
            },
            {
                'fieldId': 'custrecord_eca_quotano',    // 主键
                'interfaceId' : 'quotaNo',
                'interfaceParentId' : 'BuyerQuotaInfo',
                'fieldType' : 'value',
                'fieldName' : '中信保限额编号',
                'flag' : '0',
            },
            {
                'fieldId': 'custrecord_eca_quotaapplyno',
                'interfaceId' : 'quotaApplyNo',
                'interfaceParentId' : 'BuyerQuotaInfo',
                'fieldType' : 'value',
                'fieldName' : '中信保限额申请编号',
                'flag' : '0',
            },
            {
                'fieldId': 'custrecord_eca_corpserialno',
                'interfaceId' : 'corpSerialNo',
                'fieldType' : 'value',  // TODO
                'fieldName' : '企业内部限额申请唯一标识，分为LC和非LC',
                'flag' : '0',
            },
            {
                'fieldId': 'custrecord_eca_buyerno',
                'interfaceId' : 'buyerNo',
                'interfaceParentId' : 'BuyerQuotaInfo',
                'fieldType' : 'value',
                'fieldName' : '中国信保买方代码',
                'flag' : '0',
            },
            {
                'fieldId': 'custrecord_eca_corpbuyerno',
                'interfaceId' : 'corpBuyerNo',
                'interfaceParentId' : 'BuyerQuotaInfo',
                'fieldType' : 'value',   // 类型由列表变为文本
                'fieldName' : '企业买方代码/企业内部买方唯一标识',
                'flag' : '0',
            },
            {
                'fieldId': 'custrecord_eca_paymode',
                'interfaceId' : 'payMode',
                'interfaceParentId' : 'BuyerQuotaInfo',
                'fieldType' : 'value',
                'fieldName' : '支付方式',
                'flag' : '0',
            },
            {
                'fieldId': 'custrecord_eca_payterm',
                'interfaceId' : 'payTerm',
                'interfaceParentId' : 'BuyerQuotaInfo',
                'fieldType' : 'value',
                'fieldName' : '信用期限',
                'flag' : '0',
            },
            {
                'fieldId': 'custrecord_eca_quotasum',
                'interfaceId' : 'quotaSum',
                'interfaceParentId' : 'BuyerQuotaInfo',
                'fieldType' : 'value',
                'fieldName' : '信用限额',
                'flag' : '0',
            },
            {
                'fieldId': 'custrecord_eca_lcno',
                'interfaceId' : 'lcNo',
                'interfaceParentId' : 'BuyerQuotaInfo',
                'fieldType' : 'value',
                'fieldName' : '信用证号',
                'flag' : '0',
            },
            {
                'fieldId': 'custrecord_eca_bankswift',
                'interfaceId' : 'bankSwift',
                'interfaceParentId' : 'BuyerQuotaInfo',
                'fieldType' : 'value',
                'fieldName' : '银行SWIFT',
                'flag' : '0',
            },
            {
                'fieldId': 'custrecord_eca_bankengname',
                'interfaceId' : 'bankEngName',
                'interfaceParentId' : 'BuyerQuotaInfo',
                'fieldType' : 'value',
                'fieldName' : '银行英文名称',
                'flag' : '0',
            },
            {
                'fieldId': 'custrecord_eca_corpbankno',
                'interfaceId' : 'corpBankNo',
                'interfaceParentId' : 'BuyerQuotaInfo',
                'fieldType' : 'value',
                'fieldName' : '企业银行代码/企业内部银行唯一标识',
                'flag' : '0',
            },
            {
                'fieldId': 'custrecord_eca_quotastate',
                'interfaceId' : 'quotaState',
                'interfaceParentId' : 'BuyerQuotaInfo',
                'fieldType' : 'value',
                'fieldName' : '限额状态0无效1有效',
                'flag' : '0',
            },
            {
                'fieldId': 'custrecord_eca_effectdate',
                'interfaceId' : 'effectDate',
                'interfaceParentId' : 'BuyerQuotaInfo',
                'fieldType' : 'text',
                'fieldName' : '生效日期',
                'flag' : '0',
            },
            {
                'fieldId': 'custrecord_eca_effecttype',
                'interfaceId' : 'effecttype',
                'interfaceParentId' : 'BuyerQuotaInfo',
                'fieldType' : 'value',
                'fieldName' : '生效类型',
                'flag' : '0',
            },
            {
                'fieldId': 'custrecord_eca_lapsedate',
                'interfaceId' : 'lapseDate',
                'interfaceParentId' : 'BuyerQuotaInfo',
                'fieldType' : 'text',
                'fieldName' : '失效日期',
                'flag' : '0',
            },
            {
                'fieldId': 'custrecord_eca_lapsetype',
                'interfaceId' : 'lapsetype',
                'interfaceParentId' : 'BuyerQuotaInfo',
                'fieldType' : 'value',
                'fieldName' : '失效类型',
                'flag' : '0',
            },
            {
                'fieldId': 'custrecord_eca_auditdate',
                'interfaceId' : 'auditDate',
                'interfaceParentId' : 'BuyerQuotaInfo',
                'fieldType' : 'text',
                'fieldName' : '批复日期',
                'flag' : '0',
            },
            {
                'fieldId': 'custrecord_eca_adcondition',
                'interfaceId' : 'adCondition',
                'interfaceParentId' : 'BuyerQuotaInfo',
                'fieldType' : 'value',
                'fieldName' : '特别生效条件',
                'flag' : '0',
            },
            {
                'fieldId': 'custrecord_eca_billnote',
                'interfaceId' : 'billNote',
                'interfaceParentId' : 'BuyerQuotaInfo',
                'fieldType' : 'value',
                'fieldName' : '批复说明',
                'flag' : '0',
            },
            {
                'fieldId': 'custrecord_eca_adjustreason',
                'interfaceId' : 'adjustReason',
                'interfaceParentId' : 'BuyerQuotaInfo',
                'fieldType' : 'value',
                'fieldName' : '调整原因',
                'flag' : '0',
            },
            {
                'fieldId': 'custrecord_eca_refuserate',
                'interfaceId' : 'refuseRate',
                'interfaceParentId' : 'BuyerQuotaInfo',
                'fieldType' : 'value',
                'fieldName' : '拒收风险赔偿比例',
                'flag' : '0',
            },
            {
                'fieldId': 'custrecord_eca_otherrate',
                'interfaceId' : 'otherRate',
                'interfaceParentId' : 'BuyerQuotaInfo',
                'fieldType' : 'value',
                'fieldName' : '其它商业风险赔偿比例',
                'flag' : '0',
            },
            {
                'fieldId': 'custrecord_eca_ifrepeat',
                'interfaceId' : 'ifRepeat',
                'interfaceParentId' : 'BuyerQuotaInfo',
                'fieldType' : 'value',
                'fieldName' : '是否循环使用',
                'flag' : '0',
            },
            {
                'fieldId': 'custrecord_eca_modifytime',
                'interfaceId' : 'modifyTime',
                'interfaceParentId' : 'BuyerQuotaInfo',
                'fieldType' : 'text',
                'fieldName' : '最后修改时间',
                'flag' : '0',
            },
            {
                'fieldId': 'custrecord_eca_isprecreditquota',
                'interfaceId' : 'isPrecrEditQuota',
                'interfaceParentId' : 'BuyerQuotaInfo',
                'fieldType' : 'value',
                'fieldName' : '是否出运前',
                'flag' : '0',
            },
            {
                'fieldId': 'custrecord_eca_precreditterm',
                'interfaceId' : 'precrEditTerm',
                'interfaceParentId' : 'BuyerQuotaInfo',
                'fieldType' : 'value',
                'fieldName' : '出运前信用期限',
                'flag' : '0',
            },
            {
                'fieldId': 'custrecord_eca_aftercreditterm',
                'interfaceId' : 'aftercrEditTerm',
                'interfaceParentId' : 'BuyerQuotaInfo',
                'fieldType' : 'value',
                'fieldName' : '出运后信用期限',
                'flag' : '0',
            },
            {
                'fieldId': 'custrecord_eca_preotherinsurerate',
                'interfaceId' : 'preOtherInsureRate',
                'interfaceParentId' : 'BuyerQuotaInfo',
                'fieldType' : 'value',
                'fieldName' : '出运前商业风险其他赔偿百分比',
                'flag' : '0',
            },
            {
                'fieldId': 'custrecord_eca_prebuyernoreasonrate',
                'interfaceId' : 'preBuyernoReasonRate',
                'interfaceParentId' : 'BuyerQuotaInfo',
                'fieldType' : 'value',
                'fieldName' : '出运前商业风险买方拒收赔偿百分比',
                'flag' : '0',
            },
            {
                'fieldId': 'custrecord_eca_idlespan',
                'interfaceId' : 'idleSpan',
                'interfaceParentId' : 'BuyerQuotaInfo',
                'fieldType' : 'value',
                'fieldName' : '闲置期',
                'flag' : '0',
            },
        ];
        const FIELD_MAPPING = {
            'errorcode' : 'custrecord_eca_errorcode', // 错误代码
            'errormsg' : 'custrecord_eca_errormsg', // 错误描述
        };

        /**
         * Defines the Scheduled script trigger point.
         * @param {Object} scriptContext
         * @param {string} scriptContext.type - Script execution context. Use values from the scriptContext.InvocationType enum.
         * @since 2015.2
         */
        const execute = (scriptContext) => {
            let dateJson = getDateTime();
            let reqData = {
                "datas": {
                    "startDate": dateJson.startDate,
                    "endDate": dateJson.endDate
                },
                "imethod": IMETHOD,
            };
            let rtnData = '';
            rtnData = interfaceTool.requestEdiServer(reqData, enume.getAll().ECM_INTERFACE_TYPE_LC_LIMIT_APPLICATION_APPROVED);// 接口类型：限额批复/变更/退回通知  // TODO
            log.debug('接口返回数据', rtnData)
            if(true == rtnData.valid) {
                let infoData = rtnData.data.datas;
                if(infoData && infoData.length > 0) {
                    infoData = JSON.parse(infoData);
                    log.debug('infoData',infoData)
                    //获取所有quotaNo，匹配已有数据
                    let noticeSerialNos = ramda.groupBy(ramda.path(['noticeSerialNo']))(infoData);

                    let existNoticeSerialNoData = formatExistNoticeSerialNo(Object.keys(noticeSerialNos));

                    let methodData = formatPayMethod();

                    let createdDataIdArray = [],
                        logUpdVal = {
                            custrecord_hc_inf_process_msg: '',
                            custrecord_hc_inf_errorflag: false
                        };
                    try{
                        let lcArr = [];
                        let nlcArr = [];
                        for(let i = 0; i < infoData.length; i++) {
                            let ifLc = infoData[i].ifLc || '';
                            if (ifLc && 1 == ifLc) {
                                let lcCorpSerialNo = infoData[i].corpSerialNo;
                                lcArr.push(lcCorpSerialNo);
                            }else if (ifLc && 0 == ifLc){
                                let nlcCorpSerialNo = infoData[i].corpSerialNo;
                                nlcArr.push(nlcCorpSerialNo);
                            }
                        }
                        let lcId = getLcData(LC_LIMIT_APPLY_TYPE, lcArr);
                        let nlcId = getLcData(NO_LC_LIMIT_APPLY_TYPE, nlcArr);
                        for(let i = 0; i < infoData.length; i++) {
                            let ifLc = infoData[i].ifLc || '';
                            if (ifLc && 1 == ifLc){
                                updateLcData(infoData[i], lcId);
                            }else if (ifLc && 0 == ifLc){
                                updateNLcData(infoData[i], nlcId);
                            }


                            if (' ' != (infoData[i].approveFlag).toString()){
                                let obj;
                                if('undefined' == typeof existNoticeSerialNoData[infoData[i].noticeSerialNo]) {
                                    obj = record.create({type: QUOTA_BALANCE_TYPE});
                                } else {
                                    obj = record.load({type: QUOTA_BALANCE_TYPE, id: existNoticeSerialNoData[infoData[i].noticeSerialNo]});
                                }
                                if (infoData[i].buyerQuotaInfo){
                                    if(infoData[i].buyerQuotaInfo.payMode) {
                                        obj.setValue({fieldId: 'custrecord_eca_paymode', value: methodData[infoData[i].buyerQuotaInfo.payMode] || ''});
                                    }
                                }

                                for (let j = 0; j < FIELD_MAPPING_ARR.length; j++) {
                                    let fieldInfo = FIELD_MAPPING_ARR[j];
                                    let fieldId = fieldInfo.fieldId;
                                    let interfaceParentId = fieldInfo.interfaceParentId;
                                    let interfaceId = fieldInfo.interfaceId;
                                    let fieldType = fieldInfo.fieldType
                                    let fieldName = fieldInfo.fieldName;
                                    if ('value' == fieldType && 'payMode' != interfaceId/* && 'buyerNo' != interfaceId*/){
                                        let thisValue = '';
                                        if (interfaceParentId){
                                            let buyerQuotaInfo = infoData[i].buyerQuotaInfo || '';
                                            if (buyerQuotaInfo ){
                                                thisValue = buyerQuotaInfo[interfaceId] || '';
                                            }
                                        }else {
                                            thisValue = infoData[i][interfaceId] || '';
                                        }
                                        obj.setValue({
                                            fieldId: fieldId,
                                            value: thisValue
                                        });
                                    }

                                    if ('text' == fieldType && 'modifyTime' != interfaceId){
                                        let thisValue = '';
                                        if (interfaceParentId){
                                            let buyerQuotaInfo = infoData[i].buyerQuotaInfo || '';
                                            if (buyerQuotaInfo){
                                                thisValue = buyerQuotaInfo[interfaceId] || '';
                                            }
                                        }else {
                                            thisValue = infoData[i][interfaceId] || '';
                                        }
                                        if (thisValue){
                                            obj.setText({
                                                fieldId: fieldId,
                                                text: getFormatDate(thisValue)
                                            });
                                        }else {
                                            obj.setText({
                                                fieldId: fieldId,
                                                text: ''
                                            });
                                        }
                                    }
                                    if ('modifyTime' == interfaceId && interfaceParentId){
                                        let thisValue = '';
                                        let buyerQuotaInfo = infoData[i].buyerQuotaInfo || '';
                                        if (buyerQuotaInfo){
                                            thisValue = buyerQuotaInfo.modifyTime|| '';
                                            if (thisValue){
                                                obj.setText({
                                                    fieldId: fieldId,
                                                    text: getFormatDateTime(thisValue)
                                                });
                                            }else {
                                                obj.setText({
                                                    fieldId: fieldId,
                                                    text: ''
                                                });
                                            }
                                        }
                                    }
                                }
                                let qid = obj.save();

                                createdDataIdArray.push(qid);
                            }
                        }
                        logUpdVal.custrecord_hc_inf_process_msg = createdDataIdArray.join('&');
                    }catch (e){
                        log.error('限额批复error===>' + rtnData.logId, e);
                        if(createdDataIdArray && createdDataIdArray.length > 0) {
                            createdDataIdArray.forEach(function (cid) {
                                record.delete({type: QUOTA_BALANCE_TYPE, id: cid});
                            });
                        }
                        logUpdVal.custrecord_hc_inf_process_msg = e.message;
                        logUpdVal.custrecord_hc_inf_errorflag = true;
                    }
                    record.submitFields({
                        type: LOG_TYPE,
                        id: rtnData.logId,
                        values: logUpdVal
                    });
                }
            }
        }

        /**
         * 更新LC限额申请记录
         * @param infoData
         * @param lcJson
         */
        const updateLcData = (infoData, lcJson) => {
            let corpSerialNo = infoData.corpSerialNo;
            let lcRec = record.load({
                type:LC_LIMIT_APPLY_TYPE,
                id:lcJson[corpSerialNo]
            });

            let approveFlag = infoData.approveFlag;
            if (0 == approveFlag){
                lcRec.setValue({fieldId:'custrecord_eslcq_status', value:enume.getAll().ECM_SINOSURE_FAILED});
            }else if (1 == approveFlag){
                lcRec.setValue({fieldId:'custrecord_eslcq_status', value:enume.getAll().ECM_SINOSURE_FAILED});
            }
            let unAcceptCode = infoData.unAcceptCode;
            lcRec.setValue({fieldId:'custrecord_eslcq_errorcode', value:unAcceptCode});
            let unAcceptReason = infoData.unAcceptReason;
            lcRec.setValue({fieldId:'custrecord_eslcq_errormsg', value:unAcceptReason});
            lcRec.save({enableSourcing:true, ignoreMandatoryFields:true});
        }

        /**
         * 更新非LC限额申请记录
         * @param infoData
         * @param nlcJson
         */
        const updateNLcData = (infoData, nlcJson) => {
            let corpSerialNo = infoData.corpSerialNo;
            let nlcRec = record.load({
                type:NO_LC_LIMIT_APPLY_TYPE,
                id:nlcJson[corpSerialNo]
            });
            let approveFlag = infoData.approveFlag;
            if (0 == approveFlag){
                nlcRec.setValue({fieldId:'custrecord_esncq_status', value:enume.getAll().ECM_SINOSURE_FAILED});
            }else if (1 == approveFlag){
                nlcRec.setValue({fieldId:'custrecord_esncq_status', value:enume.getAll().ECM_SINOSURE_FAILED});
            }
            let unAcceptCode = infoData.unAcceptCode;
            nlcRec.setValue({fieldId:'custrecord_esncq_errorcode', value:unAcceptCode});
            let unAcceptReason = infoData.unAcceptReason;
            nlcRec.setValue({fieldId:'custrecord_esncq_errormsg', value:unAcceptReason});
            nlcRec.save({enableSourcing:true, ignoreMandatoryFields:true});
        }


        /**
         * 根据lc/nlc流水号查询内部id
         * @param searchType
         * @param corpSerialNoArr
         * @returns {{}}
         */
        const getLcData = (searchType, corpSerialNoArr) => {
            let myFilters = [];
            myFilters.push(['isinactive', 'is', 'false']);
            let insideFilters = [];
            if (corpSerialNoArr && corpSerialNoArr.length > 0){
                myFilters.push('and');
                for (let i = 0; i < corpSerialNoArr.length; i++){
                    if(0!=i){
                        insideFilters.push('or')
                    }
                    insideFilters.push(['idtext', 'is', corpSerialNoArr[i]]);
                }
                myFilters.push(insideFilters);
            }
            let myColumns = [];
            myColumns.push('internalid');
            myColumns.push('name');
            let mySearch = search.create({
                type:searchType,
                filters:myFilters,
                columns:myColumns
            });
            let myResult = commonApi.getAllData(mySearch);
            let lcJson = {};
            if (myResult && myResult.length > 0){
                for (let i = 0; i < myResult.length; i++){
                    let lcId = myResult[i].getValue(myColumns[0]);
                    let lcName = myResult[i].getValue(myColumns[1]);
                    lcJson[lcName] = lcId;
                }
            }
            return lcJson;
        }


        /**
         * 设置时间频率
         * @returns {{endDate: number, startDate: number}}
         */
        const getDateTime = () => {
            let newDate = new Date();
            let year = newDate.getFullYear();
            let yesYear = year;
            let month = newDate.getMonth() + Number(1);
            let yesMonth = month;
            let today = newDate.getDate();
            let yesterday = Number(today) - Number(2);
            let hour = newDate.getHours();
            hour = Number(hour) + Number(16);
            let minute = newDate.getMinutes()
            let second = newDate.getSeconds();

            if (24 <= hour){
                today = newDate.getDate() + Number(1);
                yesterday = Number(today) - Number(2);
                hour = Number(hour) - Number(24);
            }

            if (Number(1) == Number(today) && ((Number(2) == Number(month))) || (Number(4) == Number(month)) || (Number(6) == Number(month)) || (Number(8) == Number(month)) || (Number(9) == Number(month)) || (Number(11) == Number(month))){
                yesterday = Number(30);
                yesMonth = Number(month) - Number(1);
            }
            if (Number(1) == Number(today) && ((Number(5) == Number(month))) || (Number(7) == Number(month)) || (Number(10) == Number(month)) || (Number(12) == Number(month))){
                yesterday = Number(29);
                yesMonth = Number(month) - Number(1);
            }
            if (Number(1) == Number(today) && (Number(1) == Number(month))){
                yesterday = Number(30);
                yesMonth = Number(12);
                yesYear = Number(year) - Number(1);
            }
            if (Number(1) == Number(today) && (Number(3) == Number(month))){
                if ((Number(year) % Number(4) == Number(0) && Number(year) % Number(100) != Number(0)) || Number(year) % Number(400) == Number(0)){
                    yesterday = Number(28);
                    yesMonth = Number(month) - Number(1);
                }else {
                    yesterday = Number(27);
                    yesMonth = Number(month) - Number(1);
                }
            }

            minute = Number(minute) < 10 ? '0' + minute : minute;
            second = Number(second) < 10 ? '0' + second : second;
            let startDate = yesYear+'-'+yesMonth+'-'+yesterday+ ' ' + hour + ':' + minute + ':' + second;
            let endDate = year+'-'+month+'-'+today+ ' ' + hour + ':' + minute + ':' + second;

            log.debug('date', {startDate:startDate,endDate:endDate})
            return {startDate: startDate, endDate: endDate};
        }

        /**
         * 格式化日期
         * @param oldDate
         * @returns {string}
         */
        function getFormatDate(oldDate) {
            let newDate = format.format({
                value:new Date(oldDate),
                type:format.Type.DATE
            });
            return newDate
        }

        /**
         * 格式化日期
         * @param oldDate
         * @returns {string}
         */
        function getFormatDateTime(oldDate) {
            let newDate = format.format({
                value:new Date(oldDate),
                type:format.Type.DATETIME
            });
            return newDate
        }


        /**
         * 搜索已存在noticeSerialNo记录
         * @param noticeSerialNoArray              本次返回noticeSerialNo
         * @return {{}}                     {noticeSerialNo：id}
         */
        const formatExistNoticeSerialNo = noticeSerialNoArray => {
            let existData = {};//{noticeSerialNo：id}
            if(!noticeSerialNoArray || 0 == noticeSerialNoArray.length) {
                return existData;
            }
            let filters = [],
                columns = ['custrecord_eca_noticeserialno'];
            noticeSerialNoArray.forEach(function (nso) {
                filters.push(['custrecord_eca_noticeserialno', 'is', nso]);
                filters.push('or');
            });
            filters.pop();
            let results = commonApi.searchAllData(QUOTA_BALANCE_TYPE, filters, columns);
            if(results && results.length > 0) {
                results.forEach(function (res) {
                    existData[res.getValue(columns[0])] = res.id;
                });
            }
            log.debug('已存在noticeSerialNo数据', existData);
            return existData;
        }


        /**
         * 搜索【中信保-支付方式】
         * @return {{}}                     {code：id}
         */
        const formatPayMethod = () => {
            let existData = {};//{quotaNo：id}
            let filters = [],
                columns = ['custrecord_esp_code'];
            let results = commonApi.searchAllData('customrecord_ecm_sinosure_paymethod', filters, columns);
            if(results && results.length > 0) {
                results.forEach(function (res) {
                    existData[res.getValue(columns[0])] = res.id;
                });
            }
            log.debug('匹配支付方式', existData);
            return existData;
        }

        return {execute}

    });
