/**
 * @NApiVersion 2.1
 * @NScriptType MapReduceScript
 * version      date            author      remark
 * 1.0          2023/04/03      Doris       【ID1018580】Shipping Plan生成IF单变更开发
 * 2.0          2023/04/10      Doris       生成IF单日期取值变更：提货日期-->交割日期（1018580）
 */
define(['N/record', 'N/search', '/SuiteScripts/tools/common_api.js', '/SuiteScripts/SuiteScripts_DM/environment_check.js'],
    /**
     * @param{record} record
     * @param{search} search
     */
    (record, search, commonApi, enume) => {
        const SP_TYPE = 'customrecord_ecm_sp';
        const SP_SUBLIST_ID = 'recmachcustrecord_scdline_sp';
        /**
         * Defines the function that is executed at the beginning of the map/reduce process and generates the input data.
         * @param {Object} inputContext
         * @param {boolean} inputContext.isRestarted - Indicates whether the current invocation of this function is the first
         *     invocation (if true, the current invocation is not the first invocation and this function has been restarted)
         * @param {Object} inputContext.ObjectRef - Object that references the input data
         * @typedef {Object} ObjectRef
         * @property {string|number} ObjectRef.id - Internal ID of the record instance that contains the input data
         * @property {string} ObjectRef.type - Type of the record instance that contains the input data
         * @returns {Array|Object|Search|ObjectRef|File|Query} The input data to use in the map/reduce process
         * @since 2015.2
         */

        const getInputData = (inputContext) => {
            try {
                return  getSpInfo();
            } catch (e) {
                log.error('getInputData:error', e);
            }
            return [];
        }

        /**
         * 查询符合条件的SP
         */
        const getSpInfo = () => {
            let searchObj = search.load({id:'customsearch_ecmscri_spcreateif_dev'});
            let filterExp = searchObj.filterExpression;
            let newFilterExp = [];
            newFilterExp.push(filterExp);
            if (filterExp && filterExp.length > 0){
                newFilterExp.push('and');
            }
            newFilterExp.push(['custrecord_scdline_sp.custrecord_scdline_sono1', 'noneof', '@NONE@']);
            searchObj.filterExpression = newFilterExp;
            return commonApi.getAllData(searchObj);

        }

        /**
         * Defines the function that is executed when the map entry point is triggered. This entry point is triggered automatically
         * when the associated getInputData stage is complete. This function is applied to each key-value pair in the provided
         * context.
         * @param {Object} mapContext - Data collection containing the key-value pairs to process in the map stage. This parameter
         *     is provided automatically based on the results of the getInputData stage.
         * @param {Iterator} mapContext.errors - Serialized errors that were thrown during previous attempts to execute the map
         *     function on the current key-value pair
         * @param {number} mapContext.executionNo - Number of times the map function has been executed on the current key-value
         *     pair
         * @param {boolean} mapContext.isRestarted - Indicates whether the current invocation of this function is the first
         *     invocation (if true, the current invocation is not the first invocation and this function has been restarted)
         * @param {string} mapContext.key - Key to be processed during the map stage
         * @param {string} mapContext.value - Value to be processed during the map stage
         * @since 2015.2
         */

        const map = (mapContext) => {



        }



        /**
         * Defines the function that is executed when the reduce entry point is triggered. This entry point is triggered
         * automatically when the associated map stage is complete. This function is applied to each group in the provided context.
         * @param {Object} reduceContext - Data collection containing the groups to process in the reduce stage. This parameter is
         *     provided automatically based on the results of the map stage.
         * @param {Iterator} reduceContext.errors - Serialized errors that were thrown during previous attempts to execute the
         *     reduce function on the current group
         * @param {number} reduceContext.executionNo - Number of times the reduce function has been executed on the current group
         * @param {boolean} reduceContext.isRestarted - Indicates whether the current invocation of this function is the first
         *     invocation (if true, the current invocation is not the first invocation and this function has been restarted)
         * @param {string} reduceContext.key - Key to be processed during the reduce stage
         * @param {List<String>} reduceContext.values - All values associated with a unique key that was passed to the reduce stage
         *     for processing
         * @since 2015.2
         */
        const reduce = (reduceContext) => {
            try {
                const values = JSON.parse(reduceContext.values);
                createIf(values.id);
            }catch (e){
                log.error('reduce-error',e);
            }

        }

        /**
         * SP创建IF单
         * @param spId
         */
        const createIf = (spId) => {
            let spRec = record.load({type:SP_TYPE, id:spId});
            let subsidiaryId = spRec.getValue('custrecord_sp_scsubsidiary');
            let location = '';
            if (subsidiaryId){
                let subRec = record.load({type:'subsidiary', id:subsidiaryId});
                location = subRec.getValue('custrecord_ecm_location');
            }
            let lineCount = spRec.getLineCount({sublistId:SP_SUBLIST_ID});
            let poIdArr = [];
            let poJson = {};

            let itIdArr = [];
            let itJson = {};
            if (lineCount > 0){
                for (let i = 0; i < lineCount; i++){
                    let soId = spRec.getSublistValue({sublistId:SP_SUBLIST_ID, fieldId:'custrecord_scdline_sono1', line:i});
                    if (soId){
                        let poId = spRec.getSublistValue({sublistId:SP_SUBLIST_ID, fieldId:'custrecord_scdline_purchaseorder', line:i});
                        let scdlineId = spRec.getSublistValue({sublistId:SP_SUBLIST_ID, fieldId:'id', line:i});
                        let itId = spRec.getSublistValue({sublistId:SP_SUBLIST_ID, fieldId:'custrecord_scdline_it', line:i});

                        if (poId){
                            poIdArr.push(poId);
                            poJson[poId] = poJson[poId] || [];
                            poJson[poId].push(scdlineId);
                        }
                        if ('' == poId && itId){
                            itIdArr.push(itId);
                            itJson[itId] = itJson[itId] || [];
                            itJson[itId].push(scdlineId)
                        }

                    }
                }
            }
            log.debug('poJson', {poJson:poJson, poIdArr:poIdArr})
            log.debug('itJson', {itJson:itJson})

            let irInventoryInfo = {};
            if (poJson && Object.keys(poJson).length > 0){
                irInventoryInfo = getInvInfo(poJson, 'itemreceipt', 'ItemRcpt', '')
            }

            let itLocation = [];
            if (itIdArr && itIdArr.length > 0){
                itLocation = getToLocation(itIdArr,'inventorytransfer', 'InvTrnfr');
            }
            let itInventoryInfo = {};
            if (itJson && Object.keys(itJson).length > 0){
                itInventoryInfo = getInvInfo(itJson, 'inventorytransfer', 'InvTrnfr', itLocation)
            }

            let inventoryInfo = Object.assign(irInventoryInfo, itInventoryInfo);
            log.debug('inventoryInfo',inventoryInfo)

            let spData = getSpData(spId);
            if (spData && Object.keys(spData).length > 0 && inventoryInfo && Object.keys(inventoryInfo).length > 0) {
                for (const spDataKey in spData) {
                    try{
                        let ifId = '';
                        let ifRec = record.transform({fromType: 'salesorder', fromId: spDataKey, toType: 'itemfulfillment', isDynamic: true});

                        let spDataValue = spData[spDataKey];
                        ifRec.setText({fieldId:'trandate', text:spDataValue.shipdate});
                        if (spDataValue && Object.keys(spDataValue).length > 0) {
                            let lineCount = ifRec.getLineCount({sublistId: 'item'});
                            if (lineCount > 0) {
                                for (let i = 0; i < lineCount; i++) {
                                    ifRec.selectLine({sublistId: 'item', line: i});
                                    let itemInfo = ifRec.getCurrentSublistValue({
                                        sublistId: 'item',
                                        fieldId: 'item'
                                    });
                                    let itemInfoJson = spDataValue.itemInfo;
                                    for (const itemInfoJsonKey in itemInfoJson) {
                                        let itemInfoValue = itemInfoJson[itemInfoJsonKey];
                                        if (itemInfo == itemInfoJsonKey) {
                                            ifRec.setCurrentSublistValue({
                                                sublistId: 'item',
                                                fieldId: 'item',
                                                value: itemInfoJsonKey
                                            });
                                            ifRec.setCurrentSublistValue({
                                                sublistId: 'item',
                                                fieldId: 'location',
                                                value: location
                                            });
                                            ifRec.setCurrentSublistValue({
                                                sublistId: 'item',
                                                fieldId: 'quantity',
                                                value: itemInfoValue.spqty
                                            });
                                            let inventorydetail = ifRec.getCurrentSublistSubrecord({
                                                sublistId: 'item',
                                                fieldId: 'inventorydetail'
                                            });

                                            let poNo = itemInfoValue.poNo;
                                            let scdLineId = itemInfoValue.scdLineId;

                                            setBatchInfo(inventoryInfo, inventorydetail, scdLineId, itemInfo);

                                            ifRec.commitLine({sublistId: 'item'});
                                        }
                                    }
                                }
                            }
                        }
                        ifId = ifRec.save({enableSourcing:true, ignoreMandatoryFields:true});
                        if (ifId){
                            let spRec = record.load({type:SP_TYPE, id:spId});
                            spRec.setValue({fieldId:'custrecord_sp_createsoif_erromsg', value:''});
                            let lineCount = spRec.getLineCount({sublistId:SP_SUBLIST_ID});
                            if (lineCount > 0){
                                for (let i = 0; i < lineCount; i++){
                                    let soNo = spRec.getSublistValue({sublistId:SP_SUBLIST_ID, fieldId:'custrecord_scdline_sono1', line:i});
                                    let scdLineId = spRec.getSublistValue({sublistId:SP_SUBLIST_ID, fieldId:'id', line:i});
                                    if (soNo == spDataKey){
                                        spRec.setSublistValue({sublistId:SP_SUBLIST_ID, fieldId:'custrecord_scdline_soif1', value:ifId, line:i});

                                    }
                                }
                            }
                            spRec.save({enableSourcing:true, ignoreMandatoryFields:true});
                        }
                    }catch (iferror){
                        let errorMsg = '创建IF单失败，soid:'+ spDataKey + '失败原因：' + iferror.message;
                        let spRec = record.load({type:SP_TYPE, id:spId});
                        spRec.setValue({fieldId:'custrecord_sp_createsoif_erromsg', value:errorMsg});
                        spRec.save({enableSourcing:true, ignoreMandatoryFields:true});
                        log.error('生成IF单errror--->'+spDataKey,iferror);
                    }
                }
            }
        }

        /**
         * 设置库存详细信息
         * @param inventoryInfo
         * @param inventorydetail
         * @param scdLineId
         * @param itemInfo
         */
        const setBatchInfo = (inventoryInfo, inventorydetail,scdLineId, itemInfo) => {
            if (scdLineId && scdLineId.length > 0){
                for (let i = 0; i < scdLineId.length; i++){
                    if (inventoryInfo && Object.keys(inventoryInfo).length > 0) {
                        for (const scdLineIdKey in inventoryInfo) {
                            if (scdLineId[i] == scdLineIdKey){
                                let batchData = inventoryInfo[scdLineIdKey];
                                if (batchData && batchData.length > 0){
                                    let inventorySubId = 'inventoryassignment';
                                    for (let i = 0; i < batchData.length; i++){
                                        if (itemInfo == batchData[i].itemId){
                                            inventorydetail.selectNewLine({sublistId: inventorySubId});
                                            inventorydetail.setCurrentSublistValue({sublistId: inventorySubId, fieldId: 'issueinventorynumber', value: batchData[i].invId});//序号批次号
                                            inventorydetail.setCurrentSublistValue({sublistId: inventorySubId, fieldId: 'inventorystatus', value: batchData[i].status, forceSyncSourcing:true});//
                                            inventorydetail.setCurrentSublistValue({sublistId: inventorySubId, fieldId: 'quantity', value: batchData[i].quantity, forceSyncSourcing:true});//数量

                                            inventorydetail.commitLine({sublistId: inventorySubId});
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        /**
         * 搜索库存详细信息
         * @param poJson
         * @param searchType
         * @param filterType
         * @param itLocation
         * @returns {{}}
         */
        const getInvInfo = (poJson, searchType, filterType, itLocation) => {
            let scdLineArr = [];

            for (const poJsonKey in poJson) {
                let poJsonValue = poJson[poJsonKey];
                scdLineArr = scdLineArr.concat(poJsonValue);
            }
            let searchObj = search.load({id:'customsearch_ecm_sp_to_if_inventoryinfo'});
            let myColumns = searchObj.columns;
            let filterExp = searchObj.filterExpression;
            let newFilterExp = [];
            newFilterExp.push(filterExp);
            if ('itemreceipt' == searchType){
                let poIdArr = Object.keys(poJson);
                if (poIdArr && poIdArr.length > 0){
                    newFilterExp.push('and');
                    newFilterExp.push(['transaction.createdfrom', 'anyof', poIdArr]);
                }
            }
            if ('inventorytransfer' == searchType){
                let itIdArr = Object.keys(poJson);
                newFilterExp.push('and');
                newFilterExp.push(['transaction.internalid', 'anyof', itIdArr]);
            }
            if (itLocation && itLocation.length > 0){
                newFilterExp.push('and');
                newFilterExp.push(['transaction.location', 'anyof', itLocation]);
            }
            if (scdLineArr && scdLineArr.length > 0){
                newFilterExp.push('and');
                newFilterExp.push(['transaction.custcol_ecm_spline', 'anyof', scdLineArr]);
            }
            searchObj.filterExpression = newFilterExp;
            let myResult = searchObj.run().getRange({start: 0, end: 1000});
            let invJson = {};
            if (myResult && myResult.length > 0){
                for (let i = 0; i < myResult.length; i++){
                    let batchJson = {};
                    let invId = myResult[i].getValue(myColumns[2]);
                    let itemId = myResult[i].getValue(myColumns[0]);
                    let quantity = myResult[i].getValue(myColumns[4]);
                    let status = myResult[i].getValue(myColumns[3]);
                    let scdline = myResult[i].getValue(myColumns[8]);
                    let expirationdate = myResult[i].getValue(myColumns[12]);
                    let location = myResult[i].getValue(myColumns[1]);

                    invJson[scdline] = invJson[scdline] || [];
                    batchJson.invId = invId;
                    batchJson.itemId = itemId;
                    batchJson.quantity = quantity;
                    batchJson.status = status;
                    batchJson.expirationdate = expirationdate;
                    batchJson.location = location;
                    invJson[scdline].push(batchJson);
                }
            }
            log.debug('getInvInfo', invJson)
            return invJson;
        }



        /**
         * 获取it单to location
         * @param itId
         * @param searchType
         * @param filterType
         * @returns {[]}
         */
        const getToLocation = (itId, searchType, filterType) => {
            let myFilters = [];
            myFilters.push(['type', 'anyof', filterType]);

            myFilters.push('and');
            myFilters.push(['internalid', 'anyof', itId]);
            myFilters.push('and');
            myFilters.push(['mainline', 'is', 'T']);
            myFilters.push('and');
            myFilters.push(['taxline', 'is', 'F']);

            let myColumns = [];
            myColumns.push({name: "location"});

            let mySearch = search.create({type:searchType, filters:myFilters, columns:myColumns});
            let myResult = commonApi.getAllData(mySearch);
            let locationArr = [];
            if (myResult && myResult.length > 0) {
                for (let i = 0; i < myResult.length; i++) {
                    let location = myResult[i].getValue(myColumns[0]);
                    if (location && '-1' == locationArr.indexOf(location)){
                        locationArr.push(location);
                    }
                }
            }
            log.debug('locationArr',locationArr)
            return locationArr;
        }

        /**
         * 查询sp及其相关记录数据
         * @param spId
         * @returns {{}}
         */
        function getSpData(spId){
            let myFilters = [];
            myFilters.push(['custrecord_scdline_sp.internalid', 'anyof', spId]);
            myFilters.push('and');
            myFilters.push(['custrecord_scdline_sono1', 'noneof', '@NONE@']);
            myFilters.push('and');
            myFilters.push(['custrecord_scdline_soif1', 'anyof', '@NONE@']);
            let myColumns = [];
            myColumns.push({name:'custrecord_sp_deliverydate', join:'CUSTRECORD_SCDLINE_SP', label:'Shipping Date'});
            myColumns.push({name:'internalid', join: 'CUSTRECORD_SCDLINE_SP', label: 'SP 内部 ID'});
            myColumns.push({name:'custrecord_scdline_item', label: 'Item'});
            myColumns.push({name:'custrecord_scdline_qty', label: 'Qty'});
            myColumns.push({name:'custrecord_sp_location', join: 'CUSTRECORD_SCDLINE_SP', label: 'Issuing Location'});
            myColumns.push({name:'custrecord_id_seriallot', join: 'CUSTRECORD_ID_SPLINE', label: 'SERIAL/LOT NUMBER'});
            myColumns.push({name:'custrecord_id_status', join: 'CUSTRECORD_ID_SPLINE', label: 'Status'});
            myColumns.push({name:'custrecord_id_quantity', join: 'CUSTRECORD_ID_SPLINE', label: 'Quantity'});
            myColumns.push({name:'custrecord_scdline_sono1', sort:'ASC', label: 'SO NO1'});
            myColumns.push({name:'custrecord_scdline_purchaseorder', label: 'PO'});
            myColumns.push({name:'internalid', label: 'Scd Line Id'});

            let mySearch = search.create({
                type:'customrecord_ecm_scd_line',
                filters:myFilters,
                columns:myColumns
            });
            let spData = {};

            let myResult = mySearch.run().getRange({start:0, end:1000});
            if (myResult && myResult.length > 0){
                for (let i = 0; i < myResult.length; i++){
                    let shipdate = myResult[i].getValue(myColumns[0]) || '';
                    let item = myResult[i].getValue(myColumns[2]) || '';
                    let spqty = myResult[i].getValue(myColumns[3]) || '';
                    let location = myResult[i].getValue(myColumns[4]) || '';
                    let seriallot = myResult[i].getValue(myColumns[5]) || '';
                    let status = myResult[i].getValue(myColumns[6]) || '';
                    let quantity = myResult[i].getValue(myColumns[7]) || '';
                    let soNo = myResult[i].getValue(myColumns[8]) || '';
                    let poNo = myResult[i].getValue(myColumns[9]) || '';
                    let scdLineId = myResult[i].getValue(myColumns[10]) || '';

                    spData[soNo] = spData[soNo] || {itemInfo:{}, shipdate};
                    spData[soNo].shipdate = shipdate;

                    spData[soNo].itemInfo[item] = spData[soNo].itemInfo[item] || {location:'', spqty:0, poNo:'', scdLineId:[]};
                    spData[soNo].itemInfo[item].location = location;
                    spData[soNo].itemInfo[item].spqty = Number(spData[soNo].itemInfo[item].spqty).add(Number(spqty));
                    spData[soNo].itemInfo[item].poNo = poNo;
                    if(scdLineId && '-1' == spData[soNo].itemInfo[item].scdLineId.indexOf(scdLineId)){
                        spData[soNo].itemInfo[item].scdLineId.push(scdLineId);
                    }
                }
            }
            log.debug('getSpData',spData)
            return spData;
        }


        /**
         * Defines the function that is executed when the summarize entry point is triggered. This entry point is triggered
         * automatically when the associated reduce stage is complete. This function is applied to the entire result set.
         * @param {Object} summaryContext - Statistics about the execution of a map/reduce script
         * @param {number} summaryContext.concurrency - Maximum concurrency number when executing parallel tasks for the map/reduce
         *     script
         * @param {Date} summaryContext.dateCreated - The date and time when the map/reduce script began running
         * @param {boolean} summaryContext.isRestarted - Indicates whether the current invocation of this function is the first
         *     invocation (if true, the current invocation is not the first invocation and this function has been restarted)
         * @param {Iterator} summaryContext.output - Serialized keys and values that were saved as output during the reduce stage
         * @param {number} summaryContext.seconds - Total seconds elapsed when running the map/reduce script
         * @param {number} summaryContext.usage - Total number of governance usage units consumed when running the map/reduce
         *     script
         * @param {number} summaryContext.yields - Total number of yields when running the map/reduce script
         * @param {Object} summaryContext.inputSummary - Statistics about the input stage
         * @param {Object} summaryContext.mapSummary - Statistics about the map stage
         * @param {Object} summaryContext.reduceSummary - Statistics about the reduce stage
         * @since 2015.2
         */
        const summarize = (summaryContext) => {

        }

        return {getInputData, reduce, summarize}

    });
