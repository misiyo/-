/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 * version      date            author      remark
 * 1.0          2023/03/30      Doris       检验结果回写sp(1018549)
 */
define(['N/format', 'N/record', 'N/redirect', 'N/search'],
    /**
     * @param{format} format
     * @param{record} record
     * @param{redirect} redirect
     * @param{search} search
     */
    (format, record, redirect, search) => {
        /**
         * Defines the Suitelet script trigger point.
         * @param {Object} scriptContext
         * @param {ServerRequest} scriptContext.request - Incoming request
         * @param {ServerResponse} scriptContext.response - Suitelet response
         * @since 2015.2
         */
        const onRequest = (scriptContext) => {
            let request = scriptContext.request;
            let response = scriptContext.response;
            let params = request.parameters;

            try {
                let spRec = record.load({
                    type:params.objRecType,
                    id:params.objRecId
                });
                if ('GET' == request.method){

                    if ('' != params.payment && 'true' == params.alertMsg){
                        spRec.setValue({fieldId:'custrecord_sp_checkpass', value:true});
                        spRec.setValue({fieldId:'custrecord_sp_quotabalacnce_pass', value:Number(params.payment)});

                    }else if ('' == params.payment && 'true' == params.alertMsg){
                        spRec.setValue({fieldId:'custrecord_sp_checkpass', value:true});

                    }
                    spRec.save({enableSourcing:true, ignoreMandatoryFields:true});
                    response.write("<script type='text/javascript'>window.open('" + params.recordUrl + "', '_self', '');</script>");
                }
            }catch (e){
                log.error('error', e);
            }
        }



        return {onRequest}

    });
