/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 * version      date            author      remark
 * 1.0          2023/02/23      Doris       【ID1018549】Shipping Plan提交审批校验
 * 2.0          2023/02/28      Doris       【ID1018580】Shipping Plan Create SO&IF
 */
define(['N/currentRecord', 'N/url', 'N/record', 'N/search', '/SuiteScripts/tools/common_api.js', '/SuiteScripts/SuiteScripts_DM/environment_check.js'],
    /**
     * @param{currentRecord} currentRecord
     * @param{url} url
     * @param{record} record
     * @param{search} search
     */
    function(currentRecord, url, record, search, commonApi, enume) {

        /**
         * Function to be executed after page is initialized.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.mode - The mode in which the record is being accessed (create, copy, or edit)
         *
         * @since 2015.2
         */
        function pageInit(scriptContext) {

        }

        function submitSp(type, id){
            try{
                var spRec = record.load({
                    type:type,
                    id:id
                });
                var alertMsg = '';
                var apply = spRec.getValue('custrecord_sp_apply') || '';    // 是否投中信保
                var shipmentApply = spRec.getValue('custrecord_sp_shipmentapply') || '';    // 中信保申报
                var applyStatus = spRec.getValue('custrecord_sp_applystatus') || '';    // 中信保投保是否成功
                log.debug('字段',{apply:apply,shipmentApply:shipmentApply,applyStatus:applyStatus})
                if (true == apply){
                    if ('' == shipmentApply || enume.getAll().ECM_SINOSURE_PASSED != applyStatus){
                        alertMsg = 'You cannot submit it because the Sinosure application is not successful.';
                    }
                }
                var amount = getClainAmount(id);
                var preAmount = spRec.getValue('custrecord_sp_preamount');    // 预付款金额
                if (Number(preAmount) > Number(amount)){
                    alertMsg = alertMsg + 'You cannot submit it due to insufficient advance payment.';
                }
                log.debug('alertMsg', alertMsg)
                if (alertMsg){
                    spRec.setValue({fieldId:'custrecord_sp_checkpass', value:false});
                    alert(alertMsg);
                }else {
                    spRec.setValue({fieldId:'custrecord_sp_checkpass', value:true});
                }
                spRec.save({enableSourcing:true, ignoreMandatoryFields:true});
                var url = window.location.href;
                window.location.href = url;
            }catch (e){
                console.log('执行Submit-error===>'+e);
            }
        }

        /**
         * 获取当前sp对应的认领记录中金额类型为预付款的金额合计
         * @param spId
         * @returns {number}
         */
        function getClainAmount(spId){
            var myFilters = [];
            myFilters.push(['isinactive', 'is', 'false']);
            myFilters.push('and');
            myFilters.push(['custrecord_ecm_claim_sp', 'anyof', spId]);
            myFilters.push('and');
            myFilters.push(['custrecord_ecm_claim_type', 'anyof', enume.getAll().ECM_CLAIM_TYPE]);
            var myColumns = [];
            myColumns.push('custrecord_ecm_claim_amount');   // 金额

            var mySearch = search.create({
                type:'customrecord_ecm_claim_record',
                filters:myFilters,
                columns:myColumns
            });
            var myResult = mySearch.run().getRange({start:0, end:1000});
            var amount = 0;
            if (myResult && myResult.length > 0){
                for (var i = 0; i < myResult.length; i++){
                    amount = Number(amount).add(myResult[i].getValue(myColumns[0]));
                }
            }
            log.debug('amount',amount)
            return amount;
        }

        function createSoOrIf(type, id){
            try{
                var createUrl = url.resolveScript({
                    scriptId: '',     // 脚本的内部 ID。该 ID 必须标识 RESTlet 或 Suitelet。
                    deploymentId: '',
                    params:{
                        objRecType:type,
                        objRecId:id
                    }// 包含用于描述查询的名称/值对的对象。
                });
                window.open(createUrl, '_blank', '');
            }catch (e){
                console.log('执行Create SO&IF-error===>'+e);
            }
        }

        /**
         * Function to be executed when field is changed.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         * @param {string} scriptContext.fieldId - Field name
         * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
         * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
         *
         * @since 2015.2
         */
        function fieldChanged(scriptContext) {

        }

        /**
         * Function to be executed when field is slaved.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         * @param {string} scriptContext.fieldId - Field name
         *
         * @since 2015.2
         */
        function postSourcing(scriptContext) {

        }

        /**
         * Function to be executed after sublist is inserted, removed, or edited.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         *
         * @since 2015.2
         */
        function sublistChanged(scriptContext) {

        }

        /**
         * Function to be executed after line is selected.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         *
         * @since 2015.2
         */
        function lineInit(scriptContext) {

        }

        /**
         * Validation function to be executed when field is changed.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         * @param {string} scriptContext.fieldId - Field name
         * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
         * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
         *
         * @returns {boolean} Return true if field is valid
         *
         * @since 2015.2
         */
        function validateField(scriptContext) {

        }

        /**
         * Validation function to be executed when sublist line is committed.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         *
         * @returns {boolean} Return true if sublist line is valid
         *
         * @since 2015.2
         */
        function validateLine(scriptContext) {

        }

        /**
         * Validation function to be executed when sublist line is inserted.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         *
         * @returns {boolean} Return true if sublist line is valid
         *
         * @since 2015.2
         */
        function validateInsert(scriptContext) {

        }

        /**
         * Validation function to be executed when record is deleted.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         *
         * @returns {boolean} Return true if sublist line is valid
         *
         * @since 2015.2
         */
        function validateDelete(scriptContext) {

        }

        /**
         * Validation function to be executed when record is saved.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @returns {boolean} Return true if record is valid
         *
         * @since 2015.2
         */
        function saveRecord(scriptContext) {

        }

        return {
            pageInit: pageInit,
            // fieldChanged: fieldChanged,
            // postSourcing: postSourcing,
            // sublistChanged: sublistChanged,
            // lineInit: lineInit,
            // validateField: validateField,
            // validateLine: validateLine,
            // validateInsert: validateInsert,
            // validateDelete: validateDelete,
            // saveRecord: saveRecord,
            createSoOrIf:createSoOrIf,
            submitSp:submitSp
        };

    });
