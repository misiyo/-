/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * Version      Date            Author      Remark
 * 1.0          2023/04/10      Doris       【ID1019632】销售合同附件上传
 */
define(['N/record', 'N/url'],
    /**
     * @param{record} record
     */
    (record, url) => {
        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {
            try {
                let newRec = scriptContext.newRecord;
                if ('view' == scriptContext.type || 'edit' == scriptContext.type){
                    let form = scriptContext.form;
                    let uploadUrl = url.resolveScript({
                        scriptId: 'customscript_ecm_sl_so_upload_file',     // 脚本的内部 ID。该 ID 必须标识 RESTlet 或 Suitelet。
                        deploymentId: 'customdeploy_ecm_sl_so_upload_file',
                        params:{
                            objRecType:newRec.type,
                            objRecId:newRec.id
                        }// 包含用于描述查询的名称/值对的对象。
                    });
                    clickField(form, uploadUrl);

                }
            }catch (e){
                log.error('error', e);
            }
        }

        const clickField = (form, uploadUrl) => {
            try {
                form.addField({
                    type: 'inlinehtml',
                    label: ' &nbsp; ',
                    id: `custpage_click_contract_field`
                }).defaultValue = `
            <script>
                try{
                    jQuery(function () {
                        let input = '<span id="custpage_upload_file_span" style="width:40px; padding-left: 8px;"><input type="button" id="custpage_upload_file" value="Upload"></input></span>';
                        jQuery('#custbody_ecm_sc_document_fs_lbl').after(input);
                        jQuery('#custpage_upload_file').attr('onclick', "window.open('${uploadUrl}', '_blank', 'height=400, width=600, left=0, top=0;')");

                    })
                }catch (e) {
                  console.log('onclick Error:' + e.message)
                }
            </script>`
            } catch (ex) {
                log.error({ title : 'hide view elements error', details : ex });
            }
        }

        /**
         * Defines the function definition that is executed before record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const beforeSubmit = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {

        }

        return {beforeLoad/*, beforeSubmit, afterSubmit*/}

    });
