/**
 * @NApiVersion 2.1
 * @NScriptType MapReduceScript
 * version      date            author      remark
 * 1.0          2023/03/31      Doris       【ID1018580】Shipping Plan生成SO单变更开发
 * 2.0          2023/04/10      Doris       生成SO单日期取值变更：创建日期-->交割日期（1018580）
 */
define(['N/record', 'N/search', 'N/format', '/SuiteScripts/tools/common_api.js', '/SuiteScripts/SuiteScripts_DM/environment_check.js'],
    /**
     * @param{record} record
     * @param{search} search
     */
    (record, search, format, commonApi, enume) => {
        const SP_TYPE = 'customrecord_ecm_sp';
        const SP_SUBLIST_ID = 'recmachcustrecord_scdline_sp';
        /**
         * Defines the function that is executed at the beginning of the map/reduce process and generates the input data.
         * @param {Object} inputContext
         * @param {boolean} inputContext.isRestarted - Indicates whether the current invocation of this function is the first
         *     invocation (if true, the current invocation is not the first invocation and this function has been restarted)
         * @param {Object} inputContext.ObjectRef - Object that references the input data
         * @typedef {Object} ObjectRef
         * @property {string|number} ObjectRef.id - Internal ID of the record instance that contains the input data
         * @property {string} ObjectRef.type - Type of the record instance that contains the input data
         * @returns {Array|Object|Search|ObjectRef|File|Query} The input data to use in the map/reduce process
         * @since 2015.2
         */

        const getInputData = (inputContext) => {
            try {
                return getSpInfo();
            } catch (e) {
                log.error('getInputData:error', e);
            }
            return [];
        }

        /**
         * 查询符合条件的SP
         */
        const getSpInfo = () => {
            let searchObj = search.load({id:'customsearch_ecmscri_spcreateso_dev'});
            let filterExp = searchObj.filterExpression;
            let newFilterExp = [];
            newFilterExp.push(filterExp);
            if (filterExp && filterExp.length > 0){
                newFilterExp.push('and');
            }
            newFilterExp.push(['custrecord_scdline_sp.custrecord_scdline_uniquekey', 'isnotempty', '']);
            searchObj.filterExpression = newFilterExp;
            return commonApi.getAllData(searchObj);

        }

        /**
         * Defines the function that is executed when the map entry point is triggered. This entry point is triggered automatically
         * when the associated getInputData stage is complete. This function is applied to each key-value pair in the provided
         * context.
         * @param {Object} mapContext - Data collection containing the key-value pairs to process in the map stage. This parameter
         *     is provided automatically based on the results of the getInputData stage.
         * @param {Iterator} mapContext.errors - Serialized errors that were thrown during previous attempts to execute the map
         *     function on the current key-value pair
         * @param {number} mapContext.executionNo - Number of times the map function has been executed on the current key-value
         *     pair
         * @param {boolean} mapContext.isRestarted - Indicates whether the current invocation of this function is the first
         *     invocation (if true, the current invocation is not the first invocation and this function has been restarted)
         * @param {string} mapContext.key - Key to be processed during the map stage
         * @param {string} mapContext.value - Value to be processed during the map stage
         * @since 2015.2
         */

        const map = (mapContext) => {

        }

        /**
         * SP创建SO单
         * @param spId
         * @returns {[]}
         */
        const createSo = (spId) => {
            let spRec = record.load({
                type:SP_TYPE,
                id:spId
            });
            let deliveryDate = spRec.getText('custrecord_sp_deliverydate'); // 交割日期
            let soId = '';
            let soIdArr = [];
            let lineCount = spRec.getLineCount({sublistId:SP_SUBLIST_ID});
            let scLineArr = [];
            let scIdArr = [];
            if (lineCount > 0){
                for (let i = 0; i < lineCount; i++){
                    let scLine = spRec.getSublistValue({sublistId:SP_SUBLIST_ID, fieldId:'custrecord_scdline_uniquekey', line:i});
                    let soNo = spRec.getSublistValue({sublistId:SP_SUBLIST_ID, fieldId:'custrecord_scdline_sono1', line:i}) || '';
                    let scId = spRec.getSublistValue({sublistId:SP_SUBLIST_ID, fieldId:'custrecord_scdline_sc', line:i}) || '';
                    if (scLine && '-1' == scLineArr.indexOf(scLine) && '' == soNo){
                        scLineArr.push(scLine);
                    }
                    if (scLine && scId && '-1' == scIdArr.indexOf(scId) && '' == soNo){
                        scIdArr.push(scId);
                    }
                }
                if (scLineArr && scLineArr.length > 0 && scIdArr && scIdArr.length > 0){
                    let recData = getScInfoTest(scLineArr, scIdArr);

                    let scRecData = recData.scArr;
                    let soRecData = recData.soArr;

                    if (soRecData && Object.keys(soRecData).length > 0){
                        for (const soRecDataKey in soRecData) {
                            try{
                                let soRec = record.load({type:'salesorder', id:soRecDataKey});
                                soRec.setValue({fieldId:'custbody_ecm_sp', value:spId});
                                soRec.save({enableSourcing:true, ignoreMandatoryFields:true});
                                let soRecDataValue = soRecData[soRecDataKey];
                                if (soRecDataValue && soRecDataValue.length > 0){
                                    for (let i = 0; i < soRecDataValue.length; i++){
                                        for (let j = 0; j < lineCount; j++){
                                            let uniquekey = spRec.getSublistValue({sublistId:SP_SUBLIST_ID, fieldId:'custrecord_scdline_uniquekey', line:j});
                                            if (soRecDataValue[i] == uniquekey){
                                                spRec.setSublistValue({sublistId:SP_SUBLIST_ID, fieldId:'custrecord_scdline_sono1', value:soRecDataKey, line:j});
                                            }
                                        }
                                    }
                                }
                            }catch (soError){
                                log.error('SC直接回写SO-->error', soError);
                            }
                        }
                        spRec.save({enableSourcing:true, ignoreMandatoryFields:true});
                    }

                    if (scRecData && Object.keys(scRecData).length > 0){
                        for (const scRecDataKey in scRecData) {
                            try {
                                let scRecDataValue = scRecData[scRecDataKey];
                                let lineData = scRecDataValue.lineData;
                                let entity = scRecDataValue.entity;
                                let subsidiary = scRecDataValue.subsidiary;
                                let contractType = scRecDataValue.contractType;
                                let incoterm = scRecDataValue.incoterm;
                                let terms = scRecDataValue.terms;
                                let currency = scRecDataValue.currency;
                                let iscrossborder = scRecDataValue.iscrossborder;
                                let countryof_departure = scRecDataValue.countryof_departure;
                                let exchangerate = scRecDataValue.exchangerate;
                                let leadsource = scRecDataValue.leadsource;

                                let soRec = record.create({type:'salesorder',isDynamic:true});

                                soRec.setValue({fieldId:'entity', value:entity});
                                soRec.setText({fieldId:'tradate', text:deliveryDate});
                                soRec.setValue({fieldId:'subsidiary', value:subsidiary,forceSyncSourcing:true});
                                soRec.setValue({fieldId:'custbody_ecm_contract_type', value:contractType});
                                soRec.setValue({fieldId:'custbody_ecm_incoterm', value:incoterm});
                                soRec.setValue({fieldId:'currency', value:currency});
                                soRec.setValue({fieldId:'custbody_ecm_iscrossborder', value:iscrossborder});
                                soRec.setValue({fieldId:'custbody_ecm_countryof_departure', value:countryof_departure});
                                soRec.setValue({fieldId:'exchangerate', value:exchangerate});
                                soRec.setValue({fieldId:'leadsource', value:leadsource});
                                soRec.setValue({fieldId:'custbody_ecm_ordertype', value:enume.getAll().SALES_ORDER_TYPE_ORDER});
                                soRec.setValue({fieldId:'custbody_sourceformtran', value:scRecDataKey});
                                soRec.setValue({fieldId:'custbody_ecm_sp', value:spId});
                                soRec.setValue({fieldId:'orderstatus', value:'B'});

                                if (lineData && Object.keys(lineData).length > 0){
                                    for (const lineDataKey in lineData) {
                                        let lineDataValue = lineData[lineDataKey];
                                        let unit = lineDataValue.unit;
                                        let rate = lineDataValue.rate;
                                        let taxCode = lineDataValue.taxCode;

                                        let itemId = '';
                                        let sum = 0;

                                        for (let i = 0; i < lineCount; i++){
                                            let scLine = spRec.getSublistValue({sublistId:SP_SUBLIST_ID, fieldId:'custrecord_scdline_uniquekey', line:i});
                                            if (lineDataKey == scLine){
                                                itemId = spRec.getSublistValue({sublistId:SP_SUBLIST_ID, fieldId:'custrecord_scdline_item', line:i});
                                                let quantity = spRec.getSublistValue({sublistId:SP_SUBLIST_ID, fieldId:'custrecord_scdline_spqty', line:i});
                                                sum = Number(sum).add(quantity);
                                            }
                                        }

                                        let amount = Number(sum).mul(Number(rate));
                                        soRec.selectNewLine({sublistId:'item'});
                                        soRec.setCurrentSublistValue({sublistId:'item', fieldId:'item', value:itemId});
                                        soRec.setCurrentSublistValue({sublistId:'item', fieldId:'quantity', value:sum});
                                        soRec.setCurrentSublistValue({sublistId:'item', fieldId:'units', value:unit});
                                        soRec.setCurrentSublistValue({sublistId:'item', fieldId:'taxcode', value:taxCode});
                                        soRec.setCurrentSublistValue({sublistId:'item', fieldId:'amount', value:Number(amount)});
                                        soRec.setCurrentSublistValue({sublistId:'item', fieldId:'rate', value:Number(rate)});
                                        soRec.commitLine({sublistId:'item'});
                                    }
                                }
                                soId = soRec.save({enableSourcing:true, ignoreMandatoryFields:true});
                                if (soId){
                                    soIdArr.push(soId);
                                    spRec = record.load({type:SP_TYPE, id:spId});
                                    spRec.setValue({fieldId:'custrecord_sp_createsoif_erromsg', value:''});
                                    let lineIdArr = Object.keys(lineData);
                                    for (let li = 0; li < lineIdArr.length; li++){
                                        for(let lineId = 0; lineId < lineCount; lineId++){
                                            let uniquekey = spRec.getSublistValue({sublistId:SP_SUBLIST_ID, fieldId:'custrecord_scdline_uniquekey', line:lineId});
                                            if (lineIdArr[li] == uniquekey){
                                                spRec.setSublistValue({sublistId:SP_SUBLIST_ID, fieldId:'custrecord_scdline_sono1', value:soId, line:lineId});
                                            }
                                        }
                                    }

                                    spRec.save({enableSourcing:true, ignoreMandatoryFields:true});
                                }
                            }catch (ex){
                                let errorMsg = '创建so失败，scid:'+ scRecDataKey + '失败原因：' + ex.message;
                                let spRec = record.load({type:SP_TYPE, id:spId});
                                spRec.setValue({fieldId:'custrecord_sp_createsoif_erromsg', value:errorMsg});
                                spRec.save({enableSourcing:true, ignoreMandatoryFields:true});
                                log.error('创建so失败', ex);
                            }
                        }
                    }
                }
            }
            return soIdArr;
        }


        /**
         * getScInfoTest
         * @param scLineArr
         */
        const getScInfoTest = (scLineArr, scIdArr) => {
            let myFilters = [];
            myFilters.push(['type', 'anyof', 'SalesOrd']);
            let insideFilters = [];
            if (scLineArr && scLineArr.length > 0){
                myFilters.push('and');
                for (let i = 0; i < scLineArr.length; i++){
                    if(0!=i){
                        insideFilters.push('or')
                    }
                    insideFilters.push(['custcol_ecm_uniquekey', 'is', scLineArr[i]]);
                }
                myFilters.push(insideFilters);
            }
            myFilters.push('and');
            myFilters.push(['internalid', 'anyof', scIdArr]);
            let myColumns = [];
            myColumns.push({name:'internalid', sort: search.Sort.ASC});
            myColumns.push('custcol_ecm_uniquekey');
            myColumns.push('entity');
            myColumns.push('subsidiary');
            myColumns.push('custbody_ecm_contract_type');
            myColumns.push('custbody_ecm_incoterm');
            myColumns.push('terms');
            myColumns.push('currency');
            myColumns.push('custbody_ecm_iscrossborder');
            myColumns.push('custbody_ecm_countryof_departure');
            myColumns.push('exchangerate');
            myColumns.push('leadsource');
            myColumns.push('unitid');
            myColumns.push('taxcode');
            myColumns.push('fxrate');
            myColumns.push('custbody_ecm_ordertype');
            let mySearch = search.create({
                type:'salesorder',
                filters:myFilters,
                columns:myColumns
            });
            let myResult = mySearch.run().getRange({start:0, end:1000});
            let scArr = {};
            let lineData = {};
            let soArr = {};
            if (myResult && myResult.length > 0){
                for (let i = 0; i < myResult.length; i++){
                    let scId = myResult[i].getValue(myColumns[0]) || '';
                    let lineuniquekey = myResult[i].getValue(myColumns[1]) || '';

                    let orderType = myResult[i].getValue(myColumns[15]) || '';
                    if (enume.getAll().SALES_ORDER_TYPE_CONTRACT != orderType){
                        soArr[scId] = soArr[scId] || [];
                        soArr[scId].push(lineuniquekey);
                    }else {
                        scArr[scId] = scArr[scId] || {lineData : {},entity:'', subsidiary:'', contractType:'', incoterm:'', terms:'', currency:'', iscrossborder:'',countryof_departure:'',exchangerate:'', leadsource:''};

                        scArr[scId].entity = myResult[i].getValue(myColumns[2]) || '';
                        scArr[scId].subsidiary = myResult[i].getValue(myColumns[3]) || '';
                        scArr[scId].contractType = myResult[i].getValue(myColumns[4]) || '';
                        scArr[scId].incoterm = myResult[i].getValue(myColumns[5]) || '';
                        scArr[scId].terms = myResult[i].getValue(myColumns[6]) || '';
                        scArr[scId].currency = myResult[i].getValue(myColumns[7]) || '';
                        scArr[scId].iscrossborder = myResult[i].getValue(myColumns[8]);
                        scArr[scId].countryof_departure = myResult[i].getValue(myColumns[9]) || '';
                        scArr[scId].exchangerate = myResult[i].getValue(myColumns[10]) || '';
                        scArr[scId].leadsource = myResult[i].getValue(myColumns[11]) || '';

                        scArr[scId].lineData[lineuniquekey] = lineData[lineuniquekey] || {unit:'', rate:'', taxCode :''}
                        scArr[scId].lineData[lineuniquekey].unit = myResult[i].getValue(myColumns[12]) || '';
                        scArr[scId].lineData[lineuniquekey].taxCode = myResult[i].getValue(myColumns[13]) || '';
                        scArr[scId].lineData[lineuniquekey].rate = myResult[i].getValue(myColumns[14]) || '';
                    }
                }
            }
            log.debug('getScInfoTest', {scArr:scArr,soArr:soArr})
            return {scArr:scArr, soArr:soArr};
        }

        /**
         * Defines the function that is executed when the reduce entry point is triggered. This entry point is triggered
         * automatically when the associated map stage is complete. This function is applied to each group in the provided context.
         * @param {Object} reduceContext - Data collection containing the groups to process in the reduce stage. This parameter is
         *     provided automatically based on the results of the map stage.
         * @param {Iterator} reduceContext.errors - Serialized errors that were thrown during previous attempts to execute the
         *     reduce function on the current group
         * @param {number} reduceContext.executionNo - Number of times the reduce function has been executed on the current group
         * @param {boolean} reduceContext.isRestarted - Indicates whether the current invocation of this function is the first
         *     invocation (if true, the current invocation is not the first invocation and this function has been restarted)
         * @param {string} reduceContext.key - Key to be processed during the reduce stage
         * @param {List<String>} reduceContext.values - All values associated with a unique key that was passed to the reduce stage
         *     for processing
         * @since 2015.2
         */
        const reduce = (reduceContext) => {
            try {
                const values = JSON.parse(reduceContext.values);
                log.debug('values',values.id)
                createSo(values.id);
            }catch (e){
                log.error('reduce-error', e);
            }

        }


        /**
         * Defines the function that is executed when the summarize entry point is triggered. This entry point is triggered
         * automatically when the associated reduce stage is complete. This function is applied to the entire result set.
         * @param {Object} summaryContext - Statistics about the execution of a map/reduce script
         * @param {number} summaryContext.concurrency - Maximum concurrency number when executing parallel tasks for the map/reduce
         *     script
         * @param {Date} summaryContext.dateCreated - The date and time when the map/reduce script began running
         * @param {boolean} summaryContext.isRestarted - Indicates whether the current invocation of this function is the first
         *     invocation (if true, the current invocation is not the first invocation and this function has been restarted)
         * @param {Iterator} summaryContext.output - Serialized keys and values that were saved as output during the reduce stage
         * @param {number} summaryContext.seconds - Total seconds elapsed when running the map/reduce script
         * @param {number} summaryContext.usage - Total number of governance usage units consumed when running the map/reduce
         *     script
         * @param {number} summaryContext.yields - Total number of yields when running the map/reduce script
         * @param {Object} summaryContext.inputSummary - Statistics about the input stage
         * @param {Object} summaryContext.mapSummary - Statistics about the map stage
         * @param {Object} summaryContext.reduceSummary - Statistics about the reduce stage
         * @since 2015.2
         */
        const summarize = (summaryContext) => {

        }

        return {getInputData, reduce, summarize}

    });
