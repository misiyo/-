/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * version      date            author      remark
 * 1.0          2023/02/15      Doris       【ID1018421】LC限额申请
 * 2.0          2023/03/10      Doris       【ID1018421】企业买方代码字段由列表变更为自由文本
 * 3.0          2023/03/13      Doris       【ID1018421】中国信保买方代码/信保开证行SWIFT传参值下钻至买方代码申请记录：中信保买方代码，及银行代码记录：企业填写的开证行SWIFT
 * 4.0          2023/03/23      Doris       商品类别代码字段变更为：custrecord_ego_code
 */
define(['N/record', 'N/search', '/SuiteScripts/tools/common_api.js', '/SuiteScripts/tools/hc_edi_interface_tool.js', '/SuiteScripts/tools/moment.js', '/SuiteScripts/tools/ramda.min.js', '/SuiteScripts/SuiteScripts_DM/environment_check.js'],
    /**
     * @param{record} record
     * @param{search} search
     */
    (record, search, commonApi, interfaceTool, moment, ramda, enume) => {
        const LC_LIMIT_APPLY_TYPE = 'customrecord_ecm_sinosure_lc_quotaapply';// LC限额申请记录id
        const BUYER_APPLY_TYPE = 'customrecord_ecm_sinosure_buyercodeapply';  // 买方代码申请记录id
        const BANK_APPLY_TYPE = 'customrecord_ecm_sinosure_bankcodeapply';  // 银行代码申请记录id
        const LOG_TYPE = 'customrecord_hc_edi_interface_log';// 日志类型
        const IMETHOD = 'doEdiLcQuotaApplyV2';// 接口method
        const FIELD_MAPPING = {
            'customer' : 'custrecord_eslcq_customer', // 买方名称（客户）
            'clientNo' : 'custrecord_eslcq_clientno',   // 企业标识
            'policyNo' : 'custrecord_eslcq_policyno',   // 保险单号
            'siNoSureBuyerNo' : 'custrecord_eslcq_sinosurebuyerno', // 中国信保买方代码
            'corpBuyerNo' : 'custrecord_eslcq_corpbuyerno',     // 企业买方代码
            'buyerChnName' : 'custrecord_eslcq_buyerchnname',   // 买方中文名称
            'buyerEngName' : 'custrecord_eslcq_buyerengname',   // 买方英文名称
            'buyerCountryCode' : 'custrecord_eslcq_buyercountrycode',   // 买方国家代码
            'buyerEngAddress' : 'custrecord_eslcq_buyerengaddress',     // 买方英文地址
            'regionCode' : 'custrecord_eslcq_regioncode',       // 美国买方州省代码
            'buyerChnAddress' : 'custrecord_eslcq_buyerchnaddress',     // 买方中文地址
            'creditNo' : 'custrecord_eslcq_creditno',   // 统一社会信用代码
            'orgNo' : 'custrecord_eslcq_orgno',         // 组织机构代码
            'areaNo' : 'custrecord_eslcq_areano',       // 注册区域代码
            'buyerRegNo' : 'custrecord_eslcq_buyerregno',    // 买方注册号
            'buyerTel' : 'custrecord_eslcq_buyertel',   // 买方电话
            'buyerFax' : 'custrecord_eslcq_buyerfax',   // 买方传真
            'ifRepeat' : 'custrecord_eslcq_ifrepeat',   // 是否循环
            'lcNo' : 'custrecord_eslcq_lcno',           // 信用证号
            'payTermApply' : 'custrecord_eslcq_paytermapply',    // LC信用期限（天）
            'quotaSumApply' : 'custrecord_eslcq_quotasumapply',  // LC信用金额（USD）
            'lcSum' : 'custrecord_eslcq_lcsum',                  // 信用证金额（USD）
            'lastLadeDate' : 'custrecord_eslcq_lastladedate',    // 最迟装船日
            'goodsCode' : 'custrecord_eslcq_goodscode',          // 出口商品类别代码
            'elseGoodsName' : 'custrecord_eslcq_elsegoodsname',  // 商品名称
            'openBankSwift' : 'custrecord_eslcq_openbankswift',  // 信保开证行SWIFT
            'corpOpenBankNo' : 'custrecord_eslcq_corpopenbankno',    // 开证行企业内部编码
            'corpOpenBankSwift' : 'custrecord_eslcq_corpopenbankswift',    // 企业填写开证行SWIFT
            'openBankChnName' : 'custrecord_eslcq_openbankchnname',    // 开证行中文名称
            'openBankEngName' : 'custrecord_eslcq_openbankengname',    // 开证行英文名称
            'openBankCountryCode' : 'custrecord_eslcq_openbankcountrycode',    // 开证行国家代码
            'openBankAddress' : 'custrecord_eslcq_openbankaddress',    // 开证行地址（英文）
            'exBankSwift' : 'custrecord_eslcq_exbankswift',    // 信保保兑行SWIFT
            'corpExBankNo' : 'custrecord_eslcq_corpexbankno',    // 保兑行企业内部编码
            'corpExBankSwift' : 'custrecord_eslcq_corpexbankswift',    // 企业填写保兑行SWIFT
            'exBankChnName' : 'custrecord_eslcq_exbankchnname',    // 保兑行中文名称
            'exBankEngName' : 'custrecord_eslcq_exbankengname',    // 保兑行英文名称
            'exBankCountryCode' : 'custrecord_eslcq_exbankcountrycode',    // 保兑行国家代码
            'exBankAddress' : 'custrecord_eslcq_exbankaddress',    // 保兑行地址（英文）
            'ifHistTrade' : 'custrecord_eslcq_ifhisttrade',    // 是否曾收到该银行开立的信用证
            'lastYear1' : 'custrecord_eslcq_lastyear1',    // 最近三年交易年份1
            'lastPayMode1' : 'custrecord_eslcq_lastpaymode1',    // 最近三年交易结算方式1
            'lastSum1' : 'custrecord_eslcq_lastsum1',    // 最近三年交易金额1
            'lastYear2' : 'custrecord_eslcq_lastyear2',    // 最近三年交易年份2
            'lastPayMode2' : 'custrecord_eslcq_lastpaymode2',    // 最近三年交易结算方式2
            'lastSum2' : 'custrecord_eslcq_lastsum2',    // 最近三年交易金额2
            'lastYear3' : 'custrecord_eslcq_lastyear3',    // 最近三年交易年份3
            'lastPayMode3' : 'custrecord_eslcq_lastpaymode3',    // 最近三年交易结算方式3
            'lastSum3' : 'custrecord_eslcq_lastsum3',    // 最近三年交易金额3
            'bankPayBehave' : 'custrecord_eslcq_bankpaybehave',    // 银行付款表现
            'oweFlag' : 'custrecord_eslcq_oweflag',    // 银行付款异常原因代码
            'oweElseReson' : 'custrecord_eslcq_oweelsereson',    // 其他银行付款异常原因
            'remark' : 'custrecord_eslcq_remark',    // 其他说明
            'employeeName' : 'custrecord_eslcq_employeename',    // 业务员名称
            'declaration' : 'custrecord_eslcq_declaration',    // 被保险人声明
            'applicant' : 'custrecord_eslcq_applicant',    // 申请人姓名
            'applyTime' : 'custrecord_eslcq_applytime',    // 申请时间
            'fileNum' : 'custrecord_eslcq_filenum',    // 附件个数
            'ifSameWithPolicy' : 'custrecord_eslcq_ifsamewithpolicy',    // 是否与保单出运前约定一致
            'preCreditTerm' : 'custrecord_eslcq_precreditterm',    // 出运前信用期限
            'afterCreditTerm' : 'custrecord_eslcq_aftercreditterm',    // 出运后信用期限
            'ifHaveTradeFinancing' : 'custrecord_eslcq_ifhavetradefinancing',    // 在本信用限额项下是否有贸易融资需求
            'ifHaveRelation' : 'custrecord_eslcq_ifhaverelation',    // 被保险人及共保人、关联公司、代理人项下是否与买方存在关联关系
            'relationDetail' : 'custrecord_eslcq_relationdetail',    // 具体关联情况
            'isSameWithContract' : 'custrecord_eslcq_issamewithcontract',    // 被保险人与买方历史交易记录中付款人是否与合同买方一致
            'noSameWithContractReaSo' : 'custrecord_eslcq_nosamewithcontractreaso',    // 付款人名称及不一致的原因
            'errorCode': 'custrecord_eslcq_errorcode',
            'errorMsg': 'custrecord_eslcq_errormsg',
            'postsinosure' : 'custrecord_eslcq_postsinosure',    // 推送中信保
            'posterromsg' : 'custrecord_eslcq_posterromsg',    // 推送失败信息
        };

        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed before record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const beforeSubmit = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {
            if(['delete','xedit'].includes(scriptContext.type)) return ;
            let logUpdVal = {
                custrecord_hc_inf_process_msg: '',
                custrecord_hc_inf_errorflag: false
            };
            let newRec = scriptContext.newRecord;

            let oldRec = scriptContext.oldRecord;
            let rtnData = {};
            try{
                let status = newRec.getValue('custrecord_eslcq_status');    // 单据状态

                if (enume.getAll().LC_LIMIT_APPLICATION_APPROVED == status){
                    let lcRec = record.load({
                        type:newRec.type,
                        id:newRec.id
                    });
                    let customer = lcRec.getValue(FIELD_MAPPING.customer);

                    let siNoSureBuyerNo = lcRec.getValue(FIELD_MAPPING.siNoSureBuyerNo) || ''; // 中国信保买方代码
                    let corpBuyerNo = lcRec.getValue(FIELD_MAPPING.corpBuyerNo);    // 企业买方代码
                    let buyerEngName = lcRec.getValue(FIELD_MAPPING.buyerEngName);  // 买方英文名称
                    let buyerEngAddress = lcRec.getValue(FIELD_MAPPING.buyerEngAddress);
                    let buyerCountryCode = lcRec.getValue(FIELD_MAPPING.buyerCountryCode); // 中信保-国家代码记录，取哪个字段用于接口传递
                    let regionCode = lcRec.getValue(FIELD_MAPPING.regionCode);

                    // 创建买方代码记录

                    if ('' == siNoSureBuyerNo && '' != buyerCountryCode && '' == corpBuyerNo){
                        let buyerRec = record.create({
                            type:BUYER_APPLY_TYPE
                        });
                        buyerRec.setValue({fieldId:'custrecord_esbya_customer', value:customer});
                        buyerRec.setValue({fieldId:'custrecord_esbya_engname', value:buyerEngName});
                        buyerRec.setValue({fieldId:'custrecord_esbya_countrycode', value:buyerCountryCode});
                        buyerRec.setValue({fieldId:'custrecord_esbya_engaddress', value:buyerEngAddress});
                        buyerRec.setValue({fieldId:'custrecord_esbya_regioncode', value:regionCode});
                        let buyerId = buyerRec.save({enableSourcing:true, ignoreMandatoryFields:true});
                        let newBuyerRec = record.load({
                            type:BUYER_APPLY_TYPE,
                            id:buyerId
                        });
                        let name = newBuyerRec.getValue('name');
                        lcRec.setValue({fieldId:FIELD_MAPPING.corpBuyerNo, value:name});
                        lcRec.save({enableSourcing:true, ignoreMandatoryFields:true});
                        log.debug('创建企业买方代码--成功')
                    }
                    lcRec = record.load({
                        type:newRec.type,
                        id:newRec.id
                    });
                    corpBuyerNo = lcRec.getValue(FIELD_MAPPING.corpBuyerNo);    // 企业买方代码
                    let openBankEngName = lcRec.getValue(FIELD_MAPPING.openBankEngName);
                    let openBankCountryCode = lcRec.getValue(FIELD_MAPPING.openBankCountryCode);   // 中信保-国家代码记录，取哪个字段用于接口传递
                    let openBankAddress = lcRec.getValue(FIELD_MAPPING.openBankAddress);
                    let openBankSwift = lcRec.getValue(FIELD_MAPPING.openBankSwift);   // 信保开证行SWIFT
                    // 创建银行代码记录
                    if ('' == openBankSwift && '' != openBankEngName && '' != openBankCountryCode && '' != openBankAddress){
                        let bankRec = record.create({type:BANK_APPLY_TYPE});
                        bankRec.setValue({fieldId:'custrecord_esba_customer', value:customer});
                        bankRec.setValue({fieldId:'custrecord_esba_countrycode', value:openBankCountryCode});
                        bankRec.setValue({fieldId:'custrecord_esba_engname', value:openBankEngName});
                        bankRec.setValue({fieldId:'custrecord_esba_address', value:openBankAddress});
                        let bankId = bankRec.save({enableSourcing:true, ignoreMandatoryFields:true});
                        let newBankRec = record.load({
                            type:BANK_APPLY_TYPE,
                            id:bankId
                        });
                        let name = newBankRec.getValue('name');
                        lcRec.setValue({fieldId:FIELD_MAPPING.corpOpenBankNo, value:name});
                        lcRec.save({enableSourcing:true, ignoreMandatoryFields:true});
                        log.debug('创建银行代码--成功')
                    }
                    lcRec = record.load({
                        type:newRec.type,
                        id:newRec.id
                    });
                    let corpOpenBankNo = lcRec.getValue(FIELD_MAPPING.corpOpenBankNo);
                    let postErrorMsg = lcRec.getValue(FIELD_MAPPING.posterromsg); // 推送失败信息
                    let postsinosure = lcRec.getValue(FIELD_MAPPING.postsinosure);   // 推送中信保

                    if ((enume.getAll().LC_LIMIT_APPLICATION_APPROVED == status && '' == postErrorMsg && '' != openBankSwift && false == postsinosure) || (enume.getAll().LC_LIMIT_APPLICATION_APPROVED == status && '' == postErrorMsg && false == postsinosure && '' != corpBuyerNo && '' == siNoSureBuyerNo) || (enume.getAll().LC_LIMIT_APPLICATION_APPROVED == status && '' == postErrorMsg && false == postsinosure && '' == openBankSwift && '' != corpOpenBankNo)){
                        let countryCodeArr = [];
                        let lastPayModeArr = [];
                        let ifRepeatArr = [];
                        let corpSerialNoName = lcRec.getValue('name');
                        let clientNo = lcRec.getValue(FIELD_MAPPING.clientNo);
                        let policyNo = lcRec.getValue(FIELD_MAPPING.policyNo);

                        let buyerChnName = lcRec.getValue(FIELD_MAPPING.buyerChnName);
                        if (buyerCountryCode && '-1' == countryCodeArr.indexOf(buyerCountryCode)) {
                            countryCodeArr.push(buyerCountryCode);
                        }
                        let buyerNo = '';
                        if (siNoSureBuyerNo){
                            let buyerRec = record.load({type:'customrecord_ecm_sinosure_buyercodeapply', id:siNoSureBuyerNo});
                            buyerNo = buyerRec.getValue('custrecord_esbya_buyerno');    // 买方代码申请-中信保买方代码
                        }
                        let bankNo = '';
                        if (openBankSwift){
                            let bankRec = record.load({type:'customrecord_ecm_sinosure_bankcodeapply', id:openBankSwift}); // 银行代码申请
                            bankNo = bankRec.getValue('custrecord_esba_bankswift'); // 企业填写的开证行SWIFT
                        }
                        let buyerChnAddress = lcRec.getValue(FIELD_MAPPING.buyerChnAddress);
                        let creditNo = lcRec.getValue(FIELD_MAPPING.creditNo);
                        let orgNo = lcRec.getValue(FIELD_MAPPING.orgNo);
                        let areaNo = lcRec.getValue(FIELD_MAPPING.areaNo);
                        let buyerRegNo = lcRec.getValue(FIELD_MAPPING.buyerRegNo);
                        let buyerTel = lcRec.getValue(FIELD_MAPPING.buyerTel);
                        let buyerFax = lcRec.getValue(FIELD_MAPPING.buyerFax);
                        let ifRepeat = lcRec.getValue(FIELD_MAPPING.ifRepeat); // 中信保-是否循环记录，取哪个字段用于接口传递
                        if (ifRepeat && '-1' == ifRepeatArr.indexOf(ifRepeat)) {
                            ifRepeatArr.push(ifRepeat);
                        }
                        let lcNo = lcRec.getValue(FIELD_MAPPING.lcNo);
                        let payTermApply = lcRec.getValue(FIELD_MAPPING.payTermApply);
                        let quotaSumApply = lcRec.getValue(FIELD_MAPPING.quotaSumApply);
                        let lcSum = lcRec.getValue(FIELD_MAPPING.lcSum);
                        let lastLadeDate = lcRec.getText(FIELD_MAPPING.lastLadeDate);
                        let goodsCode = lcRec.getValue(FIELD_MAPPING.goodsCode);   // 中信保-商品类别代码记录，取哪个字段用于接口传递
                        let elseGoodsName = lcRec.getValue(FIELD_MAPPING.elseGoodsName);

                        let corpOpenBankSwift = lcRec.getValue(FIELD_MAPPING.corpOpenBankSwift);
                        let openBankChnName = lcRec.getValue(FIELD_MAPPING.openBankChnName);
                        if (openBankCountryCode && '-1' == countryCodeArr.indexOf(openBankCountryCode)) {
                            countryCodeArr.push(openBankCountryCode);
                        }
                        let exBankSwift = lcRec.getValue(FIELD_MAPPING.exBankSwift);
                        let corpExBankNo = lcRec.getText(FIELD_MAPPING.corpExBankNo);
                        let corpExBankSwift = lcRec.getValue(FIELD_MAPPING.corpExBankSwift);
                        let exBankChnName = lcRec.getValue(FIELD_MAPPING.exBankChnName);
                        let exBankEngName = lcRec.getValue(FIELD_MAPPING.exBankEngName);
                        let exBankCountryCode = lcRec.getValue(FIELD_MAPPING.exBankCountryCode);   // 中信保-国家代码记录，取哪个字段用于接口传递
                        if (exBankCountryCode && '-1' == countryCodeArr.indexOf(exBankCountryCode)) {
                            countryCodeArr.push(exBankCountryCode);
                        }
                        let exBankAddress = lcRec.getValue(FIELD_MAPPING.exBankAddress);
                        let ifHistTrade = lcRec.getValue(FIELD_MAPPING.ifHistTrade);
                        if (ifHistTrade && '-1' == ifRepeatArr.indexOf(ifHistTrade)) {
                            ifRepeatArr.push(ifHistTrade);
                        }
                        let lastYear1 = lcRec.getValue(FIELD_MAPPING.lastYear1);
                        let lastPayMode1 = lcRec.getValue(FIELD_MAPPING.lastPayMode1); // 中信保-交易结算方式记录，取哪个字段用于接口传递
                        if (lastPayMode1 && lastPayMode1.length > 0){
                            for (let i = 0; i < lastPayMode1.length; i++){
                                if (lastPayMode1[i] && '-1' == lastPayModeArr.indexOf(lastPayMode1[i])) {
                                    lastPayModeArr.push(lastPayMode1[i]);
                                }
                            }
                        }
                        let lastSum1 = lcRec.getValue(FIELD_MAPPING.lastSum1);
                        let lastYear2 = lcRec.getValue(FIELD_MAPPING.lastYear2);
                        let lastPayMode2 = lcRec.getValue(FIELD_MAPPING.lastPayMode2); // 中信保-交易结算方式记录，取哪个字段用于接口传递
                        if (lastPayMode2 && lastPayMode2.length > 0){
                            for (let i = 0; i < lastPayMode2.length; i++){
                                if (lastPayMode2[i] && '-1' == lastPayModeArr.indexOf(lastPayMode2[i])) {
                                    lastPayModeArr.push(lastPayMode2[i]);
                                }
                            }
                        }
                        let lastSum2 = lcRec.getValue(FIELD_MAPPING.lastSum2);
                        let lastYear3 = lcRec.getValue(FIELD_MAPPING.lastYear3);
                        let lastPayMode3 = lcRec.getValue(FIELD_MAPPING.lastPayMode3); // 中信保-交易结算方式记录，取哪个字段用于接口传递
                        if (lastPayMode3 && lastPayMode3.length > 0){
                            for (let i = 0; i < lastPayMode3.length; i++){
                                if (lastPayMode3[i] && '-1' == lastPayModeArr.indexOf(lastPayMode3[i])) {
                                    lastPayModeArr.push(lastPayMode3[i]);
                                }
                            }
                        }
                        let lastSum3 = lcRec.getValue(FIELD_MAPPING.lastSum3);
                        let bankPayBehave = lcRec.getValue(FIELD_MAPPING.bankPayBehave);   // 中信保-银行付款表现记录，取哪个字段用于接口传递
                        let oweFlag = lcRec.getValue(FIELD_MAPPING.oweFlag);   // 中信保-银行付款异常原因代码记录，取哪个字段用于接口传递
                        let oweElseReson = lcRec.getValue(FIELD_MAPPING.oweElseReson);
                        let remark = lcRec.getValue(FIELD_MAPPING.remark);
                        let employeeName = lcRec.getValue(FIELD_MAPPING.employeeName);
                        let declaration = lcRec.getValue(FIELD_MAPPING.declaration);   // 默认为1
                        let applicant = lcRec.getValue(FIELD_MAPPING.applicant);
                        let applyTime = lcRec.getText(FIELD_MAPPING.applyTime);
                        let fileNum = lcRec.getValue(FIELD_MAPPING.fileNum);
                        let ifSameWithPolicy = lcRec.getValue(FIELD_MAPPING.ifSameWithPolicy); // TODO
                        if (ifSameWithPolicy && '-1' == ifRepeatArr.indexOf(ifSameWithPolicy)) {
                            ifRepeatArr.push(ifSameWithPolicy);
                        }
                        let preCreditTerm = lcRec.getValue(FIELD_MAPPING.preCreditTerm);
                        let afterCreditTerm = lcRec.getValue(FIELD_MAPPING.afterCreditTerm);
                        let ifHaveTradeFinancing = lcRec.getValue(FIELD_MAPPING.ifHaveTradeFinancing);
                        if (ifHaveTradeFinancing && '-1' == ifRepeatArr.indexOf(ifHaveTradeFinancing)) {
                            ifRepeatArr.push(ifHaveTradeFinancing);
                        }
                        let ifHaveRelation = lcRec.getValue(FIELD_MAPPING.ifHaveRelation);
                        if (ifHaveRelation && '-1' == ifRepeatArr.indexOf(ifHaveRelation)) {
                            ifRepeatArr.push(ifHaveRelation);
                        }
                        let relationDetail = lcRec.getValue(FIELD_MAPPING.relationDetail);
                        let isSameWithContract = lcRec.getValue(FIELD_MAPPING.isSameWithContract);
                        if (isSameWithContract && '-1' == ifRepeatArr.indexOf(isSameWithContract)) {
                            ifRepeatArr.push(isSameWithContract);
                        }
                        let noSameWithContractReaSo = lcRec.getValue(FIELD_MAPPING.noSameWithContractReaSo);
                        let errorCode = lcRec.getValue(FIELD_MAPPING.errorCode);
                        let errorMsg = lcRec.getValue(FIELD_MAPPING.errorMsg);

                        let countryCodeJson = {}, lastPayModeJson = {}, bankPayBehaveJson = {}, oweFlagJson = {}, ifRepeatJson = {}, goodCodeJson = {};
                        // 国家代码
                        if (countryCodeArr && countryCodeArr.length > 0){
                            countryCodeJson = getCode('customrecord_ecm_countrycode', countryCodeArr, 'custrecord_ec_code');
                        }

                        // 交易结算代码
                        if (lastPayModeArr && lastPayModeArr.length > 0){
                            lastPayModeJson = getCode('customrecord_ecm_paymode', lastPayModeArr, 'custrecord_epy_code');
                        }
                        if (bankPayBehave){
                            bankPayBehaveJson = getCode('customrecord_ecm_bankpaybehave', bankPayBehave, 'custrecord_ebb_code');

                        }
                        if (oweFlag){
                            oweFlagJson = getCode('customrecord_ecm_oweflag', oweFlag, 'custrecord_eof_code');
                        }
                        if (ifRepeatArr && ifRepeatArr.length > 0){
                            ifRepeatJson = getCode('customrecord_ecm_ifrepeat', ifRepeatArr, 'custrecord_eif_code');
                        }
                        if (goodsCode && goodsCode.length > 0){
                            goodCodeJson = getCode('customrecord_ecm_goodscode', goodsCode, 'custrecord_ego_code');
                        }

                        let datas = [];
                        let dataJson = {};
                        dataJson.corpSerialNo = corpSerialNoName;
                        dataJson.clientNo = clientNo;
                        dataJson.policyNo = policyNo;
                        dataJson.sinosureBuyerNo = buyerNo;
                        dataJson.corpBuyerNo = corpBuyerNo;
                        dataJson.buyerChnName = buyerChnName;
                        dataJson.buyerEngName = buyerEngName;
                        dataJson.buyerCountryCode = countryCodeJson[buyerCountryCode] || '';
                        dataJson.buyerEngAddress = buyerEngAddress;
                        dataJson.regionCode = regionCode;
                        dataJson.buyerChnAddress = buyerChnAddress;
                        dataJson.creditno = creditNo;
                        dataJson.orgno = orgNo;
                        dataJson.areaNo = areaNo;
                        dataJson.buyerRegNo = buyerRegNo;
                        dataJson.buyerTel = buyerTel;
                        dataJson.buyerFax = buyerFax;
                        dataJson.ifRepeat = ifRepeatJson[ifRepeat] || '';
                        dataJson.lcNo = lcNo;
                        dataJson.payTermApply = payTermApply;
                        dataJson.quotaSumApply = quotaSumApply;
                        dataJson.lcSum = lcSum;
                        dataJson.lastLadeDate = getDateFormat(lastLadeDate);
                        dataJson.goodsCode = getDatas(goodsCode, goodCodeJson);
                        dataJson.elsegoodsName = elseGoodsName;
                        dataJson.openBankSwift = bankNo;
                        dataJson.corpOpenBankNo = corpOpenBankNo;
                        dataJson.corpOpenBankSwift = corpOpenBankSwift;
                        dataJson.openBankChnName = openBankChnName;
                        dataJson.openBankEngName = openBankEngName;
                        dataJson.openBankCountryCode = countryCodeJson[openBankCountryCode] || '';
                        dataJson.openBankAddress = openBankAddress;
                        dataJson.exBankSwift = exBankSwift;
                        dataJson.corpExBankNo = corpExBankNo;
                        dataJson.corpExBankSwift = corpExBankSwift;
                        dataJson.exBankChnName = exBankChnName;
                        dataJson.exBankEngName = exBankEngName;
                        dataJson.exBankCountryCode = countryCodeJson[exBankCountryCode] || '';
                        dataJson.exBankAddress = exBankAddress;
                        dataJson.ifhisttrade = ifRepeatJson[ifHistTrade] || '';
                        dataJson.lastYear1 = lastYear1;
                        dataJson.lastPayMode1 = getDatas(lastPayMode1, lastPayModeJson);
                        dataJson.lastSum1 = lastSum1;
                        dataJson.lastYear2 = lastYear2;
                        dataJson.lastPayMode2 = getDatas(lastPayMode2, lastPayModeJson);
                        dataJson.lastSum2 = lastSum2;
                        dataJson.lastYear3 = lastYear3;
                        dataJson.lastPayMode3 = getDatas(lastPayMode3, lastPayModeJson);
                        dataJson.lastSum3 = lastSum3;
                        dataJson.bankPayBehave = bankPayBehaveJson[bankPayBehave] || '';
                        dataJson.oweFlag = oweFlagJson[oweFlag] || '';
                        dataJson.oweElseReson = oweElseReson;
                        dataJson.remark = remark;
                        dataJson.employeeName = employeeName;
                        dataJson.declaration = declaration;
                        dataJson.applicant = applicant;
                        dataJson.applyTime = getDateFormat(applyTime);
                        dataJson.filenum = fileNum;
                        dataJson.ifsamewithpolicy = ifRepeatJson[ifSameWithPolicy];
                        dataJson.precreditterm = preCreditTerm;
                        dataJson.aftercreditterm = afterCreditTerm;
                        dataJson.ifhavetradefinancing = ifRepeatJson[ifHaveTradeFinancing] || '';
                        dataJson.ifhaverelation = ifRepeatJson[ifHaveRelation] || '';
                        dataJson.relationdetail = relationDetail;
                        dataJson.issamewithcontract = ifRepeatJson[isSameWithContract] || '';
                        dataJson.nosamewithcontractreason = noSameWithContractReaSo;
                        datas.push(dataJson);
                        let body = {};
                        body.datas = datas;
                        body.imethod = IMETHOD;
                        log.debug('body',body)
                        try{
                            rtnData = interfaceTool.requestEdiServer(body, enume.getAll().ECM_INTERFACE_TYPE_LC_LIMIT_APPLICATION);// 接口类型：LC限额申请
                            log.debug('rtnData', rtnData)
                            logUpdVal.custrecord_hc_inf_process_msg = newRec.id;
                            record.submitFields({
                                type: LOG_TYPE,
                                id: rtnData.logId,
                                values: logUpdVal
                            });
                            let lcRec = record.load({
                                type:newRec.type,
                                id:newRec.id
                            });
                            if (true == rtnData.valid && '' == rtnData.data.errormsg){
                                lcRec.setValue({fieldId:FIELD_MAPPING.postsinosure, value: true});
                                lcRec.setValue({fieldId:FIELD_MAPPING.posterromsg, value: ''});
                                lcRec.save({enableSourcing:true, ignoreMandatoryFields:true});
                            }else {
                                lcRec.setValue({fieldId:FIELD_MAPPING.postsinosure, value: false});
                                lcRec.setValue({fieldId:FIELD_MAPPING.posterromsg, value: rtnData.data.errormsg});
                                lcRec.save({enableSourcing:true, ignoreMandatoryFields:true});
                            }
                        }catch (e){
                            logUpdVal.custrecord_hc_inf_process_msg = e.message;
                            logUpdVal.custrecord_hc_inf_errorflag = true;
                            record.submitFields({
                                type: LOG_TYPE,
                                id: rtnData.logId,
                                values: logUpdVal
                            });
                            let lcRec = record.load({
                                type:newRec.type,
                                id:newRec.id
                            });
                            lcRec.setValue({fieldId:FIELD_MAPPING.postsinosure, value: false});
                            lcRec.setValue({fieldId:FIELD_MAPPING.posterromsg, value: rtnData.data.errormsg});
                            lcRec.save({enableSourcing:true, ignoreMandatoryFields:true});
                        }
                    }
                }

            }catch (e){
                log.error('LC限额申请error===>' + newRec.id, e);
                let lcRec = record.load({type:newRec.type, id:newRec.id});
                lcRec.setValue({fieldId:FIELD_MAPPING.errorMsg, value:e.message});
                lcRec.save({enableSourcing:true, ignoreMandatoryFields:true});
            }
        }

        /**
         * 日期转换
         * @param date
         * @returns {string}
         */
        const getDateFormat = (date) => {
            date = new Date(date);
            let year = date.getFullYear();
            let month = date.getMonth() + 1;
            let day = date.getDate();
            if (month < 10){
                month = '0' + month;
            }
            if (day < 10){
                day = '0' + day;
            }
            return year + '-' + month + '-' + day;
        }

        /**
         * 数据转换
         * @param code
         * @param codeJson
         * @returns {*}
         */
        const getDatas = (code, codeJson) => {
            let data;
            if (code && code.length > 1){
                let goodCodeArr = '';
                for (let i = 0; i < code.length; i++){
                    if (0!=i){
                        goodCodeArr += ',' ;
                    }
                    goodCodeArr += codeJson[code[i]];
                }
                data = goodCodeArr;
            }else {
                data = codeJson[code] || '';
            }
            log.debug('code-->'+code, data)
            return data;
        }

        /**
         * 搜索各记录代码字段
         * @param searchType
         * @param codeArr
         * @param fieldId
         * @returns {{}}
         */
        const getCode = (searchType, codeArr, fieldId) => {
            let myFilters = [];
            myFilters.push(['isinactive', 'is', 'false']);
            let insideFilters = [];
            if (codeArr && codeArr.length > 0){
                myFilters.push('and');
                for (let i = 0; i < codeArr.length; i++){
                    if(0!=i){
                        insideFilters.push('or')
                    }
                    insideFilters.push(['internalid', 'anyof', codeArr[i]]);
                }
                myFilters.push(insideFilters);
            }
            let myColumns = [];
            myColumns.push('internalid');
            myColumns.push(fieldId);
            let mySearch = search.create({
                type:searchType,
                filters:myFilters,
                columns:myColumns
            });
            let myResult = mySearch.run().getRange({start:0, end:1000});
            let codeJson = {};
            if (myResult && myResult.length > 0){
                for (let i = 0; i < myResult.length; i++){
                    let internalid = myResult[i].getValue(myColumns[0]);
                    let code = myResult[i].getValue(myColumns[1]);
                    codeJson[internalid] = code;
                }
            }
            return codeJson;
        }

        return {/*beforeLoad, beforeSubmit, */afterSubmit}

    });
