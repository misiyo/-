/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * Version          Date          Author        Remark
 * 1.0              2023/3/2      Kori          TAPD【1018618】基于SP公司间自动生成账单
 * 1.1              2023/3/7      Kori          TAPD【1018618】账单class字段、memo字段取值变更，ordertype条件
 * 1.2              2023/3/9      Kori          合并will生成日记账
 * 1.3              2023/3/13     Kori          增加取值字段
 * 1.4              2023/3/14     Kori          优化
 * 1.5              2023/3/21     Kori          优化rate数值异常问题
 * 2.0              2023/4/7      Kori          合并ir转移数量至scd脚本
 * 2.1              2023/02/28    Kori          TAPD【1018680】根据PO创建IR单后，将采购收货单的数量反写SP子记录的【实际出运数量】。
 * 2.2              2023/03/01    Kori          记录type、sublistId、fieldId变更及测试支持
 * 2.3              2023/03/03    Kori          数量回写改为数量相加
 * 2.4              2023/04/06    Kori          明细行回写条件ECM唯一键改为spLine
 */
define(['N/record', 'N/runtime', 'N/search', 'N/url', 'N/https', '../tools/common_api.js'],
    /**
 * @param{record} record
 * @param{runtime} runtime
 * @param{search} search
 * @param{url} url
 */
    (record, runtime, search, url, https, commonApi) => {
        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed before record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const beforeSubmit = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {
            irRecordCreateAccountAndJournalentry(scriptContext);//ir单自动生成日记账、账单
        }

        /**
         * ir单自动生成日记账、账单
         * @param scriptContext
         */
        const irRecordCreateAccountAndJournalentry = (scriptContext) => {
            let newRec = scriptContext.newRecord;
            let recType = scriptContext.type;
            if(recType == 'delete'){
                return;
            }
            let accountId = irRecordCreateAccount(scriptContext, newRec, recType);//ir单自动生成日记账、账单
            irRecordCreateJournalentry(recType,accountId);//ir单自动生成日记账
        }

        /**
         * ir单生成账单
         * @param scriptContext
         */
        const irRecordCreateAccount = (scriptContext, newRec, recType) => {
            let accountRec;
            let accountId;

            let orderType = newRec.getValue('custbody_ecm_ordertype');
            let poId = newRec.getValue('createdfrom');
            let isPoRec = true;
            if (poId) {
                let createFromTypeInfo = search.lookupFields({
                    type: 'itemreceipt',
                    id: newRec.id,
                    columns: ['createdfrom.type']
                });
                let createFromType = createFromTypeInfo['createdfrom.type'][0].value;
                if (createFromType != 'PurchOrd') {
                    isPoRec = false;
                }
            }

            irChangeSpLineQty(newRec, isPoRec, recType)//自动带值到sp Qty
            if ((orderType == 3 || orderType == '3') && isPoRec) {//ir生成账单
                try {
                    if (recType == 'create') {
                        let poId = newRec.getValue('createdfrom');
                        accountRec = record.transform({
                            fromType: record.Type.PURCHASE_ORDER,
                            fromId: poId,
                            toType: record.Type.VENDOR_BILL,
                            isDynamic: false,
                        })
                    } else if (recType == 'edit') {
                        accountId = newRec.getValue('custbody_ecm_je_bill');
                        if (accountId) {
                            accountRec = record.load({type: 'vendorbill', id: accountId});
                        } else {
                            let poId = newRec.getValue('createdfrom');
                            accountRec = record.transform({
                                fromType: record.Type.PURCHASE_ORDER,
                                fromId: poId,
                                toType: record.Type.VENDOR_BILL,
                                isDynamic: false,
                            })
                        }
                    }
                    let {bodyData, itemData, keyArr} = getIrData(newRec);

                    //account Body塞值
                    for (key in bodyData) {
                        if (bodyData[key] && key != 'class1' && key != 'trandate') {
                            accountRec.setValue({fieldId: key, value: bodyData[key]})
                        } else if (bodyData[key] && key == 'class1' && key != 'trandate') {
                            accountRec.setValue({fieldId: 'class', value: bodyData[key]})
                        } else {//trandate
                            accountRec.setText({fieldId: key, text: bodyData[key]})
                        }
                    }
                    //account 明细行 塞值
                    if (itemData.length > 0) {
                        let itemCount = accountRec.getLineCount({sublistId: 'item'});
                        if (itemCount > 0) {//移除已存在行
                            for (let i = itemCount - 1; i >= 0; i--) {
                                if (keyArr.length <= i) {
                                    accountRec.removeLine({sublistId: 'item', line: i});
                                }
                            }
                        }
                        for (let index = 0; index < itemData.length; index++) {
                            accountRec.setSublistValue({
                                sublistId: 'item',
                                fieldId: 'location',
                                value: itemData[index].lineLoc,
                                line: index
                            });
                            accountRec.setSublistValue({
                                sublistId: 'item',
                                fieldId: 'quantity',
                                value: String(itemData[index].lineQty),
                                line: index
                            });
                            accountRec.setSublistValue({
                                sublistId: 'item',
                                fieldId: 'rate',
                                value: itemData[index].lineRate,
                                line: index
                            });

                            let invRec = accountRec.getSublistSubrecord({
                                sublistId: 'item',
                                fieldId: 'inventorydetail',
                                line: index
                            });
                            let invCount = invRec.getLineCount({sublistId: 'inventoryassignment'});
                            if (invCount > 0) {
                                for (let k = invCount - 1; k >= 0; k--) {
                                    invRec.removeLine({sublistId: 'inventoryassignment', line: k});
                                }
                            }
                            invRec.setSublistValue({
                                sublistId: 'inventoryassignment',
                                fieldId: 'receiptinventorynumber',
                                value: itemData[index].receiptNumber,
                                line: 0
                            })
                            invRec.setSublistValue({
                                sublistId: 'inventoryassignment',
                                fieldId: 'quantity',
                                value: itemData[index].lineQty,
                                line: 0
                            });
                        }
                    }

                    accountId = accountRec.save({enableSourcing: true, ignoreMandatoryFields: true});

                    if (accountId) {//反写
                        let irRec = record.load({type: 'itemreceipt', id: newRec.id});
                        irRec.setValue({fieldId: 'custbody_ecm_je_bill', value: accountId});
                        irRec.save({enableSourcing: true, ignoreMandatoryFields: true});

                    }
                } catch (e) {
                    log.error('e', e.message);
                }
            }
            return accountId;
        }

        const irChangeSpLineQty = (newRec, isPoRec,recType) => {
            //IR QTY
            if(isPoRec && ((recType == 'edit' && 'USERINTERFACE' == runtime.executionContext) || recType == 'create')){
                var lineCount = newRec.getLineCount('item');
                if(lineCount > 0){
                    var spId = newRec.getValue('custbody_ecm_sp');
                    var irCreateFrom = newRec.getValue('createdfrom');
                    if(spId){
                        var spRec = record.load({type:'customrecord_ecm_sp', id:spId});
                        var spStatus = spRec.getValue('custrecord_sp_status');
                        if(spStatus != '5' && spStatus != 5){//未完结
                            var irData = getIrData1(newRec);
                            if(irData.length > 0){//sp回写数量
                                var spCount = spRec.getLineCount({sublistId:'recmachcustrecord_scdline_sp'});
                                for(var i = 0; i < spCount; i++){
                                    for(var j =0; j < irData.length; j++){
                                        var spItem = spRec.getSublistValue({sublistId:'recmachcustrecord_scdline_sp', fieldId:'custrecord_scdline_item', line: i});
                                        var spId = spRec.getSublistValue({sublistId:'recmachcustrecord_scdline_sp', fieldId:'id', line: i});
                                        if(spId){
                                            var spInfo = search.lookupFields({
                                                type:'customrecord_ecm_scd_line',
                                                id:spId,
                                                columns:['custrecord_scdline_purchaseorder']
                                            });
                                            if(Object.keys(spInfo['custrecord_scdline_purchaseorder']).length > 0){
                                                var spCreatedFrom = spInfo['custrecord_scdline_purchaseorder'][0].value;
                                            }else{
                                                var spCreatedFrom = '';
                                            }

                                        }
                                        var spQty = spRec.getSublistValue({sublistId:'recmachcustrecord_scdline_sp', fieldId:'custrecord_scdline_spqty', line: i}) || 0;
                                        if(spCreatedFrom == irCreateFrom && Number(spId) == Number(irData[j].irLine)){
                                            // var spNewQty = Number(spQty).add(Number(irData[j].irQty));
                                            log.debug('irData[j].irQty',irData[j].irQty);
                                            spRec.setSublistValue({sublistId:'recmachcustrecord_scdline_sp',fieldId:'custrecord_scdline_spqty',value:irData[j].irQty,line:i})
                                        }
                                    }
                                }
                                spRec.save({enableSourcing:true,ignoreMandatoryFields:true});
                            }
                        }
                    }
                }
            }
        }

        /**
         * ir单生成日记账
         * @param recType
         * @param accountId
         */
        const irRecordCreateJournalentry = (recType,accountId) => {
            if(recType == 'create' && accountId) {
                //新增：will生成日记账
                let obj = {id : accountId, type : 'vendorbill'};
                let slUrl = url.resolveScript({
                    scriptId: 'customscript_ecm_sl_create_je',
                    deploymentId: 'customdeploy_ecm_sl_create_je',
                    returnExternalUrl: true
                });
                slUrl += '&rid=' + encodeURIComponent(accountId);
                if (runtime.executionContext !== runtime.ContextType.SUITELET) {
                    log.debug('runtime.executionContext',runtime.executionContext);
                    let response = https.post({
                        url: slUrl,
                        body: obj,
                    });
                }
            }
        }

        /**
         * 获取IR单数据
         * @param newRec
         * @returns {{itemData: *[], bodyData: {}}}
         */
        const getIrData = (newRec) => {
            let bodyData = getIrBodyData(newRec);
            let {itemData, keyArr} = getIrItemData(newRec);
            return {bodyData,itemData,keyArr};
        }

        /**
         * 获取IR单body字段数据
         * @param newRec
         * @returns {{}}
         */
        const getIrBodyData = (newRec) => {
            let bodyData = {};
            let custbody_ecm_ordertype = newRec.getValue('custbody_ecm_ordertype');//待确定
            let trandate = newRec.getValue('trandate');
            let entity = newRec.getValue('entity');
            let currency = newRec.getValue('currency');
            let subsidiary = newRec.getValue('subsidiary');
            let class1 = newRec.getValue('class');
            let department = newRec.getValue('department');
            let exchangerate = newRec.getValue('exchangerate');
            let custbody_ecm_sp = newRec.getValue('custbody_ecm_sp');
            let poId = newRec.getValue('createdfrom');
            let custbody_ecm_icposo_transaction = '';
            if(poId){
                let companyOrder = search.lookupFields({
                    type:'purchaseorder',
                    id:poId,
                    columns:['custbody_ecm_icposo_transaction']
                });
                custbody_ecm_icposo_transaction = companyOrder['custbody_ecm_icposo_transaction'][0].value;
            }

            bodyData.entity = entity;
            // bodyData.subsidiary = subsidiary;
            bodyData.custbody_ecm_ordertype = custbody_ecm_ordertype;
            bodyData.trandate = trandate;
            bodyData.currency = currency;
            bodyData.class1 = class1;
            bodyData.department = department;
            bodyData.exchangerate = exchangerate;
            bodyData.custbody_ecm_sp = custbody_ecm_sp;
            bodyData.custbody_ecm_icposo_transaction = custbody_ecm_icposo_transaction;
            return bodyData;
        }

        /**
         * 获取IR单明细行数据
         * @param newRec
         * @returns {*[]}
         */
        const getIrItemData = (newRec) => {
            let itemData = [];
            let keyArr = [];
            let irRec = record.load({type:'itemreceipt',id:newRec.id})
            let lineCount = irRec.getLineCount({sublistId:'item'});
            if(lineCount > 0){
                for(let index  = 0; index < lineCount; index++){
                    let lineItem = irRec.getSublistValue({sublistId:'item',fieldId:'item',line:index});//货品
                    let lineQty = irRec.getSublistValue({sublistId:'item',fieldId:'quantity',line:index}) || 0;//数量
                    let lineLoc = irRec.getSublistValue({sublistId:'item',fieldId:'location',line:index});//地点
                    let lineRate = irRec.getSublistValue({sublistId:'item',fieldId:'rate',line:index});//单价
                    let lineSpLine = irRec.getSublistValue({sublistId:'item',fieldId:'custcol_ecm_uniquekey',line:index});//修改：取值不匹配
                    let lineSpLine1 = irRec.getSublistValue({sublistId:'item',fieldId:'custcol_emc_line_no',line:index});//修改：取值不匹配
                    //明细行货品对应的采购订单
                    let poId = irRec.getValue('createdfrom');
                    let poRec = record.load({type:'purchaseorder',id:poId});
                    let poLine = poRec.findSublistLineWithValue({sublistId:'item',fieldId:'custcol_emc_line_no',value:lineSpLine1});//对应行
                    let lineTaxcode = '';
                    if(poLine != -1 && poLine != '-1'){
                        lineTaxcode = poRec.getSublistValue({sublistId:'item', fieldId:'taxcode', line:poLine});//税码
                    }
                    let lineUnit = irRec.getSublistValue({sublistId:'item',fieldId:'units',line:index});//计量单位
                    //获取库存详细信息序列号
                    let invRec = irRec.getSublistSubrecord({sublistId:'item',fieldId:'inventorydetail',line:index});
                    let invCount = invRec.getLineCount({sublistId:'inventoryassignment'});
                    let receiptNumber = '';
                    if(invCount > 0){
                        receiptNumber = invRec.getSublistValue({sublistId:'inventoryassignment',fieldId:'receiptinventorynumber',line:0});
                    }

                    let irJson = {
                        'lineItem':lineItem,
                        'lineQty':lineQty,
                        'lineLoc':lineLoc,
                        'lineRate':lineRate,
                        'lineSpLine':lineSpLine,
                        'lineTaxcode':lineTaxcode,
                        'receiptNumber':receiptNumber,
                        'lineUnit':lineUnit
                    }
                    itemData.push(irJson);
                    if(lineSpLine1){
                        keyArr.push(lineSpLine1);
                    }
                }
            }
            return {itemData, keyArr};
        }

        /**
         * 获取IR单明细行的数据
         * @param newRec
         * @returns {*[]}
         */
        function getIrData1(newRec) {
            var irData = [];
            var spArr = getAllSpSublistQty();//获取所有sp关联ir的总数量
            log.debug('spArr',spArr);
            var irCount = newRec.getLineCount({sublistId:'item'});
            if(irCount > 0){
                for(var index = 0; index < irCount; index ++){
                    var irRelateSp = newRec.getValue('custbody_ecm_sp');
                    var irItem = newRec.getSublistValue({sublistId:'item', fieldId:'item', line:index});
                    // var irLine = newRec.getSublistValue({sublistId:'item', fieldId:'custcol_ecm_uniquekey', line:index});
                    var irLine = newRec.getSublistValue({sublistId:'item', fieldId:'custcol_ecm_spline', line:index});
                    // var irQty = newRec.getSublistValue({sublistId:'item', fieldId:'quantity', line:index}) || 0;
                    var irQty = 0;
                    if(spArr.length > 0){
                        for(var a = 0; a < spArr.length; a++){
                            if(String(spArr[a].spid) == String(irRelateSp) && String(spArr[a].spLine) == String(irLine)){
                                irQty = spArr[a].spQty;
                                log.debug('irQty',irQty)
                                break;
                            }
                        }
                    }
                    var irJson = {
                        irItem:irItem,
                        irLine:irLine,
                        irQty:irQty,
                    }
                    log.debug('irJson',irJson);
                    var createIr = true;
                    for(var i = 0; i < irData.length; i++){
                        if(irData[i].irItem == irItem && irLine == irData[i].irLine){
                            createIr = false;
                            irData[i].irQty = Number(irData[i].irQty).add(Number(irQty));
                            break;
                        }
                    }
                    if(createIr && irLine){//首行
                        irData.push(irJson)
                    }
                }
            }
            return irData;
        }

        function getAllSpSublistQty() {
            var spArr = [];
            var spSearch = search.load({id:'customsearch_ecm_irrewritescdl_qty'});
            var spRes = commonApi.getAllData(spSearch);
            var spColumns =spSearch.columns;
            if(spRes.length > 0){
                for(var index = 0; index < spRes.length; index++){
                    var spid = spRes[index].getValue(spColumns[0]);
                    var spLine = spRes[index].getValue(spColumns[1]);
                    var spQty = spRes[index].getValue(spColumns[2]);
                    var spJson = {
                        'spid' : spid,
                        'spLine' : spLine,
                        'spQty' : spQty,
                    }
                    spArr.push(spJson)
                }
            }
            return spArr;
        }

        return {/**beforeLoad, beforeSubmit, **/afterSubmit}

    });


