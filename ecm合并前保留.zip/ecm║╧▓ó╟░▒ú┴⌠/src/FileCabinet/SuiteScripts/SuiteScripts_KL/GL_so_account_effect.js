/**
 * Version        Date            Author            Remarks
 * 1.0            2023/3/2       Kori Li           TAPD【1019138】公司间IF,发票总账影响科目取值
 */


function customizeGlImpact(transactionRecord, standardLines, customLines, book) {
    //加载IF单或invoice
    var orderType = transactionRecord.getFieldValue('custbody_ecm_ordertype');//生成总账影响条件：“custbody_ecm_ordertype”字段值为“Intercompany Order”
    var irId = transactionRecord.getFieldValue('createdfrom');//生成总账影响条件：so
    // nlapiLogExecution('DEBUG', 'irId', irId);
    var isTHStyle = true;
    if (irId) {
        var soInfo = searchRelatedRecordType(irId);//获取createfrom类型
        var accountJson = getAllItemAccountInfos(transactionRecord);
        if (soInfo.tuihuoType != 'SalesOrd') {
            isTHStyle = false;
        }
    }
    var type = transactionRecord.recordType;
    //IF
    if (type == 'itemfulfillment' && (orderType == 3 || orderType == '3') && isTHStyle) {
        //获取标准总账影响数据
        var stdCnt = standardLines.getCount();
        var arr = [];
        for (var j = 0; j < stdCnt; j++) {
            var oneStdLine = standardLines.getLine(j);
            var accountId = oneStdLine.getAccountId();
            var classId = oneStdLine.getClassId();
            var debitAmt = oneStdLine.getDebitAmount() || 0; // 借
            var creditAmt = oneStdLine.getCreditAmount() || 0; // 贷
            var memo = oneStdLine.getMemo(); // memo
            var entityId = oneStdLine.getEntityId(); // name
            var departmentId = oneStdLine.getDepartmentId();
            var locationId = oneStdLine.getLocationId();

            if (Number(debitAmt) > 0 || Number(creditAmt) > 0) {
                if (Number(debitAmt) > 0 &&( (j-1)%3 == 0)) {
                    var oldLineObj = {//原借
                        'accountId': accountId, //贷方科目取借方科目
                        'classId': classId,
                        'debitAmt': debitAmt,
                        'creditAmt': creditAmt,
                        'memo': memo,
                        'entityId': entityId,
                        'departmentId': departmentId,
                        'locationId': locationId
                    }
                    arr.push(oldLineObj);
                    if(j > 1){
                        var s = ((j - 1) / 3) + 1;

                    }else{
                        s = 1;
                    }
                    var newLineObj = {//贷
                        'accountId': accountJson[s].intercocogsaccountId, //借方科目取贷方科目
                        'classId': classId,
                        'debitAmt': creditAmt,
                        'creditAmt': debitAmt,
                        'memo': memo,
                        'entityId': entityId,
                        'departmentId': departmentId,
                        'locationId': locationId,
                    }
                    arr.push(newLineObj);
                }
            }
        }
        if (arr.length > 0) {//创建自定义GL总账科目
            var custCnt = customLines.getCount();
            for (var b = 0; b < arr.length; b++) {
                var newCusline = customLines.addNewLine();
                var oneCusLine = arr[b];
                newCusline.setAccountId(Number(oneCusLine.accountId));
                if (oneCusLine.debitAmt && Number(oneCusLine.debitAmt) > 0) {
                    newCusline.setCreditAmount(Number(oneCusLine.debitAmt));
                } else if (oneCusLine.creditAmt && Number(oneCusLine.creditAmt) > 0) {
                    newCusline.setDebitAmount(Number(oneCusLine.creditAmt));
                }
                newCusline.setMemo(oneCusLine.memo);
                newCusline.setEntityId(oneCusLine.entityId);
                newCusline.setDepartmentId(oneCusLine.departmentId);
                newCusline.setClassId(oneCusLine.classId);
                newCusline.setLocationId(oneCusLine.locationId);
            }
        }
    }
    //invoice
    if (type == 'invoice' && (orderType == 3 || orderType == '3') && isTHStyle) {
        //获取标准总账影响数据
        var stdCnt = standardLines.getCount();
        var arr = [];
        var arr1 = [];
        for (var j = 0; j < stdCnt - 1; j++) {//忽略隐藏行VAT
            var oneStdLine = standardLines.getLine(j);
            var accountId = oneStdLine.getAccountId();
            var classId = oneStdLine.getClassId();
            var debitAmt = oneStdLine.getDebitAmount() || 0; // 借
            var creditAmt = oneStdLine.getCreditAmount() || 0; // 贷
            var memo = oneStdLine.getMemo(); // memo
            var entityId = oneStdLine.getEntityId(); // name
            var departmentId = oneStdLine.getDepartmentId(); // department
            var locationId = oneStdLine.getLocationId(); // location

            if (Number(debitAmt) > 0 || Number(creditAmt) > 0) {
                if (Number(creditAmt) > 0) {
                    var oldLineObj = {//贷=>借
                        'accountId': accountId, //借方科目取贷方科目
                        'classId': classId,
                        'debitAmt': debitAmt,
                        'creditAmt': creditAmt,
                        'memo': memo,
                        'entityId': entityId,
                        // 'departmentId': departmentId,
                    }
                    arr.push(oldLineObj);
                    var newLineObj = {//借
                        'accountId': accountJson[j].intercoincomeaccountId, //借方科目取货品科目
                        'classId': classId,
                        'debitAmt': creditAmt,
                        'creditAmt': debitAmt,
                        'memo': memo,
                        'entityId': entityId,
                        // 'departmentId': departmentId,
                    }
                    arr1.push(newLineObj);
                }
            }
        }
        var arr2 = arr.concat(arr1);
        if (arr2.length > 0) {//创建自定义GL总账科目
            var custCnt = customLines.getCount();
            for (var b = 0; b < arr2.length; b++) {
                var newCusline = customLines.addNewLine();
                var oneCusLine = arr2[b];
                newCusline.setAccountId(Number(oneCusLine.accountId));
                if (oneCusLine.debitAmt && Number(oneCusLine.debitAmt) > 0) {
                    newCusline.setCreditAmount(Number(oneCusLine.debitAmt));
                } else if (oneCusLine.creditAmt && Number(oneCusLine.creditAmt) > 0) {
                    newCusline.setDebitAmount(Number(oneCusLine.creditAmt));
                }
                if(oneCusLine.memo){
                    newCusline.setMemo(oneCusLine.memo);
                }
                if(oneCusLine.entityId){
                    newCusline.setEntityId(oneCusLine.entityId);
                }
                if(oneCusLine.classId){
                    newCusline.setEntityId(oneCusLine.classId);
                }
                // if(oneCusLine.locationId){
                //     newCusline.setEntityId(oneCusLine.locationId);
                // }
            }
        }
    }
}

//获取创建自记录类型
function searchRelatedRecordType(irId) {
    try{
        var soInfo = {};
        var columns = new Array();
        var filters = [];
        filters.push(new nlobjSearchFilter("internalid",null,"anyof",irId));
        filters.push(new nlobjSearchFilter("mainline",null,"is","T"));
        columns[0] = new nlobjSearchColumn("type");
        columns[1] = new nlobjSearchColumn("typecode");
        var search  = nlapiCreateSearch("transaction", filters, columns);
        var res = search.runSearch().getResults(0,1);
        nlapiLogExecution('DEBUG','searchRes ==', JSON.stringify(res));
        if(res.length > 0){
            var tuihuoType = res[0].getValue('typecode');
            soInfo.tuihuoType = tuihuoType;
        }
    }catch (e) {
        nlapiLogExecution('DEBUG', 'e', e.message);
    }
    return soInfo;
}

//获取货品账户
function getAllItemAccountInfos(tarRec) {
    var accountJson = {};
    var lineCnt = tarRec.getLineItemCount('item');
    nlapiLogExecution('DEBUG','行数量',lineCnt);
    var lineNo = 0;
    for (var i = 1; i <= lineCnt; i++) {
        lineNo++;
        var itemiid = tarRec.getLineItemValue('item', 'item', i);
        var filters = [];
        var columns = new Array();
        filters.push(new nlobjSearchFilter("internalid", null, "anyof", itemiid));
        columns[0] = new nlobjSearchColumn("internalid");
        columns[1] = new nlobjSearchColumn("intercoexpenseaccount");
        columns[2] = new nlobjSearchColumn("incomeaccount");
        columns[3] = new nlobjSearchColumn("intercoincomeaccount");
        columns[4] = new nlobjSearchColumn("salesdescription");
        var resultSearch = nlapiCreateSearch("item", filters, columns);
        var resultRun = resultSearch.runSearch();
        resultRun.forEachResult(function (searchResult) {
            var itemid = searchResult.getValue(columns[0]);
            var intercocogsaccountId = searchResult.getValue(columns[1]);
            var incomeaccountId = searchResult.getValue(columns[2]);
            var intercoincomeaccountId = searchResult.getValue(columns[3]);
            var description = searchResult.getValue(columns[4]);
            var resJson = {
                'itemid':itemid,
                'lineNo':lineNo,
                'intercocogsaccountId' : Number(intercocogsaccountId),
                'incomeaccountId' : Number(incomeaccountId),
                'intercoincomeaccountId' : Number(intercoincomeaccountId),
                'description' : description
            }
            accountJson[lineNo] = resJson;
            return true;
        });
    }
    return accountJson;
}
