/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 * Version          Date           Author            Remarks
 * 1.0              2023/3/21      Kori              TAPD【1019293】到达按钮
 * 2.0              2023/4/07      Kori              新增会计期间关闭弹窗
 * 3.0              2023/4/09      Kori              优化
 * 待补充            待补充          待补充              回写字段status正式环境校验
 */
define(['N/record', 'N/search', 'N/ui/serverWidget', '../tools/common_api.js'],
    /**
 * @param{record} record
 * @param{search} search
 * @param{serverWidget} serverWidget
 */
    (record, search, serverWidget, commonApi) => {
        /**
         * Defines the Suitelet script trigger point.
         * @param {Object} scriptContext
         * @param {ServerRequest} scriptContext.request - Incoming request
         * @param {ServerResponse} scriptContext.response - Suitelet response
         * @since 2015.2
         */
        const onRequest = (scriptContext) => {
            let request = scriptContext.request;
            let response = scriptContext.response;
            let param = request.parameters;
            let method = request.method;
            let spId = param.spId;
            if('GET' == method){
                let curForm = serverWidget.createForm({title:'Fill in the arrival Information', hideNavBar:false});
                curForm.addSubmitButton('Submit');
                let dateOfArrival = curForm.addField({id:'custpage_date', type:'DATE', label:'Date of arrival'});
                dateOfArrival.isMandatory = true;
                let spRecId = curForm.addField({id:'custpage_spid', type:'text', label:'SP ID'});
                spRecId.defaultValue = spId;
                spRecId.updateDisplayType({
                    displayType : serverWidget.FieldDisplayType.HIDDEN
                });
                response.writePage(curForm);
            }else{
                let dateOfArrival = param.custpage_date;
                let spRecId  = param.custpage_spid;
                //根据日期判断 会计期间是否关闭
                if(dateOfArrival){
                    let periodIsOpen = checkPeriodIsCloseOrNot(dateOfArrival);
                    if(periodIsOpen){
                        let newRec = record.load({type:'customrecord_ecm_sp', id:Number(spRecId)});
                        newRec.setText({fieldId:'custrecord_sp_arrivaldate',text:dateOfArrival});
                        newRec.setValue({fieldId:'custrecord_sp_status',value:4});//到达
                        newRec.save({enableSourcing:true,ignoreMandatoryFields:true});
                        //刷新父页面后关闭窗口
                        response.write('<script>window.opener.location.reload();window.close();</script>')
                    }else{
                        // alert('You cannot use this date as the accounting period has been closed.');
                        response.write('You cannot use this date as the accounting period has been closed.')
                    }
                }
            }
        }

        /**
         * 校验日期期间是否关闭
         * @param dateOfArrival
         * @returns {boolean}
         */
        const checkPeriodIsCloseOrNot = (dateOfArrival) => {
            let periodIsOpen = true;
            var accountSearch = search.create({
                type: "accountingperiod",
                filters:
                    [
                        ["startdate","onorbefore",dateOfArrival],
                        "AND",
                        ["enddate","onorafter",dateOfArrival],
                        "AND",
                        ["isinactive","is","F"],
                        "AND",
                        ["isquarter","is","F"],
                        "AND",
                        ["isyear","is","F"]
                    ],
                columns:
                    [
                        search.createColumn({name: "aplocked", label: "已锁定 AP"}),
                        search.createColumn({name: "alllocked", label: "全部锁定"}),
                        search.createColumn({name: "arlocked", label: "已锁定 AR"})
                    ]
            });
            let accountRes = commonApi.getAllData(accountSearch);
            let accountColumn = accountSearch.columns;
            if(accountRes.length > 0){
                for(let index = 0; index < accountRes.length; index++){
                    let aplocked = accountRes[0].getValue(accountColumn[0]);
                    let alllocked = accountRes[0].getValue(accountColumn[1]);
                    let arlocked = accountRes[0].getValue(accountColumn[2]);
                    if(aplocked || alllocked || arlocked){
                        periodIsOpen = false;
                    }
                }
            }
            return periodIsOpen;
        }

        return {onRequest}

    });
