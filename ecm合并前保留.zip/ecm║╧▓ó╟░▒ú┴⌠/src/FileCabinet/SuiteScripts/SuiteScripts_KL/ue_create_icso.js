/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * Version          Date            Author            Remark
 * 1.0              2022/2/23         Kori            TAPD【1018572】PO Create ICSO (公司间SO)
 * 2.0              2023/1/3          Kori            增加currency自动带值
 * 3.0              2023/3/17         Kori            增加taxcode,subsidiary取值
 */
define(['N/record', 'N/search', 'N/runtime', 'N/url'],
    /**
 * @param{record} record
 * @param{search} search
 */
    (record, search, runtime, url) => {
        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {
            icpoCreateIcsoRecord(scriptContext);
        }

        /**
         * 创建icso记录
         * @param scriptContext
         */
        const icpoCreateIcsoRecord = (scriptContext) => {
            let order = 'SANDBOX' == runtime.envType ? 3 : 3;//Intercompany Order

            let newRec = scriptContext.newRecord;
            let recType = scriptContext.type;
            let curForm = scriptContext.form;
            let orderType = newRec.getValue('custbody_ecm_ordertype');
            let poSub = newRec.getValue('subsidiary');
            let poNum = newRec.getValue('tranid');
            let soCreate = newRec.getValue('custbody_ecm_icposo_transaction');
            let country;
            if(poSub){
                let countryInfo = search.lookupFields({
                    type:'subsidiary',
                    id:poSub,
                    columns:['country']
                });
                country = countryInfo['country'][0].value;
            }
            if(recType == 'view' && orderType == order && !soCreate){
                let poUrl = url.resolveScript({
                    scriptId:'customscript_hc_create_icso_sl',
                    deploymentId:'customdeploy_hc_create_icso_sl_dep',
                    params:{
                        'poId' : newRec.id,
                        'poSub' : poSub,
                        'poNum' : poNum,
                        'country' : country,
                    }
                });

                let btnFuc = 'window.open("'+ poUrl +'","_blank"," top = 100px left = 200px height = 350px width = 670px")';

                curForm.addButton({
                    id:'custpage_btn_cspo_create',
                    label:'Create ICSO',
                    functionName : btnFuc
                })
            }
        }

        /**
         * Defines the function definition that is executed before record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const beforeSubmit = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {

        }

        return {beforeLoad/**, beforeSubmit, afterSubmit**/}

    });
