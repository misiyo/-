/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * Version          Date           Author            Remarks
 * 1.0              2023/3/21      Kori              TAPD【1019293】到达按钮
 * 2.0              2023/4/06      Kori              按钮条件取消has border == true
 * 3.0              2023/4/07      Kori              新增会计期间关闭弹窗
 * 待补充            待补充          待补充              status正式环境校验
 */
define(['N/record', 'N/url'],
    /**
 * @param{record} record
 * @param{url} url
 */
    (record, url) => {
        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {
            spDateButtonToModifyRecord(scriptContext)
        }

        /**
         * sp到达按钮修改记录日期&&判断会计期间是否关闭
         * @param scriptContext
         */
        const spDateButtonToModifyRecord = (scriptContext) => {
            let newRec = scriptContext.newRecord;
            let recType = scriptContext.type;
            let recForm = scriptContext.form;
            let recStatus = newRec.getValue('custrecord_sp_status');
            let hasBorder = newRec.getValue('custrecord_sp_iscross_border');
            //按钮显示条件：离港已出境 || 提货未出境
            if(recType == 'view' && ((recStatus == 3) || (recStatus == 2 && hasBorder == false))){
                let slUrl = url.resolveScript({
                    scriptId:'customscript_hc_sp_arrival_date_sl',
                    deploymentId:'customdeploy_hc_sp_arrival_date_sl_dep',
                    params:{
                        'spId' : newRec.id,
                    }
                });

                let btnFuc = 'window.open("'+ slUrl +'","_blank"," top = 100px left = 200px height = 350px width = 670px")';

                recForm.addButton({
                    id:'custpage_btn_sp_date',
                    label:'Arrive',
                    functionName : btnFuc
                })
            }
        }

        /**
         * Defines the function definition that is executed before record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const beforeSubmit = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {

        }

        return {beforeLoad/**, beforeSubmit, afterSubmit**/}

    });
