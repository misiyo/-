/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 * Version          Date            Author            Remark
 * 1.0              2022/2/23         Kori            TAPD【1018572】PO Create ICSO (公司间SO)
 * 2.0              2023/1/3          Kori            增加currency自动带值
 * 3.0              2023/3/17         Kori            增加taxcode,subsidiary取值
 */
define(['N/currentRecord', 'N/runtime', 'N/search', '../tools/common_api.js'],
/**
 * @param{currentRecord} currentRecord
 */
function(currentRecord, runtime, search, commonApi) {
    /**
     * Function to be executed after page is initialized.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.mode - The mode in which the record is being accessed (create, copy, or edit)
     *
     * @since 2015.2
     */
    function pageInit(scriptContext) {

    }

    /**
     * 按钮关闭sl页面
     */
    function closePage() {
        let url = window.location.href;
        window.close();
    }


    /**
     * 搜索客户对应的货币
     * @param customer
     * @returns {*[]}
     */
    function searchCurrencyArrWithCtm(customer) {
        var currencyArr = [];
        var currencySearch = search.create({
            type: "customer",
            filters:
                [
                    ["internalid","anyof",customer]
                ],
            columns:
                [
                    search.createColumn({name: "internalid", label: "内部 ID"}),
                    search.createColumn({
                        name: "currency",
                        join: "customerCurrencyBalance",
                        label: "货币"
                    })
                ]
        });
        var currencyRes = commonApi.getAllData(currencySearch);
        var currencyCol = currencySearch.columns;
        if(currencyRes.length > 0){
            for(var index = 0; index < currencyRes.length; index++){
                var currencyId = currencyRes[index].getValue(currencyCol[1]);
                var currencyname = currencyRes[index].getValue(currencyCol[1]);
                let curjson = {
                    'currencyId' : currencyId,
                    'currencyname' : currencyname
                }
                currencyArr.push(curjson);
            }
        }
        return currencyArr;
    }


    /**
     * 获取客户对应的子公司
     * @param customer
     * @returns {*[]}
     */
    function searchSubsidiaryArrWithCtm(customer) {
        var currencyArr = [];
        var currencySearch = search.create({
            type: "customer",
            filters:
                [
                    ["internalid","anyof",customer]
                ],
            columns:
                [
                    search.createColumn({
                        name: "internalid",
                        join: "mseSubsidiary",
                        label: "内部 ID"
                    }),
                    search.createColumn({
                        name: "namenohierarchy",
                        join: "mseSubsidiary",
                        label: "名称（无层次结构）"
                    })
                ]
        });
        var currencyRes = commonApi.getAllData(currencySearch);
        var currencyCol = currencySearch.columns;
        if(currencyRes.length > 0){
            for(var index = 0; index < currencyRes.length; index++){
                var currencyId = currencyRes[index].getValue(currencyCol[0]);
                var currencyname = currencyRes[index].getValue(currencyCol[1]);
                let curjson = {
                    'currencyId' : currencyId,
                    'currencyname' : currencyname
                }
                currencyArr.push(curjson);
            }
        }
        return currencyArr;
    }

    /**
     * 获取税码
     * @param country1
     * @param subsidiary1
     * @returns {*[]}
     */
    function searchTaxcode (country1, subsidiary1) {
        var taxArr = [];
        var taxcodeSearch = search.create({
            type: "salestaxitem",
            filters:
                [
                    ["country","anyof",country1],
                    "AND",
                    ["subsidiary","anyof",subsidiary1]
                ],
            columns:
                [
                    search.createColumn({name: "name", label: "名称"}),
                    search.createColumn({
                        name: "rate",
                        sort: search.Sort.ASC,
                        label: "税率"
                    }),
                    search.createColumn({name: "internalid"}),
                ]
        });
        var taxRes = commonApi.getAllData(taxcodeSearch);
        var taxCol = taxcodeSearch.columns;
        if(taxRes.length > 0){
            for(var index = 0; index < taxRes.length; index++){
                var taxname = taxRes[index].getValue(taxCol[0]);
                var taxcode = taxRes[index].getValue(taxCol[1]);
                var taxid = taxRes[index].getValue(taxCol[2]);
                if(String(taxcode) == '0.00%'){
                    taxname = taxname + ' 0.00%';
                }
                var taxJson = {
                    'taxname':taxname,
                    'taxcode':taxcode,
                    'taxid':taxid,
                }
                taxArr.push(taxJson);
            }
        }
        return taxArr;
    }

    /**
     * Function to be executed when field is changed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
     * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
     *
     * @since 2015.2
     */
    function fieldChanged(scriptContext) {
        changeSublistLineAndJQueryControl(scriptContext)
    }

    /**
     * jQuery页面控制及明细行字段带值
     * @param scriptContext
     */
    function changeSublistLineAndJQueryControl(scriptContext){
        var curRec = scriptContext.currentRecord;
        var curField = scriptContext.fieldId;
        if(curField == 'custpage_customer'){
            var customer = curRec.getValue('custpage_customer');
            if(customer){
                var currencyArr = searchCurrencyArrWithCtm(customer);
                var ctmField = curRec.getField('custpage_currency');
                ctmField.removeSelectOption({value:null});
                ctmField.insertSelectOption({value:'',text:''});
                if(currencyArr.length > 0){
                    for(var m = 0; m < currencyArr.length; m ++){
                        ctmField.insertSelectOption({value:currencyArr[m].currencyId,text:currencyArr[m].currencyname});
                    }
                }
            }
        }
        if(curField == 'custpage_customer'){
            var customer = curRec.getValue('custpage_customer');
            if(customer){
                var subsidiaryArr = searchSubsidiaryArrWithCtm(customer);
                var ctmField = curRec.getField('custpage_subsidiary');
                ctmField.removeSelectOption({value:null});
                ctmField.insertSelectOption({value:'',text:''});
                if(subsidiaryArr.length > 0){
                    for(var m = 0; m < subsidiaryArr.length; m ++){
                        ctmField.insertSelectOption({value:subsidiaryArr[m].currencyId,text:subsidiaryArr[m].currencyname});
                    }
                }
            }
        }
        if(curField == 'custpage_customer' || curField == 'custpage_subsidiary'){
            var customer = curRec.getValue('custpage_customer');
            var subsidiary = curRec.getValue('custpage_subsidiary');
            if(customer && subsidiary){
                var countryInfo = search.lookupFields({
                    type:'subsidiary',
                    id:subsidiary,
                    columns:['country']
                });
                var country = countryInfo['country'][0].value;
                var taxrateArr = searchTaxcode(country, subsidiary);
                var rateField = curRec.getField('custpage_taxrate');
                rateField.removeSelectOption({value:null});
                rateField.insertSelectOption({value:'',text:''});
                if(taxrateArr.length > 0){
                    for(var m = 0; m < taxrateArr.length; m ++){
                        rateField.insertSelectOption({value:taxrateArr[m].taxid,text:taxrateArr[m].taxname});
                    }
                }
            }
        }
    }

    /**
     * Function to be executed when field is slaved.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     *
     * @since 2015.2
     */
    function postSourcing(scriptContext) {

    }

    /**
     * Function to be executed after sublist is inserted, removed, or edited.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @since 2015.2
     */
    function sublistChanged(scriptContext) {

    }

    /**
     * Function to be executed after line is selected.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @since 2015.2
     */
    function lineInit(scriptContext) {

    }

    /**
     * Validation function to be executed when field is changed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
     * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
     *
     * @returns {boolean} Return true if field is valid
     *
     * @since 2015.2
     */
    function validateField(scriptContext) {

    }

    /**
     * Validation function to be executed when sublist line is committed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateLine(scriptContext) {

    }

    /**
     * Validation function to be executed when sublist line is inserted.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateInsert(scriptContext) {

    }

    /**
     * Validation function to be executed when record is deleted.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateDelete(scriptContext) {

    }

    /**
     * Validation function to be executed when record is saved.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @returns {boolean} Return true if record is valid
     *
     * @since 2015.2
     */
    function saveRecord(scriptContext) {

    }

    return {
        pageInit: pageInit,
        closePage:closePage,
        fieldChanged: fieldChanged,
        // postSourcing: postSourcing,
        // sublistChanged: sublistChanged,
        // lineInit: lineInit,
        // validateField: validateField,
        // validateLine: validateLine,
        // validateInsert: validateInsert,
        // validateDelete: validateDelete,
        // saveRecord: saveRecord
    };
    
});
