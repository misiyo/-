/**
 * @NApiVersion 2.1
 * @NScriptType ScheduledScript
 * Version         Date               Author            Remarks
 * 1.0             2023/02/15         Kori              TAPD【1018422】宜开美接口03 买方代码申请批复
 * 1.1             2023/02/17         Kori              TAPD【1018422】宜开美接口数据测试
 */
define(['N/record', 'N/runtime', 'N/search', '../tools/common_api.js', '../tools/ramda.min.js', '/SuiteScripts/tools/moment.js',  '/SuiteScripts/tools/hc_edi_interface_tool.js'],
    /**
 * @param{record} record
 * @param{runtime} runtime
 * @param{search} search
 */
    (record, runtime, search, commonApi, ramda, moment, interfaceTool) => {

        const BUYER_BALANCE_TYPE = 'customrecord_ecm_sinosure_buyercodeappro';//买方代码批复通知记录id
        const BUYERAPPLY_BALANCE_TYPE = 'customrecord_ecm_sinosure_buyercodeapply';//买方代码申请记录id
        const LOG_TYPE = 'customrecord_hc_edi_interface_log';//日志类型
        const IMETHOD = 'doEdiBuyerCodeApprove';//接口method
        const ITYPE = 5;//接口类型：限额余额
        const BUYER_FIELD_MAPPING = {
            //买方批复信息
            'noticeSerialNo' : 'custrecord_esbp_noticeserialno',//主键
            'corpSerialNo' : 'custrecord_esbp_corpserialno',
            'approveFlag' : 'custrecord_esbp_approveflag',
            'unAcceptCode' : 'custrecord_esbp_unacceptcode',
            'unAcceptReason' : 'custrecord_esbp_unacceptreason',
            'notifyTime' : 'custrecord_esbp_notifytime',
            //买方详细信息
            'corpSerialNo' : 'custrecord_esbp_corpserialno',
            'clientNo' : 'custrecord_esbp_clientno',
            'buyerNo': 'custrecord_esbp_buyerno',
            'mergeNo': 'custrecord_esbp_mergeno',
            'shtName': 'custrecord_esbp_shtname',
            'chnName': 'custrecord_esbp_chnname',
            'engName': 'custrecord_esbp_engname',
            'countryCode': 'custrecord_esbp_countrycode',
            'engAddress': 'custrecord_esbp_engaddress',
            'chnAddress': 'custrecord_esbp_chnaddress',
            'regionCode': 'custrecord_esbp_regioncode',
            'regAddress': 'custrecord_esbp_regaddress',
            'regNo': 'custrecord_esbp_regno',
            'tel': 'custrecord_esbp_tel',
            'fax': 'custrecord_esbp_fax',
            'webAddress': 'custrecord_esbp_webaddress',
            'eMail': 'custrecord_esbp_email',
            'setDate': 'custrecord_esbp_setdate',
            'regyear': 'custrecord_esbp_regyear',
            'corporation': 'custrecord_esbp_corporation',
            'equity': 'custrecord_esbp_equity',
            'yearSale': 'custrecord_esbp_yearsale',
            'orgno': 'custrecord_esbp_orgno',
            'creditno': 'custrecord_esbp_creditno',
            'remark': 'custrecord_esbp_remark',
            'modifyTime': 'custrecord_esbp_modifytime',

            'errorCode': 'custrecord_esbp_errorcode',
            'errorMsg': 'custrecord_esbp_errormsg',
        };
        const BUYERApy_FIELD_MAPPING = {
            'corpSerialNo' : 'name',//流水号
            'clientNo' : 'custrecord_esbya_clientno',
            'shtName': 'custrecord_esbya_shtname',
            'chnName': 'custrecord_esbya_chnname',
            'engName': 'custrecord_esbya_engname',
            'countryCode': 'custrecord_esbya_countrycode',
            'engAddress': 'custrecord_esbya_engaddress',
            'chnAddress': 'custrecord_esbya_chnaddress',
            'regionCode': 'custrecord_esbya_regioncode',
            'regAddress': 'custrecord_esbya_regaddress',
            'regNo': 'custrecord_esbya_regno',
            'tel': 'custrecord_esbya_tel',
            'fax': 'custrecord_esbya_fax',
            'webAddress': 'custrecord_esbya_webaddress',
            'eMail': 'custrecord_esbya_email',
            'setDate': 'custrecord_esbya_setdate',
            'regyear': 'custrecord_esbya_regyear',
            'corporation': 'custrecord_esbya_corporation',
            'equity': 'custrecord_esbya_equity',
            'yearSale': 'custrecord_esbya_yearsale',
            'orgno': 'custrecord_esbya_orgno',
            'creditno': 'custrecord_esbya_creditno',
            'buyerNo': 'custrecord_esbya_buyerno',
        };

        /**
         * Defines the Scheduled script trigger point.
         * @param {Object} scriptContext
         * @param {string} scriptContext.type - Script execution context. Use values from the scriptContext.InvocationType enum.
         * @since 2015.2
         */
        const execute = (scriptContext) => {
            echemiBuyerInterface(scriptContext);//宜开美买方批复接口
        }

        /**
         * 宜开美买方批复接口
         * @param scriptContext
         */
        const echemiBuyerInterface = (scriptContext) => {
            let reqData = {
                "datas": {
                    "startDate": "1580486400000",
                    "endDate": (new Date()).getTime() + ''
                },
                "imethod": IMETHOD,
            };
            let rtnData = interfaceTool.requestEdiServer(reqData, ITYPE);//获取中信保“买方代码批复结果”

            let countryInfo = searchNSCountry();
            let USAStateInfo = searchNSUSAState();
            if(rtnData.valid == true){
                let infoData = rtnData.data.datas;
                if(infoData && infoData.length > 0) {
                    infoData = JSON.parse(infoData);
                    //获取所有quotaNo，匹配已有数据
                    let quotaNos = ramda.groupBy(ramda.path(['noticeSerialNo']))(infoData);
                    let existQuotaData = formatExistQuotaNo(Object.keys(quotaNos));
                    //获取所有quotaNo，匹配已有数据
                    let corpSerialNo = ramda.groupBy(ramda.path(['corpSerialNo']))(infoData);
                    let existCorpSerialNo = formatCorpSerialNo(Object.keys(corpSerialNo));

                    let createdDataIdArray = [],
                        logUpdVal = {
                            custrecord_hc_inf_process_msg: '',
                            custrecord_hc_inf_errorflag: false
                        };
                    let buyerApyId1 = '';

                    try {
                        for(let i = 0; i < infoData.length; i++) {
                            let obj;
                            if('undefined' == typeof existQuotaData[infoData[i].noticeSerialNo]) {
                                obj = record.create({type: BUYER_BALANCE_TYPE});
                            } else {
                                obj = record.load({type: BUYER_BALANCE_TYPE, id: existQuotaData[infoData[i].noticeSerialNo]});
                            }
                            for(key in infoData[i]) {
                                if('notifyTime' == key) {
                                    let tmpDate = moment(infoData[i].key);
                                    if (!isNaN(tmpDate)) {
                                        let tmpDateStr = tmpDate.format('MM/DD/YYYY');
                                        obj.setText({fieldId: BUYER_FIELD_MAPPING[key], text: tmpDateStr});
                                    }
                                }else if('noticeSerialNo' == key || 'corpSerialNo' == key){
                                    obj.setValue({fieldId: BUYER_FIELD_MAPPING[key], value: infoData[i][key]});
                                }else if('unAcceptReason' == key){
                                    obj.setValue({fieldId: BUYER_FIELD_MAPPING[key], value: infoData[i][key]});
                                }else if('unAcceptCode' == key){
                                    obj.setValue({fieldId: BUYER_FIELD_MAPPING[key], value: infoData[i][key]});
                                }else if('approveFlag' == key){//0-申请退回/不通过；1-通过/代码发布
                                    if(infoData[i].approveFlag == 0 || infoData[i].approveFlag == '0'){
                                        obj.setValue({fieldId: BUYER_FIELD_MAPPING[key], value: '申请退回/不通过'})
                                    }else{
                                        obj.setValue({fieldId: BUYER_FIELD_MAPPING[key], value: '通过/代码发布'})
                                    }
                                }else{//buyerInfo == infoData[i].key
                                    let buyerInfo = infoData[i].buyerInfo;
                                    // try{
                                    for(key1 in buyerInfo){
                                        if('setDate' == key1 || 'modifyTime' == key1) {
                                            let tmpDate = moment(buyerInfo.key1);
                                            if (!isNaN(tmpDate)) {
                                                let tmpDateStr = tmpDate.format('MM/DD/YYYY');
                                                obj.setText({fieldId: BUYER_FIELD_MAPPING[key1], text: tmpDateStr});
                                            }
                                        } else if('countryCode' == key1){
                                            for(let index = 0; index < countryInfo.length; index ++){
                                                if(countryInfo[index].ecCode == buyerInfo[key1]){
                                                    obj.setValue({fieldId: BUYER_FIELD_MAPPING[key1], value: countryInfo[index].NSCtyId});
                                                    break;
                                                }
                                            }
                                        } else if('regionCode' == key1){
                                            for(let index = 0; index < USAStateInfo.length; index ++){
                                                if(USAStateInfo[index].ecCode == buyerInfo[key1]){
                                                    obj.setValue({fieldId: BUYER_FIELD_MAPPING[key1], value: USAStateInfo[index].nsId});
                                                    break;
                                                }
                                            }
                                        } else{
                                            obj.setValue({fieldId: BUYER_FIELD_MAPPING[key1], value: buyerInfo[key1]});
                                        }
                                    }
                                }
                            }

                            let qid = obj.save({ignoreMandatoryFields:true,enableSourcing:true});
                            createdDataIdArray.push(qid);

                            if(qid){//将更新信息同步至买方代码申请
                                let buyerApyRec;
                                if('undefined' != typeof existCorpSerialNo[infoData[i].corpSerialNo]){
                                    buyerApyRec = record.load({type:BUYERAPPLY_BALANCE_TYPE,id:existCorpSerialNo[infoData[i].corpSerialNo]});
                                    let buyerApyInfo = infoData[i].buyerInfo;
                                    buyerApyId1 = existCorpSerialNo[infoData[i].corpSerialNo];

                                    for(key in buyerApyInfo){
                                        if('setDate' == key) {
                                            let tmpDate = moment(buyerApyInfo.key);
                                            if (!isNaN(tmpDate)) {
                                                let tmpDateStr = tmpDate.format('MM/DD/YYYY');
                                                buyerApyRec.setText({fieldId: BUYERApy_FIELD_MAPPING[key], text: tmpDateStr});
                                            }
                                        } else if('countryCode' == key){
                                            for(let index = 0; index < countryInfo.length; index ++){
                                                if(countryInfo[index].ecCode == buyerApyInfo[key]){
                                                    buyerApyRec.setValue({fieldId: BUYERApy_FIELD_MAPPING[key], value: countryInfo[index].NSCtyId});
                                                    break;
                                                }
                                            }
                                        } else if('regionCode' == key){
                                            for(let index = 0; index < USAStateInfo.length; index ++){
                                                if(USAStateInfo[index].ecCode == buyerApyInfo[key]){
                                                    buyerApyRec.setValue({fieldId: BUYERApy_FIELD_MAPPING[key], value: USAStateInfo[index].nsId});
                                                    break;
                                                }
                                            }
                                        } else if('modifyTime' != key){
                                            buyerApyRec.setValue({fieldId: BUYERApy_FIELD_MAPPING[key], value: buyerApyInfo[key]});
                                        }

                                    }
                                    let buyerApyId =  buyerApyRec.save({enableSourcing:true,ignoreMandatoryFields:true});
                                    // log.debug('buyerApyId',buyerApyId);
                                }

                            }
                        }
                        logUpdVal.custrecord_hc_inf_process_msg = createdDataIdArray.join('&');
                    } catch (e) {
                        log.error('生成买方代码申请反馈error===>' + rtnData.logId, e);
                        if(createdDataIdArray && createdDataIdArray.length > 0) {
                            createdDataIdArray.forEach(function (cid) {
                                record.delete({type: BUYER_BALANCE_TYPE, id: cid});
                            });
                        }
                        logUpdVal.custrecord_esbp_errormsg = e.message;
                        logUpdVal.custrecord_hc_inf_errorflag = true;
                        record.submitFields({
                            type: BUYERAPPLY_BALANCE_TYPE,
                            id: buyerApyId1,
                            values: 6
                        });
                    }
                    record.submitFields({
                        type: LOG_TYPE,
                        id: rtnData.logId,
                        values: logUpdVal
                    });
                }
            }
        }

        /**
         * 搜索已存在noticeSerialNo记录
         * @param quotaNoArray              本次返回quotaNo
         * @return {{}}                     {quotaNo：id}
         */
        const formatExistQuotaNo = quotaNoArray => {
            let existData = {};//{quotaNo：id}
            if(!quotaNoArray || 0 == quotaNoArray.length) {
                return existData;
            }
            let filters = [],
                columns = ['custrecord_esbp_noticeSerialNo'];
            quotaNoArray.forEach(function (qno) {
                filters.push(['custrecord_esbp_noticeSerialNo', 'is', qno]);
                filters.push('or');
            });
            filters.pop();
            let results = commonApi.searchAllData(BUYER_BALANCE_TYPE, filters, columns);
            if(results && results.length > 0) {
                results.forEach(function (res) {
                    existData[res.getValue(columns[0])] = res.id;
                });
            }
            // log.debug('已存在quotaNo数据', existData);
            return existData;
        }

        const formatCorpSerialNo = quotaNoArray => {
            let existData = {};//{quotaNo：id}
            if(!quotaNoArray || 0 == quotaNoArray.length) {
                return existData;
            }
            let filters = [],
                columns = ['name'];
            quotaNoArray.forEach(function (qno) {
                filters.push(['internalid', 'anyof', qno]);
                filters.push('or');
            });
            filters.pop();
            let results = commonApi.searchAllData(BUYERAPPLY_BALANCE_TYPE, filters, columns);
            if(results && results.length > 0) {
                results.forEach(function (res) {
                    existData[res.getValue(columns[0])] = res.id;
                });
            }
            // log.debug('已存在CorpSerial数据', existData);
            return existData;
        }


        /**
         * 搜索客户
         * @param quotaNoArray              本次返回buyerNo
         * @return {{}}                     {buyerNo：id}
         */
        const formatCustomData = buyerNoArray => {
            let existData = {};//{quotaNo：id}
            if(!buyerNoArray || 0 == buyerNoArray.length) {
                return existData;
            }
            let filters = [],
                columns = ['custrecord_esbp_buyerNo'];
            buyerNoArray.forEach(function (bno) {
                filters.push(['custrecord_esbp_buyerNo', 'is', bno]);
                filters.push('or');
            });
            filters.pop();
            let results = commonApi.searchAllData('customer', filters, columns);
            if(results && results.length > 0) {
                results.forEach(function (res) {
                    existData[res.getValue(columns[0])] = res.id;
                });
            }
            // log.debug('匹配customer', existData);
            return existData;
        }

        const searchNSCountry = () => {
            let countryInfo = [];
            let countrycodeSearchObj = search.create({
                type: "customrecord_ecm_countrycode",
                filters: [],
                columns: [
                    search.createColumn({name: "custrecord_ec_code", label: "代码"}),
                    search.createColumn({name: "internalid", label: "内部 ID"})
                ]
            });
            let countryRes = commonApi.getAllData(countrycodeSearchObj);
            let countryCol = countrycodeSearchObj.columns;
            if(countryRes.length > 0){
                for(let index = 0; index < countryRes.length; index++){
                    let ecCode = countryRes[index].getValue(countryCol[0]);
                    let NSCtyId = countryRes[index].getValue(countryCol[1]);
                    let ctyJson = {
                        ecCode:ecCode,
                        NSCtyId:NSCtyId
                    }
                    countryInfo.push(ctyJson);
                }
            }

            return countryInfo;
        }

        const searchNSUSAState = () => {
            let USAStateInfo = [];
            let regioncodeSearchObj = search.create({
                type: "customrecord_ecm_us_regioncode",
                filters: [],
                columns: [
                    search.createColumn({name: "custrecord_eur_code", label: "代码"}),
                    search.createColumn({name: "internalid", label: "内部 ID"})
                ]
            });
            let regionRes = commonApi.getAllData(regioncodeSearchObj);
            let regionCol = regioncodeSearchObj.columns;
            if(regionRes.length > 0){
                for(let index = 0; index < regionRes.length; index ++){
                    let ecCode = regionRes[index].getValue(regionCol[0]);
                    let nsId = regionRes[index].getValue(regionCol[1]);
                    let regionJson = {
                        ecCode:ecCode,
                        nsId:nsId
                    }
                    USAStateInfo.push(regionJson)
                }
            }

            return USAStateInfo;
        }

        return {execute}

    });
