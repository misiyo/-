/**
 *@NApiVersion 2.x
 *@NScriptType ClientScript
 * version 1.0 Josie 编辑时计算货品和销售单上的值，保留四位小数
 *
 * Version      Date            Author          Memo
 * 2.0          2023/01/16      John Wang       报价单计算逻辑（1017891）
 * 3.0          2023/02/01      John Wang       新增保存前日期校验（1018219）
 * 4.0          2023/03/21      John Wang       custcol_ecm_freight_cost=>custcol_ecm_oceanfreight（1017891）
 * 5.0          2023/04/03      John Wang       custcol_ecm_pallet_cost=>custcol_ecm_sinosurecost（1017891）
 * 6.0          2023/04/07      John Wang       v1转移至用户自己开发（1017891）
 * 7.0          2023/04/14      John Wang       新增字段：数量（折算重量单位）计算逻辑（1017891）
 */
define(['N/currentRecord', 'N/currency', 'N/record', 'N/runtime', '/SuiteScripts/tools/common_api.js', 'N/format'],
    function (currentRecord, currency, record, runtime, commonApi, format) {

    /**是否是报价单：是（true）*/
    var ESTIMATE_FLAG = false;
    /**是否是管理员：是（true）*/
    var ADMIN_FLAG = false;
    /**汇率*/
    var CUY_ERATE = {};//{1:6.073}
    /**报价单明细行触发单价计算字段*/
    var ESTIMATE_RATE_FIELDS = ['custcol_ecm_oceanfreight', 'custcol_ecm_other_cost', 'custcol_ecm_payment_term_cost', 'custcol_ecm_sinosurecost', 'custcol_ecm_profit'];
    function pageInit(context) {
        if('estimate' == context.currentRecord.type) {
            ESTIMATE_FLAG = true;
            if(3 == runtime.getCurrentUser().role) {
                ADMIN_FLAG = true;
            }
        }
        if(true == ESTIMATE_FLAG && false == ADMIN_FLAG) {
            ['price', 'tax1amt', 'grossamt'].forEach(function (fid) {
                nlapiDisableLineItemField('item', fid,true)
            });
        }
        // console.log('ESTIMATE_FLAG==>' + ESTIMATE_FLAG + '|ADMIN_FLAG==>' + ADMIN_FLAG)
    }

    function saveRecord(context) {
        var obj = currentRecord.get();
        var length = obj.getLineCount({sublistId: 'item'});
        var dueDate = obj.getText({fieldId: 'duedate'}),
            appStatus = obj.getValue({fieldId: 'custbody_ecm_approval_status'});//approved=3
        if(dueDate && '' != dueDate) {
            dueDate = format.parse({value:dueDate,type:format.Type.DATE});
        }
        var lineData = [];//[{item: '', date: ''}]
        var mainCuy = obj.getText({fieldId: 'currency'}),
            totalRefSellingAmt = 0,//SUM(custcol_ecm_reference_price*qty)
            totalRefPurchaseAmt = 0;//SUM(custcol_ecm_purchase_price*qty)
        for(var i = 0; i < length; i++) {
            var sprice = obj.getSublistValue({sublistId: 'item', fieldId: 'custcol_ecm_reference_price', line: i}),
                pprice = obj.getSublistValue({sublistId: 'item', fieldId: 'custcol_ecm_purchase_price', line: i}),
                qty = obj.getSublistValue({sublistId: 'item', fieldId: 'custcol_ecm_qty_packunit', line: i}),
                lineCuy = obj.getSublistValue({sublistId: 'item', fieldId: 'custcol_ecm_currency', line: i}),//行币种
                itemId = obj.getSublistText({sublistId: 'item', fieldId: 'item', line: i}),
                toDate = obj.getSublistText({sublistId: 'item', fieldId: 'custcol_ecm_to_date', line: i});//TO_DATE
            var erate = 1;//汇率
            if(lineCuy != mainCuy && 'undefined' == typeof CUY_ERATE[lineCuy]) {
                erate = currency.exchangeRate({source: lineCuy, target: mainCuy});
                CUY_ERATE[lineCuy] = erate;
            } else if(lineCuy != mainCuy && 'undefined' != typeof CUY_ERATE[lineCuy]){
                erate = CUY_ERATE[lineCuy];
            }
            totalRefSellingAmt = Number(totalRefSellingAmt).add(Number(sprice || 0).mul(Number(qty)).mul(Number(erate)));
            totalRefPurchaseAmt = Number(totalRefPurchaseAmt).add(Number(pprice || 0).mul(Number(qty)).mul(Number(erate)));
            lineData.push({item: itemId, date: toDate});
        }
        obj.setValue({fieldId: 'custbody_ecm_sum_ref_sellingprice', value: Number(totalRefSellingAmt).toFixedNew(2)})
        obj.setValue({fieldId: 'custbody_ecm_sum_ref_purchaseprice', value: Number(totalRefPurchaseAmt).toFixedNew(2)})
        //校验date
        if(3 != appStatus) {
            var invalidMsg = [];
            for(var j = 0; j < lineData.length; j++) {
                if('' == lineData[j].date || '' != lineData[j].date && format.parse({value: lineData[j].date, type: format.Type.DATE}) < dueDate) {
                    invalidMsg.push(lineData[j].item + ' ' + lineData[j].date + ';');
                }
            }
            if(invalidMsg.length > 0) {
                alert('存在一个货品明细行的 截止日期 早于 报价单的过期日期。\nEstimate expiry date cannot be later than the earliest To Date of price books selected in item lines.\n' + invalidMsg.join('\n'));
                return false;
            }
        }
        return true;
    }

    function validateField(context) {

    }

    function fieldChanged(context) {
        var obj = context.currentRecord;
        var subid = context.sublistId,
            fieldId = context.fieldId;
        /*if (rec_type === 'inventoryitem' || rec_type === 'assemblyitem' || rec_type === 'lotnumberedassemblyitem' || rec_type === 'lotnumberedinventoryitem') {
            if (fieldName === 'custitem_nvci_case_height_mm' || fieldName === 'custitem_nvci_case_width_mm' || fieldName === 'custitem_nvci_case_depth_mm') {
                var height = cur_rec.getValue('custitem_nvci_case_height_mm');
                var width = cur_rec.getValue('custitem_nvci_case_width_mm');
                var depth = cur_rec.getValue('custitem_nvci_case_depth_mm');
                cur_rec.setValue('custitem_nvci_case_cbm', getFloat(height * width * depth / 1000000000, 4));
            }

        }*/
        if(true == ESTIMATE_FLAG && 'custcol_ecm_qty_packunit' == fieldId) {
            var weightPerPac = obj.getCurrentSublistValue({sublistId: subid, fieldId: 'custcol_ecm_case_package_kg'}),//单件装重量
                qtyInBase = obj.getCurrentSublistValue({sublistId: subid, fieldId: 'custcol_ecm_qty_packunit'});//数量（折算重量单位）
            obj.setCurrentSublistValue({sublistId: subid, fieldId: 'quantity', value: Number(qtyInBase).div(Number(weightPerPac || 1)), ignoreFieldChange: true});
        }
        if(true == ESTIMATE_FLAG && 'quantity' == fieldId) {
            var weightPerPac = obj.getCurrentSublistValue({sublistId: subid, fieldId: 'custcol_ecm_case_package_kg'}),//单件装重量
                qty = obj.getCurrentSublistValue({sublistId: subid, fieldId: 'quantity'});//数量（折算重量单位）
            obj.setCurrentSublistValue({sublistId: subid, fieldId: 'custcol_ecm_qty_packunit', value: Number(qty).mul(Number(weightPerPac || 1)), ignoreFieldChange: true});
        }

        if('item' == subid && false == ADMIN_FLAG && 'item' == fieldId) {
            setTimeout(function () {
                nlapiDisableLineItemField(subid, 'rate',true);
                console.log('fieldchange disable rate=====' + fieldId);
            }, 300);
        }

    }

    function postSourcing(context) {

    }

    function lineInit(context) {
        /*if('item' == context.sublistId && true == ESTIMATE_FLAG && false == ADMIN_FLAG) {
            setTimeout(function () {
                console.log('start disable rate');
                var obj = context.currentRecord;
                var index = obj.getCurrentSublistIndex({
                    sublistId: 'item'
                });
                obj.getSublistField({
                    sublistId : 'item',
                    fieldId: 'rate',
                    line: index
                }).isDisabled = true;
                console.log('end disable rate');
            }, 300);
        }*/
        if('item' == context.sublistId && false == ADMIN_FLAG) {
            setTimeout(function () {
                nlapiDisableLineItemField('item', 'rate',true);
                console.log('lineInit disable rate=====');
            }, 300);
        }
    }

    function validateDelete(context) {

    }

    function validateLine(context) {

    }

    function validateInsert(context) {

    }

    function sublistChanged(context) {

    }

    return {
        fieldChanged: fieldChanged,
        //validateLine: validateLine,
        pageInit: pageInit,
        saveRecord: saveRecord,
        // validateField: validateField,
        // postSourcing: postSourcing,
        lineInit: lineInit,
        // validateDelete: validateDelete,
        // validateInsert: validateInsert,

        // sublistChanged: sublistChanged
    }
});