/**
 *@NApiVersion 2.x
 *@NScriptType ClientScript
 */
/** 
 * version  date        Author      remark
 * 1.0      2020/05/13  Maggie      备货单筛选页面处理逻辑
 */
define(['N/http', 'N/record', 'N/search', 'N/url', 'N/currentRecord', 'N/runtime'], function (http, record, search, url, currentRecord, runtime) {

    //改变url的值
    function changeURLArg(url, arg, arg_val) {
        //console.log('Transfer customer CS ','changeURLArg');
        var pattern = arg + '=([^&]*)';
        var replaceText = arg + '=' + arg_val;
        if (url.match(pattern)) {
            var tmp = '/(' + arg + '=)([^&]*)/gi';
            tmp = url.replace(eval(tmp), replaceText);
            return tmp;
        } else {
            if (url.match('[\?]')) {
                return url + '&' + replaceText;
            } else {
                return url + '?' + replaceText;
            }
        }
    }

    //上一页 下一页 按钮的方法
    function nextPage(currentPage, allpage) {
        console.log('Transfer customer CS ', 'nextPage');
        var url = window.location.href; //获取到当前页面的url
        if (currentPage > allpage) {
            url = changeURLArg(url, 'cz', '2'); //改变url的值
            url = changeURLArg(url, 'currentPage', allpage);
            //console.log('url1',url);
            setWindowChanged(window, false);
            window.location.href = url;
        }
        if (currentPage < 1) {
            url = changeURLArg(url, 'cz', '2'); //改变url的值
            url = changeURLArg(url, 'currentPage', 1);
            console.log('url2', url);
            setWindowChanged(window, false);
            window.location.href = url;
        }
        if ((currentPage >= 1) && (currentPage <= allpage)) {
            url = changeURLArg(url, 'cz', '2'); //改变url的值
            url = changeURLArg(url, 'currentPage', currentPage);
            //console.log('url3',url);
            setWindowChanged(window, false);
            window.location.href = url;

        }
    }

    function pageInit(context) {

    }

    function saveRecord(context) {
        var currec = context.currentRecord;
	    //console.log('check_bill',check_bill);
		var linecount = currec.getLineCount('custpage_sublist_line');
		//获取checkbox数据
		var flag = getCheckData(currec);
			if (flag >1) {
				alert('只能选择一张备货生产通知单');
				return false;
			} else if(flag == 0){
				alert('请勾选备货生产通知单');
				return false;
			}
			return true;
    }

    function getCheckData(currObj) {
        //var ret_arr = [];
        var flag = 0;
        var linecount = currObj.getLineCount('custpage_sublist_line');
        for (var len = 0; len < linecount; len++) {
            var check_box = currObj.getSublistValue({
                sublistId: 'custpage_sublist_line',
                fieldId: 'custpage_ordercheckbbox',
                line: len
            });
            if (check_box == 'T' || check_box == true) {
                flag =flag + 1;
                if(flag > 1){
                    break;
                }
            }
        }
        return flag;
    }

    function validateField(context) {

    }

    function close(){
        //关闭弹窗
		window.close();//关闭页面
    }

    function refresh_by_condition(){
        var now_rec = currentRecord.get();
        var pd_no = now_rec.getValue('custpage_pd_no');
        var cust = now_rec.getText('custpage_customer');
        var date = now_rec.getText('custpage_date');
        var entity = now_rec.getValue('custpage_entity');
        var soid = now_rec.getValue('custpage_rec_id');
        var url=window.location.href;//获取到当前页面的url
        url = changeURLArg(url,'pd_no',pd_no);
		url = changeURLArg(url,'cust',cust);
		url = changeURLArg(url,'date',date);
		url = changeURLArg(url,'entity',entity);
        url = changeURLArg(url,'recid',soid);
        setWindowChanged(window, false);
        window.location.href = url;
    }

    function reset(){
        var cRecord = currentRecord.get();
        var soid = cRecord.getValue('custpage_rec_id');
        var url = window.location.href; //获取到当前页面的url
        //url = changeURLArg(url,'currentPage',1);
		url = changeURLArg(url,'custpage_rec_id',soid);
		setWindowChanged(window, false);
        window.location.href = url;
    }

    function fieldChanged(scriptContext) {
        var now_rec = scriptContext.currentRecord;
        var now_sublistid = scriptContext.sublistId;
        var now_fieldid = scriptContext.fieldId; //拿到当前的字段
        var now_line = scriptContext.line;
        var url = window.location.href; //获取到当前页面的url

        //更改当前页数
        if (now_fieldid == 'custpage_currentpage1') {
            var currentpage = now_rec.getValue({
                fieldId: 'custpage_currentpage1'
            });
            var totalpage = now_rec.getValue({
                fieldId: 'custpage_totalpage1'
            });
            if (currentpage <= totalpage) {
                url = changeURLArg(url, 'currentPage', currentpage); //改变url的值
                setWindowChanged(window, false);
                window.location.href = url;

            } else {
                url = changeURLArg(url, 'currentPage', totalpage); //改变url的值
                setWindowChanged(window, false);
                window.location.href = url;

            }
        } else if (now_fieldid == 'custpage_pagesize') {
            var pagesize = now_rec.getValue({
                fieldId: 'custpage_pagesize'
            });
            if (pagesize <= 1000 && pagesize >= 5) {
                url = changeURLArg(url, 'pagesize', pagesize); //改变url的值
                setWindowChanged(window, false);
                window.location.href = url;

            } else {
                alert('请输入5-1000范围内的整数')
            }
        } else {
            console.log('now_fieldid', now_fieldid);
        }

    }

    function postSourcing(context) {

    }

    function lineInit(context) {

    }

    function validateDelete(context) {

    }

    function validateInsert(context) {

    }

    function validateLine(context) {

    }

    function sublistChanged(context) {

    }

    return {
        /* pageInit: pageInit, */
        saveRecord: saveRecord,
        /* validateField: validateField, */
        fieldChanged: fieldChanged,
        /* postSourcing: postSourcing,
        lineInit: lineInit,
        validateDelete: validateDelete,
        validateInsert: validateInsert,
        validateLine: validateLine,
        sublistChanged: sublistChanged, */
        nextPage:nextPage,
        close:close,
        refresh_by_condition :refresh_by_condition,
        reset:reset
    }
});