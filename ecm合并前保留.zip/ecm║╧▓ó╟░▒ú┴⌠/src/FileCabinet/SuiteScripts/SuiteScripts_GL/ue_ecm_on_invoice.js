/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * Version      Date            Author          Remarks
 * 1.0          2023/03/14      Gino Lu         运营发票打印按钮（序号19.1网站）【ID1019140】
 * 2.0          2023/04/18      Gino Lu         脚本已弃用
 */
define(['N/record', 'N/runtime', 'N/task', 'N/ui/serverWidget', 'N/url'],
    /**
     * @param{record} record
     * @param{runtime} runtime
     * @param{task} task
     * @param{serverWidget} serverWidget
     * @param{url} url
     */
    (record, runtime, task, serverWidget, url) => {
        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {
            addInvPrintExcelButton(scriptContext);
        }

        const addInvPrintExcelButton = (scriptContext) => {
            let typeObj = scriptContext.type;
            let newRec = scriptContext.newRecord;
            let curForm = scriptContext.form;

            if (typeObj == 'view') {
                let invUrl = url.resolveScript({
                    scriptId: 'customscript_ecm_inv_print_excel_sl',
                    deploymentId: 'customdeploy_ecm_inv_print_excel_sl',
                    // returnExternalUrl: true
                });
                let printInv = "window.open('" + invUrl + "&rec_id=" + newRec.id + "&rec_type=" + newRec.type + "','_self')";
                curForm.addButton({
                    id: "custpage_ecm_invoice_print_btn",
                    label: "Print Invoice",
                    functionName: printInv
                });
            }
        }

        /**
         * Defines the function definition that is executed before record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const beforeSubmit = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {

        }

        return {
            beforeLoad,
            // beforeSubmit,
            // afterSubmit
        }

    });
