/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 * version      date            author              remark
 * 1.0          2023/03/01      Gino Lu             下推生成Shipping Plan页面【ID1018531】
 * 2.0          2023/03/07      Gino Lu             完善逻辑
 * 3.0          2023/03/13      Gino Lu             逻辑变更
 * 4.0          2023/03/15      Gino Lu             逻辑变更
 * 5.0          2023/03/16      Gino Lu             完善逻辑
 * 6.0          2023/03/21      Gino Lu             变更逻辑
 * 7.0          2023/03/24      Gino Lu             变更逻辑
 * 8.0          2023/03/27      Gino Lu             变更逻辑
 * 9.0          2023/04/04      Gino Lu             添加字段校验
 * 10.0         2023/04/12      Gino Lu             修改字段取值校验
 */
define(['N/currentRecord', 'N/record', 'N/url', 'N/runtime', 'N/search', 'SuiteScripts/tools/common_api.js'],
/**
 * @param{currentRecord} currentRecord
 * @param record
 * @param url
 * @param runtime
 * @param search
 * @param commonApi
 */
function(currentRecord, record, url, runtime, search, commonApi) {
    /**
     * Function to be executed after page is initialized.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.mode - The mode in which the record is being accessed (create, copy, or edit)
     *
     * @since 2015.2
     */
    function pageInit(scriptContext) {
        window.openDetailPage = openDetailPage;
        window.writeBackInventoryDetail = writeBackInventoryDetail;
    }

    /**
     * 明细行
     */
    var pageUrl = false;
    function openDetailPage(itemId, lineId, location, scdQty) {
        if(!itemId || itemId == ''){
            alert('The line does not have a corresponding item!');
            return;
        }
        if(!location || location == ''){
            alert('Dont exist any location.');
            return;
        }
        if(false === pageUrl) {
            pageUrl = url.resolveScript({
                scriptId: 'customscript_ecm_check_inventory_qty_sl',
                deploymentId: 'customdeploy_ecm_check_inventory_qty_sl'
            });
        }
        window.open(pageUrl + '&itemId=' + encodeURIComponent(itemId) + '&lineId=' + encodeURIComponent(lineId) + '&location=' + encodeURIComponent(location) + '&scdQty=' + scdQty, '_blank', 'left=500,top=700,height=600,width=1100');
    }

    //回写intentory detail值
    function writeBackInventoryDetail(lineId, qty, ecmInventoryDetailArr, cost) {
        console.log('Inventory_qty======>'+qty);
        console.log('Inventory_json======>'+JSON.stringify(ecmInventoryDetailArr));
        console.log('Inventory_cost======>'+cost);
        var curRec = currentRecord.get();
        var index = curRec.findSublistLineWithValue({sublistId: 'custpage_sublist_line', fieldId: 'custpage_line_scdline', value: lineId});
        curRec.selectLine({sublistId: 'custpage_sublist_line', line: index});
        curRec.setCurrentSublistValue({sublistId: 'custpage_sublist_line', fieldId: 'custpage_line_inventory', value: qty});
        curRec.setCurrentSublistValue({sublistId: 'custpage_sublist_line', fieldId: 'custpage_line_ecm_json', value: JSON.stringify(ecmInventoryDetailArr)});
        curRec.setCurrentSublistValue({sublistId: 'custpage_sublist_line', fieldId: 'custpage_line_average_cost', value: cost});
        curRec.commitLine({sublistId: 'custpage_sublist_line'});
    }

    /**
     * Function to be executed when field is changed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
     * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
     *
     * @since 2015.2
     */
    function fieldChanged(scriptContext) {
    }

    /**
     * Validation function to be executed when record is saved.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @returns {boolean} Return true if record is valid
     *
     * @since 2015.2
     */
    function saveRecord(scriptContext) {
        var curRec = scriptContext.currentRecord;
        var lineCount = curRec.getLineCount('custpage_sublist_line');
        var ssNo = curRec.getValue('custpage_ssno');
        // var isSelect = false;
        var hasInventoryQty = true;
        for (var i = 0; i < lineCount; i++) {
            // var lineSelect = curRec.getSublistValue('custpage_sublist_line','custpage_line_select',i);
            // if (true == lineSelect || 'T' == lineSelect) {
            //     isSelect = true;
            var inventoryType = curRec.getSublistValue('custpage_sublist_line','custpage_line_inventory_type',i);
            if(inventoryType == 2){ //为仓库发货
                var inventoryQty = curRec.getSublistValue('custpage_sublist_line','custpage_line_inventory',i);
                if (inventoryQty == '' || !inventoryQty){
                    hasInventoryQty = false;
                }
            }
            // }
        }
        // if (!isSelect) {
        //     alert('Choose one line at least!');
        //     return false;
        // }
        if (!ssNo || ssNo == '') {
            alert('Please input the necessary field: SS NO');
            return false;
        }
        if(lineCount == 0){
            alert('Dont have any lines now! Please check your search.');
            return false;
        }
        if(!hasInventoryQty){
            alert('Please input the Inventory Detail.');
            return false;
        }
        return true;
    }

    // 搜索按钮
    function searchData() {
        var curRec = currentRecord.get();
        var ssNo = curRec.getValue('custpage_ssno');
        if (!ssNo || ssNo == '') {
            alert('Please input the necessary field: SS NO');
            return;
        }
        var url = window.location.href;
        var urlArr = url.split('&');

        if(typeof ssNo == 'object' && ssNo.length > 1){
            console.log('ssNo==>'+ssNo);
            var res = judgeSSInfo(ssNo);
            if(res !== false){
                alert('The values of ' + res[0] + ' are not the same!');
                setWindowChanged(window, false);
                window.location.href = urlArr[0] + "&" + urlArr[1];
                return;
            }
        }
        var newUrl = '&iss=T';
        if (ssNo){
            newUrl += '&ssno=' + encodeURIComponent(ssNo);
        }
        setWindowChanged(window, false);
        window.location.href = urlArr[0] + "&" + urlArr[1] + newUrl;
    }

    //ss数据校验
    function judgeSSInfo(ssNoArr){
        var scdData = getSCDData(ssNoArr);
        console.log('scIdArr===>'+scdData.scIdArr);
        console.log('scdLine===>'+JSON.stringify(scdData.line));
        if(scdData.diffArr.length > 0){
            return scdData.diffArr;
        }
        else {
            var scIdArr = scdData.scIdArr;
            var scData = getSCData(scIdArr);
            console.log('scLine===>'+JSON.stringify(scData.line));
            if(scData.diffArr.length > 0){
                return scData.diffArr;
            }
        }

        return false;
    }

    //scd搜索
    function getSCDData(ssNoArr) {
        var data = {},
            scIdArr = [],
            line = [];
        var diffArr = [];
        var filters = [],
            columns = [];
        filters.push(['custrecord_scd_ss', 'anyof', ssNoArr]);

        columns.push(search.createColumn({name: 'custrecord_ssc_scnumber', join: 'CUSTRECORD_SCD_SS', label: 'Sales Contract'}));
        columns.push(search.createColumn({name: 'custrecord_ssc_iscross_border', join: 'CUSTRECORD_SCD_SS', label: 'Whether Cross-border'}));
        columns.push(search.createColumn({name: 'custrecord_ssc_incoterm', join: 'CUSTRECORD_SCD_SS', label: 'Incoterm'}));
        columns.push(search.createColumn({name: 'custrecord_ssc_shipping_method', join: 'CUSTRECORD_SCD_SS', label: 'Transportation'}));
        columns.push(search.createColumn({name: 'custrecord_ssc_order_type', join: 'CUSTRECORD_SCD_SS', label: 'Contract Type'}));
        columns.push(search.createColumn({name: 'custrecord_ss_country_loading', join: 'CUSTRECORD_SCD_SS', label: 'Country of Departure'}));
        columns.push(search.createColumn({name: 'custrecord_ss_destilocation', join: 'CUSTRECORD_SCD_SS', label: 'Inbound Warehouse'}));
        columns.push(search.createColumn({name: 'custrecord_scd_warehousestock', label: 'Warehouse Stock'}));
        var mySearchObj = search.create({
            type: 'customrecord_ecm_scd',
            filters: filters,
            columns: columns
        });
        var res = commonApi.getAllData(mySearchObj);

        for (var j = 0; j < res.length; j++) {
            var json = {};
            var scId = res[j].getValue(columns[0]);
            if (scIdArr.indexOf(scId) == -1 && scId) {
                scIdArr.push(scId);
            }
            var isNewLine = false;
            for (var i = 1; i < columns.length; i++) {
                json[columns[i].name] = res[j].getValue(columns[i]);
                for (var k = 0; k < line.length; k++) {
                    if (json[columns[i].name] != line[k][columns[i].name]) {
                        if(diffArr.indexOf(columns[i].label) == -1){
                            diffArr.push(columns[i].label);
                        }
                        isNewLine = true;
                    }
                }
            }
            if(isNewLine || line.length == 0){
                line.push(json);
            }
        }
        data.scIdArr = scIdArr;
        data.diffArr = diffArr;
        data.line = line;

        return data;
    }

    //sc搜索
    function getSCData(scIdArr) {
        var data = {},
            line = [];
        var diffArr = [];
        var filters = [],
            columns = [];
        filters.push(['internalid', 'anyof', scIdArr]);
        filters.push('and');
        filters.push(['mainline', 'is', 'F']);
        filters.push('and');
        filters.push(['taxline', 'is', 'F']);

        columns.push(search.createColumn({name: 'entity', label: 'Customer'}));
        columns.push(search.createColumn({name: 'subsidiary', label: 'Subsidiary'}));
        columns.push(search.createColumn({name: 'currency', label: 'Currency'}));
        columns.push(search.createColumn({name: 'custbody_ecm_prepayment_ratio', label: 'Advance Payment Ratio'}));
        columns.push(search.createColumn({name: 'custbody_ecm_prepay_method', label: 'Prepayment Method'}));
        columns.push(search.createColumn({name: 'custbody_ecm_prepay_node', label: 'Advance Payment Node'}));
        columns.push(search.createColumn({name: 'custbody_ecm_advance_prepaydays', label: 'Days of Advance Payment'}));
        columns.push(search.createColumn({name: 'custbody_ecm_balance_payment', label: 'Contract Balance Ratio'}));
        columns.push(search.createColumn({name: 'custbody_ecm_balance_prepay_node', label: 'Contract Balance Node'}));
        columns.push(search.createColumn({name: 'custbody_ecm_balance_termsdays', label: 'Balance Days'}));
        columns.push(search.createColumn({name: 'custbody_ecm_balance_prepay_method', label: 'Balance Payment Method'}));
        columns.push(search.createColumn({name: 'custbody_ecm_deliverydate_type', label: 'Delivery of Japanese Language'}));
        columns.push(search.createColumn({name: 'custbody_ecm_commissioncurrency', label: 'Currency of Service Fee'}));
        var mySearchObj = search.create({
            type: 'salesorder',
            filters: filters,
            columns: columns
        });
        var res = commonApi.getAllData(mySearchObj);

        for(var j = 0; j < res.length;j++){
            var json = {};
            var isNewLine = false;
            for(var i = 1;i < columns.length;i++){
                json[columns[i].name] = res[j].getValue(columns[i]);
                for (var k = 0; k < line.length; k++) {
                    if (json[columns[i].name] != line[k][columns[i].name]) {
                        if(diffArr.indexOf(columns[i].label) == -1){
                            diffArr.push(columns[i].label);
                        }
                        isNewLine = true;
                    }
                }
            }
            if(isNewLine || line.length == 0){
                line.push(json);
            }
        }
        data.diffArr = diffArr;
        data.line = line;

        return data;
    }

    return {
        pageInit: pageInit,
        // fieldChanged: fieldChanged,
        saveRecord: saveRecord,
        searchData: searchData
    };

});
