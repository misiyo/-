/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * version      date            author              remark
 * 1.0          2023/02/20      Gino Lu             Shipping Schedule票号自动编码（1018529）
 * 2.0          2023/02/22      Gino Lu             bug修改
 * 3.0          2023/02/23      John Wang           ShippingSchedule保存后，回写SC明细行已生成数量（1018529）
 * 3.0          2023/02/23      Gino Lu             bug修改
 * 4.0          2023/03/17      John Wang           v3新增合计字段回写（1018529）
 */
define(['N/record', 'N/runtime', 'N/search', 'SuiteScripts/tools/common_api.js'],
    /**
     * @param{record} record
     * @param{runtime} runtime
     * @param{search} search
     * @param commonApi
     */
    (record, runtime, search, commonApi) => {
        const SS_SUBID = 'recmachcustrecord_sscd_parent';//Shipping Schedule sublistId
        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed before record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const beforeSubmit = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {
            if ('delete' == scriptContext.type) {
                return;
            }
            createNo(scriptContext);
            if('customrecord_shipping_schedule' == scriptContext.newRecord.type) {
                ssWriteBackSc(scriptContext);
            }
        }

        /**
         * 基础数据自动编码
         * @param scriptContext
         */
        const createNo = (scriptContext) => {
            try {
                let recType = scriptContext.newRecord.type;
                // log.debug('recType', recType);
                let recId = scriptContext.newRecord.id;
                // log.debug('recId', recId);
                let isCreate = (scriptContext.type == 'create') ? true : false;
                let curObj = record.load({type: recType, id: recId});

                if(isCreate && recType == 'customrecord_shipping_schedule'){
                    createScNo(curObj);
                }
            } catch (e) {
                log.error('CreateNo Error', e);
            }
        }

        /**
         * 销售合同自动编码
         * @param recType
         * @param curObj
         */
        const createScNo = (curObj) => {
            let scNumber = curObj.getText('custrecord_ssc_scnumber').split(/ /g);
            let scName = scNumber[Number(scNumber.length).sub(1)].replace('#', '');
            // let scFields = search.lookupFields({
            //     type: 'customsale_ecm_sales_contract',
            //     id: scNumber,
            //     columns: ['tranid']
            // });
            // if(scFields) {
            //     scName = scFields.tranid;
            // }
            log.debug('scName', scName);
            let scSearch = search.create({
                type: curObj.type,
                filters: [
                    ['formulatext: TO_CHAR({name})', 'startswith', scName],
                    'and',
                    ['internalid', 'noneof', curObj.id]
                ],
                columns: [
                    search.createColumn({name: 'name'})
                ],
            });
            let myDet = commonApi.getAllData(scSearch);
            let newName = scName + '-' + Number(myDet.length).add(1);
            log.debug('newName', newName);
            curObj.setValue({fieldId: 'name', value: newName.trim()});
            curObj.save({ignoreMandatoryFields: true, enableSourcing: true});
        }

        /**
         * SS回写SC明细行已生成数量
         * @param scriptContext
         */
        const ssWriteBackSc = scriptContext => {
            if('USERINTERFACE' != runtime.executionContext && 'SUITELET' != runtime.executionContext) {
                return;
            }
            let newRecord = scriptContext.newRecord,
                type = scriptContext.type;
            try {
                let obj = record.load({type: newRecord.type, id: newRecord.id});
                let scid = obj.getValue({fieldId: 'custrecord_ssc_scnumber'});//销售合同
                let newLineData = formatSSLineData(obj),
                    oldLineData = {};
                if('edit' == type) {
                    let oldRecord = scriptContext.oldRecord;
                    oldLineData = formatSSLineData(oldRecord);
                }
                //格式化差异数据并更新
                let updData = {};
                for(key in ('edit' == type ? oldLineData : newLineData)) {
                    updData[key] = Number(oldLineData[key] || 0).sub(Number(newLineData[key] || 0));
                }
                log.debug('ss回写sc明细行====' + newRecord.id, JSON.stringify(updData));
                let scObj = record.load({type: 'salesorder', id: scid}),
                    saveFlag = false;
                let createdQtyTotal = scObj.getValue({fieldId: 'custbody_ecm_sumqtyof_sscreated'});
                for(key in updData) {
                    let index = scObj.findSublistLineWithValue({sublistId: 'item', fieldId: 'custcol_ecm_uniquekey', value: key});
                    if(index > -1) {
                        saveFlag = true;
                        let createdQty = scObj.getSublistValue({sublistId: 'item', fieldId: 'custcol_ecm_shipings_qty_created', line: index});
                        createdQtyTotal = Number(createdQtyTotal || 0).sub(Number(updData[key] || 0));
                        scObj.setSublistValue({sublistId: 'item', fieldId: 'custcol_ecm_shipings_qty_created', line: index, value: Number(createdQty || 0).sub(Number(updData[key] || 0))});
                    }
                }
                if(true == saveFlag) {
                    scObj.setValue({fieldId:'custbody_ecm_sumqtyof_sscreated', value:createdQtyTotal});
                    scObj.save({ignoreMandatoryFields: true, enableSourcing: true});
                }
            } catch (e) {
                log.error('ss回写sc数量===>' + newRecord.id, e);
            }
        }

        /**
         * 格式化明细行数量data
         * @param obj
         * @return {{}}         {scLineId:qty}
         */
        const formatSSLineData = obj => {
            let lineData = {};//{scLineId: qty}
            let length = obj.getLineCount({sublistId: SS_SUBID});
            for(let i = 0; i < length; i++) {
                let lineId = obj.getSublistValue({sublistId: SS_SUBID, fieldId: 'custrecord_sscd_sclineid', line: i}),
                    qty = obj.getSublistValue({sublistId: SS_SUBID, fieldId: 'custrecord_sscd_ssqty', line: i});
                if('' != lineId) {
                    lineData[lineId] = qty;
                }
            }
            return lineData;
        }

        return {
            // beforeLoad,
            // beforeSubmit,
            afterSubmit
        }

    });
