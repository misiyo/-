/**
 * @NApiVersion 2.1
 * @NScriptType ScheduledScript
 *
 * Version		Date			Author			Memo
 * 1.0			2023/02/17		Gino Lu		    中信保：收汇确认批复（1018293）
 * 2.0			2023/03/07		Gino Lu		    测试修改
 * 3.0			2023/03/09		Gino Lu		    测试修改
 */
define(['N/https', 'N/search', 'N/record', 'N/task', '/SuiteScripts/tools/common_api.js', '/SuiteScripts/tools/hc_edi_interface_tool.js', '/SuiteScripts/tools/moment.js', '/SuiteScripts/tools/ramda.min.js'],
    /**
     * @param{https} https
     * @param search
     * @param record
     * @param{task} task
     * @param commonApi
     * @param interfaceTool
     * @param moment
     * @param ramda
     */
    (https, search, record, task, commonApi, interfaceTool, moment, ramda) => {
        const QUOTA_BALANCE_TYPE = 'customrecord_ecm_sinosure_receiptapprove';//收汇确认反馈id
        const LOG_TYPE = 'customrecord_hc_edi_interface_log';//日志类型
        const IMETHOD = 'getEdiReceiptApproveInfo';//接口method
        const ITYPE = 11;//接口类型：收汇确认批复（获取）
        const FIELD_MAPPING = {
            'noticeSerialNo' : 'custrecord_esra_noticeserialno', //主键:中信保通知序号
            'clientNo' : 'custrecord_esra_clientno', //企业标识
            'corpSerialNo' : 'custrecord_esra_corpserialno', //企业内部收汇唯一标识
            'policyNo' : 'custrecord_esra_policyno', //保险单号
            'invoiceNo' : 'custrecord_esra_invoiceno', //发票编号
            'transportDate' : 'custrecord_esra_transportdate', //出运日期
            'approveFlag' : 'custrecord_esra_approveflag', //审批标志
            'unAcceptCode' : 'custrecord_esra_unacceptcode', //错误信息代码
            'unAcceptReason': 'custrecord_esra_unacceptreason', //申请退回/不通过原因
            'notifyTime': 'custrecord_esra_notifytime', //最新通知时间
            'errorCode': 'custrecord_esra_errorcode', //错误代码
            'errorMsg': 'custrecord_esra_errormsg' //错误描述
        };
        /**
         * Defines the Scheduled script trigger point.
         * @param {Object} scriptContext
         * @param {string} scriptContext.type - Script execution context. Use values from the scriptContext.InvocationType enum.
         * @since 2015.2
         */
        const execute = (scriptContext) => {
            let startDate = getNewDateFormat(-2);
            let endDate = getNewDateFormat(0);
            let reqData = {
                datas: {
                    startDate: startDate + " 00:00:00",
                    endDate: endDate + " 23:59:59"
                },
                imethod: IMETHOD
            };
            log.debug('reqData', reqData);
            let rtnData = interfaceTool.requestEdiServer(reqData, ITYPE);
            log.debug('接口返回数据', rtnData);
            if(true == rtnData.valid) {
                let infoData = rtnData.data.datas;
                if(infoData && infoData.length > 0) {
                    infoData = JSON.parse(infoData);
                    //获取所有noticeSerialNo，匹配已有数据
                    let noticeSerialNo = ramda.groupBy(ramda.path(['noticeSerialNo']))(infoData);
                    let existNoticeSerialNoData = formatExistNoticeSerialNo(Object.keys(noticeSerialNo));
                    let corpSerialNo = ramda.groupBy(ramda.path(['corpSerialNo']))(infoData);
                    let corpSerialNoData = formatCorpSerialNo(Object.keys(corpSerialNo));
                    let methodData = formatPayMethod();
                    let createdDataIdArray = [],
                        applyRecordIdArray = [],
                        logUpdVal = {
                            custrecord_hc_inf_process_msg: '',
                            custrecord_hc_inf_errorflag: false
                        };
                    try {
                        for(let i = 0; i < infoData.length; i++) {
                            let obj;
                            if('undefined' == typeof existNoticeSerialNoData[infoData[i].noticeSerialNo]) {
                                obj = record.create({type: QUOTA_BALANCE_TYPE});
                            } else {
                                obj = record.load({type: QUOTA_BALANCE_TYPE, id: existNoticeSerialNoData[infoData[i].noticeSerialNo]});
                            }
                            for(let key in infoData[i]) {
                                if('transportDate' == key) {
                                    let tmpDate = moment(infoData[i].key);
                                    if (!isNaN(tmpDate)) {
                                        let tmpDateStr = tmpDate.format('MM/DD/YYYY');
                                        obj.setText({fieldId: FIELD_MAPPING[key], text: tmpDateStr});
                                    }
                                }
                                else {
                                    obj.setValue({fieldId: FIELD_MAPPING[key], value: infoData[i][key]});
                                }
                            }
                            let recordId = obj.save({enableSourcing: true, ignoreMandatoryFields: true});
                            createdDataIdArray.push(recordId);

                            //更新收汇确认申报单
                            if(corpSerialNoData[infoData[i].corpSerialNo] != '' && corpSerialNoData[infoData[i].corpSerialNo]){
                                let applyRecord = record.load({type: 'customrecord_ecm_sinosure_receiptapply', id: corpSerialNoData[infoData[i].corpSerialNo]});
                                if(infoData[i].approveFlag !== '') {
                                    if (infoData[i].approveFlag == 1 || infoData[i].approveFlag == '1') {
                                        applyRecord.setValue({fieldId: 'custrecord_esre_status', value: 5});
                                    }
                                    else {
                                        applyRecord.setValue({fieldId: 'custrecord_esre_status', value: 6});
                                    }
                                }
                                if(infoData[i].unAcceptCode) {
                                    applyRecord.setValue({fieldId: 'custrecord_esre_errorcode', value: infoData[i].unAcceptCode});
                                }
                                else {
                                    applyRecord.setValue({fieldId: 'custrecord_esre_errorcode', value: ''});
                                }
                                if(infoData[i].unAcceptReason) {
                                    applyRecord.setValue({fieldId: 'custrecord_esre_errormsg', value: infoData[i].unAcceptReason});
                                }
                                else {
                                    applyRecord.setValue({fieldId: 'custrecord_esre_errormsg', value: ''});
                                }
                                applyRecord.save({enableSourcing: true, ignoreMandatoryFields: true});
                                applyRecordIdArray.push(corpSerialNoData[infoData[i].corpSerialNo]);
                            }
                        }
                        logUpdVal.custrecord_hc_inf_process_msg = createdDataIdArray.join('&');
                    } catch (e) {
                        log.error('生成收汇确认反馈error===>' + rtnData.logId, e);
                        if(createdDataIdArray && createdDataIdArray.length > 0) {
                            createdDataIdArray.forEach(function (cid) {
                                record.delete({type: QUOTA_BALANCE_TYPE, id: cid});
                            });
                        }
                        if(applyRecordIdArray && applyRecordIdArray.length > 0) {
                            applyRecordIdArray.forEach(function (aid) {
                                let applyRecord = record.load({type: 'customrecord_ecm_sinosure_receiptapply', id: aid});
                                applyRecord.setValue({fieldId: 'custrecord_esre_status', value: 3});
                                applyRecord.setValue({fieldId: 'custrecord_esre_errorcode', value: ''});
                                applyRecord.setValue({fieldId: 'custrecord_esre_errormsg', value: ''});
                                applyRecord.save({enableSourcing: true, ignoreMandatoryFields: true});
                            });
                        }
                        logUpdVal.custrecord_hc_inf_process_msg = e.message;
                        logUpdVal.custrecord_hc_inf_errorflag = true;
                    }
                    log.debug('收汇确认反馈id', createdDataIdArray);
                    log.debug('收汇确认申请id', applyRecordIdArray);
                    record.submitFields({
                        type: LOG_TYPE,
                        id: rtnData.logId,
                        values: logUpdVal
                    });
                }
            }
        }

        /**
         * 搜索corpSerialNo记录
         * @param corpSerialNoArray              本次返回corpSerialNo
         * @return {{}}                     {corpSerialNo：id}
         */
        const formatCorpSerialNo = corpSerialNoArray => {
            let existData = {};//{corpSerialNo：id}
            if(!corpSerialNoArray || 0 == corpSerialNoArray.length) {
                return existData;
            }
            let filters = [],
                columns = ['name'];
            corpSerialNoArray.forEach(function (corpSerialNo) {
                filters.push(['custrecord_esre_corpserialno', 'is', corpSerialNo]);
                filters.push('or');
            });
            filters.pop();
            let mySearchObj = search.create({
                type: 'customrecord_ecm_sinosure_receiptapply',
                filters: filters,
                columns: columns
            });
            let results = commonApi.getAllData(mySearchObj);
            if(results && results.length > 0) {
                results.forEach(function (res) {
                    existData[res.getValue(columns[0])] = res.id;
                });
            }
            log.debug('corpSerialNo数据', existData);
            return existData;
        }

        /**
         * 搜索已存在noticeSerialNo记录
         * @param noticeSerialNoArray              本次返回noticeSerialNo
         * @return {{}}                     {noticeSerialNo：id}
         */
        const formatExistNoticeSerialNo = noticeSerialNoArray => {
            let existData = {};//{noticeSerialNo：id}
            if(!noticeSerialNoArray || 0 == noticeSerialNoArray.length) {
                return existData;
            }
            let filters = [],
                columns = ['custrecord_esra_noticeserialno'];
            noticeSerialNoArray.forEach(function (noticeSerialNo) {
                filters.push(['custrecord_esra_noticeserialno', 'is', noticeSerialNo]);
                filters.push('or');
            });
            filters.pop();
            let results = commonApi.searchAllData(QUOTA_BALANCE_TYPE, filters, columns);
            if(results && results.length > 0) {
                results.forEach(function (res) {
                    existData[res.getValue(columns[0])] = res.id;
                });
            }
            log.debug('已存在noticeSerialNo数据', existData);
            return existData;
        }

        /**
         * 搜索【中信保-支付方式】
         * @return {{}}                     {code：id}
         */
        const formatPayMethod = () => {
            let existData = {};
            let filters = [],
                columns = ['custrecord_esp_code'];
            let results = commonApi.searchAllData('customrecord_ecm_sinosure_paymethod', filters, columns);
            if(results && results.length > 0) {
                results.forEach(function (res) {
                    existData[res.getValue(columns[0])] = res.id;
                });
            }
            return existData;
        }

        /**
         * 日期转换
         * @param date
         * @returns {string}
         */
        const getNewDateFormat = (num) => {
            let date = getCurrentZoneDate('');
            date.setDate(date.getDate() + num);
            let year = date.getFullYear();
            let month = date.getMonth() + 1;
            let day = date.getDate();
            if (month < 10){
                month = '0' + month;
            }
            if (day < 10){
                day = '0' + day;
            }
            return year + '-' + month + '-' + day;
        }

        //获得当前时区下的日期
        function getCurrentZoneDate(dateStr){
            let dateOri = '';
            if('' == dateStr) {
                dateOri = new Date();
            } else {
                dateOri = new Date(dateStr);
            }
            let year = dateOri.getUTCFullYear(), month = dateOri.getUTCMonth(), day = dateOri.getUTCDate();
            let hour = dateOri.getUTCHours(), minute = dateOri.getUTCMinutes(), second = dateOri.getUTCSeconds();
            dateOri = new Date(year, month, day, hour, minute, second);

            let oriTime = dateOri.getTime();
            let newDate = new Date(oriTime);

            return newDate;
        }

        return {execute}

    });