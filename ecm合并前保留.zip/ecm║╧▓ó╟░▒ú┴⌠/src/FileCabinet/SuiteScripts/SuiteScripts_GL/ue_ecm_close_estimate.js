/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * Version      Date            Author              Memo
 * 1.0          2023/02/06      Gino Lu            【Estimate】失效【ID1017892】
 */
define(['N/record', 'N/runtime', 'N/search', '/SuiteScripts/tools/common_api.js'],
    /**
     * @param{record} record
     * @param{runtime} runtime
     * @param{search} search
     * @param commonApi
     */
    (record, runtime, search, commonApi) => {
        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed before record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const beforeSubmit = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {
            if(scriptContext.type == 'delete'){
                return;
            }
            if(scriptContext.type == 'create' || scriptContext.type == 'copy'){
                closeOtherEstimate(scriptContext);
            }
        }

        /**
         * 将其他估价单失效
         */
        const closeOtherEstimate = (scriptContext) =>{
            let newRec = scriptContext.newRecord;
            let oppoId = newRec.getValue('opportunity');
            if(!oppoId){
                return ;
            }

            let mySearchObj = search.create({
                type: 'estimate',
                filters: [
                    ['type','anyof','Estimate'],
                    'AND',
                    ['custbody_ecm_closed','is','F'],
                    'AND',
                    ['opportunity', 'anyof', oppoId],
                    'AND',
                    ['internalid', 'noneof', newRec.id]
                ],
                columns: [
                    search.createColumn({name: 'internalid'}),
                ]
            });
            let columns = mySearchObj.columns;
            let results = commonApi.getAllData(mySearchObj);
            if(results && results.length > 0) {
                results.forEach(result =>{
                    let oldEstId = result.getValue(columns[0]);
                    let oldEstRec = record.load({
                        type: 'estimate',
                        id: oldEstId
                    });
                    oldEstRec.setValue({fieldId: 'custbody_ecm_closed', value: true});
                    oldEstRec.save({enableSourcing: true, ignoreMandatoryFields: true});
                });
            }
        }

        return {
            // beforeLoad,
            // beforeSubmit,
            afterSubmit
        }

    });
