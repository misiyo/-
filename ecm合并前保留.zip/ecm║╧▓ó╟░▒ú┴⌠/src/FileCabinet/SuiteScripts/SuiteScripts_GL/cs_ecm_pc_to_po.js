/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 * version      date            author              remark
 * 1.0          2023/04/03      Gino Lu             PC 转 PO【ID1019456】
 */
define(['N/currentRecord', 'N/record', 'N/runtime', 'N/search', '/SuiteScripts/tools/common_api.js'],
/**
 * @param{currentRecord} currentRecord
 * @param{record} record
 * @param{runtime} runtime
 * @param{search} search
 * @param commonApi
 */
function(currentRecord, record, runtime, search, commonApi) {
    
    /**
     * Function to be executed after page is initialized.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.mode - The mode in which the record is being accessed (create, copy, or edit)
     *
     * @since 2015.2
     */
    function pageInit(scriptContext) {
        setPcToPoValues(scriptContext);
    }

    //初始化若为Pc to Po时设置字段值
    function setPcToPoValues(scriptContext) {
        var curRec = scriptContext.currentRecord;
        var curType = scriptContext.mode;
        var json = commonApi.formatHrefParamsAsJson();
        if(curType == 'copy' && json.cp == 'T'){
            var pcId = json.id;
            curRec.setValue({fieldId: 'custbody_ecm_pcfrom', value: pcId});
            curRec.setValue({fieldId: 'custbody_ecm_contract_to_order', value: true});
            curRec.setValue({fieldId: 'custbody_ecm_ordertype', value: 2});

            for(var i = 0;i < curRec.getLineCount({sublistId: 'item'});i++){
                curRec.selectLine({sublistId: 'item', line: i});
                var qty = curRec.getCurrentSublistValue({sublistId: 'item', fieldId: 'quantity'});
                var createQty = curRec.getCurrentSublistValue({sublistId: 'item', fieldId: 'custcol_ecm_creatpoqty'});

                curRec.setCurrentSublistValue({sublistId: 'item', fieldId: 'quantity', value: Number(qty).sub(createQty), ignoreFieldChange: true});
                curRec.setCurrentSublistValue({sublistId: 'item', fieldId: 'isclosed', value: false, ignoreFieldChange: true});
                curRec.commitLine({sublistId: 'item'});
            }
        }
    }

    /**
     * Function to be executed when field is changed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
     * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
     *
     * @since 2015.2
     */
    function fieldChanged(scriptContext) {
    }

    /**
     * Function to be executed when field is slaved.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     *
     * @since 2015.2
     */
    function postSourcing(scriptContext) {

    }

    /**
     * Function to be executed after sublist is inserted, removed, or edited.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @since 2015.2
     */
    function sublistChanged(scriptContext) {

    }

    /**
     * Function to be executed after line is selected.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @since 2015.2
     */
    function lineInit(scriptContext) {

    }

    /**
     * Validation function to be executed when field is changed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
     * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
     *
     * @returns {boolean} Return true if field is valid
     *
     * @since 2015.2
     */
    function validateField(scriptContext) {
        forbidChangeOrderType(scriptContext);
        return true;
    }

    //Pc to Po时禁止修改单据类型
    function forbidChangeOrderType(scriptContext) {
        var fieldId = scriptContext.fieldId;
        var curRec = scriptContext.currentRecord;

        if(fieldId == 'custbody_ecm_ordertype'){
            if(curRec.getValue('custbody_ecm_ordertype') == 1 && curRec.getValue('custbody_ecm_contract_to_order') == true){
                alert('You cannot choose the order type: Contract!');
                curRec.setValue({fieldId: 'custbody_ecm_ordertype', value: 2});
                return false;
            }
        }

        return true;
    }

    /**
     * Validation function to be executed when sublist line is committed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateLine(scriptContext) {
        checkLineInfo(scriptContext);
        return true;
    }

    var initItemData = {};
    //校验明细行内容
    function checkLineInfo(scriptContext) {
        var subId = scriptContext.sublistId;
        var curRec = scriptContext.currentRecord;
        if('item' == subId && curRec.getValue('custbody_ecm_contract_to_order') == true) {
            var pcId = curRec.getValue('custbody_ecm_pcfrom');
            var lineId = curRec.getCurrentSublistValue({sublistId: 'item', fieldId: 'custcol_emc_line_no'});

            if(lineId == '') {
                alert('Dont allow to create new line!');
                return false;
            }
            else {
                // 根据行唯一键，查找到该行原本的可开票金额
                var mySearch = search.create({
                    type: 'purchaseorder',
                    filters:[
                        ['type','anyof','PurchOrd'],
                        'AND',
                        ['internalid', 'anyof', pcId],
                        'AND',
                        ['custcol_emc_line_no', 'equalto', lineId],
                        'AND',
                        ['mainline', 'is', 'F'],
                        'AND',
                        ['taxline', 'is', 'F']
                    ],
                    columns:['quantity', 'custcol_ecm_creatpoqty', 'fxrate'],
                });
                var myDet = mySearch.run().getRange({start:0,end:10});
                if(myDet && myDet.length > 0) {
                    initItemData[lineId] = Number(myDet[0].getValue('quantity')).sub(Number(myDet[0].getValue('custcol_ecm_creatpoqty')));

                    var objId = curRec.getCurrentSublistIndex('item');
                    if(curRec.id) {
                        var rec = record.load({
                            type: 'purchaseorder',
                            id: curRec.id
                        });
                        initItemData[lineId] = Number(initItemData[lineId])
                            .add(Number(rec.getSublistValue({sublistId: 'item', fieldId: 'quantity', line: objId})));
                    }

                    // 和当前行qty数据进行比较
                    var qty = curRec.getCurrentSublistValue({sublistId: 'item', fieldId: 'quantity'});
                    if(Number(qty) > Number(initItemData[lineId])) {
                        alert('The quantity cannot be more than ' + initItemData[lineId] + '！');
                        curRec.cancelLine({sublistId: 'item'});
                        return false;
                    }
                    curRec.selectLine({sublistId: 'item', line: objId});
                    curRec.setCurrentSublistValue({sublistId: 'item', fieldId: 'rate', value: myDet[0].getValue('fxrate')});
                    // curRec.commitLine({sublistId: 'item'});
                }
            }
        }
        return true;
    }

    /**
     * Validation function to be executed when sublist line is inserted.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateInsert(scriptContext) {

    }

    /**
     * Validation function to be executed when record is deleted.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateDelete(scriptContext) {

    }

    /**
     * Validation function to be executed when record is saved.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @returns {boolean} Return true if record is valid
     *
     * @since 2015.2
     */
    function saveRecord(scriptContext) {

    }

    return {
        pageInit: pageInit,
        // fieldChanged: fieldChanged,
        // postSourcing: postSourcing,
        // sublistChanged: sublistChanged,
        // lineInit: lineInit,
        validateField: validateField,
        validateLine: validateLine,
        // validateInsert: validateInsert,
        // validateDelete: validateDelete,
        // saveRecord: saveRecord
    };
    
});
