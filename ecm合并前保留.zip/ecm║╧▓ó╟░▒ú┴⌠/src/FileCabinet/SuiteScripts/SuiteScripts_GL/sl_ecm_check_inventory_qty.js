/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 * version      date            author              remark
 * 1.0          2023/03/06      Gino Lu             校验库存可用量页面【ID1018531】
 * 2.0          2023/03/07      Gino Lu             完善逻辑
 * 3.0          2023/03/13      Gino Lu             逻辑变更
 * 4.0          2023/03/15      Gino Lu             逻辑变更
 * 5.0          2023/03/16      Gino Lu             完善逻辑
 * 6.0          2023/03/21      Gino Lu             变更逻辑
 * 7.0          2023/03/24      Gino Lu             变更逻辑
 */
define(['N/config', 'N/encode', 'N/file', 'N/format', 'N/http', 'N/https', 'N/record', 'N/url', 'N/runtime', 'N/search', 'N/ui/serverWidget', '/SuiteScripts/tools/common_api.js'],
    /**
     * @param{config} config
     * @param{encode} encode
     * @param{file} file
     * @param{format} format
     * @param{http} http
     * @param{https} https
     * @param{record} record
     * @param{url} url
     * @param{runtime} runtime
     * @param{search} search
     * @param{serverWidget} serverWidget
     * @param commonApi
     */
    (config, encode, file, format, http, https, record, url, runtime, search, serverWidget, commonApi) => {
        /**
         * Defines the Suitelet script trigger point.
         * @param {Object} scriptContext
         * @param {ServerRequest} scriptContext.request - Incoming request
         * @param {ServerResponse} scriptContext.response - Suitelet response
         * @since 2015.2
         */
        const onRequest = (scriptContext) => {
            let request = scriptContext.request;
            let response = scriptContext.response;
            let params = request.parameters;
            // log.debug('params', params);

            if ('GET' == request.method) {
                let form = createForm(params);
                response.writePage(form);
            }
        }

        // 创建页面
        function createForm(params) {
            let form = serverWidget.createForm({title: 'Inventory Detail', hideNavBar: true});
            form.clientScriptModulePath = './cs_ecm_check_inventory_qty.js';
            form.addButton({id: 'custpage_btn_submit', label: 'Submit', functionName: 'doSubmit'});
            form.addButton({id: 'custpage_btn_cancel', label: 'Cancel', functionName: 'doCancel'});

            let scdQtyField = form.addField({id: 'custpage_inventory_scdqty', type: 'text', label: 'SCD Quantity'});
            scdQtyField.updateDisplayType({displayType: serverWidget.FieldDisplayType.INLINE});
            if(params.scdQty){
                scdQtyField.defaultValue = params.scdQty;
            }
            let scdItemIdField = form.addField({id: 'custpage_inventory_itemid', type: 'select', source: 'lotnumberedinventoryitem', label: 'SCD Item'});
            scdItemIdField.updateDisplayType({displayType: serverWidget.FieldDisplayType.INLINE});
            if(params.itemId){
                scdItemIdField.defaultValue = params.itemId;
            }
            let scdLineIdField = form.addField({id: 'custpage_inventory_lineid', type: 'select', source: 'customrecord_ecm_scd_line', label: 'SCD Line'});
            scdLineIdField.updateDisplayType({displayType: serverWidget.FieldDisplayType.INLINE});
            if(params.lineId){
                scdLineIdField.defaultValue = params.lineId;
            }
            let locationField = form.addField({id: 'custpage_inventory_location', type: 'select', source: 'location', label: 'location'});
            locationField.updateDisplayType({displayType: serverWidget.FieldDisplayType.INLINE});
            if(params.location){
                locationField.defaultValue = params.location;
            }

            let sublist = form.addSublist({id: 'inventory_list', label: 'Inventory Detail', type: 'INLINEEDITOR'});
            let data = getInventoryInfo(params);
            let numberField = sublist.addField({id: 'custpage_inventory_number', type: 'select', label: 'Batch Information'});
            numberField.addSelectOption({value: '', text: ''});
            data.forEach(json => {
                numberField.addSelectOption({value: json.value, text: json.text});
            });
            let maxQtyField = sublist.addField({id: 'custpage_max_qty', type: 'text', label: 'Available Quantity', displayType: serverWidget.FieldDisplayType.ENTRY});
            maxQtyField.updateDisplayType({displayType: serverWidget.FieldDisplayType.DISABLED});

            let costField = sublist.addField({id: 'custpage_inventory_cost', type: 'text', label: 'Inventory Cost', displayType: serverWidget.FieldDisplayType.ENTRY});
            costField.updateDisplayType({displayType: serverWidget.FieldDisplayType.DISABLED});

            let unitField = sublist.addField({id: 'custpage_inventory_unit', type: 'select', source: '-221', label: 'Unit', displayType: serverWidget.FieldDisplayType.ENTRY});
            unitField.updateDisplayType({displayType: serverWidget.FieldDisplayType.DISABLED});

            let inventoryQtyField = sublist.addField({id: 'custpage_inventory_qty', type: 'text', label: 'Quantity', displayType: serverWidget.FieldDisplayType.ENTRY});

            let palletNumberField = sublist.addField({id: 'custpage_inventory_pallet_number', type: 'text', label: 'PALLET NUMBER', displayType: serverWidget.FieldDisplayType.ENTRY});

            let perPalletField = sublist.addField({id: 'custpage_inventory_per_pallet', type: 'text', label: 'NET WEIGHT PER PALLET', displayType: serverWidget.FieldDisplayType.ENTRY});

            let palletSizeField = sublist.addField({id: 'custpage_inventory_pallet_size', type: 'text', label: 'PALLET SIZE', displayType: serverWidget.FieldDisplayType.ENTRY});

            let packageNumberField = sublist.addField({id: 'custpage_inventory_package_number', type: 'text', label: 'NUMBER OF PACKAGES', displayType: serverWidget.FieldDisplayType.ENTRY});

            let grossWeightField = sublist.addField({id: 'custpage_inventory_gross_weight', type: 'text', label: 'GROSS WEIGHT', displayType: serverWidget.FieldDisplayType.ENTRY});

            let netWeightField = sublist.addField({id: 'custpage_inventory_net_weight', type: 'text', label: 'NET WEIGHT', displayType: serverWidget.FieldDisplayType.ENTRY});

            let volumeField = sublist.addField({id: 'custpage_inventory_volume', type: 'text', label: 'VOLUME', displayType: serverWidget.FieldDisplayType.ENTRY});

            let dateProductionField = sublist.addField({id: 'custpage_inventory_date_production', type: 'date', label: 'DATE OF PRODUCTION', displayType: serverWidget.FieldDisplayType.ENTRY});

            return form;
        }

        //获取批次信息
        function getInventoryInfo(params) {
            let data = [];
            let serialArr = [];
            let inventoryBalanceSearchObj = search.create({ //获取所有关联的批次号和on hand数量
                type: 'invtnumberitembalance',
                filters: [
                    ['formulanumeric: {onhand}', 'greaterthan', '0'],
                    "AND",
                    ['inventorynumber', 'noneof', '@NONE@'],
                    'AND',
                    ['location', 'anyof', params.location],
                    'AND',
                    ['item', 'anyof', params.itemId]
                ],
                columns: [
                    search.createColumn({name: 'inventorynumber', summary: 'GROUP', sort: search.Sort.ASC, label: 'Inventory Number'}),
                    search.createColumn({name: 'onhand', summary: 'SUM', label: 'On Hand'})
                ]
            });
            let results = commonApi.getAllData(inventoryBalanceSearchObj);
            let columns = inventoryBalanceSearchObj.columns;
            if(results && results.length > 0) {
                for (let i = 0; i < results.length; i++) {
                    let inventoryNumberList = {};
                    let serial = results[i].getValue(columns[0]);
                    serialArr.push(serial);
                    inventoryNumberList.value = serial;
                    inventoryNumberList.text = results[i].getText(columns[0]);
                    inventoryNumberList.qty = results[i].getValue(columns[1]);
                    data.push(inventoryNumberList);
                }
            }
            // log.debug('oriData', data);

            if(serialArr.length > 0){
                let customJson = getCustomInventoryQty(params, serialArr);
                for(let serial in customJson){ //查找自定义库存详情中的批次数量
                    data.find((json, index) => { //标准库存详情的批次数量-自定义库存详情中的批次数量
                        if(json.value == serial){
                            data[index].qty = Number(data[index].qty).sub(Number(customJson[serial]));
                        }
                    });
                }
            }
            for(let i = Number(data.length).sub(1); i >=0; i--){
                if(Number(data[i].qty) <= 0){ //批次数量小于等于0的删除
                    data.splice(i, 1);
                }
            }

            return data;
        }

        //获取自定义库存详情中的批次数量
        function getCustomInventoryQty(params, serialArr) {
            let data = {};
            let mySearchObj = search.create({
                type: 'customrecord_ecm_scd_line',
                filters: [
                    ['custrecord_id_spline.custrecord_id_item','anyof',params.itemId],
                    'AND',
                    ['custrecord_id_spline.custrecord_id_seriallot','anyof',serialArr],
                    'AND',
                    ['custrecord_id_spline.custrecord_id_location','anyof',params.location],
                    'AND',
                    ['custrecord_scdline_sp.custrecord_sp_status','anyof','1','6','7'] //未出运,订舱成功,预估费用已提交
                ],
                columns: [
                    search.createColumn({name: 'custrecord_id_seriallot', join: 'CUSTRECORD_ID_SPLINE', sort: search.Sort.ASC, summary: 'GROUP', label: 'SERIAL/LOT NUMBER'}),
                    search.createColumn({name: 'custrecord_id_quantity', join: 'CUSTRECORD_ID_SPLINE', summary: 'SUM', label: 'Quantity'})
                ]
            });
            let res = commonApi.getAllData(mySearchObj);
            let columns = mySearchObj.columns;
            if(res && res.length > 0){
                for(let i = 0; i < res.length; i++){
                    data[res[i].getValue(columns[0])] = res[i].getValue(columns[1]);
                }
            }
            // log.debug('customData', data);

            return data;
        }

        return {onRequest}

    });
