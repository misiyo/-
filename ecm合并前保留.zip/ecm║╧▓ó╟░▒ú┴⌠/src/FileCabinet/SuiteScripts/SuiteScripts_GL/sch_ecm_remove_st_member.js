/**
 * @NApiVersion 2.1
 * @NScriptType ScheduledScript
 * Version      Date            Author              Memo
 * 1.0          2023/02/06      Gino Lu             Sales Team Member Remove All【ID1018284】
 */
define(['N/record', 'N/runtime', 'N/search', '/SuiteScripts/tools/common_api.js'],
    /**
     * @param{record} record
     * @param{runtime} runtime
     * @param{search} search
     * @param commonApi
     */
    (record, runtime, search, commonApi) => {

        /**
         * Defines the Scheduled script trigger point.
         * @param {Object} scriptContext
         * @param {string} scriptContext.type - Script execution context. Use values from the scriptContext.InvocationType enum.
         * @since 2015.2
         */
        const execute = (scriptContext) => {
            let scriptObj = runtime.getCurrentScript();
            let params = scriptObj.getParameter('custscript_ecm_search_st_member');
            log.debug('params', params);
            let data = getData(params);
            log.debug('data', data);
            for(let key in data){
                removeSalesTeamLine(data[key]);
            }
        }

        //获取当前系统内搜索下所有结果
        const getData = (params) => {
            let data = {}
            try{
                let mySearchObj = search.load({
                    id: params
                });
                let results = commonApi.getAllData(mySearchObj);
                if(results && results.length > 0) {
                    results.forEach(result =>{
                        let json = {
                            id: result.id,
                            type: result.recordType
                        };
                        data[json.id] = json;
                    });
                }
            }catch (e) {
              log.error('getData Error', e);
            }
            return data;
        }

        //删除单据下sales team明细行
        const removeSalesTeamLine = (value) => {
            try {
                let customRec = record.load({
                    type: value.type,
                    id: value.id
                });
                let lineCnt = customRec.getLineCount('salesteam');
                for(let i = Number(lineCnt).sub(1);i >= 0;i--){
                    customRec.removeLine({sublistId: 'salesteam', line: i, ignoreRecalc: true});
                }
                customRec.save({enableSourcing: true, ignoreMandatoryFields: true});
            }catch (e){
                log.error('removeSalesTeamLine Error', e);
            }
        }

        return {execute}

    });
