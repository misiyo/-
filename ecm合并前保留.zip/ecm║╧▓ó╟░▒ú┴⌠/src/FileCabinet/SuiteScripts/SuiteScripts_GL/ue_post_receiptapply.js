/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * version      date            author          remark
 * 1.0          2023/02/17      Gino Lu		    中信保：收汇确认申请（1018293）
 * 2.0			2023/03/07		Gino Lu		    测试修改
 * 3.0			2023/03/08		Gino Lu		    测试修改
 * 4.0			2023/03/09		Gino Lu		    测试修改
 */
define(['N/record', 'N/search', '/SuiteScripts/tools/common_api.js', '/SuiteScripts/tools/hc_edi_interface_tool.js', '/SuiteScripts/tools/moment.js', '/SuiteScripts/tools/ramda.min.js'],
    /**
     * @param{record} record
     * @param{search} search
     */
    (record, search, commonApi, interfaceTool, moment, ramda) => {
        const QUOTA_BALANCE_TYPE = 'customrecord_ecm_sinosure_receiptapply';//收汇确认申请记录id
        const LOG_TYPE = 'customrecord_hc_edi_interface_log';// 日志类型
        const IMETHOD = 'doEdiReceiptApply';// 接口method
        const ITYPE = 10;//接口类型：收汇确认申请（推送）
        const FIELD_MAPPING = {
            'corpSerialNo' : 'name', //流水号
            'clientNo' : 'custrecord_esre_clientno', //企业标识
            'policyNo' : 'custrecord_esre_policyno', //保险单号
            'buyerNo' : 'custrecord_esre_buyerno', //中国信保买方代码
            'invoiceNo' : 'custrecord_esre_invoiceno', //发票号
            'transportDate' : 'custrecord_esre_transportdate', //出运日期
            'receiptDate' : 'custrecord_esre_receiptdate', //实际收汇日期
            'receiptFlag' : 'custrecord_esre_receiptflag', //收汇标志
            'receiptSum' : 'custrecord_esre_receiptsum', //累计已收汇金额（币种同申报币种）
            'applicantName' : 'custrecord_esre_applicantname', //申请人姓名
            'applyTime' : 'custrecord_esre_applytime', //申请时间
            'errorCode': 'custrecord_esre_errorcode', //错误代码
            'errorMsg': 'custrecord_esre_errormsg' //错误描述
        };

        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed before record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const beforeSubmit = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {
            if(['delete','xedit'].includes(scriptContext.type)) return ;
            let logUpdVal = {
                custrecord_hc_inf_process_msg: '',
                custrecord_hc_inf_errorflag: false
            };
            let newRec = scriptContext.newRecord;
            let rtnData = {};
            try{
                let status = newRec.getValue('custrecord_esre_status'); //单据状态
                let isPost = newRec.getValue('custrecord_esre_postsinosure'); //是否推送中信保
                let shipId = newRec.getValue('custrecord_esre_sourcelist'); //关联出运申请批复
                let shipStatus = shipSearch(shipId);
                if (3 == status && isPost == false && shipStatus){ //status=信保通过
                    let datas = [];
                    let dataJson = {};
                    for(let key in FIELD_MAPPING){
                        if(key == 'receiptDate' || key == 'transportDate' || key == 'applyTime'){
                            let date = newRec.getValue(FIELD_MAPPING[key]);
                            if(date != ''){
                                dataJson[key] = getDateFormat(date);
                            }
                        }
                        else if(newRec.getText(FIELD_MAPPING[key]) == ''){
                            if(newRec.getValue(FIELD_MAPPING[key]) != ''){
                                dataJson[key] = newRec.getValue(FIELD_MAPPING[key]);
                            }
                        }
                        else if(key == 'receiptFlag'){
                            dataJson[key] = newRec.getValue(FIELD_MAPPING[key]);
                        }
                        else {
                            dataJson[key] = newRec.getText(FIELD_MAPPING[key]);
                        }
                    }
                    datas.push(dataJson);
                    log.debug('datas', datas);

                    let body = {};
                    body.datas = datas;
                    body.imethod = IMETHOD;
                    log.debug('body',body)
                    try{
                        rtnData = interfaceTool.requestEdiServer(body, ITYPE);
                        log.debug('rtnData', rtnData);
                        record.submitFields({
                            type: LOG_TYPE,
                            id: rtnData.logId,
                            values: logUpdVal
                        });
                        record.submitFields({
                            type: newRec.type,
                            id: newRec.id,
                            values: {
                                custrecord_esre_postsinosure: true,
                                custrecord_esre_posterromsg: ''
                            }
                        });
                    }catch (e){
                        logUpdVal.custrecord_hc_inf_process_msg = e.message;
                        logUpdVal.custrecord_hc_inf_errorflag = true;
                        record.submitFields({
                            type: LOG_TYPE,
                            id: rtnData.logId,
                            values: logUpdVal
                        });
                    }

                }
                else if(!shipStatus){
                    record.submitFields({
                        type: newRec.type,
                        id: newRec.id,
                        values: {
                            custrecord_esre_posterromsg: 'Shipping Plan 的出运明细申报状态 不等于 “信保通过”，不可以确认收汇。'
                        }
                    });
                }
            }catch (e){
                log.error('RA限额申请error===>' + rtnData.logId, e);
                let raRec = record.load({type:QUOTA_BALANCE_TYPE, id:newRec.id});
                raRec.setValue({fieldId:FIELD_MAPPING.errorMsg, value:e.message});
                raRec.save({enableSourcing: true, ignoreMandatoryFields: true});
            }
        }

        //查询出运明细申报单据状态是否为信保通过
        const shipSearch = (shipId) => {
            let shipStatus = false;
            let shipSearchObj = search.create({
                type: 'customrecord_ecm_sp',
                filters: [
                    ['internalid', 'anyof', shipId]
                ],
                columns: [
                    search.createColumn({name: 'custrecord_essap_status', join: 'CUSTRECORD_SP_SHIPMENTAPPLY'})
                ]
            });
            let shipRes = commonApi.getAllData(shipSearchObj);
            let shipColumns = shipSearchObj.columns;
            if(shipRes && shipRes.length > 0){
                shipStatus = (shipRes[0].getValue(shipColumns[0]) == 5);
            }
            return shipStatus;
        }

        /**
         * 日期转换
         * @param date
         * @returns {string}
         */
        const getDateFormat = (date) => {
            date = new Date(date);
            let year = date.getFullYear();
            let month = date.getMonth() + 1;
            let day = date.getDate();
            if (month < 10){
                month = '0' + month;
            }
            if (day < 10){
                day = '0' + day;
            }
            return year + '-' + month + '-' + day;
        }

        return {beforeLoad, beforeSubmit, afterSubmit}

    });

