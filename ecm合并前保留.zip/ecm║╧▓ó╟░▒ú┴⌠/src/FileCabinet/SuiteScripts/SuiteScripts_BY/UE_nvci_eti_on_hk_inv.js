/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 */
define(['N/file', 'N/record', 'N/runtime', 'N/search'],
    /**
 * @param{file} file
 * @param{record} record
 * @param{runtime} runtime
 * @param{search} search
 */
    (file, record, runtime, search) => {
        let CUSTOMER_ETI = '6768';    //Pro:6768   Sandbox:6789
        let SUBLIST_ID = 'recmachcustrecord_nvci_fo_in_parent';
        let ACCOUNT_DEBIT = '228';    //Pro:228    Sandbox:764
        let ACCOUNT_CREDIT = '2490';  //Pro:2490   Sandbox:2605
        let ETI_JE_FORM_ID = '125';   //Pro:125    Sandbox:119
        let ETI_SUBSIDIARY = '3';     //Pro:3      Sandbox:8
        let ETI_JE_DEPART = '141';    //Pro:141    Sandbox:391

        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed before record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const beforeSubmit = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {
            let newRec = scriptContext.newRecord;
            let type = scriptContext.type;
            let pStatus = newRec.getValue({fieldId : 'custrecord_nvci_fo_in_p_status' });
            let customer = newRec.getValue({fieldId : 'custrecord_nvci_fo_in_customer' });
            let invDate = newRec.getValue({fieldId : 'custrecord_nvci_fo_in_dec_actdate' });

            if (type !== 'delete' && type !== 'xedit') {
                if (invDate && isAfterStartDate(invDate) && customer == CUSTOMER_ETI) {
                    if (pStatus == '3') {
                        // void
                        deleteRelatedJe(scriptContext);
                    } else {
                        createOrUpdateRelatedJe(scriptContext);
                    }
                }
            } else if (type === 'delete') {
                deleteRelatedJe(scriptContext);
            } else if (type === 'xedit') {
                if (pStatus == '3') {
                    // void
                    deleteRelatedJe(scriptContext);
                }
            }
        }

        const isAfterStartDate = (invDate) => {
            let rtnFlag = false;
            if (invDate) {
                try {
                    let tmpDate = new Date(invDate);
                    //tmpDate.getFullYear(), tmpDate.getMonth() + 1, tmpDate.getDate()
                    if (tmpDate.getFullYear() > 2021 || (tmpDate.getFullYear() === 2021 && tmpDate.getMonth() >= 8)) {
                        rtnFlag = true;
                    }
                } catch (e) {
                    log.error({title : 'isAfterStartDate error', details : JSON.stringify(e)});
                }
            }

            return rtnFlag;
        }

        const createOrUpdateRelatedJe = (scriptContext) => {
            let newRec = scriptContext.newRecord;
            let etiJeId = newRec.getValue({fieldId : 'custrecord_fo_in_eti_je'});
            try {
                let totalAmount = getTotalAmount(newRec);
                let jeRec;
                if (etiJeId) {
                    jeRec = record.load({type : record.Type.JOURNAL_ENTRY, id : etiJeId});
                    let lineCnt = jeRec.getLineCount({sublistId : 'line'});
                    for (let i = 0; i < lineCnt; i++) {
                        jeRec.removeLine({sublistId : 'line', line : 0});
                    }
                } else {
                    jeRec = record.create({type : record.Type.JOURNAL_ENTRY});
                    jeRec.setValue({fieldId : 'customform', value : ETI_JE_FORM_ID});
                    jeRec.setValue({fieldId : 'subsidiary', value : ETI_SUBSIDIARY});
                    jeRec.setValue({fieldId : 'approvalstatus', value : '2'});   //Approved
                }
                jeRec.setValue({fieldId : 'custbody_created_from_ci', value : newRec.id});
                jeRec.setValue({fieldId : 'currency', value : newRec.getValue({fieldId : 'custrecord_nvci_fo_in_currency'})});
                jeRec.setValue({fieldId : 'trandate', value : newRec.getValue({fieldId : 'custrecord_nvci_fo_in_dec_actdate'})});
                jeRec.setValue({fieldId : 'custbody_nvci_invoice_no', value : newRec.getValue({fieldId : 'custrecord_nvci_fo_in_invoice_no'})});
                let postPeriodInfos = getPostPeriodInfos(newRec.getValue({fieldId : 'custrecord_nvci_fo_in_dec_actdate'}));
                let tmpMemo = newRec.getValue({fieldId : 'custrecord_nvci_fo_in_invoice_no'}) + ' inventory in transit ' + postPeriodInfos.periodName;
                jeRec.setValue({fieldId : 'memo', value : tmpMemo});

                jeRec.setSublistValue({sublistId : 'line', fieldId : 'account', value : ACCOUNT_DEBIT, line : 0});
                jeRec.setSublistValue({sublistId : 'line', fieldId : 'debit', value : totalAmount, line : 0});
                jeRec.setSublistValue({sublistId : 'line', fieldId : 'memo', value : tmpMemo, line : 0});
                jeRec.setSublistValue({sublistId : 'line', fieldId : 'department', value : ETI_JE_DEPART, line : 0});
                jeRec.setSublistValue({sublistId : 'line', fieldId : 'account', value : ACCOUNT_CREDIT, line : 1});
                jeRec.setSublistValue({sublistId : 'line', fieldId : 'credit', value : totalAmount, line : 1});
                jeRec.setSublistValue({sublistId : 'line', fieldId : 'memo', value : tmpMemo, line : 1});
                jeRec.setSublistValue({sublistId : 'line', fieldId : 'department', value : ETI_JE_DEPART, line : 1});
                let jeId = jeRec.save({enableSourcing : true, ignoreMandatoryFields : true});

                record.submitFields({type : newRec.type, id: newRec.id, values : {'custrecord_fo_in_eti_je' : jeId}});
            } catch (e) {
                log.error({title : 'updateRelatedJe error', details : JSON.stringify(e)});
            }
        }

        const getPostPeriodInfos = (reqDate) => {
            let rtnObj = {};

            try {
                let tarDate = getSystemDate(reqDate);
                let aFilters = [];
                aFilters.push(search.createFilter({name: 'isyear', operator: search.Operator.IS, values: false}));
                aFilters.push(search.createFilter({name: 'isquarter', operator: search.Operator.IS, values: false}));
                aFilters.push(search.createFilter({name: 'isadjust', operator: search.Operator.IS, values: false}));
                aFilters.push(search.createFilter({name: 'startdate', operator: search.Operator.ONORBEFORE, values: tarDate}));
                aFilters.push(search.createFilter({name: 'enddate', operator: search.Operator.ONORAFTER, values: tarDate}));
                let aColumns = [];
                aColumns.push(search.createColumn({name: 'internalid'}));
                aColumns.push(search.createColumn({name: 'periodname'}));
                let tmpSearch = search.create({type: 'accountingperiod', filters: aFilters, columns: aColumns});
                log.debug({title : 'tmpSearch', details : JSON.stringify(tmpSearch)});
                let res = tmpSearch.run().getRange({start: 0, end: 1});
                if (res && res.length > 0) {
                    rtnObj = {
                        'internalid' : res[0].getValue(aColumns[0]),
                        'periodName' : res[0].getValue(aColumns[1]),
                    };
                }
            } catch (e) {
                log.error({title : 'getPeriodFromDate error', details : e});
                throw e;
            }
            return rtnObj;
        }

        const getSystemDate = (reqDate) => {
            return getCurrentDateFormat(reqDate.getFullYear(), reqDate.getMonth() + 1, reqDate.getDate());
        }

        //获取当前用户的时间格式
        const getCurrentDateFormat = (year, month, day) => {
            let rtnStr;
            let monthArr = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
            let userObj = runtime.getCurrentUser();
            let s_context = userObj.getPreference({name: 'DATEFORMAT'});
            log.debug({title : 's_context', details : s_context});
            if (s_context === 'YYYY年M月D日' || s_context === 'YYYY年MM月DD日') {
                rtnStr = year + '年'+ month + '月' + day + '日';
            }else if (s_context === 'YYYY-M-D' || s_context === 'YYYY-MM-DD') {
                rtnStr = year + '-'+ month + '-' + day;
            }else if (s_context === 'YYYY M D' || s_context === 'YYYY MM DD') {
                rtnStr = year + ' '+ month + ' ' + day;
            }else if (s_context === 'YYYY/M/D' || s_context === 'YYYY/MM/DD') {
                rtnStr = year + '/'+ addZero(month) + '/' + addZero(day);
            }else if (s_context === 'M/D/YYYY' || s_context === 'MM/DD/YYYY') {
                rtnStr = month + '/'+ day + '/' + year;
            }else if (s_context === 'D/M/YYYY' || s_context === 'DD/MM/YYYY') {
                rtnStr = day + '/'+ month + '/' + year;
            }else if (s_context === 'D-Mon-YYYY' || s_context === 'DD-Mon-YYYY') {
                rtnStr = day + '-' + monthArr[month-1] + '-' + year;
            }else if (s_context === 'D.M.YYYY' || s_context === 'DD.MM.YYYY') {
                rtnStr = day + '.'+ month + '.' + year;
            }
            log.debug({title : 'rtnStr', details : rtnStr});
            return rtnStr;
        }

        const addZero = (number) => {
            return number > 9 ? number : ('0' + number);
        }

        const deleteRelatedJe = (scriptContext) => {
            let newRec = scriptContext.newRecord;
            let etiJeId = newRec.getValue({fieldId : 'custrecord_fo_in_eti_je'});
            if (!etiJeId) {
                try {
                    let tmpRec = record.load({type : newRec.type, id: newRec.id});
                    etiJeId = tmpRec.getValue({fieldId : 'custrecord_fo_in_eti_je'});
                } catch (e) {
                    log.error({title : 'deleteRelatedJe load error', details : JSON.stringify(e)});
                }
            }
            if (etiJeId) {
                try {
                    record.delete({type : record.Type.JOURNAL_ENTRY, id : etiJeId});
                } catch (e) {
                    log.error({title : 'deleteRelatedJe error', details : JSON.stringify(e)});
                }
            }
        }

        const getTotalAmount = (newRec) => {
            let rtnVal = 0;

            let lineCnt = newRec.getLineCount({sublistId : SUBLIST_ID});
            for (let i = 0; i < lineCnt; i++) {
                let tmpAmount = newRec.getSublistValue({sublistId: SUBLIST_ID, fieldId : 'custrecord_nvci_fo_in_l_sales_amount', line : i}) || 0;
                rtnVal = accAdd(rtnVal, tmpAmount);
            }

            return rtnVal;
        }

        const accAdd = (arg1, arg2) => {
            let r1, r2, m, c;
            try {
                r1 = arg1.toString().split(".")[1].length;
            } catch (e) {
                r1 = 0;
            }
            try {
                r2 = arg2.toString().split(".")[1].length;
            } catch (e) {
                r2 = 0;
            }
            c = Math.abs(r1 - r2);
            m = Math.pow(10, Math.max(r1, r2));
            if (c > 0) {
                let cm = Math.pow(10, c);
                if (r1 > r2) {
                    arg1 = Number(arg1.toString().replace(".", ""));
                    arg2 = Number(arg2.toString().replace(".", "")) * cm;
                } else {
                    arg1 = Number(arg1.toString().replace(".", "")) * cm;
                    arg2 = Number(arg2.toString().replace(".", ""));
                }
            } else {
                arg1 = Number(arg1.toString().replace(".", ""));
                arg2 = Number(arg2.toString().replace(".", ""));
            }
            return (arg1 + arg2) / m;
        }

        return {
            beforeLoad,
            beforeSubmit,
            afterSubmit
        }
    });
