/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 * Version        Date            Author            Remark
 * 1.0            2023/03/02      Will              自动生成公司间抵销日记账(1018665)
 * 2.0            2023/03/13      Will              新增子公司取值逻辑(1018665)
 */
define(['N/https', 'N/currentRecord', 'N/record', 'N/runtime', 'N/search', 'N/task', 'N/ui/serverWidget','N/redirect'],
    /**
     * @param{https} https
     * @param currentRecord
     * @param record
     * @param runtime
     * @param search
     * @param task
     * @param serverWidget
     */
    (https, currentRecord, record, runtime, search, task, serverWidget,redirect) => {
        /**
         * Defines the Suitelet script trigger point.
         * @param {Object} scriptContext
         * @param {ServerRequest} scriptContext.request - Incoming request
         * @param {ServerResponse} scriptContext.response - Suitelet response
         * @since 2015.2
         */
        const onRequest = (scriptContext) => {
            let request = scriptContext.request;
            let params = request.parameters;
            let response = scriptContext.response;
            // log.debug('request', request);
            // log.debug('params', params);
            if(request.method == 'POST') {
                let id = params.id;
                let type = params.type;
                createJe(id,type);
            }
        }

        function createJe(id,type) {
            let curRec = record.load({type: type, id: id});
            let orderType = curRec.getValue('custbody_ecm_ordertype');
            // log.debug('orderType', orderType);

            if (orderType == 3) { //TODO 环境校验
                let subsidiary;
                let icSubsidiary;
                let curSubsidiary = curRec.getValue('subsidiary');
                let icPoSo = curRec.getValue('custbody_ecm_icposo_transaction');
                // log.debug('curSubsidiary',curSubsidiary);
                // log.debug('icPoSo',icPoSo);
                if (type == 'invoice') {
                    let subFields = search.lookupFields({type: 'purchaseorder', id: icPoSo, columns: ['subsidiary']});
                    icSubsidiary = subFields.subsidiary[0].value;
                } else if (type == 'vendorbill') {
                    let subFields = search.lookupFields({type: 'salesorder', id: icPoSo, columns: ['subsidiary']});
                    icSubsidiary = subFields.subsidiary[0].value;
                }
                // log.debug('icSubsidiary',icSubsidiary);
                let curIndex = searchParentSub(curSubsidiary); //TODO 环境校验
                let icIndex = searchParentSub(icSubsidiary);   //TODO 环境校验
                // log.debug('curIndex',curIndex);
                // log.debug('icIndex',icIndex);
                if (curSubsidiary == 1 || icSubsidiary == 1) { //TODO 环境校验
                    subsidiary = 1
                } else if (Number(curIndex) <= Number(icIndex)) {
                    subsidiary = curSubsidiary
                } else if (Number(curIndex) > Number(icIndex)) {
                    subsidiary = icSubsidiary
                }
                // log.debug('subsidiary',subsidiary);

                let offSetCompanyId;
                let offSetSubFields = search.lookupFields({type: 'subsidiary', id: subsidiary, columns: ['custrecord_ecm_offsetcompany']});
                offSetCompanyId = offSetSubFields.custrecord_ecm_offsetcompany;
                log.debug('offSetCompanyId',offSetCompanyId);

                if (type == 'invoice') {
                    let currency = curRec.getValue('currency');
                    let date = curRec.getValue('trandate');
                    let total = curRec.getValue('total');
                    let sp = curRec.getValue('custbody_ecm_sp');

                    let obj = record.create({type: 'journalentry',isDynamic: true});
                    obj.setValue({fieldId: 'subsidiary', value: offSetCompanyId[0].value});
                    obj.setValue({fieldId: 'currency', value: currency});
                    obj.setValue({fieldId: 'trandate', value: date});
                    obj.setValue({fieldId: 'custbody_ecm_sp', value: sp});
                    obj.setValue({fieldId: 'custbody_ecm_je_invoice', value: id});
                    obj.setValue({fieldId: 'custbody_ecm_ordertype', value: orderType});
                    obj.setValue({fieldId: 'memo', value: 'Intercompany Elimination'});
                    obj.setValue({fieldId: 'approvalstatus', value: 2}); //TODO 环境校验


                    obj.selectNewLine({sublistId: 'line'});
                    obj.setCurrentSublistValue({sublistId: 'line', fieldId: 'account', value: 1474, ignoreFieldChange: true});
                    obj.setCurrentSublistValue({sublistId: 'line', fieldId: 'debit', value: total, ignoreFieldChange: true});
                    obj.commitLine({sublistId: 'line'});

                    obj.selectNewLine({sublistId: 'line'});
                    obj.setCurrentSublistValue({sublistId: 'line', fieldId: 'account', value: 1476, ignoreFieldChange: true});
                    obj.setCurrentSublistValue({sublistId: 'line', fieldId: 'credit', value: total, ignoreFieldChange: true});
                    obj.commitLine({sublistId: 'line'});

                    let recId = obj.save({ignoreMandatoryFields: true, enablesourcing: false});
                    log.debug('recId',recId);
                    if (recId) {
                        curRec.setValue({fieldId: 'custbody_ecm_je_setoff', value: recId});
                        curRec.save({ignoreMandatoryFields:true, enablesourcing:false});
                    }
                } else if (type == 'vendorbill') {
                    let currency = curRec.getValue('currency');
                    let date = curRec.getValue('trandate');
                    let total = curRec.getValue('usertotal');
                    let sp = curRec.getValue('custbody_ecm_sp');

                    let obj = record.create({type: 'journalentry',isDynamic: true});
                    obj.setValue({fieldId: 'subsidiary', value: offSetCompanyId[0].value});
                    obj.setValue({fieldId: 'currency', value: currency});
                    obj.setValue({fieldId: 'trandate', value: date});
                    obj.setValue({fieldId: 'custbody_ecm_sp', value: sp});
                    obj.setValue({fieldId: 'custbody_ecm_je_bill', value: id});
                    obj.setValue({fieldId: 'custbody_ecm_ordertype', value: orderType});
                    obj.setValue({fieldId: 'memo', value: 'Intercompany Elimination'});
                    obj.setValue({fieldId: 'approvalstatus', value: 2}); //TODO 环境校验


                    obj.selectNewLine({sublistId: 'line'});
                    obj.setCurrentSublistValue({sublistId: 'line', fieldId: 'account', value: 1475, ignoreFieldChange: true});
                    obj.setCurrentSublistValue({sublistId: 'line', fieldId: 'debit', value: total, ignoreFieldChange: true});
                    obj.commitLine({sublistId: 'line'});

                    obj.selectNewLine({sublistId: 'line'});
                    obj.setCurrentSublistValue({sublistId: 'line', fieldId: 'account', value: 1474, ignoreFieldChange: true});
                    obj.setCurrentSublistValue({sublistId: 'line', fieldId: 'credit', value: total, ignoreFieldChange: true});
                    obj.commitLine({sublistId: 'line'});

                    let recId = obj.save({ignoreMandatoryFields: true, enablesourcing: false});
                    log.debug('recId',recId);
                    if (recId) {
                        curRec.setValue({fieldId: 'custbody_ecm_je_setoff', value: recId});
                        curRec.save({ignoreMandatoryFields:true, enablesourcing:false});
                    }
                }
            }
        }

        /**
         * 找到母公司的次数
         * @param subsidiaryId
         * @returns {number}
         */
        function searchParentSub(subsidiaryId) {
            let index = 0;
            if (subsidiaryId == 1) {
                return index;
            } else {
                for (let i = 0; i < 9; i++) {
                    let subFields = search.lookupFields({type: 'subsidiary', id: subsidiaryId, columns: ['parent']});
                    let parSubsidiaryId = subFields.parent;
                    subsidiaryId = parSubsidiaryId;
                    index++;
                    if (parSubsidiaryId == 1) {
                        break
                    }
                }
                return index;
            }
        }


        return {onRequest}

    });
