/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 * Version      Date            Author              Memo
 * 1.0          2023/03/21      Will                Departure Information页面
 * 2.0          2023/04/10      Will                会计期间管理校验
 */
define(['N/http', 'N/record', 'N/redirect', 'N/search', 'N/ui/serverWidget', 'N/config','N/file', 'SuiteScripts/tools/common_api.js'],
    /**
     * @param{http} http
     * @param{record} record
     * @param{redirect} redirect
     * @param{search} search
     * @param{serverWidget} serverWidget
     * @param{config} config
     * @param{file} file
     * @param commonApi
     */
    (http, record, redirect, search, serverWidget, config,file, commonApi) => {
        /**
         * Defines the Suitelet script trigger point.
         * @param {Object} scriptContext
         * @param {ServerRequest} scriptContext.request - Incoming request
         * @param {ServerResponse} scriptContext.response - Suitelet response
         * @since 2015.2
         */
        const onRequest = (scriptContext) => {
            let request = scriptContext.request;
            let response = scriptContext.response;
            let params = request.parameters;
            // log.debug('params', params);
            // log.debug('request', request);

            if ('GET' == request.method) {
                let form = createForm(params);
                response.writePage(form);
            } else {
                let id = params.custpage_rid;
                let date = params.custpage_departure_date;
                if(date) {
                    let periodIsOpen = checkPeriodIsCloseOrNot(date);
                    if (periodIsOpen) {
                        let spRec = record.load({type: 'customrecord_ecm_sp', id: id});
                        spRec.setText({fieldId:'custrecord_sp_departuredate', text: date});
                        spRec.setValue({fieldId:'custrecord_sp_status', value: 3}); // TODO 环境校验 离港
                        spRec.save({enableSourcing:true, ignoreMandatoryFields:true});
                        response.write('<script>window.opener.location.reload();window.close();</script>')
                    } else {
                        response.write('You cannot use this date as the accounting period has been closed.')
                    }
                }

            }
        }

        //创建页面
        function createForm(params) {
            let form = serverWidget.createForm({title:'Fill in the booking information', hideNavBar: true});
            form.addSubmitButton({label: 'Submit'});

            let ladingNoField = form.addField({id : 'custpage_departure_date', label : 'Date of departure', type : 'date'});
            ladingNoField.isMandatory = true;

            let idField = form.addField({id : 'custpage_rid', label : 'type', type : 'text'});
            idField.updateDisplayType({displayType : serverWidget.FieldDisplayType.HIDDEN});
            idField.defaultValue = params.spid;

            return form;
        }

        /**
         * 校验日期期间是否关闭
         * @param dateOfArrival
         * @returns {boolean}
         */
        const checkPeriodIsCloseOrNot = (dateOfArrival) => {
            let periodIsOpen = true;
            var accountSearch = search.create({
                type: "accountingperiod",
                filters:
                    [
                        ["startdate","onorbefore",dateOfArrival],
                        "AND",
                        ["enddate","onorafter",dateOfArrival],
                        "AND",
                        ["isinactive","is","F"],
                        "AND",
                        ["isquarter","is","F"],
                        "AND",
                        ["isyear","is","F"]
                    ],
                columns:
                    [
                        search.createColumn({name: "aplocked", label: "已锁定 AP"}),
                        search.createColumn({name: "alllocked", label: "全部锁定"}),
                        search.createColumn({name: "arlocked", label: "已锁定 AR"})
                    ]
            });
            let accountRes = commonApi.getAllData(accountSearch);
            let accountColumn = accountSearch.columns;
            if(accountRes.length > 0){
                for(let index = 0; index < accountRes.length; index++){
                    let aplocked = accountRes[0].getValue(accountColumn[0]);
                    let alllocked = accountRes[0].getValue(accountColumn[1]);
                    let arlocked = accountRes[0].getValue(accountColumn[2]);
                    if(aplocked || alllocked || arlocked){
                        periodIsOpen = false;
                    }
                }
            }
            return periodIsOpen;
        }

        return {onRequest}

    });
