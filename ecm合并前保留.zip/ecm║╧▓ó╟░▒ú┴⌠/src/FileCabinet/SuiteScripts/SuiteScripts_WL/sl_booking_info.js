/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 * Version      Date            Author              Memo
 * 1.0          2023/03/21      Will                Booking Information页面(1019290)
 * 2.0          2023/04/12      Will                Booking Information页面新增字段及字段控制(1019290)
 * 3.0          2023/04/13      Will                Booking Information页面新增字段(1019290)
 */
define(['N/http', 'N/record', 'N/redirect', 'N/search', 'N/ui/serverWidget', 'N/config','N/file'],
    /**
     * @param{http} http
     * @param{record} record
     * @param{redirect} redirect
     * @param{search} search
     * @param{serverWidget} serverWidget
     * @param{config} config
     * @param{file} file
     */
    (http, record, redirect, search, serverWidget, config,file) => {
        /**
         * Defines the Suitelet script trigger point.
         * @param {Object} scriptContext
         * @param {ServerRequest} scriptContext.request - Incoming request
         * @param {ServerResponse} scriptContext.response - Suitelet response
         * @since 2015.2
         */
        const onRequest = (scriptContext) => {
            let request = scriptContext.request;
            let response = scriptContext.response;
            let params = request.parameters;
            // log.debug('params', params);
            // log.debug('request', request);

            if ('GET' == request.method) {
                let form = createForm(params);
                response.writePage(form);
            } else {
                let id = params.custpage_rid;
                let no = params.custpage_lading_no;
                let ship = params.custpage_ship_name;
                let eta = params.custpage_eta;
                let etd = params.custpage_etd;
                let voyage = params.custpage_voyage;
                let carrier = params.custpage_carrier;
                let vendor = params.custpage_vendor;
                let transit = params.custpage_transit;
                let detention = params.custpage_detention;
                let freight = params.custpage_freight;
                let currency = params.custpage_currency;
                let remark = params.custpage_remark;
                let spRec = record.load({type: 'customrecord_ecm_sp', id: id});
                spRec.setValue({fieldId:'custrecord_sp_ladingno', value: no});
                spRec.setValue({fieldId:'custrecord_sp_shipname', value: ship});
                spRec.setText({fieldId:'custrecord_sp_eta', text: eta});
                spRec.setText({fieldId:'custrecord_sp_etd', text: etd});
                spRec.setValue({fieldId:'custrecord_sp_voyage', value: voyage});
                spRec.setValue({fieldId:'custrecord_sp_status', value: 6}); // TODO 环境校验 订舱成功
                spRec.setValue({fieldId:'custrecord_sp_carrier', value: carrier});
                spRec.setValue({fieldId:'custrecord_sp_freightfor', value: vendor});
                spRec.setValue({fieldId:'custrecord_sp_transittime', value: transit});
                spRec.setValue({fieldId:'custrecord_sp_freedet', value: detention});
                spRec.setValue({fieldId:'custrecord_sp_freight', value: freight});
                spRec.setValue({fieldId:'custrecord_sp_freightcurrency', value: currency});
                spRec.setValue({fieldId:'custrecord_sp_bookingremark', value: remark});
                spRec.save({enableSourcing:true, ignoreMandatoryFields:true});

                response.write('<script>window.opener.location.reload();window.close();</script>')
            }
        }

        //创建页面
        function createForm(params) {
            let form = serverWidget.createForm({title:'Fill in the booking information', hideNavBar: true});
            form.clientScriptModulePath = './cs_booking_info.js';
            form.addSubmitButton({label: 'Submit'});

            let carrierField = form.addField({id : 'custpage_carrier', label : 'Carrier', type : 'text'});
            carrierField.isMandatory = true;

            let forwarderField = form.addField({id: 'custpage_vendor', label: 'FREIGHT FORWARDER', type: 'select', source:'vendor'});
            forwarderField.isMandatory = true;

            let ladingNoField = form.addField({id : 'custpage_lading_no', label : 'B/L NO.', type : 'text'});
            ladingNoField.isMandatory = true;

            let shipField = form.addField({id : 'custpage_ship_name', label : 'Name of Transport', type : 'text'});
            shipField.isMandatory = true;

            let voyageField = form.addField({id : 'custpage_voyage', label : 'Voyage', type : 'text'});
            voyageField.isMandatory = true;

            let etdField = form.addField({id : 'custpage_etd', label : 'ETD', type : 'date'});
            etdField.isMandatory = true;

            let transitField = form.addField({id : 'custpage_transit', label : 'Transit Time (Days)', type : 'text'});
            transitField.isMandatory = true;

            let etaField = form.addField({id : 'custpage_eta', label : 'ETA', type : 'date'});
            etaField.updateDisplayType({displayType : serverWidget.FieldDisplayType.DISABLED});
            etaField.isMandatory = true;

            let detentionField = form.addField({id : 'custpage_detention', label : 'Free Detention at Destination', type : 'text'});
            detentionField.isMandatory = true;

            let freightField = form.addField({id : 'custpage_freight', label : 'Ocean/Air Freight', type : 'text'});
            freightField.isMandatory = true;

            let currencyField = form.addField({id: 'custpage_currency', label: 'Freight Currency', type: 'select', source:'currency'});
            currencyField.isMandatory = true;

            let remarkField = form.addField({id : 'custpage_remark', label : 'Booking Remark', type : 'text'});

            let idField = form.addField({id : 'custpage_rid', label : 'type', type : 'text'});
            idField.updateDisplayType({displayType : serverWidget.FieldDisplayType.HIDDEN});
            idField.defaultValue = params.spid;

            return form;
        }

        return {onRequest}

    });
