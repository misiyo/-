/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * Version        Date            Author          Memo
 * 1.0            2023/03/27      Will            预收款的认领(1018615)
 * 2.0            2023/03/28      Will            添加表单校验(1018615)
 * 3.0            2023/04/18      Will            回写逻辑修改(1018615)
 */
define(['N/currentRecord', 'N/record', 'N/runtime', 'N/search', 'N/task', 'N/ui/serverWidget', '/SuiteScripts/tools/ramda.min.js'],
    /**
     * @param{currentRecord} currentRecord
     * @param{record} record
     * @param{runtime} runtime
     * @param{search} search
     * @param{task} task
     * @param{serverWidget} serverWidget
     * @param ramda
     */
    (currentRecord, record, runtime, search, task, serverWidget,ramda) => {
        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed before record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const beforeSubmit = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {
            if (['delete', 'xedit'].includes(scriptContext.type)) return;
            let newRec = scriptContext.newRecord;
            let curRec = record.load({type: newRec.type, id: newRec.id});
            let customForm = curRec.getValue('customform');
            let role = runtime.getCurrentUser().role;
            if (customForm == 122) {
                writeBack(scriptContext,curRec)
            }
        }

        function depositSearch(spArr) {
            let depositSearchObj = search.create({
                type: "deposit",
                filters:
                    [
                        ["type","anyof","Deposit"],
                        "AND",
                        ["customform","anyof","122"]
                    ],
                columns:
                    [
                        search.createColumn({name: "account", label: "科目"}),
                        search.createColumn({name: "fxamount", label: "金额（外币）"}),
                        search.createColumn({name: "memo", label: "备注"}),
                        search.createColumn({name: "otherrefnum", label: "采购订单/支票号码"})
                    ]
            });
            let columns = depositSearchObj.columns;
            let result = depositSearchObj.run().getRange({start: 0, end: 1000});
            let info = [];
            if (result && result.length > 0) {
                for (let i = 0; i < result.length; i++) {
                    let account = result[i].getValue(columns[0]);
                    let amount = Math.abs(result[i].getValue(columns[1]));
                    let sp = result[i].getValue(columns[2]);
                    let refNum = result[i].getValue(columns[3]);
                    if (account != 1155 && spArr.indexOf(sp) != -1) {
                        let json = {
                            sp : sp,
                            amount : amount,
                            refNum : refNum
                        }
                        info.push(json)
                    }
                }
            }
            return info;
        }

        function writeBack(scriptContext,curRec) {
            try {
                if(scriptContext.type == 'create') {
                    let total = curRec.getValue('total');
                    curRec.setValue({fieldId: 'custbody_ecm_paymentamount', value: total});
                    curRec.save({ignoreMandatoryFields:true, enablesourcing:false});
                }

                let length = curRec.getLineCount('other');
                let spArr = [];
                for (let i = 0; i < length; i++) {
                    let sp = curRec.getSublistValue({sublistId: 'other', fieldId: 'memo', line: i});
                    let entity = curRec.getSublistValue({sublistId: 'other', fieldId: 'entity', line: i});
                    if (spArr.indexOf(sp) == -1 && entity != 52226) {
                        spArr.push(sp);
                    }

                }
                // log.debug('spArr',spArr);
                let info = depositSearch(spArr);
                // log.debug('info',info);
                let spInfo = ramda.groupBy(ramda.path(['sp']))(info);
                log.debug('spInfo',spInfo);
                for (let key in spInfo) {
                    let spId = Number(key.split('-')[1]);
                    let spArr = spInfo[key];
                    let total = 0;
                    for (let i = 0; i < spArr.length; i++) {
                        let amount = spArr[i].amount;
                        total = Number(total) + Number(amount)
                    }
                    let spRec = record.load({type: 'customrecord_ecm_sp', id: spId});
                    spRec.setValue({fieldId: 'custrecord_sp_topreamount', value: total});
                    spRec.save({ignoreMandatoryFields:true, enablesourcing:false});
                }
            } catch (e) {
                log.error('Error', e);
            }
        }


        return {/*beforeLoad, beforeSubmit,*/ afterSubmit}

    });
