/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * Version		Date			Author			Memo
 * 1.0          2023/03/02      Will            自动生成公司间抵销日记账(1018665)
 * 2.0          2023/03/09      Will            去除生成逻辑，增加修改逻辑(1018665)
 * 3.0          2023/03/29      Will            生成修改抵消日记账(1018665)
 * 4.0          2023/04/03      Will            去除生成抵消日记账(1018665)
 */
define(['N/currentRecord', 'N/record', 'N/search', 'N/url', 'N/redirect', 'N/https','N/runtime','SuiteScripts/tools/common_api.js'],
    /**
     * @param{currentRecord} currentRecord
     * @param{record} record
     * @param{search} search
     * @param{url} url
     * @param redirect
     * @param https
     * @param runtime
     * @param commonApi
     */
    (currentRecord, record, search, url, redirect, https, runtime, commonApi) => {
        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed before record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const beforeSubmit = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {
            if (['delete', 'xedit'].includes(scriptContext.type)) return;
            let newRec = scriptContext.newRecord;
            let curRec = record.load({type: newRec.type, id: newRec.id});
            let jeId = curRec.getValue('custbody_ecm_je_setoff');
            let AgainstJe = curRec.getValue('custbody_echemi_writeoffcertificates');
            try {
                if (jeId && jeId != '') {
            		let obj = record.load({type: 'journalentry', id: jeId, isDynamic: true});
                    modifyJe(curRec,obj)
                }
                if (AgainstJe && AgainstJe != '') {
                    modifyAgainstJe(curRec,AgainstJe)
                }
            } catch (e) {
                log.error('Error', e);
            }
        }

        function modifyJe(curRec,obj) {
            let currency = curRec.getValue('currency');
            let date = curRec.getValue('trandate');
            let total = curRec.getValue('total');
            let sp = curRec.getValue('custbody_ecm_sp');

            obj.setValue({fieldId: 'currency', value: currency});
            obj.setValue({fieldId: 'trandate', value: date});
            obj.setValue({fieldId: 'custbody_ecm_sp', value: sp});


            obj.selectLine({sublistId: 'line', line: 0});
            obj.setCurrentSublistValue({sublistId: 'line', fieldId: 'debit', value: total, ignoreFieldChange: true});
            obj.commitLine({sublistId: 'line'});

            obj.selectLine({sublistId: 'line', line: 1});
            obj.setCurrentSublistValue({sublistId: 'line', fieldId: 'credit', value: total, ignoreFieldChange: true});
            obj.commitLine({sublistId: 'line'});

            obj.save({ignoreMandatoryFields: true, enablesourcing: false});
        }

        function modifyAgainstJe(curRec,AgainstJe) {
            let obj = record.load({type: 'journalentry', id: AgainstJe, isDynamic: true});
            let currency = curRec.getValue('currency');
            let total = curRec.getValue('total');
            let sp = curRec.getValue('custbody_ecm_sp');

            obj.setValue({fieldId: 'currency', value: currency});
            obj.setValue({fieldId: 'custbody_ecm_sp', value: sp});


            obj.selectLine({sublistId: 'line', line: 0});
            obj.setCurrentSublistValue({sublistId: 'line', fieldId: 'debit', value: total, ignoreFieldChange: true});
            obj.commitLine({sublistId: 'line'});

            obj.selectLine({sublistId: 'line', line: 1});
            obj.setCurrentSublistValue({sublistId: 'line', fieldId: 'credit', value: total, ignoreFieldChange: true});
            obj.commitLine({sublistId: 'line'});

            obj.save({ignoreMandatoryFields: true, enablesourcing: false});
        }

        /**
         * 获取当前日期
         * @param dateformat
         * @return {string|boolean}
         */
        const formatNowDate = (dateformat) => {
            let now = commonApi.getNowDateTime(true);
            let dateArr = now.split('/');
            let year = dateArr[0], month = dateArr[1], day = dateArr[2];
            if ('' == year || '' == month || '' == day || '' == dateformat) {
                return false;
            }
            if ('YYYY年M月D日' == dateformat) {
                return year + '年' + Number(month) + '月' + Number(day) + '日 ';
            } else if ('YYYY年MM月DD日' == dateformat) {
                return year + '年' + month + '月' + day + '日 ';
            } else if ('YYYY-M-D' == dateformat) {
                return year + '-' + Number(month) + '-' + Number(day);
            } else if('YYYY-MM-DD' == dateformat) {
                return year + '-' + month + '-' + day;
            } else if ('YYYY M D' == dateformat) {
                return year + ' ' + Number(month) + ' ' + Number(day);
            } else if ('YYYY MM DD' == dateformat) {
                return year + ' ' + month + ' ' + day;
            } else if ('YYYYMMDD' == dateformat) {
                return year + month + day;
            } else if ('YYYY/M/D' == dateformat) {
                return year + '/' + Number(month) + '/' + Number(day);
            } else if ('YYYY/MM/DD' == dateformat) {
                return year + '/' + month + '/' + day;
            } else if ('M/D/YYYY' == dateformat) {
                return Number(month) + '/' + Number(day) + '/' + year;
            } else if ('MM/DD/YYYY' == dateformat) {
                return month + '/' + day + '/' + year;
            } else if ('D/M/YYYY' == dateformat) {
                return Number(day) + '/' + Number(month) + '/' + year;
            } else if ('DD/MM/YYYY' == dateformat) {
                return day + '/' + month + '/' + year;
            } else if ('D-Mon-YYYY' == dateformat) {
                let months = ["1", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                let tempMonth = months[month - 1];
                return Number(day) + '-' + tempMonth + '月-' + year;
            } else if ('DD-Mon-YYYY' == dateformat) {
                let months = ["1", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                let tempMonth = months[month - 1];
                return day + '-' + tempMonth + '月-' + year;
            } else if ('D.M.YYYY' == dateformat) {
                return Number(day) + '.' + Number(month) + '.' + year;
            } else if('DD.MM.YYYY' == dateformat) {
                return day + '.' + month + '.' + year;
            }
        }

        return {/*beforeLoad, beforeSubmit,*/ afterSubmit}

    });
