/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */
define(['N/currentRecord', 'N/record', 'N/runtime', 'N/search', 'SuiteScripts/tools/common_api.js'],
    /**
     * @param{currentRecord} currentRecord
     * @param record
     * @param runtime
     * @param search
     * @param commonApi
     */
    function (currentRecord, record, runtime, search, commonApi) {

        /**
         * Function to be executed after page is initialized.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.mode - The mode in which the record is being accessed (create, copy, or edit)
         *
         * @since 2015.2
         */
        function pageInit(scriptContext) {

        }

        /**
         * Function to be executed when field is changed.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         * @param {string} scriptContext.fieldId - Field name
         * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
         * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
         *
         * @since 2015.2
         */
        function fieldChanged(scriptContext) {
            var fieldId = scriptContext.fieldId;
            var curRec = scriptContext.currentRecord;
            if (fieldId == 'custpage_etd' || fieldId == 'custpage_transit') {
                var etd = curRec.getText('custpage_etd');
                var transit = Number(curRec.getValue('custpage_transit'));
                console.log('etd',etd);
                console.log('transit',transit);
                var eta = addDaysToDate(etd, transit)
                curRec.setText({fieldId:'custpage_eta', text: eta});
            }
        }

        function addDaysToDate(dateString, daysToAdd) {
            // 将日期字符串转换为 Date 对象
            var date = new Date(dateString);
            // 将给定的天数添加到日期
            date.setDate(date.getDate() + daysToAdd);
            // 格式化日期字符串（例：03/24/2023）
            return ('0' + (date.getMonth() + 1)).slice(-2) + '/' + ('0' + date.getDate()).slice(-2) + '/' + date.getFullYear();
        }


        return {
            // pageInit: pageInit,
            fieldChanged: fieldChanged,
        };


    });
