/**
 * @NApiVersion 2.1
 * @NScriptType ScheduledScript
 *
 * Version		Date			Author			Memo
 * 1.0			2023/02/16		Will Liu		中信保：出运申报受理反馈(1018425)
 */
define(['N/https', 'N/record', 'N/task', '/SuiteScripts/tools/common_api.js', '/SuiteScripts/tools/hc_edi_interface_tool.js', '/SuiteScripts/tools/moment.js', '/SuiteScripts/tools/ramda.min.js'],
    /**
     * @param{https} https
     * @param{task} task
     */
    (https, record, task, commonApi, interfaceTool, moment, ramda) => {
        const QUOTA_BALANCE_TYPE = 'customrecord_ecm_sinosure_shipmentapprov';//出运申报受理反馈id
        const LOG_TYPE = 'customrecord_hc_edi_interface_log';//日志类型
        const IMETHOD = 'getEdiShipmentApproveInfo';//接口method
        const ITYPE = 9;//接口类型：限额余额
        const FIELD_MAPPING = {
            'noticeSerialNo' : 'custrecord_essav_noticeserialno',//主键
            'corpSerialNo' : 'custrecord_essav_corpserialno',
            'shipmentID' : 'custrecord_essav_shipmentid',
            'clientNo' : 'custrecord_essav_clientno',
            'policyNo' : 'custrecord_essav_policyno',
            'invoiceNo' : 'custrecord_essav_invoiceno',
            'transportDate' : 'custrecord_essav_transportdate',
            'approveFlag' : 'custrecord_essav_approveflag',
            'unAcceptReason': 'custrecord_essav_unacceptreason',
            'premiumRate': 'custrecord_essav_premiumrate',
            'premium': 'custrecord_essav_premium',
            'dollarRate': 'custrecord_essav_dollarrate',
            'invoiceSumUsd': 'custrecord_essav_invoicesumusd',
            'insureSumUsd': 'custrecord_essav_insuresumusd',
            'remark': 'custrecord_essav_remark',
            'buyerno': 'custrecord_essav_buyerno',
            'bankno': 'custrecord_essav_bankno',
            'paymode': 'custrecord_essav_paymode',
            'feepaymode': 'custrecord_essav_feepaymode',
            'payterm': 'custrecord_essav_payterm',
            'notifyTime': 'custrecord_essav_notifytime',
            'unAcceptCode': 'custrecord_essav_unacceptcode',
            'errorCode': 'custrecord_essav_errorcode',
            'errorMsg': 'custrecord_essav_errormsg',
        };
        /**
         * Defines the Scheduled script trigger point.
         * @param {Object} scriptContext
         * @param {string} scriptContext.type - Script execution context. Use values from the scriptContext.InvocationType enum.
         * @since 2015.2
         */
        const execute = (scriptContext) => {
            let dateJson = getDateTime();
            let reqData = {
                "datas": {
                    "startDate": dateJson.startDate,
                    "endDate": dateJson.endDate
                },
                "imethod": "getEdiShipmentApproveInfo"
            };
            let rtnData = interfaceTool.requestEdiServer(reqData, ITYPE);
            log.debug('接口返回数据', rtnData);
            if(true == rtnData.valid) {
                let infoData = rtnData.data.datas;
                if(infoData && infoData.length > 0) {
                    infoData = JSON.parse(infoData);
                    log.debug('infoData',infoData);
                    //获取所有noticeSerialNo，匹配已有数据
                    let noticeSerialNo = ramda.groupBy(ramda.path(['noticeSerialNo']))(infoData);
                    let existNoticeSerialNoData = formatExistNoticeSerialNo(Object.keys(noticeSerialNo));
                    let corpSerialNo = ramda.groupBy(ramda.path(['corpSerialNo']))(infoData);
                    let corpSerialNoData = formatCorpSerialNo(Object.keys(corpSerialNo));
                    let methodData = formatPayMethod();
                    let createdDataIdArray = [],
                        applyRecordIdArray = [],
                        spRecordIdArray = []
                        logUpdVal = {
                            custrecord_hc_inf_process_msg: '',
                            custrecord_hc_inf_errorflag: false
                        };
                    try {
                        for(let i = 0; i < infoData.length; i++) {
                            let obj;
                            if('undefined' == typeof existNoticeSerialNoData[infoData[i].noticeSerialNo]) {
                                obj = record.create({type: 'customrecord_ecm_sinosure_shipmentapprov'});
                            } else {
                                obj = record.load({type: 'customrecord_ecm_sinosure_shipmentapprov', id: existNoticeSerialNoData[infoData[i].noticeSerialNo]});
                            }
                            if(infoData[i].payMode) {
                                obj.setValue({fieldId: 'custrecord_essav_paymode', value: methodData[infoData[i].payMode] || ''});
                            }
                            if(infoData[i].feepaymode) {
                                obj.setValue({fieldId: 'custrecord_essav_feepaymode', value: methodData[infoData[i].feepaymode] || ''});
                            }
                            if(infoData[i].approveFlag) {
                                if (Number(infoData[i].approveFlag) == 0 || infoData[i].approveFlag == '0') {
                                    obj.setValue({fieldId: 'custrecord_essav_approveflag', value: '信保失败'});
                                } else {
                                    obj.setValue({fieldId: 'custrecord_essav_approveflag', value: '信保通过'});
                                }
                            }
                            for(let key in infoData[i]) {
                                if('notifyTime' == key || 'transportDate' == key) {
                                    let tmpDate = moment(infoData[i].key);
                                    if (!isNaN(tmpDate)) {
                                        let tmpDateStr = tmpDate.format('MM/DD/YYYY');
                                        obj.setText({fieldId: FIELD_MAPPING[key], text: tmpDateStr});
                                    }
                                } else if('feepaymode' != key && 'payMode' != key && 'approveFlag' != key){
                                    obj.setValue({fieldId: FIELD_MAPPING[key], value: infoData[i][key]});
                                }
                            }
                            let recordId = obj.save();
                            log.debug('recordId',recordId);
                            createdDataIdArray.push(recordId);
                        }
                        logUpdVal.custrecord_hc_inf_process_msg = createdDataIdArray.join('&');
                    } catch (e) {
                        log.error('生成出运申报受理反馈error===>' + rtnData.logId, e);
                        if(createdDataIdArray && createdDataIdArray.length > 0) {
                            createdDataIdArray.forEach(function (cid) {
                                record.delete({type: 'customrecord_ecm_sinosure_shipmentapprov', id: cid});
                            });
                        }
                        logUpdVal.custrecord_hc_inf_process_msg = e.message;
                        logUpdVal.custrecord_hc_inf_errorflag = true;
                    }

                    try {
                        for(let i = 0; i < infoData.length; i++) {
                            //更新出运明细申报单
                            let applyRecord = record.load({type: 'customrecord_ecm_sinosure_shipmentapply', id: corpSerialNoData[infoData[i].corpSerialNo]});
                            if (Number(infoData[i].approveFlag) == 0 || infoData[i].approveFlag == '0') {
                                applyRecord.setValue({fieldId: 'custrecord_essap_status', value: 6});
                            } else {
                                applyRecord.setValue({fieldId: 'custrecord_essap_status', value: 5});
                            }
                            if(infoData[i].unAcceptCode) {
                                applyRecord.setValue({fieldId: 'custrecord_essap_errorcode', value: infoData[i].unAcceptCode});
                            }
                            if(infoData[i].unAcceptReason) {
                                applyRecord.setValue({fieldId: 'custrecord_essap_errormsg', value: infoData[i].unAcceptReason});
                            }
                            applyRecord.save();
                            applyRecordIdArray.push(corpSerialNoData[infoData[i].corpSerialNo]);

                            let spId = applyRecord.getValue('custrecord_essap_shippingplan');
                            let spRecord = record.load({type: 'customrecord_ecm_sp', id: spId});
                            if (Number(infoData[i].approveFlag) == 0 || infoData[i].approveFlag == '0') {
                                spRecord.setValue({fieldId: 'custrecord_sp_applystatus', value: 6});
                            } else {
                                spRecord.setValue({fieldId: 'custrecord_sp_applystatus', value: 5});
                            }
                            spRecord.save();
                            spRecordIdArray.push(spId);
                        }
                        logUpdVal.custrecord_hc_inf_process_msg = createdDataIdArray.join('&');
                    } catch (e) {
                        log.error('更新出运申报error===>' + rtnData.logId, e);
                        if(applyRecordIdArray && applyRecordIdArray.length > 0) {
                            applyRecordIdArray.forEach(function (aid) {
                                let applyRecord = record.load({type: 'customrecord_ecm_sinosure_shipmentapply', id: aid});
                                applyRecord.setValue({fieldId: 'custrecord_essap_status', value: 3});
                                applyRecord.setValue({fieldId: 'custrecord_essap_errorcode', value: ''});
                                applyRecord.setValue({fieldId: 'custrecord_essap_errormsg', value: ''});
                                applyRecord.save();
                            });
                        }
                        if(spRecordIdArray && spRecordIdArray.length > 0) {
                            spRecordIdArray.forEach(function (aid) {
                                let spRecord = record.load({type: 'customrecord_ecm_sp', id: aid});
                                spRecord.setValue({fieldId: 'custrecord_sp_applystatus', value: 3});
                                spRecord.save();
                            });
                        }
                        logUpdVal.custrecord_hc_inf_process_msg = e.message;
                        logUpdVal.custrecord_hc_inf_errorflag = true;
                    }

                    record.submitFields({
                        type: LOG_TYPE,
                        id: rtnData.logId,
                        values: logUpdVal
                    });
                }
            }
        }

        /**
         * 搜索corpSerialNo记录
         * @param corpSerialNoArray              本次返回corpSerialNo
         * @return {{}}                     {corpSerialNo：id}
         */
        const formatCorpSerialNo = corpSerialNoArray => {
            let existData = {};//{corpSerialNo：id}
            if(!corpSerialNoArray || 0 == corpSerialNoArray.length) {
                return existData;
            }
            let filters = [],
                columns = ['name'];
            corpSerialNoArray.forEach(function (corpSerialNo) {
                filters.push(['idtext', 'is', corpSerialNo]);
                filters.push('or');
            });
            filters.pop();
            let results = commonApi.searchAllData('customrecord_ecm_sinosure_shipmentapply', filters, columns);
            if(results && results.length > 0) {
                results.forEach(function (res) {
                    existData[res.getValue(columns[0])] = res.id;
                });
            }
            log.debug('corpSerialNo数据', existData);
            return existData;
        }

        /**
         * 搜索已存在noticeSerialNo记录
         * @param noticeSerialNoArray              本次返回noticeSerialNo
         * @return {{}}                     {noticeSerialNo：id}
         */
        const formatExistNoticeSerialNo = noticeSerialNoArray => {
            let existData = {};//{noticeSerialNo：id}
            if(!noticeSerialNoArray || 0 == noticeSerialNoArray.length) {
                return existData;
            }
            let filters = [],
                columns = ['custrecord_essav_noticeserialno'];
            noticeSerialNoArray.forEach(function (noticeSerialNo) {
                filters.push(['custrecord_essav_noticeserialno', 'is', noticeSerialNo]);
                filters.push('or');
            });
            filters.pop();
            let results = commonApi.searchAllData('customrecord_ecm_sinosure_shipmentapprov', filters, columns);
            if(results && results.length > 0) {
                results.forEach(function (res) {
                    existData[res.getValue(columns[0])] = res.id;
                });
            }
            log.debug('已存在noticeSerialNo数据', existData);
            return existData;
        }

        /**
         * 搜索【中信保-支付方式】
         * @return {{}}                     {code：id}
         */
        const formatPayMethod = () => {
            let existData = {};
            let filters = [],
                columns = ['custrecord_esp_code'];
            let results = commonApi.searchAllData('customrecord_ecm_sinosure_paymethod', filters, columns);
            if(results && results.length > 0) {
                results.forEach(function (res) {
                    existData[res.getValue(columns[0])] = res.id;
                });
            }
            log.debug('匹配支付方式', existData);
            return existData;
        }

        /**
         * 设置时间频率
         * @returns {{endDate: number, startDate: number}}
         */
        const getDateTime = () => {
            let newDate = new Date();
            let year = newDate.getFullYear();
            let yesYear = year;
            let month = newDate.getMonth() + Number(1);
            let yesMonth = month;
            let today = newDate.getDate();
            let yesterday = Number(today) - Number(2);
            let hour = newDate.getHours();
            log.debug('hour', hour)
            hour = Number(hour) + Number(16);
            let minute = newDate.getMinutes()
            let second = newDate.getSeconds();

            if (24 <= hour){
                today = newDate.getDate() + Number(1);
                yesterday = Number(today) - Number(2);
                hour = Number(hour) - Number(24);
            }
            log.debug('today', {today:today, yesterday:yesterday})

            if (Number(1) == Number(today) && ((Number(2) == Number(month))) || (Number(4) == Number(month)) || (Number(6) == Number(month)) || (Number(8) == Number(month)) || (Number(9) == Number(month)) || (Number(11) == Number(month))){
                yesterday = Number(30);
                yesMonth = Number(month) - Number(1);
            }
            if (Number(1) == Number(today) && ((Number(5) == Number(month))) || (Number(7) == Number(month)) || (Number(10) == Number(month)) || (Number(12) == Number(month))){
                yesterday = Number(29);
                yesMonth = Number(month) - Number(1);
            }
            if (Number(1) == Number(today) && (Number(1) == Number(month))){
                yesterday = Number(30);
                yesMonth = Number(12);
                yesYear = Number(year) - Number(1);
            }
            if (Number(1) == Number(today) && (Number(3) == Number(month))){
                if ((Number(year) % Number(4) == Number(0) && Number(year) % Number(100) != Number(0)) || Number(year) % Number(400) == Number(0)){
                    yesterday = Number(28);
                    yesMonth = Number(month) - Number(1);
                }else {
                    yesterday = Number(27);
                    yesMonth = Number(month) - Number(1);
                }
            }
            // let startDate = new Date(yesYear+'/'+yesMonth+'/'+yesterday+ ' ' + '08:00:00').getTime();
            // let endDate = new Date(year+'/'+month+'/'+today+ ' ' + '07:59:59').getTime();
            // hour = Number(hour).sub(8) < 10 ? '0' + Number(hour).sub(8) : Number(hour).sub(8);
            minute = Number(minute) < 10 ? '0' + minute : minute;
            second = Number(second) < 10 ? '0' + second : second;
            let startDate = yesYear+'-'+yesMonth+'-'+yesterday+ ' ' + hour + ':' + minute + ':' + second;
            let endDate = year+'-'+month+'-'+today+ ' ' + hour + ':' + minute + ':' + second;

            // let startDate = '2023-03-08 14:53:52'
            // let endDate = '2023-03-12 14:53:52'
            log.debug('today' , year+'/'+month+'/'+today)
            log.debug('date', {startDate:startDate,endDate:endDate})
            return {startDate: startDate, endDate: endDate};
        }

        return {execute}

    });
