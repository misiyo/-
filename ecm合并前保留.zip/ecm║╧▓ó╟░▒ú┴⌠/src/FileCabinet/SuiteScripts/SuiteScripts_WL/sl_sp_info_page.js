/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 * Version      Date            Author              Memo
 * 1.0          2023/03/21      Will                SP Information页面
 */
define(['N/http', 'N/record', 'N/redirect', 'N/search', 'N/ui/serverWidget', 'N/config','N/file'],
    /**
     * @param{http} http
     * @param{record} record
     * @param{redirect} redirect
     * @param{search} search
     * @param{serverWidget} serverWidget
     * @param{config} config
     * @param{file} file
     */
    (http, record, redirect, search, serverWidget, config,file) => {
        /**
         * Defines the Suitelet script trigger point.
         * @param {Object} scriptContext
         * @param {ServerRequest} scriptContext.request - Incoming request
         * @param {ServerResponse} scriptContext.response - Suitelet response
         * @since 2015.2
         */
        const onRequest = (scriptContext) => {
            let request = scriptContext.request;
            let response = scriptContext.response;
            let params = request.parameters;
            // log.debug('params', params);
            // log.debug('request', request);
            try {
                if ('GET' == request.method) {
                    let form = createForm(params);
                    response.writePage(form);
                }
            } catch (e) {
                log.error('Error===>', e);
            }
        }

        //创建页面
        function createForm(params) {
            let form = serverWidget.createForm({title:'Select Shipping Plan', hideNavBar: true});
            form.clientScriptModulePath = './cs_sp_info_page.js';
            form.addButton({id: 'custpage_btn_submit', label: 'Submit', functionName: 'doSubmit'});
            form.addButton({id: 'custpage_btn_cancel', label: 'Cancel', functionName: 'doCancel'});

            let spField = form.addField({id : 'custpage_sp', label : 'Shipping Plan', type : 'select'});
            spField.isMandatory = true;
            let spList = getAllSp();
            spField.addSelectOption({value: '', text: ''});
            spList.forEach(lc => {
                spField.addSelectOption({value: lc.value, text: lc.name});
            });

            let idField = form.addField({id : 'custpage_rid', label : 'type', type : 'text'});
            idField.updateDisplayType({displayType : serverWidget.FieldDisplayType.HIDDEN});
            idField.defaultValue = params.rid;

            return form;
        }

        /**
         * 获取全部SP
         * @returns {*[]}
         */
        function getAllSp() {
            let spList = [];
            let spSearchObj = search.create({
                type: "customrecord_ecm_sp",
                filters:
                    [],
                columns:
                    [
                        search.createColumn({
                            name: "name",
                            sort: search.Sort.ASC,
                            label: "ID"
                        }),
                        search.createColumn({name: "internalid", label: "内部 ID"})
                    ]
            });
            let columns = spSearchObj.columns;
            let res = spSearchObj.run().getRange({start: 0, end: 1000});
            if (res && res.length > 0) {
                for (let i = 0; i < res.length; i++) {
                    let spNum = res[i].getValue(columns[0]);
                    let id = res[i].getValue(columns[1]);
                    let json = {};
                    json.value = id;
                    json.name = spNum;
                    spList.push(json);
                }
            }
            return spList;
        }

        return {onRequest}

    });
