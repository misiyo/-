/**
 * @NApiVersion 2.1
 * @NScriptType ScheduledScript
 *
 * Version		Date			Author			Memo
 * 1.0			2023/02/16		Will Liu		中信保：出运申报受理反馈(1018425)
 */
define(['N/https', 'N/record', 'N/task', '/SuiteScripts/tools/common_api.js', '/SuiteScripts/tools/hc_edi_interface_tool.js', '/SuiteScripts/tools/moment.js', '/SuiteScripts/tools/ramda.min.js'],
    /**
     * @param{https} https
     * @param record
     * @param{task} task
     * @param commonApi
     * @param interfaceTool
     * @param moment
     * @param ramda
     */
    (https, record, task, commonApi, interfaceTool, moment, ramda) => {
        /**
         * Defines the Scheduled script trigger point.
         * @param {Object} scriptContext
         * @param {string} scriptContext.type - Script execution context. Use values from the scriptContext.InvocationType enum.
         * @since 2015.2
         */
        const execute = (scriptContext) => {
            try {
                let spIdArr = searchSpId();
                for (let i = 0; i < spIdArr.length; i++) {
                    let spRec = record.load({type: 'customrecord_ecm_sp', id: spIdArr[i]});
                    let length = spRec.getLineCount('item');
                    let updState = true;
                    for (let j = 0; j < length; j++) {
                        let spQty = spRec.getSublistValue({sublistId:'item',fieldId:'custrecord_scdline_spqty',line:i});//实际发运数量
                        let qty = spRec.getSublistValue({sublistId:'item',fieldId:'custrecord_scdline_qty',line:i});//数量
                        if (Number(qty) < Number(spQty)) {
                            updState = false
                        }
                    }
                    if (updState == true) {
                        spRec.setValue({fieldId:'custrecord_sp_status', value:2});
                    }
                    spRec.save({ignoreMandatoryFields: true, enableSourcing: true});
                }
            } catch (e) {
                log.error('Error', e);
            }
        }


        /**
         * 搜索状态为待出运的的Shipping Plan id
         * @returns {*[]}
         */
        function searchSpId() {
            let filters = [];
            let columns = [];
            filters.push(["custrecord_sp_status","is",1]);//TODO 单据状态
            filters.push('AND');
            filters.push(['isinactive', 'is', 'false']);
            columns.push(search.createColumn({name: "internalid", label: "Internal ID"}));
            let spSearchObj = search.create({type: 'customrecord_ecm_sp', filters: filters, columns: columns});
            let result = spSearchObj.run().getRange({start: 0, end: 1000});
            let spIdArr = [];
            if (result.length > 0) {
                for (let i = 0; i < result.length; i++) {
                    let spId = result[i].getValue(columns[0]);
                    spIdArr.push(spId);
                }
            }
            return spIdArr
        }

        return {execute}
    });
