/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * version      date            author          remark
 * 1.0          2023/02/15      Will Liu        中信保：出运明细申报(1018425)
 */
define(['N/http', 'N/https', 'N/record', 'N/search', 'N/url', '/SuiteScripts/tools/hc_edi_interface_tool.js'],
    /**
     * @param{http} http
     * @param{https} https
     * @param{record} record
     * @param{search} search
     */
    (http, https, record, search, url, interfaceTool) => {
        const LOG_TYPE = 'customrecord_hc_edi_interface_log';//日志类型
        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed before record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const beforeSubmit = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {
            if(['delete','xedit'].includes(scriptContext.type)) return;
            let newRec = scriptContext.newRecord;
            let curRec = record.load({type: newRec.type, id: newRec.id});
            let status = curRec.getValue('custrecord_essap_status');//单据状态
            let postsinosure = curRec.getValue('custrecord_essap_postsinosure');//推送中信保
            let posterromsg = curRec.getValue('custrecord_essap_posterromsg');//推送失败信息

            if (status == 3 && postsinosure == false && posterromsg == '') {
                let rtn;
                try {
                    rtn = sendData(curRec);
                } catch (e) {
                    log.error('Error', e);
                    curRec.setValue({fieldId: 'custrecord_essap_postsinosure', value: false});
                    curRec.setValue({fieldId: 'custrecord_essap_posterromsg', value: e});
                    curRec.save({ignoreMandatoryFields: true, enableSourcing: true});
                }
            }
        }

        function sendData(curRec) {
            let buyerNo = curRec.getValue('custrecord_essap_buyerno');//中国信保买方代码
            let insureSum = curRec.getValue('custrecord_essap_insuresum');//投保金额
            let quotaBalance = limitBalanceSearch(buyerNo);//限额余额
            log.debug('buyerNo',buyerNo);
            log.debug('insureSum',insureSum);
            log.debug('quotaBalance',quotaBalance);
            if (Number(quotaBalance) < Number(insureSum)) {
                curRec.setValue({fieldId: 'custrecord_essap_postsinosure', value: false});
                curRec.setValue({fieldId: 'custrecord_essap_posterromsg', value: '此客户中信保限额余额不足，请查询余额后重新提交'});
                curRec.save({ignoreMandatoryFields: true, enableSourcing: true});
            } else {
                let data = {};
                let arr = [];
                let json = {};
                json.corpSerialNo = curRec.getValue('name');//ID
                json.clientNo = curRec.getValue('custrecord_essap_clientno');//企业标识
                json.policyNo = curRec.getValue('custrecord_essap_policyno');//保险单号
                json.buyerNo = curRec.getValue('custrecord_essap_buyerno');//中国信保买方代码
                json.corpBuyerNo = curRec.getValue('custrecord_essap_corpbuyerno');//企业买方代码
                json.buyerChnName = curRec.getValue('custrecord_essap_buyerchnname');//买方中文名称
                json.buyerEngName = curRec.getValue('custrecord_essap_buyerengname');//买方英文名称
                let buyerCountryCode = curRec.getValue('custrecord_essap_buyercountrycode');//买方国家代码
                if (buyerCountryCode) {
                    json.buyerCountryCode = countryCodeSearch(buyerCountryCode);
                } else {
                    json.buyerCountryCode = '';
                }
                json.buyerEngAddr = curRec.getValue('custrecord_essap_buyerengaddr');//买方英文地址
                json.buyerChnAddr = curRec.getValue('custrecord_essap_buyerchnaddr');//买方中文地址
                json.buyerRegNo = curRec.getValue('custrecord_essap_buyerregno');//买方注册号
                json.buyerTel = curRec.getValue('custrecord_essap_buyertel');//买方电话
                json.buyerFax = curRec.getValue('custrecord_essap_buyerfax');//买方传真
                json.bankNo = curRec.getValue('custrecord_essap_bankno');//开证行SWIFT
                json.corpBankNo = curRec.getValue('custrecord_essap_corpbankno');//企业开证行代码
                json.bankChnName = curRec.getValue('custrecord_essap_bankchnname');//开证行中文名称
                json.bankEngName = curRec.getValue('custrecord_essap_bankengname');//开证行英文名称
                let bankCountryCode = curRec.getValue('custrecord_essap_bankcountrycode');//开证行国家代码
                json.bankCountryCode = bankCountryCode == '' ? '' : countryCodeSearch(bankCountryCode);
                json.bankCountryName = curRec.getValue('custrecord_essap_bankcountryname');//开证行国家名称
                json.bankAddr = curRec.getValue('custrecord_essap_bankaddr');//开证行地址
                json.invoiceNo = curRec.getValue('custrecord_essap_invoiceno');//发票编号
                let invoiceSum = curRec.getValue('custrecord_essap_invoicesum');//发票金额
                if (invoiceSum) {
                    json.invoiceSum = curRec.getValue('custrecord_essap_invoicesum');
                } else {
                    json.invoiceSum = curRec.getValue('custrecord_essap_insuresum');
                }
                json.insureSum = curRec.getValue('custrecord_essap_insuresum');//投保金额
                let moneyId = curRec.getValue('custrecord_essap_moneyid');//出运货币代码
                json.moneyId = currencyCodeSearch(moneyId);
                json.payTerm = curRec.getValue('custrecord_essap_payterm');//合同支付期限（天）
                let payMode = curRec.getValue('custrecord_essap_paymode');//合同支付方式
                json.payMode = payMethodSearch(payMode);
                let feePayMode = curRec.getValue('custrecord_essap_feepaymode');//缴费支付方式
                json.feePayMode = payMethodSearch(feePayMode);
                let trafficCode = curRec.getValue('custrecord_essap_trafficcode');//运输方式
                json.trafficCode = trafficCode == '' ? '' : shippingMethodSearch(trafficCode);
                json.transportDate = getDateFormat(curRec.getText('custrecord_essap_transportdate'));//出运日期
                let code10 = curRec.getValue('custrecord_essap_code10');//海关10位商品代码
                json.code10 = code10;
                // json.code10 = '8525801300';
                json.lcno = curRec.getValue('custrecord_essap_lcno');//信用证号
                json.goodsName = curRec.getValue('custrecord_essap_goodsname');//商品名称
                json.contractNo = curRec.getValue('custrecord_essap_contractno');//合同号
                json.customsBillNo = curRec.getValue('custrecord_essap_customsbillno');//报关单号
                json.remark = curRec.getValue('custrecord_essap_remark');//保户特别说明
                let expectDate = curRec.getText('custrecord_essap_expectdate');
                json.expectdate = expectDate == '' ? '' : getDateFormat(expectDate);//期望承保情况通知书出具日期
                json.orderNo = curRec.getValue('custrecord_essap_orderno');//订单号
                let ifFinancing = curRec.getValue('custrecord_essap_iffinancing');//是否需要申请融资
                if (ifFinancing == 1) {
                    json.ifFinancing = '1';
                } else {
                    json.ifFinancing = '0';
                }
                json.payerName = curRec.getValue('custrecord_essap_payername');//付款人
                json.employeeName = curRec.getValue('custrecord_essap_employeename');//员工名称
                json.applicantName = curRec.getValue('custrecord_essap_applicantname');//申请人姓名
                json.applyTime = getDateFormat(curRec.getText('custrecord_essap_applytime'));//申请时间
                arr.push(json);
                data.datas = arr;
                data.imethod = 'doEdiShipmentApply';
                log.debug('data',data);
                let rtn = interfaceTool.requestEdiServer(data,8);
                log.debug('rtn',rtn);
                if (true == rtn.valid && '' == rtn.data.errormsg) {
                    curRec.setValue({fieldId: 'custrecord_essap_postsinosure', value: true});
                    curRec.setValue({fieldId: 'custrecord_essap_posterromsg', value: ''});
                    curRec.save({ignoreMandatoryFields: true, enableSourcing: true});
                } else {
                    curRec.setValue({fieldId: 'custrecord_essap_postsinosure', value: false});
                    curRec.setValue({fieldId: 'custrecord_essap_posterromsg', value: rtn.data.errormsg});
                    curRec.save({ignoreMandatoryFields: true, enableSourcing: true});
                    let logUpdVal = {
                        custrecord_hc_inf_process_msg: rtn.data.errormsg,
                        custrecord_hc_inf_errorflag: true
                    };
                    record.submitFields({
                        type: LOG_TYPE,
                        id: rtn.logId,
                        values: logUpdVal
                    });
                }
                return rtn;
            }
        }

        function limitBalanceSearch(buyerNo) {
            let filters = [];
            let columns = [];
            filters.push(["custrecord_esl_buyerno","is",buyerNo]);
            filters.push('AND');
            filters.push(['isinactive', 'is', 'false']);
            columns.push(search.createColumn({name: "custrecord_esl_quotabalance", label: "限额余额"}));
            let limitBalanceSearchObj = search.create({type: 'customrecord_ecm_sinosure_limitbalance', filters: filters, columns: columns});
            let result = limitBalanceSearchObj.run().getRange({start: 0, end: 1000});
            if (result.length > 0) {
                return result[0].getValue(columns[0])
            }
        }

        /**
         * 国家代码
         * @param countryCode
         * @returns {*}
         */
        function countryCodeSearch(countryCode) {
            let filters = [];
            let columns = [];
            filters.push(['internalid', 'anyof', countryCode]);
            filters.push('AND');
            filters.push(['isinactive', 'is', 'false']);
            columns.push(search.createColumn({name: "custrecord_ec_code"}));
            let limitBalanceSearchObj = search.create({type: 'customrecord_ecm_countrycode', filters: filters, columns: columns});
            let result = limitBalanceSearchObj.run().getRange({start: 0, end: 1000});
            if (result.length > 0) {
                return result[0].getValue(columns[0])
            }
        }

        /**
         * 货币代码
         * @param currencyCode
         * @returns {*}
         */
        function currencyCodeSearch(currencyCode) {
            let filters = [];
            let columns = [];
            filters.push(['internalid', 'anyof', currencyCode]);
            filters.push('AND');
            filters.push(['isinactive', 'is', 'false']);
            columns.push(search.createColumn({name: "custrecord_escc_code"}));
            let limitBalanceSearchObj = search.create({type: 'customrecord_ecm_sinosure_currency_code', filters: filters, columns: columns});
            let result = limitBalanceSearchObj.run().getRange({start: 0, end: 1000});
            if (result.length > 0) {
                return result[0].getValue(columns[0])
            }
        }

        /**
         * 支付方式
         * @param payMethodId
         * @returns {*}
         */
        function payMethodSearch(payMethodId) {
            let filters = [];
            let columns = [];
            filters.push(['internalid', 'anyof', payMethodId]);
            filters.push('AND');
            filters.push(['isinactive', 'is', 'false']);
            columns.push(search.createColumn({name: "custrecord_esp_code"}));
            let limitBalanceSearchObj = search.create({type: 'customrecord_ecm_sinosure_paymethod', filters: filters, columns: columns});
            let result = limitBalanceSearchObj.run().getRange({start: 0, end: 1000});
            if (result.length > 0) {
                return result[0].getValue(columns[0])
            }
        }

        /**
         * 货物代码
         * @param goodsId
         * @returns {*}
         */
        function goodsSearch(goodsId) {
            let filters = [];
            let columns = [];
            filters.push(['internalid', 'anyof', goodsId]);
            filters.push('AND');
            filters.push(['isinactive', 'is', 'false']);
            columns.push(search.createColumn({name: "custrecord_epcc_code"}));
            let limitBalanceSearchObj = search.create({type: 'customrecord_ecm_product_category_code', filters: filters, columns: columns});
            let result = limitBalanceSearchObj.run().getRange({start: 0, end: 1000});
            if (result.length > 0) {
                return result[0].getValue(columns[0])
            }
        }

        /**
         * 运输方式代码
         * @param smId
         * @returns {*}
         */
        function shippingMethodSearch(smId) {
            let filters = [];
            let columns = [];
            filters.push(['internalid', 'anyof', smId]);
            filters.push('AND');
            filters.push(['isinactive', 'is', 'false']);
            columns.push(search.createColumn({name: "custrecord_esm_code"}));
            let limitBalanceSearchObj = search.create({type: 'customrecord_ecm_shippingmethod', filters: filters, columns: columns});
            let result = limitBalanceSearchObj.run().getRange({start: 0, end: 1000});
            if (result.length > 0) {
                return result[0].getValue(columns[0])
            }
        }

        /**
         * 日期转换
         * @param date
         * @returns {string}
         */
        const getDateFormat = (date) => {
            date = new Date(date);
            let year = date.getFullYear();
            let month = date.getMonth() + 1;
            let day = date.getDate();
            if (month < 10){
                month = '0' + month;
            }
            if (day < 10){
                day = '0' + day;
            }
            return year + '-' + month + '-' + day;
        }


        return {beforeLoad, beforeSubmit, afterSubmit}

    });
