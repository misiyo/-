/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * Version        Date            Author          Memo
 * 1.0            2023/02/27      Will Liu        Shipping Plan到达时进行库存转移(1018809)
 * 2.0            2023/03/02      Will Liu        取值修改(1018809)
 * 3.0            2023/03/16      Will Liu        整体逻辑修改(1018809)
 * 4.0            2023/03/21      Will Liu        逻辑变更(1018809)
 * 5.0            2023/03/22      Will Liu        it搜索逻辑变更(1018809)
 * 6.0            2023/04/06      Will Liu        it生成逻辑变更(1018809)
 * 7.0            2023/04/12      Will Liu        it单日期取值变更为取SP上的Arrive Date(1018809)
 * 8.0            2023/04/17      Will Liu        到达和提货时发邮件(1019769,1019767)
 */
define(['N/record','N/email', 'N/runtime', 'N/search', 'N/query', 'N/url'],
    /**

     * @param{record} record
     * @param{runtime} runtime
     * @param{search} search
     * @param query
     * @param{email} email
     */
    (record, email, runtime, search,query, url) => {
        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed before record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const beforeSubmit = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {
            if (['delete', 'xedit'].includes(scriptContext.type)) return;
            let newRec = scriptContext.newRecord;
            let spId = newRec.id;
            let curRec = record.load({type: newRec.type, id: newRec.id, isDynamic: true});
            createInventoryTransfer(spId,curRec);
            fullyPickedUpSendEmail(curRec);
            arrivedSendEmail(curRec);
        }

        function searchIrId(spLineIdArr) {
            let filters = [];
            let columns = [];
            filters.push(['type','anyof','ItemRcpt']);
            filters.push('AND');
            filters.push(['custcol_ecm_spline','anyof',spLineIdArr]);
            filters.push('AND');
            filters.push(['custbody_ecm_ordertype','anyof',2]); // TODO 环境校验 Order
            columns.push(search.createColumn({name: 'internalid', summary: 'GROUP', label: '内部 ID'}));
            let inventoryDetailSearchObj = search.create({
                type: 'itemreceipt',
                filters: filters,
                columns: columns
            });
            let result = inventoryDetailSearchObj.run().getRange({start: 0, end: 1000});
            let irIdArr = [];
            if (result && result.length > 0) {
                for (let i = 0; i < result.length; i++) {
                    let irId = result[i].getValue(columns[0]);
                    irIdArr.push(irId)
                }
                return irIdArr;
            }
        }

        function searchIrInventoryDetail(irIdArr) {
            let irSpKeyArr = [];
            let irInventoryInfoArr = [];
            for (let i = 0; i < irIdArr.length; i++) {
                let irRec = record.load({type: 'itemreceipt', id: irIdArr[i], isDynamic: true});
                let irLength = irRec.getLineCount('item');
                let irInventoryInfo = {};
                if (irLength > 0) {
                    for(let i = 0; i < irLength; i++) {
                        let irItemId = irRec.getSublistValue({sublistId:'item',fieldId:'item',line: i});
                        let irSpLineId = irRec.getSublistValue({sublistId:'item',fieldId:'custcol_ecm_spline',line: i});
                        let irSpKey = irSpLineId + '&' + irItemId;
                        if (irSpKeyArr.indexOf(irSpKey) == -1) {
                            irSpKeyArr.push(irSpKey)
                        }
                        irInventoryInfo[irSpKey] = [];
                        irRec.selectLine({sublistId: 'item', line: i});
                        let inventoryDetailRecord = irRec.getCurrentSublistSubrecord({sublistId:'item',fieldId:'inventorydetail'});
                        let inventoryLines = inventoryDetailRecord.getLineCount('inventoryassignment');
                        if (inventoryLines && inventoryLines > 0) {
                            for (let i = 0; i < inventoryLines; i++) {
                                let numberedRecordId = inventoryDetailRecord.getSublistValue({sublistId: 'inventoryassignment',fieldId: 'numberedrecordid',line: i});
                                let inventoryQuantity = inventoryDetailRecord.getSublistValue({sublistId: 'inventoryassignment',fieldId: 'quantity',line: i});
                                let inventoryStatus = inventoryDetailRecord.getSublistValue({sublistId: 'inventoryassignment',fieldId: 'inventorystatus',line: i});
                                let itemInventoryInfo = {
                                    numberedRecordId : numberedRecordId,
                                    inventoryQuantity : inventoryQuantity,
                                    inventoryStatus : inventoryStatus
                                };
                                irInventoryInfo[irSpKey].push(itemInventoryInfo);
                            }
                        }
                    }
                    irInventoryInfoArr.push(irInventoryInfo);
                }
            }
            // log.debug('irInventoryInfoArr',irInventoryInfoArr);
            let templateInfo = {};
            for (let i = 0; i < irSpKeyArr.length; i++) {
                templateInfo[irSpKeyArr[i]] = [];
            }
            for (let i = 0; i < irInventoryInfoArr.length; i++) {
                let irInventoryInfo = irInventoryInfoArr[i];
                for (let key in templateInfo) {
                    let templateInfoArr = templateInfo[key];
                    for (let irKey in irInventoryInfo) {
                        if (key == irKey) {
                            templateInfoArr.push(irInventoryInfo[key])
                        }
                    }
                }
            }
            // log.debug('templateInfo',templateInfo);
            return templateInfo
        }

        function searchItInventoryDetail(itIdArr,spItLineIdArr) {
            let itSpKeyArr = [];
            let itInventoryInfoArr = [];
            for (let i = 0; i < itIdArr.length; i++) {
                let itRec = record.load({type: 'inventorytransfer', id: itIdArr[i], isDynamic: true});
                let itLength = itRec.getLineCount('inventory');
                let itInventoryInfo = {};
                let spItLineId = spItLineIdArr[i];
                for(let i = 0; i < itLength; i++) {
                    let itItemId = itRec.getSublistValue({sublistId:'inventory',fieldId:'item',line: i});
                    let itSpLineId = itRec.getSublistValue({sublistId:'inventory',fieldId:'custcol_ecm_spline',line: i});
                    if (spItLineId == itSpLineId) {
                        let itSpKey = itSpLineId + '&' + itItemId;
                        if (itSpKeyArr.indexOf(itSpKey) == -1) {
                            itSpKeyArr.push(itSpKey)
                        }
                        itInventoryInfo[itSpKey] = [];
                        itRec.selectLine({sublistId: 'inventory', line: i});
                        let inventoryDetailRecord = itRec.getCurrentSublistSubrecord({sublistId:'inventory',fieldId:'inventorydetail'});
                        let inventoryLines = inventoryDetailRecord.getLineCount('inventoryassignment');
                        if (inventoryLines && inventoryLines > 0) {
                            for (let i = 0; i < inventoryLines; i++) {
                                let numberedRecordId = inventoryDetailRecord.getSublistValue({sublistId: 'inventoryassignment',fieldId: 'numberedrecordid',line: i});
                                let inventoryQuantity = inventoryDetailRecord.getSublistValue({sublistId: 'inventoryassignment',fieldId: 'quantity',line: i});
                                let inventoryStatus = inventoryDetailRecord.getSublistValue({sublistId: 'inventoryassignment',fieldId: 'inventorystatus',line: i});
                                let itemInventoryInfo = {
                                    numberedRecordId : numberedRecordId,
                                    inventoryQuantity : inventoryQuantity,
                                    inventoryStatus : inventoryStatus
                                };
                                itInventoryInfo[itSpKey].push(itemInventoryInfo);
                            }
                        }
                    }
                }
                itInventoryInfoArr.push(itInventoryInfo);
            }
            // log.debug('itInventoryInfoArr',itInventoryInfoArr);
            let templateInfo = {};
            for (let i = 0; i < itSpKeyArr.length; i++) {
                templateInfo[itSpKeyArr[i]] = [];
            }
            for (let i = 0; i < itInventoryInfoArr.length; i++) {
                let irInventoryInfo = itInventoryInfoArr[i];
                for (let key in templateInfo) {
                    let templateInfoArr = templateInfo[key];
                    for (let irKey in irInventoryInfo) {
                        if (key == irKey) {
                            templateInfoArr.push(irInventoryInfo[key])
                        }
                    }
                }
            }
            // log.debug('templateInfo',templateInfo);
            return templateInfo
        }

        function createIt(tranDate, subsidiary, location, desLocation, allItemInfo,spId) {
            let itRecord = record.create({
                type: 'inventorytransfer',
                isDynamic: true
            });
            itRecord.setText({fieldId: 'trandate', text: tranDate});
            itRecord.setValue({fieldId: 'subsidiary', value: subsidiary});
            itRecord.setValue({fieldId: 'location', value: location});
            itRecord.setValue({fieldId: 'transferlocation', value: desLocation});
            itRecord.setValue({fieldId: 'custbody_ecm_sp', value: spId});
            for (let i = 0; i < allItemInfo.length; i++) {
                itRecord.selectNewLine('inventory');
                itRecord.setCurrentSublistValue({sublistId: 'inventory', fieldId: 'item', value: allItemInfo[i].item});
                itRecord.setCurrentSublistValue({sublistId: 'inventory', fieldId: 'units', value: allItemInfo[i].unit});
                itRecord.setCurrentSublistValue({sublistId: 'inventory', fieldId: 'adjustqtyby', value: allItemInfo[i].qty});
                itRecord.setCurrentSublistValue({sublistId: 'inventory', fieldId: 'custcol_ecm_spline', value: allItemInfo[i].spLineId});
                let inventorydetail_record = itRecord.getCurrentSublistSubrecord({sublistId: 'inventory', fieldId: 'inventorydetail'});
                let spKey = Object.keys(allItemInfo[i])[4];
                let inventoryDetailArr = allItemInfo[i][spKey];
                for (let j = 0; j < inventoryDetailArr.length; j++) {
                    let inventoryDetailArray = inventoryDetailArr[j];
                    for (let k = 0; k < inventoryDetailArray.length; k++) {
                        inventorydetail_record.selectNewLine({sublistId: 'inventoryassignment'});
                        inventorydetail_record.setCurrentSublistValue({
                            sublistId: 'inventoryassignment',
                            fieldId: 'issueinventorynumber',
                            value: inventoryDetailArray[k].numberedRecordId
                        });
                        inventorydetail_record.setCurrentSublistValue({
                            sublistId: 'inventoryassignment',
                            fieldId: 'inventorystatus',
                            value: inventoryDetailArray[k].inventoryStatus
                        });
                        inventorydetail_record.setCurrentSublistValue({
                            sublistId: 'inventoryassignment',
                            fieldId: 'toinventorystatus',
                            value: inventoryDetailArray[k].inventoryStatus
                        });
                        // inventorydetail_record.setCurrentSublistText({
                        //     sublistId: 'inventoryassignment',
                        //     fieldId: 'expirationdate',
                        //     text: inventoryDetailArr[j].expirationDate
                        // });
                        inventorydetail_record.setCurrentSublistValue({
                            sublistId: 'inventoryassignment',
                            fieldId: 'quantity',
                            value: inventoryDetailArray[k].inventoryQuantity
                        });
                        inventorydetail_record.commitLine({sublistId: 'inventoryassignment'});
                    }
                }
                itRecord.commitLine('inventory')
            }
            let itId = itRecord.save({ignoreMandatoryFields: true, enableSourcing: true});
            log.debug('itId',itId);
            return itId
        }

        function createInventoryTransfer(spId,curRec) {
            try {
                let it = curRec.getValue('custrecord_sp_it');//关联it
                let arriveIt = curRec.getValue('custrecord_sp_arriveit');
                let desLocation = curRec.getValue('custrecord_sp_destilocation');//目的仓
                let status = curRec.getValue('custrecord_sp_status');//状态
                if (desLocation != '' && status == 4 && arriveIt == '') { //TODO 环境校验
                    let length = curRec.getLineCount('recmachcustrecord_scdline_sp');
                    // let tranDate = getNowDateTime();
                    let tranDate = curRec.getText('custrecord_sp_arrivaldate');
                    // let subsidiary = curRec.getValue('custrecord_sp_scsubsidiary');//子公司
                    // let subFields = search.lookupFields({type: 'subsidiary', id: subsidiary, columns: ['custrecord_ecm_location']});
                    // let location = subFields.custrecord_ecm_location[0].value;

                    let subFields = search.lookupFields({type: 'location', id: desLocation, columns: ['subsidiary']});
                    let subName = subFields.subsidiary;
                    log.debug('subName',subName);
                    let myLoadedQuery = query.load({id: 'custworkbook17'});
                    let mySuiteQLQuery = myLoadedQuery.toSuiteQL();
                    let results = mySuiteQLQuery.run();
                    let mrSet = results.asMappedResults();
                    let subId = 0;
                    for (let i = 0; i < mrSet.length; i++) {
                        if (mrSet[i].name == subName) {
                            subId = mrSet[i].id
                        }
                    }
                    let locFields = search.lookupFields({type: 'subsidiary', id: subId, columns: ['custrecord_ecm_location']});
                    let locId = locFields.custrecord_ecm_location[0].value;
                    log.debug('locId',locId);



                    let allItemInfo = [];
                    let itArr = [];
                    let spLineIdArr = [];
                    let spItLineIdArr = [];
                    for (let i = 0 ; i < length; i++) {
                        let item = curRec.getSublistValue({sublistId: 'recmachcustrecord_scdline_sp', fieldId: 'custrecord_scdline_item', line: i});
                        let unit = curRec.getSublistValue({sublistId: 'recmachcustrecord_scdline_sp', fieldId: 'custrecord_scdline_unit', line: i});
                        let qty = curRec.getSublistValue({sublistId: 'recmachcustrecord_scdline_sp', fieldId: 'custrecord_scdline_spqty', line: i});
                        let distributionType = curRec.getSublistValue({sublistId: 'recmachcustrecord_scdline_sp', fieldId: 'custrecord_scdline_distributiontype', line: i});
                        let spLineId = curRec.getSublistValue({sublistId: 'recmachcustrecord_scdline_sp', fieldId: 'id', line: i});
                        let itId = curRec.getSublistValue({sublistId: 'recmachcustrecord_scdline_sp', fieldId: 'custrecord_scdline_it', line: i});
                        let spKey = spLineId + '&' + item;

                        if (distributionType == 1 || distributionType == 3) { //TODO 以销定采 采购合同
                            spLineIdArr.push(spLineId);
                        } else if (distributionType == 2) {
                            itArr.push(itId);
                            spItLineIdArr.push(spLineId)
                        }
                        let itemInfo = {
                            item : item,
                            unit : unit,
                            qty : qty,
                            spLineId : spLineId
                        }
                        itemInfo[spKey] = [];
                        allItemInfo.push(itemInfo);
                    }
                    // log.debug('allItemInfo',allItemInfo);
                    // log.debug('spLineIdArr',spLineIdArr);

                    let itInfo;
                    let irInfo;
                    if (itArr.length > 0) {
                        itInfo = searchItInventoryDetail(itArr,spItLineIdArr);
                    }
                    if (spLineIdArr.length > 0) {
                        let irIdArr = searchIrId(spLineIdArr);
                        irInfo = searchIrInventoryDetail(irIdArr);
                    }
                    if (itInfo) {
                        for (let i = 0; i < allItemInfo.length; i++) {
                            let spKey1 = Object.keys(allItemInfo[i])[4];
                            for (let key in itInfo) {
                                if (spKey1 == key) {
                                    allItemInfo[i][key] = itInfo[key]
                                }
                            }
                        }
                        // log.debug('allItemInfo', allItemInfo);
                    }
                    if (irInfo) {
                        for (let i = 0; i < allItemInfo.length; i++) {
                            let spKey1 = Object.keys(allItemInfo[i])[4];
                            for (let key in irInfo) {
                                if (spKey1 == key) {
                                    allItemInfo[i][key] = irInfo[key]
                                }
                            }
                        }
                        log.debug('allItemInfo', allItemInfo);
                    }
                    if (allItemInfo && allItemInfo.length > 0) {
                        let itId = createIt(tranDate, subId, locId, desLocation, allItemInfo,spId);
                        curRec.setValue({fieldId: 'custrecord_sp_arriveit', value: itId});
                        curRec.save({ignoreMandatoryFields: true, enableSourcing: true});
                    }
                }
            } catch (e) {
                log.error('Error', e);
            }
        }

        function arrivedSendEmail(curRec) {
            let status = curRec.getValue('custrecord_sp_status');
            let pickup = curRec.getValue('custrecord_sp_email_pickup');
            if (status == 4 && pickup == false) {
                try {
                    let arr = [];
                    let warehouseClerk = curRec.getValue({fieldId: 'custrecord_sp_warehouseclerk'});
                    let cusService = curRec.getValue({fieldId: 'custrecord_sp_cusservice'});
                    if (cusService && arr.indexOf(cusService) == -1) {
                        arr.push(cusService)
                    }
                    let docOfficer2 = curRec.getValue({fieldId: 'custrecord_sp_docofficer2'});
                    if (docOfficer2 && arr.indexOf(docOfficer2) == -1) {
                        arr.push(docOfficer2)
                    }
                    let supplyPlanner = curRec.getValue({fieldId: 'custrecord_sp_supplyplanner'});
                    if (supplyPlanner && arr.indexOf(supplyPlanner) == -1) {
                        arr.push(supplyPlanner)
                    }

                    let sippingAddArr = curRec.getValue({fieldId: 'custrecord_sp_sippingadd'}).split(';');
                    let uniqueArr = arr.concat(sippingAddArr).filter(function(item, index, arr) {
                        return arr.indexOf(item) === index;
                    });

                    const groupSize = 10; // 分组大小
                    const groups = []; // 存储分组后的数组

                    for (let i = 0; i < uniqueArr.length; i += groupSize) {
                        const group = uniqueArr.slice(i, i + groupSize);
                        groups.push(group);
                    }

                    let output = url.resolveRecord({
                        recordType: 'customrecord_ecm_sp',
                        recordId: curRec.id,
                    }).split('&');
                    let exUrl = 'https://' + output[2].split('=')[1].replace('_', '-') + '.app.netsuite.com' + output[0] + '&' + output[1];

                    let emailBody = [
                        "The Shipping Plan has been Shipped.",
                        "<br>",
                        "<a href='",
                        exUrl,
                        "'>",
                        "View Record",
                        "</a>"
                    ].join("");

                    for (let i = 0; i < groups.length; i++) {
                        email.send({
                            author: warehouseClerk,
                            recipients : groups[i],
                            subject: 'The Shipping Plan has been fully picked up.',
                            body: emailBody
                        });
                    }
                    curRec.setValue({fieldId: 'custrecord_sp_email_pickup', value: true});
                    curRec.save({ignoreMandatoryFields: true, enableSourcing: true});
                } catch (e) {
                    log.error('Error', e);
                }
            }
        }

        function fullyPickedUpSendEmail(curRec) {
            let status = curRec.getValue('custrecord_sp_status');
            let pickup = curRec.getValue('custrecord_sp_email_pickup');
            if (status == 2 && pickup == false) {
                try {
                    let arr = [];
                    let supplyPlanner = curRec.getValue({fieldId: 'custrecord_sp_supplyplanner'});
                    let cusService = curRec.getValue({fieldId: 'custrecord_sp_cusservice'});
                    if (cusService && arr.indexOf(cusService) == -1) {
                        arr.push(cusService)
                    }
                    let docOfficer2 = curRec.getValue({fieldId: 'custrecord_sp_docofficer2'});
                    if (docOfficer2 && arr.indexOf(docOfficer2) == -1) {
                        arr.push(docOfficer2)
                    }
                    let logistician2 = curRec.getValue({fieldId: 'custrecord_sp_logistician2'});
                    if (logistician2 && arr.indexOf(logistician2) == -1) {
                        arr.push(logistician2)
                    }

                    let output = url.resolveRecord({
                        recordType: 'customrecord_ecm_sp',
                        recordId: curRec.id,
                    }).split('&');
                    let exUrl = 'https://' + output[2].split('=')[1].replace('_', '-') + '.app.netsuite.com' + output[0] + '&' + output[1];

                    let emailBody = [
                        "The Shipping Plan has been Shipped.",
                        "<br>",
                        "<a href='",
                        exUrl,
                        "'>",
                        "View Record",
                        "</a>"
                    ].join("");

                    email.send({
                        author: supplyPlanner,
                        recipients : arr,
                        subject: 'The Shipping Plan has been fully picked up.',
                        body: emailBody
                    });
                    curRec.setValue({fieldId: 'custrecord_sp_email_pickup', value: true});
                    curRec.save({ignoreMandatoryFields: true, enableSourcing: true});
                } catch (e) {
                    log.error('Error', e);
                }
            }
        }

        /**
         * 获取当前日期时间
         * @return {string}
         */
        function getNowDateTime() {
            var now = new Date();
            var moffset = now.getTimezoneOffset();
            now = new Date(now.getTime() + ((8 * 60 + moffset) * 60 * 1000));
            var t = new Date(now.getTime() + (0 * 60 * 60 * 1000));
            var year = t.getFullYear();
            var month = t.getMonth() + 1;
            var day = t.getDate();
            month = month < 10 ? '0' + month : month;
            day = day < 10 ? '0' + day : day;
            return month + '/' + day + '/' + year;
        }


        return {/*beforeLoad, beforeSubmit,*/ afterSubmit}

    });
