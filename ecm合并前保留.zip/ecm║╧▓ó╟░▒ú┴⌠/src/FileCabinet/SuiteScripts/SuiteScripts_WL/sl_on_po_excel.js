/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 * @NModuleScope SameAccount
 * Version      Date            Author             Remark
 * 1.0          2023/03/14      Will               采购合同(1019161)
 */
define(['N/file', 'N/record', 'N/render', 'N/search', 'N/encode', 'N/format', 'N/config', 'SuiteScripts/tools/common_api.js'],
    /**
     * @param {file} file
     * @param {record} record
     * @param {render} render
     * @param {search} search
     * @param encode
     * @param format
     * @param config
     * @param commonApi
     */
    function (file, record, render, search, encode, format, config, commonApi) {

        /**
         * Definition of the Suitelet script trigger point.
         *
         * @param {Object} context
         * @param {ServerRequest} context.request - Encapsulation of the incoming request
         * @param {ServerResponse} context.response - Encapsulation of the Suitelet response
         * @Since 2015.2
         */
        function onRequest(context) {
            let request = context.request;
            let response = context.response;
            try {
                if (request.method == 'GET') {
                    let param = request.parameters;
                    let poId = param.rid;
                    // log.debug('param',param);
                    // log.debug('poId', poId);
                    let xmlStr = getXml(poId);
                    context.response.writeFile(xmlStr);
                }
            } catch (e) {
                log.error('Error===>', e);
            }

        }

        function getXml(poId) {
            let poObj = record.load({type: 'purchaseorder', id: poId});
            let tranId = poObj.getValue('tranid');
            let subsidiary = poObj.getValue('subsidiary');
            let subsidiaryRec = record.load({type: 'subsidiary', id: subsidiary});
            let country = subsidiaryRec.getValue('country');
            let printFormat;
            if (country == 'CN' || country == 'TW' || country == 'MO' || country == 'HK') {
                printFormat = '/SuiteScripts/SuiteScripts_WL/采购合同CN.txt';
            } else {
                printFormat = '/SuiteScripts/SuiteScripts_WL/采购合同EN.txt';
            }
            let time = formatNowDate('YYYYMMDD');
            let fileName = tranId + '_' + time;

            let tempFile = file.load({
                id: printFormat,
            });


            let t_render = render.create();
            //模板的内容
            t_render.templateContent = tempFile.getContents();

            let allData = formatPoData(poId,subsidiaryRec,country);

            t_render.addCustomDataSource({
                alias: 'data',
                format: render.DataSource.OBJECT,
                data: allData
            });

            let excel_str = t_render.renderAsString();

            //将字符串转换为另一种类型的编码
            let fstr = encode.convert({
                string: excel_str,
                inputEncoding: encode.Encoding.UTF_8,
                outputEncoding: encode.Encoding.BASE_64
            });

            let nowDate = new Date();
            let now = format.format({
                value: nowDate,
                type: format.Type.DATETIME
            });

            let name = fileName + '.xls';


            let excel = file.create({
                name: name,
                fileType: file.Type.EXCEL,
                contents: fstr
            });
            return excel;
        }


        function formatPoData(poId,subsidiaryRec,country) {
            let data = {};
            let obj = record.load({type: 'purchaseorder', id: poId});
            let json = searchContactPrimary(poId);
            data.contact = json.name;
            data.contactEmail = json.email;
            data.subName = subsidiaryRec.getValue('custrecord_ecm_subname_cn');
            data.subAddress = subsidiaryRec.getValue('custrecord_ecm_subaddress_cn');
            data.fax = subsidiaryRec.getValue('fax');
            data.phone = subsidiaryRec.getValue('custrecord37');
            data.federalIdNumber = subsidiaryRec.getValue('federalidnumber');
            data.subNameEn = subsidiaryRec.getValue('custrecord_ecm_subname_en');

            let entity = obj.getValue('entity');
            let vendorSearch = search.lookupFields({
                type: 'vendor',
                id: entity,
                columns: ['companyname','phone','fax','vatregnumber','custentity_ecm_engname']
            });
            data.companyName = vendorSearch.companyname;
            data.vendorPhone = vendorSearch.phone;
            data.vendorFax = vendorSearch.fax;
            data.vatregNumber = vendorSearch.vatregnumber;
            data.engname = vendorSearch.custentity_ecm_engname;

            let bankInfoId = obj.getValue('custbody_ecm_vendorbankinfoma');
            if (bankInfoId) {
                let bankInfoSearch = search.lookupFields({
                    type: 'customrecord_ecm_bankinfo',
                    id: bankInfoId,
                    columns: ['custrecord_ecm_beneficiarybankcn','custrecord_ecm_bankaccount','custrecord_ecm_bankdetails']
                });
                data.beneficiaryBankCn = bankInfoSearch.custrecord_ecm_beneficiarybankcn;
                data.bankAccount = bankInfoSearch.custrecord_ecm_bankaccount;
                data.bankDetails = bankInfoSearch.custrecord_ecm_bankdetails;
            }
            data.tranId = obj.getValue('tranid');
            data.tranDate = obj.getText('trandate');
            data.currency = obj.getText('currency');
            data.signAddress = obj.getValue('custbody_ecm_signaddress_cn');
            data.signAddressEn = obj.getValue('custbody_ecm_signaddress_en');
            data.signingDate = obj.getText('custbody_ecm_signingdate');
            data.totalAmtEn = obj.getText('custbody_ecm_totalamt_en');
            data.termsDisplayEn = obj.getText('custbody_ecm_termsdisplay_en');
            let shelfLifeYear = obj.getValue('custbody_ecm_shelflifeyear');
            let reqQuality = obj.getValue('custbody_ecm_quality_index_req');
            if (shelfLifeYear != '' && reqQuality != '') {
                data.case1 = '1';
            } else if (shelfLifeYear != '' && reqQuality == '') {
                data.case2 = '1';
            } else if (shelfLifeYear == '' && reqQuality != '') {
                data.case3 = '1';
            } else if (shelfLifeYear == '' && reqQuality == '') {
                data.case4 = '1';
            }
            data.shelfLifeYear = obj.getValue('custbody_ecm_shelflifeyear');
            data.reqQuality = obj.getValue('custbody_ecm_quality_index_req');
            data.billAddress = obj.getValue('billaddress');
            data.termsDisplay = obj.getValue('custbody_ecm_termsdisplay_cn');
            data.creator = obj.getText('custbody_creator');
            let creatorId = obj.getValue('custbody_creator');
            let creatorSearch = search.lookupFields({
                type: 'employee',
                id: creatorId,
                columns: ['email']
            });
            data.creatorEmail = creatorSearch.email

            let specIsDisplay = obj.getValue('custbody_ecm_skuspec_isdisplay');
            let brandIsDisplay = obj.getValue('custbody_ecm_skubrand_isdisplay');
            let casNoIsDisplay = obj.getValue('custbody_ecm_casno_isdisplay');
            let hsCodeIsDisplay = obj.getValue('custbody_ecm_skuhscode_isdisplay');
            let inCoTerm = obj.getText('incoterm');
            let loadingPort = obj.getText('custbody_ecm_loadingport');
            let departure = obj.getText('custbody_ecm_countryof_departure');
            let destinationPort = obj.getText('custbody_ecm_destination_port');
            let countryOfDestination = obj.getText('custbody_ecm_countryof_destination');
            let deliveryAddress = obj.getText('custbody_ecm_delivery_address');
            let placeOfReceipt = obj.getText('custbody_ecm_placeofreceipt');
            if (inCoTerm == 'EXW') {
                data.deliveryPlace = 'EXW ' + deliveryAddress;
                data.transportMode = '';
                data.transportModeEn = '';
            } else if (inCoTerm == 'FCA') {
                data.deliveryPlace = 'FCA ' + deliveryAddress;
                data.transportMode = '陆运费由供方承担。';
                data.transportModeEn = 'The land freight is borne by Seller\'s .';
            } else if (inCoTerm == 'CPT') {
                data.deliveryPlace = 'CPT ' + placeOfReceipt;
                data.transportMode = '陆运费、卸货费、仓库费、港口费、海运费由供方承担。';
                data.transportModeEn = 'The land freight, the unloading fee, the Warehouse fee, the Port fee, the Ocean freight is borne by Seller\'s .';
            } else if (inCoTerm == 'CIP') {
                data.deliveryPlace = 'CIP ' + placeOfReceipt;
                data.transportMode = '陆运费、卸货费、仓库费、港口费、海运费、保险费由供方承担。';
                data.transportModeEn = 'The land freight, the unloading fee, the Warehouse fee, the Port fee, the Ocean freight, the Premium is borne by Seller\'s .';
            } else if (inCoTerm == 'FAS') {
                data.deliveryPlace = 'FAS ' + loadingPort;
                data.transportMode = '陆运费、卸货费、仓库费、港口费由供方承担。';
                data.transportModeEn = 'The land freight, the unloading fee, the Warehouse fee, the Port fee is borne by Seller\'s .';
            } else if (inCoTerm == 'FOB') {
                data.deliveryPlace = 'FOB ' + loadingPort;
                data.transportMode = '陆运费、卸货费、仓库费、港口费由供方承担。';
                data.transportModeEn = 'The land freight, the unloading fee, the Warehouse fee, the Port fee is borne by Seller\'s .';
            } else if (inCoTerm == 'CFR') {
                data.deliveryPlace = 'CFR ' + destinationPort;
                data.transportMode = '陆运费、卸货费、仓库费、港口费、海运费由供方承担。';
                data.transportModeEn = 'The land freight, the unloading fee, the Warehouse fee, the Port fee, the Ocean freight, is borne by Seller\'s .';
            } else if (inCoTerm == 'CIF') {
                data.deliveryPlace = 'CIF ' + destinationPort;
                data.transportMode = '陆运费、卸货费、仓库费、港口费、海运费、保险费由供方承担。';
                data.transportModeEn = 'The land freight, the unloading fee, the Warehouse fee, the Port fee, the Ocean freight, the Premium is borne by Seller\'s .';
            } else if (inCoTerm == 'DES') {
                data.deliveryPlace = 'DES ' + destinationPort;
                data.transportMode = '陆运费、卸货费、仓库费、港口费、海运费、保险费由供方承担。';
                data.transportModeEn = 'The land freight, the unloading fee, the Warehouse fee, the Port fee, the Ocean freight, the Premium is borne by Seller\'s .';
            } else if (inCoTerm == 'DEQ') {
                data.deliveryPlace = 'DEQ ' + destinationPort;
                data.transportMode = '陆运费、卸货费、仓库费、港口费、海运费、保险费由供方承担。';
                data.transportModeEn = 'The land freight, the unloading fee, the Warehouse fee, the Port fee, the Ocean freight, the Premium is borne by Seller\'s .';
            } else if (inCoTerm == 'DDU') {
                data.deliveryPlace = 'DDU ' + placeOfReceipt;
                data.transportMode = '陆运费、卸货费、仓库费、港口费、海运费、保险费由供方承担。';
                data.transportModeEn = 'The land freight, the unloading fee, the Warehouse fee, the Port fee, the Ocean freight, the Premium is borne by Seller\'s .';
            } else if (inCoTerm == 'DDP') {
                data.deliveryPlace = 'DDP ' + placeOfReceipt;
                data.transportMode = '陆运费、卸货费、仓库费、港口费、海运费、保险费由供方承担。';
                data.transportModeEn = 'The land freight, the unloading fee, the Warehouse fee, the Port fee, the Ocean freight, the Premium is borne by Seller\'s .';
            } else if (inCoTerm == 'DAF') {
                data.deliveryPlace = 'DAF ' + placeOfReceipt;
                data.transportMode = '陆运费、卸货费、仓库费、港口费、海运费、保险费由供方承担。';
                data.transportModeEn = 'The land freight, the unloading fee, the Warehouse fee, the Port fee, the Ocean freight, the Premium is borne by Seller\'s .';
            } else if (inCoTerm == 'DAT') {
                data.deliveryPlace = 'DAT ' + placeOfReceipt;
                data.transportMode = '陆运费、卸货费、仓库费、港口费、海运费、保险费由供方承担。';
                data.transportModeEn = 'The land freight, the unloading fee, the Warehouse fee, the Port fee, the Ocean freight, the Premium is borne by Seller\'s .';
            } else if (inCoTerm == 'DAP') {
                data.deliveryPlace = 'DAP ' + placeOfReceipt;
                data.transportMode = '陆运费、卸货费、仓库费、港口费、海运费、保险费由供方承担。';
                data.transportModeEn = 'The land freight, the unloading fee, the Warehouse fee, the Port fee, the Ocean freight, the Premium is borne by Seller\'s .';
            } else if (inCoTerm == 'DPU') {
                data.deliveryPlace = 'DPU ' + placeOfReceipt;
                data.transportMode = '陆运费、卸货费、仓库费、港口费、海运费、保险费由供方承担。';
                data.transportModeEn = 'The land freight, the unloading fee, the Warehouse fee, the Port fee, the Ocean freight, the Premium is borne by Seller\'s .';
            }

            if (inCoTerm == 'EXW' || inCoTerm == 'FCA') {
                data.deliveryPlaceEn = deliveryAddress;
            } else if (inCoTerm != 'EXW' && inCoTerm != 'FCA' && (loadingPort == 'Any Port' || loadingPort == '')) {
                data.deliveryPlaceEn = 'Any Port in ' + departure;
            } else if (inCoTerm != 'EXW' && inCoTerm != 'FCA' && loadingPort != 'Any Port' && loadingPort != '') {
                data.deliveryPlaceEn = loadingPort;
            }



            let itemArr = searchItem(poId);


            let length = obj.getLineCount('item');
            let lines = [];
            let unit;
            let totalQuantity = 0;
            let totalGrossAmt = 0;
            for (let i = 0; i < length; i++) {
                let itemId = obj.getSublistValue({sublistId: 'item', fieldId: 'item', line: i});
                let itemName = obj.getSublistValue({sublistId: 'item', fieldId: 'custcol_ecm_productname_cn', line: i});
                let quantity = obj.getSublistValue({sublistId: 'item', fieldId: 'quantity', line: i});
                let units = obj.getSublistText({sublistId: 'item', fieldId: 'units', line: i});
                let rate = obj.getSublistValue({sublistId: 'item', fieldId: 'rate', line: i});
                let taxRate = obj.getSublistText({sublistId: 'item', fieldId: 'taxrate1', line: i});
                let grossAmt = obj.getSublistValue({sublistId: 'item', fieldId: 'grossamt', line: i});
                let packageRemark = obj.getSublistValue({sublistId: 'item', fieldId: 'custcol_ecm_packageremark', line: i});
                let isPallet = obj.getSublistValue({sublistId: 'item', fieldId: 'custcol_ecm_ispallet', line: i});
                let hsCode = obj.getSublistValue({sublistId: 'item', fieldId: 'custcol_emc_hscode', line: i});
                let taxRateNumber = Number(commonApi.percentToNumber(taxRate)) + 1;
                let price = Number(rate).mul(Number(taxRateNumber));
                unit = obj.getSublistText({sublistId: 'item', fieldId: 'units', line: 0});
                totalQuantity = Number(totalQuantity).add(Number(quantity)) || ' ';
                totalGrossAmt = Number(totalGrossAmt).add(Number(grossAmt)) || ' ';

                let line = {
                    itemId : itemId,
                    itemName : itemName,
                    quantity : quantity,
                    units : units,
                    price : price,
                    grossAmt : grossAmt,
                    packageRemark : packageRemark,
                    isPallet : isPallet,
                    hsCode : hsCode
                };
                lines.push(line);
            }

            for (let i = 0; i < lines.length; i++) {
                let pcItemId = lines[i].itemId;
                for (let j = 0; j < itemArr.length; j++) {
                    let itemId = itemArr[j].itemId;
                    if (pcItemId == itemId) {
                        lines[i].specification = '';
                        lines[i].packing = '';
                        lines[i].productNameEn = itemArr[j].productNameEn;
                        if (specIsDisplay == true) {
                            lines[i].specification += itemArr[j].combine + '<br>';
                        }
                        if (brandIsDisplay == true) {
                            lines[i].specification += itemArr[j].brand + '<br>';
                        }
                        if (casNoIsDisplay == true) {
                            lines[i].specification += itemArr[j].cas + '<br>';
                        }
                        if (hsCodeIsDisplay == true) {
                            lines[i].specification += lines[i].hsCode;
                        }

                        if (itemArr[j].unitsType == 'Weight' || itemArr[j].unitsType == 'Volume') {
                            if (lines[i].isPallet == true) {
                                lines[i].packing = lines[i].packageRemark + '；' + '打托缠膜';
                            } else {
                                lines[i].packing = lines[i].packageRemark;
                            }
                        } else if (itemArr[j].unitsType == 'Package') {
                            if (lines[i].isPallet == true) {
                                if (country == 'CN' || country == 'TW' || country == 'MO' || country == 'HK') {
                                    lines[i].packing = itemArr[j].packageKg + itemArr[j].wgtUnit + '/' + itemArr[j].remark + '；' + '<br>' + lines[i].packageRemark + '；' + '打托缠膜';
                                } else {
                                    lines[i].packing = itemArr[j].packageKg + itemArr[j].wgtUnit + '/' + itemArr[j].productNameEn + '；' + '<br>' + lines[i].packageRemark + '；' + '打托缠膜';
                                }
                            } else {
                                if (country == 'CN' || country == 'TW' || country == 'MO' || country == 'HK') {
                                    lines[i].packing = itemArr[j].packageKg + itemArr[j].wgtUnit + '/' + itemArr[j].remark + '；' + '<br>' + lines[i].packageRemark;
                                } else {
                                    lines[i].packing = itemArr[j].packageKg + itemArr[j].wgtUnit + '/' + itemArr[j].productNameEn + '；' + '<br>' + lines[i].packageRemark;
                                }
                            }
                        }
                    }
                }
            }

            data.unit = unit;
            data.list = lines;
            data.totalQuantity = totalQuantity;
            data.totalGrossAmt = totalGrossAmt;
                data.chineseTotalGrossAmt = commonApi.convertNumberToChineseCharacter(totalGrossAmt);
            log.debug('data',data);
            return data;
        }

        function searchItem(poId) {
            let columns = [];
            let mySearch = search.create({
                type: "purchaseorder",
                filters:
                    [
                        ["type","anyof","PurchOrd"],
                        "AND",
                        ["internalid","anyof",poId],
                        "AND",
                        ["mainline","is","F"],
                        "AND",
                        ["taxline","is","F"]
                    ],
                columns: columns
            });
            columns.push(search.createColumn({
                name: "internalid",
                join: "item",
            }));
            columns.push(search.createColumn({
                name: "custitem_ecm_spec_combine_cn",
                join: "item",
            }));
            columns.push(search.createColumn({
                name: "custitem_ecm_brand",
                join: "item",
            }));
            columns.push(search.createColumn({
                name: "custitem_ecm_cas",
                join: "item",
            }));
            columns.push(search.createColumn({
                name: "unitstype",
                join: "item",
            }));
            columns.push(search.createColumn({
                name: "custitem_ecm_case_package_kg",
                join: "item",
            }));
            columns.push(search.createColumn({
                name: "custitem_ecm_wgt_unit",
                join: "item",
            }));
            columns.push(search.createColumn({
                name: "custitem_ecm_package_remk_cn",
                join: "item",
            }));
            columns.push(search.createColumn({
                name: "custitem_ecm_package_remk_en",
                join: "item",
            }));
            let result = mySearch.run().getRange({start: 0, end: 1000});
            if (result && result.length > 0) {
                let itemArr = [];
                for (let i = 0; i < result.length; i++) {
                    let itemId = result[i].getValue(columns[0]);
                    let combine = result[i].getValue(columns[1]);
                    let brand = result[i].getValue(columns[2]);
                    let cas = result[i].getValue(columns[3]);
                    let unitsType = result[i].getText(columns[4]);
                    let packageKg = result[i].getValue(columns[5]);
                    let wgtUnit = result[i].getText(columns[6]);
                    let remark = result[i].getValue(columns[7]);
                    let productNameEn = result[i].getText(columns[8]);
                    let json = {
                        itemId : itemId,
                        combine : combine,
                        brand : brand,
                        cas : cas,
                        unitsType : unitsType,
                        packageKg : packageKg,
                        wgtUnit : wgtUnit,
                        remark : remark,
                        productNameEn : productNameEn
                    }
                    itemArr.push(json);
                }
                // log.debug('itemArr',itemArr);
                return itemArr;
            }
        }

        function searchContactPrimary(poId) {
            let purchaseorderSearchObj = search.create({
                type: "purchaseorder",
                filters:
                    [
                        ["type","anyof","PurchOrd"],
                        "AND",
                        ["internalid","anyof",poId],
                        "AND",
                        ["mainline","is","F"],
                        "AND",
                        ["taxline","is","F"],
                    ],
                columns:
                    [
                        search.createColumn({
                            name: "entityid",
                            join: "contactPrimary",
                            label: "名称"
                        }),
                        search.createColumn({
                            name: "email",
                            join: "contactPrimary",
                            label: "电子邮件"
                        })
                    ]
            });
            let columns = purchaseorderSearchObj.columns;
            let result = purchaseorderSearchObj.run().getRange({start: 0, end: 1000});
            // log.debug('result',result);
            if (result && result.length > 0) {
                return {
                    name: result[0].getValue(columns[0]),
                    email: result[0].getValue(columns[1])
                };
            }
        }


        /**
         * 获取当前日期
         * @param dateformat
         * @return {string|boolean}
         */
        const formatNowDate = (dateformat) => {
            let now = commonApi.getNowDateTime(true);
            let dateArr = now.split('/');
            let year = dateArr[0], month = dateArr[1], day = dateArr[2];
            if ('' == year || '' == month || '' == day || '' == dateformat) {
                return false;
            }
            if ('YYYY年M月D日' == dateformat) {
                return year + '年' + Number(month) + '月' + Number(day) + '日 ';
            } else if ('YYYY年MM月DD日' == dateformat) {
                return year + '年' + month + '月' + day + '日 ';
            } else if ('YYYY-M-D' == dateformat) {
                return year + '-' + Number(month) + '-' + Number(day);
            } else if('YYYY-MM-DD' == dateformat) {
                return year + '-' + month + '-' + day;
            } else if ('YYYY M D' == dateformat) {
                return year + ' ' + Number(month) + ' ' + Number(day);
            } else if ('YYYY MM DD' == dateformat) {
                return year + ' ' + month + ' ' + day;
            } else if ('YYYYMMDD' == dateformat) {
                return year + month + day;
            } else if ('YYYY/M/D' == dateformat) {
                return year + '/' + Number(month) + '/' + Number(day);
            } else if ('YYYY/MM/DD' == dateformat) {
                return year + '/' + month + '/' + day;
            } else if ('M/D/YYYY' == dateformat) {
                return Number(month) + '/' + Number(day) + '/' + year;
            } else if ('MM/DD/YYYY' == dateformat) {
                return month + '/' + day + '/' + year;
            } else if ('D/M/YYYY' == dateformat) {
                return Number(day) + '/' + Number(month) + '/' + year;
            } else if ('DD/MM/YYYY' == dateformat) {
                return day + '/' + month + '/' + year;
            } else if ('D-Mon-YYYY' == dateformat) {
                let months = ["1", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                let tempMonth = months[month - 1];
                return Number(day) + '-' + tempMonth + '月-' + year;
            } else if ('DD-Mon-YYYY' == dateformat) {
                let months = ["1", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                let tempMonth = months[month - 1];
                return day + '-' + tempMonth + '月-' + year;
            } else if ('D.M.YYYY' == dateformat) {
                return Number(day) + '.' + Number(month) + '.' + year;
            } else if('DD.MM.YYYY' == dateformat) {
                return day + '.' + month + '.' + year;
            }
        }

        return {
            onRequest: onRequest
        };

    });
