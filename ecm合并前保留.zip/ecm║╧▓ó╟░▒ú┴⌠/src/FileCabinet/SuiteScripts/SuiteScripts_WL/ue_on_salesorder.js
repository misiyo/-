/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * Version        Date            Author          Memo
 * 1.0            2023/02/20      Will Liu        销售合同名称展示(1018389)
 * 1.0            2023/02/21      Will Liu        销售合同带出报关信息(1018389)
 * 1.0            2023/02/21      Will Liu        销售合同行序号，行唯一键(1018389)
 * 1.0            2023/02/21      Will Liu        销售合同数量汇总展示(1018389)
 */
define(['N/currentRecord', 'N/record', 'N/runtime', 'N/search', 'N/task', 'N/ui/serverWidget'],
    /**
 * @param{currentRecord} currentRecord
 * @param{record} record
 * @param{runtime} runtime
 * @param{search} search
 * @param{task} task
 * @param{serverWidget} serverWidget
 */
    (currentRecord, record, runtime, search, task, serverWidget) => {
        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {
            let newRec = scriptContext.newRecord;
            let form = scriptContext.form;
            let orderType = newRec.getValue('custbody_ecm_ordertype');
            if (orderType == 1) { //TODO 环境校验
                form.title = 'Sales Contract';
            }
        }

        /**
         * Defines the function definition that is executed before record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const beforeSubmit = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {
            if(['delete','xedit'].includes(scriptContext.type)) return;
            let oldRec;
            if (scriptContext.oldRecord) {
                oldRec = scriptContext.oldRecord;
            }
            let newRec = scriptContext.newRecord;
            let curRec = record.load({type: newRec.type, id: newRec.id});
            let length = curRec.getLineCount('item');
            try {
                setLine(curRec,length,oldRec);
                setSumQty(curRec,length);
                setLineDeclaration(curRec,length);
                curRec.save({ignoreMandatoryFields: true, enableSourcing: true});
            } catch (e) {
                log.error('Error===>' + newRec.id, e);
            }
        }

        /**
         *设置行序号和行唯一键
         * @param curRec
         * @param length
         * @param oldRec
         */
        function setLine(curRec,length,oldRec) {
            let lineNoArr = [];
            let needAddNo = false;
            for(let index = 0; index < length; index++) {
                const lineNo = curRec.getSublistValue({sublistId:'item',fieldId:'custcol_emc_line_no',line:index});
                lineNoArr.push(lineNo);
                if (lineNo == '') {
                    needAddNo = true
                }
            }
            // log.debug('lineNoArr',lineNoArr);
            if (oldRec) {
                if (needAddNo == true) {
                    let oldLength = oldRec.getLineCount('item');
                    let maxNo = 0;
                    for(let index = 0; index < oldLength; index++) {
                        const lineNo = oldRec.getSublistValue({sublistId:'item',fieldId:'custcol_emc_line_no',line:index});
                        if (Number(lineNo) > Number(maxNo)) {
                            maxNo = lineNo
                        }
                    }

                    for (let i = 0; i < lineNoArr.length; i++) {
                        if (lineNoArr[i] == '') {
                            curRec.setSublistValue({sublistId:'item',fieldId:'custcol_emc_line_no',line:i,value:maxNo + 1});
                            maxNo = maxNo + 1;
                        }
                    }
                }
            } else {
                for(let index = 0; index < length; index++) {
                    curRec.setSublistValue({sublistId:'item',fieldId:'custcol_emc_line_no',line:index,value:index + 1});
                }
            }
            for(let index = 0; index < length; index++) {
                let uniqueKey = curRec.getSublistValue({sublistId:'item',fieldId:'custcol_ecm_uniquekey',line:index});
                if (uniqueKey == '') {
                    let lineUnKty = curRec.getSublistValue({sublistId:'item',fieldId:'lineuniquekey',line:index});
                    curRec.setSublistValue({sublistId:'item',fieldId:'custcol_ecm_uniquekey',line:index,value:lineUnKty});
                }
            }
        }

        /**
         * 设置汇总数量
         * @param curRec
         * @param length
         */
        function setSumQty(curRec,length) {
            let sumCreatedQty = 0;
            let sumQty = 0;
            for (let i = 0; i < length; i++) {
                let createdQty = curRec.getSublistValue({sublistId: 'item', fieldId: 'custcol_ecm_shipings_qty_created', line: i});
                let quantity = curRec.getSublistValue({sublistId: 'item', fieldId: 'quantity', line: i});
                sumQty = Number(sumQty) + Number(quantity);
                sumCreatedQty = Number(sumCreatedQty) + Number(createdQty);
            }
            curRec.setValue({fieldId:'custbody_ecm_sumqtyof_sscreated', value:sumCreatedQty});
            curRec.setValue({fieldId:'custbody_ecm_sumqty', value:sumQty});
        }

        /**
         * 明细行报关信息匹配
         * @param curRec
         * @param length
         */
        function setLineDeclaration(curRec,length) {
            let originCountry = curRec.getValue('custbody_ecm_countryof_departure');
            let itemIdArr = [];
            for (let i = 0; i < length; i++) {
                let itemId = curRec.getSublistValue({sublistId: 'item', fieldId: 'item', line: i});
                itemIdArr.push(itemId);
            }
            // log.debug('itemIdArr',itemIdArr);
            let declarationInfoIdArr = [];
            if (itemIdArr && itemIdArr.length > 0 && originCountry) {
                let filters = [];
                let columns = [];
                filters.push(["custrecord_ecm_ecd_parent_cust_decl","anyof",itemIdArr]);
                filters.push('AND');
                filters.push(["custrecord_ecm_ecd_area","anyof",originCountry]);
                filters.push('AND');
                filters.push(['isinactive', 'is', 'false']);
                columns.push(search.createColumn({name: "internalid", label: "内部 ID"}));
                columns.push(search.createColumn({name: "custrecord_ecm_ecd_parent_cust_decl", label: "SKU ID"}));
                let declarationInfoSearchObj = search.create({type: 'customrecord_ecm_customs_declarationinfo', filters: filters, columns: columns});
                let result = declarationInfoSearchObj.run().getRange({start: 0, end: 1000});
                // log.debug('result',result);
                if (result && result.length > 0) {
                    for (let i = 0; i < itemIdArr.length; i++) {
                        let json = {};
                        for (let j = 0; j < result.length; j++) {
                            let skuId = result[j].getValue(columns[1]);
                            if (itemIdArr[i] == skuId) {
                                json = {
                                    itemId : itemIdArr[i],
                                    declarationId : result[j].getValue(columns[0])
                                }
                                break;
                            } else {
                                json = {
                                    itemId : itemIdArr[i],
                                    declarationId : ''
                                }
                            }
                        }
                        declarationInfoIdArr.push(json)
                    }
                }
                // log.debug('declarationInfoIdArr',declarationInfoIdArr);
            }
            if (declarationInfoIdArr && declarationInfoIdArr.length > 0) {
                for (let i = 0; i < declarationInfoIdArr.length; i++) {
                    curRec.setSublistValue({sublistId:'item',fieldId:'custcol_ecm_item_customs_declaration',line:i,value:declarationInfoIdArr[i].declarationId});
                }
            }
        }

        return {beforeLoad, beforeSubmit, afterSubmit}

    });
