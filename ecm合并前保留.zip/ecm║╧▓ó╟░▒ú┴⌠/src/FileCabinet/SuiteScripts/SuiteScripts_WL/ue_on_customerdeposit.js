/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * Version        Date            Author          Memo
 *
 *
 */
define(['N/currentRecord', 'N/record', 'N/runtime', 'N/search', 'N/task', 'N/ui/serverWidget'],
    /**
     * @param{currentRecord} currentRecord
     * @param{record} record
     * @param{runtime} runtime
     * @param{search} search
     * @param{task} task
     * @param{serverWidget} serverWidget
     */
    (currentRecord, record, runtime, search, task, serverWidget) => {
        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed before record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const beforeSubmit = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {
            if (['delete', 'xedit'].includes(scriptContext.type)) return;
            let newRec = scriptContext.newRecord;
            let curRec = record.load({type: newRec.type, id: newRec.id});
            try {
                let data = formatData(curRec);
                for (let key in data) {
                    let dataArr = data[key];
                    let spRec = record.load({type: 'customrecord_ecm_sp', id: key});
                    let toPreAmount = 0;
                    let toPayAmount = 0;
                    for (let i = 0; i < dataArr.length; i++) {
                        if (dataArr[i].type == 1) {
                            toPreAmount = Number(toPreAmount) + Number(dataArr[i].amount)
                        } else if (dataArr[i].type == 2) {
                            toPayAmount = Number(toPayAmount) + Number(dataArr[i].amount)
                        }
                    }
                    toPreAmount = Number(spRec.getValue('custrecord_sp_topreamount')) + toPreAmount;
                    toPayAmount = Number(spRec.getValue('custrecord_sp_topayamount')) + toPayAmount;
                    log.debug('toPreAmount',toPreAmount);
                    log.debug('toPayAmount',toPayAmount);

                    spRec.setValue({fieldId: 'custrecord_sp_topreamount', value: toPreAmount});
                    spRec.setValue({fieldId: 'custrecord_sp_topayamount', value: toPayAmount});
                    let spId = spRec.save({ignoreMandatoryFields:true, enablesourcing:false});

                    if (spId) {
                        for (let i = 0; i < dataArr.length; i++) {
                            let id = dataArr[i].id;
                            let lineNumber = curRec.findSublistLineWithValue({sublistId: 'recmachcustrecord38', fieldId: 'id', value: id});
                            curRec.setSublistValue({sublistId: 'recmachcustrecord38', fieldId: 'custrecord_ecm_claim', line: lineNumber, value: true});
                        }
                    }
                }
                curRec.save({ignoreMandatoryFields:true, enablesourcing:false});
            } catch (e) {
                log.error('Error', e);
            }
        }

        function formatData(curRec) {
            let length = curRec.getLineCount('recmachcustrecord38');
            let info = [];
            for (let i = 0; i < length; i++) {
                let claim = curRec.getSublistValue({sublistId: 'recmachcustrecord38', fieldId: 'custrecord_ecm_claim', line: i});
                if (claim == false || claim == 'F') {
                    let id = curRec.getSublistValue({sublistId: 'recmachcustrecord38', fieldId: 'id', line: i});
                    let claim_amount = curRec.getSublistValue({sublistId: 'recmachcustrecord38', fieldId: 'custrecord_ecm_claim_amount', line: i});
                    let sp = curRec.getSublistValue({sublistId: 'recmachcustrecord38', fieldId: 'custrecord_ecm_claim_sp', line: i});
                    let type = curRec.getSublistValue({sublistId: 'recmachcustrecord38', fieldId: 'custrecord_ecm_claim_type', line: i});
                    let key = sp + '&' + type;
                    let json = {
                        id : id,
                        amount : claim_amount,
                        sp : sp,
                        type : type,
                        key : key
                    }
                    info.push(json);
                }
            }
            if (info && info.length > 0) {
                let data = {};
                for (let i = 0; i < info.length; i++) {
                    let sp = info[i].sp;
                    if (typeof data[sp] == 'undefined') {
                        data[sp] = [];
                        data[sp].push(info[i]);
                    } else {
                        data[sp].push(info[i]);
                    }
                }
                log.debug('data',data);
                return data;
            }
        }

        return {/*beforeLoad, beforeSubmit,*/ afterSubmit}

    });
