/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 * Version        Date            Author          Memo
 * 1.0            2023/03/07      Will            预收款的认领校验(1018615)
 * 2.0            2023/03/17      Will            添加校验条件(1018615)
 * 3.0            2023/03/20      Will            添加校验条件(1018615)
 */
define(['N/currentRecord', 'N/record', 'N/search'],
/**
 * @param{currentRecord} currentRecord
 * @param{record} record
 * @param{search} search
 */
function(currentRecord, record, search) {
    
    /**
     * Function to be executed after page is initialized.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.mode - The mode in which the record is being accessed (create, copy, or edit)
     *
     * @since 2015.2
     */
    function pageInit(scriptContext) {

    }

    /**
     * Function to be executed when field is changed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
     * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
     *
     * @since 2015.2
     */
    function fieldChanged(scriptContext) {
        var fieldId = scriptContext.fieldId;
        // console.log('fieldId',fieldId);
        var curRec = scriptContext.currentRecord;
        if (fieldId == 'custrecord_ecm_claim_sp') {
            var sp = curRec.getCurrentSublistValue({sublistId: 'recmachcustrecord38', fieldId: 'custrecord_ecm_claim_sp'});
            // console.log('sp',sp);
            var spSearch = search.lookupFields({
                type: 'customrecord_ecm_sp',
                id: sp,
                columns: ['custrecord_sp_deliverydate']
            });
            var deliveryDate = spSearch.custrecord_sp_deliverydate;
            // console.log('deliveryDate',deliveryDate);
            if (deliveryDate) {
                curRec.setCurrentSublistValue({sublistId: 'recmachcustrecord38', fieldId: 'custrecord_ecm_claim_type', value: 1, ignoreFieldChange: true});
            } else {
                curRec.setCurrentSublistValue({sublistId: 'recmachcustrecord38', fieldId: 'custrecord_ecm_claim_type', value: 2, ignoreFieldChange: true});
            }

        }
    }

    /**
     * Function to be executed when field is slaved.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     *
     * @since 2015.2
     */
    function postSourcing(scriptContext) {

    }

    /**
     * Function to be executed after sublist is inserted, removed, or edited.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @since 2015.2
     */
    function sublistChanged(scriptContext) {

    }

    /**
     * Function to be executed after line is selected.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @since 2015.2
     */
    function lineInit(scriptContext) {

    }

    /**
     * Validation function to be executed when field is changed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
     * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
     *
     * @returns {boolean} Return true if field is valid
     *
     * @since 2015.2
     */
    function validateField(scriptContext) {

    }

    /**
     * Validation function to be executed when sublist line is committed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateLine(scriptContext) {
        var curRec = scriptContext.currentRecord;
        var payment = curRec.getValue('payment');
        var customer = curRec.getValue('customer');
        var claim = curRec.getCurrentSublistValue({sublistId:'recmachcustrecord38', fieldId:'custrecord_ecm_claim'});
        var serviceCharge = curRec.getCurrentSublistValue({sublistId:'recmachcustrecord38', fieldId:'custrecord_ecm_servicecharge'});
        var amount = curRec.getCurrentSublistValue({sublistId:'recmachcustrecord38', fieldId:'custrecord_ecm_claim_amount'});
        var sp = curRec.getCurrentSublistValue({sublistId:'recmachcustrecord38', fieldId:'custrecord_ecm_claim_sp'});
        var type = curRec.getCurrentSublistValue({sublistId:'recmachcustrecord38', fieldId:'custrecord_ecm_claim_type'});
        // console.log('payment',payment);
        // console.log('amount',amount);
        // console.log('sp',sp);
        // console.log('customer',customer);

        var spSearch = search.lookupFields({
            type: 'customrecord_ecm_sp',
            id: sp,
            columns: ['custrecord_sp_customer']
        });
        var spCustomer = spSearch.custrecord_sp_customer[0].value;
        // console.log('spCustomer',spCustomer);

        if (claim == true || claim == 'T') {
            alert("已认领");
            return false;
        }

        if (Number(amount) < 0) {
            alert("金额不能为负数");
            return false;
        }

        if (!amount || !sp || !type || !serviceCharge) {
            alert("请填写完整信息");
            return false;
        }

        if (spCustomer != customer) {
            alert("客户不一致");
        }


        if (amount && sp && type && serviceCharge) {
            if (type == 1) { //TODO 环境校验 预付款
                var preAmountField = search.lookupFields({type: 'customrecord_ecm_sp', id: sp, columns: ['custrecord_sp_preamount']});
                var preAmount = preAmountField.custrecord_sp_preamount;
                // console.log('preAmount',preAmount);
                var toPreAmountField = search.lookupFields({type: 'customrecord_ecm_sp', id: sp, columns: ['custrecord_sp_topreamount']});
                var toPreAmount = toPreAmountField.custrecord_sp_topreamount;
                // console.log('toPreAmount',toPreAmount);

                if (Number(amount) + Number(serviceCharge) > Number(preAmount) - Number(toPreAmount)) {
                    alert("当前认领金额已超过Shipping Plan金额");
                    return false;
                }
            } else if (type == 2) { //TODO 环境校验 尾款
                var payAmountField = search.lookupFields({type: 'customrecord_ecm_sp', id: sp, columns: ['custrecord_sp_payamount']});
                var payAmount = payAmountField.custrecord_sp_payamount;
                // console.log('payAmount',payAmount);
                var toPayAmountField = search.lookupFields({type: 'customrecord_ecm_sp', id: sp, columns: ['custrecord_sp_topayamount']});
                var toPayAmount = toPayAmountField.custrecord_sp_topayamount;
                // console.log('toPayAmount',toPayAmount);

                if (Number(amount) + Number(serviceCharge) > Number(payAmount) - Number(toPayAmount)) {
                    alert("当前认领金额已超过Shipping Plan金额");
                    return false;
                }
            }
        }

        curRec.setCurrentSublistValue({sublistId: 'recmachcustrecord38', fieldId: 'custrecord_ecm_spcustomer', value: customer, ignoreFieldChange: true});




        return true;
    }

    /**
     * Validation function to be executed when sublist line is inserted.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateInsert(scriptContext) {

    }

    /**
     * Validation function to be executed when record is deleted.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateDelete(scriptContext) {

    }

    /**
     * Validation function to be executed when record is saved.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @returns {boolean} Return true if record is valid
     *
     * @since 2015.2
     */
    function saveRecord(scriptContext) {
        var curRec = scriptContext.currentRecord;
        var payment = curRec.getValue('payment');
        var length = curRec.getLineCount('recmachcustrecord38');
        var totalAmount = 0;
        for (var i = 0; i < length; i++) {
            var claim_amount = curRec.getSublistValue({sublistId:'recmachcustrecord38',fieldId:'custrecord_ecm_claim_amount',line: i});
            totalAmount = Number(totalAmount) + Number(claim_amount);
        }
        console.log('totalAmount',totalAmount);

        if (Number(totalAmount) > Number(payment)) {
            alert("当前认领金额已超出存款金额");
            return false;
        }
        return true;
    }

    return {
        // pageInit: pageInit,
        fieldChanged: fieldChanged,
        // postSourcing: postSourcing,
        // sublistChanged: sublistChanged,
        // lineInit: lineInit,
        // validateField: validateField,
        validateLine: validateLine,
        // validateInsert: validateInsert,
        // validateDelete: validateDelete,
        saveRecord: saveRecord
    };
    
});
