define(['N/runtime'], function(runtime) {
    function getSecret() {
        if (runtime.accountId == '7533841_SB1') {
            // 锐意国内生产环境沙盒的判断，推送的目标环境的Token请求信息（海外沙盒）
            return {
                consumer: {
                    public: '126b5b6866dd7217551a4d99f56154755318364bd849e2de94338bd2ef623a6f',
                    secret: 'cfc0129c99bb324841bf4824d6f4c6999cb6e968d31cec511cea65074906ff04'
                },
                token: {
                    public: '073a6240c0387627732ce50ed6b6852a4b2f2b6f7c5c9350437900960cd60e33',
                    secret: 'f3dc9d009321291c5f31092a04478eba4230cea9c7d2475387d27076ad356de5'
                },
                realm: '7533841_SB1'
            }
        } else if (runtime.accountId == '7533841') {
            // 锐意国内生产环境的判断，推送的目标环境的Token请求信息（海外生产）
            return {
                consumer: {
                    public: '',
                    secret: ''
                },
                token: {
                    public: '',
                    secret: ''
                },
                realm: '7533841'
            }
        }
    }
    
    return {
        getSecret: getSecret,
    }
    
});
