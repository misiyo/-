/**
 * @NModuleScope public
 */
//获取当前时间,调用：getNowDate(type)  type:date、dateTime
define(['N/runtime','./moment.js','N/format'],

    function(runtime,moment,format) {
        return {
            getNowDate:getCompanyDate,                  //获取当前时间
            dateFormat:dateFormat,                      //将日期格式化为当前NS的字符串
            getTimeStamp:getTimeStamp,                  //获取当前时间戳

            getMonthLastDay: getMonthLastDay, //获取当月最后一天
            getLastMonthFirstDay: getLastMonthFirstDay, //获取指定日期的下月第一天
            getCurrentMonthFirstDay: getCurrentMonthFirstDay, //获取指定日期的当月第一天
            formatDate2ISO: formatDate2ISO
        };

        /**
         * 根据公司配置获取当前时间
         * @returns {Date}
         */
        function getCompanyDate(type) {
            //时区映射
            var TIMEZONEMAPPING = {
                "Etc/GMT+12": "GMT-12:00",
                "Pacific/Samoa": "GMT-11:00",
                "Pacific/Honolulu": "GMT-10:00",
                "America/Anchorage": "GMT-09:00",
                "America/Los_Angeles": "GMT-08:00",
                "America/Tijuana": "GMT-08:00",
                "America/Denver": "GMT-07:00",
                "America/Phoenix": "GMT-07:00",
                "America/Chihuahua": "GMT-07:00",
                "America/Chicago": "GMT-06:00",
                "America/Regina": "GMT-06:00",
                "America/Guatemala": "GMT-06:00",
                "America/Mexico_City": "GMT-06:00",
                "America/New_York": "GMT-05:00",
                "US/East-Indiana": "GMT-05:00",
                "America/Bogota": "GMT-05:00",
                "America/Caracas": "GMT-04:30",
                "America/Halifax": "GMT-04:00",
                "America/La_Paz": "GMT-04:00",
                "America/Manaus": "GMT-04:00",
                "America/Santiago": "GMT-04:00",
                "America/St_Johns": "GMT-03:30",
                "America/Sao_Paulo": "GMT-03:00",
                "America/Buenos_Aires": "GMT-03:00",
                "Etc/GMT+3": "GMT-03:00",
                "America/Godthab": "GMT-03:00",
                "America/Montevideo": "GMT-03:00",
                "America/Noronha": "GMT-02:00",
                "Etc/GMT+1": "GMT-01:00",
                "Atlantic/Azores": "GMT-01:00",
                "Europe/London": "GMT",
                "GMT": "GMT",
                "Atlantic/Reykjavik": "GMT",
                "Europe/Warsaw": "GMT+01:00",
                "Europe/Paris": "GMT+01:00",
                "Etc/GMT-1": "GMT+01:00",
                "Europe/Amsterdam": "GMT+01:00",
                "Europe/Budapest": "GMT+01:00",
                "Africa/Cairo": "GMT+02:00",
                "Europe/Istanbul": "GMT+02:00",
                "Asia/Jerusalem": "GMT+02:00",
                "Asia/Amman": "GMT+02:00",
                "Asia/Beirut": "GMT+02:00",
                "Africa/Johannesburg": "GMT+02:00",
                "Europe/Kiev": "GMT+02:00",
                "Europe/Minsk": "GMT+02:00",
                "Africa/Windhoek": "GMT+02:00",
                "Asia/Riyadh": "GMT+03:00",
                "Europe/Moscow": "GMT+03:00",
                "Asia/Baghdad": "GMT+03:00",
                "Africa/Nairobi": "GMT+03:00",
                "Asia/Tehran": "GMT+03:30",
                "Asia/Muscat": "GMT+04:00",
                "Asia/Baku": "GMT+04:00",
                "Asia/Yerevan": "GMT+04:00",
                "Etc/GMT-3": "GMT+04:00",
                "Asia/Kabul": "GMT+04:30",
                "Asia/Karachi": "GMT+05:00",
                "Asia/Yekaterinburg": "GMT+05:00",
                "Asia/Tashkent": "GMT+05:00",
                "Asia/Calcutta": "GMT+05:30",
                "Asia/Katmandu": "GMT+05:45",
                "Asia/Almaty": "GMT+06:00",
                "Asia/Dhaka": "GMT+06:00",
                "Asia/Rangoon": "GMT+06:30",
                "Asia/Bangkok": "GMT+07:00",
                "Asia/Krasnoyarsk": "GMT+07:00",
                "Asia/Hong_Kong": "GMT+08:00",
                "Asia/Kuala_Lumpur": "GMT+08:00",
                "Asia/Taipei": "GMT+08:00",
                "Australia/Perth": "GMT+08:00",
                "Asia/Irkutsk": "GMT+08:00",
                "Asia/Manila": "GMT+08:00",
                "Asia/Seoul": "GMT+09:00",
                "Asia/Tokyo": "GMT+09:00",
                "Asia/Yakutsk": "GMT+09:00",
                "Australia/Darwin": "GMT+09:30",
                "Australia/Adelaide": "GMT+09:30",
                "Australia/Sydney": "GMT+10:00",
                "Australia/Brisbane": "GMT+10:00",
                "Australia/Hobart": "GMT+10:00",
                "Pacific/Guam": "GMT+10:00",
                "Asia/Vladivostok": "GMT+10:00",
                "Asia/Magadan": "GMT+11:00",
                "Pacific/Kwajalein": "GMT+12:00",
                "Pacific/Auckland": "GMT+12:00",
                "Pacific/Tongatapu": "GMT+13:00",
            }
            var currentUser = runtime.getCurrentUser();
            var timezone =  currentUser.getPreference('TIMEZONE');
            var currentDateTime = new Date();
            var companyTimeZone = TIMEZONEMAPPING[timezone];
            var timeZoneOffSet = (companyTimeZone == 'GMT') ? 0 : Number(companyTimeZone.substr(3, 6).replace(/\+|:00/gi, '').replace(/:30/gi, '.5').replace(/:45/gi, '.75'));

            if (type == 'datetime') {
                var UTC = currentDateTime.getTime() + 0;
                var companyDateTime = UTC;
                return dateFormat(new Date(companyDateTime),type);
            }else {
                var UTC = currentDateTime.getTime() + (currentDateTime.getTimezoneOffset() * 60000);
                var companyDateTime = UTC + (timeZoneOffSet * 60 * 60 * 1000);
                return dateFormat(new Date(companyDateTime),type);
            }
        }

        //获取当前时间戳，默认格式为：2022-01-14T16:20:30+08:00
        function getTimeStamp(type) {
            if (type == 'YYYY-MM-DD HH:mm:ss') {
                return moment(new Date()).utcOffset('+0800').format('YYYY-MM-DD HH:mm:ss');
            }
            return moment(new Date()).utcOffset('+0800').format();
            // return moment(new Date()).format();
        }

        function formatDate2ISO(str) {
            return moment(new Date(str)).utcOffset('+0800').format();
        }

        //将日期格式化为当前NS的字符串
        function dateFormat(dateObj,dateType) {
            var thisDate = '';
            var currentUser = runtime.getCurrentUser();

            if(dateType === 'datetime'){
                var timezone =  currentUser.getPreference('TIMEZONE');
                thisDate = format.format({value:dateObj,type:format.Type.DATETIME,timezone:timezone});
            }else {
                thisDate = format.format({value:dateObj,type:format.Type.DATE});
            }
            return thisDate;
        }


        //获取指定日期的当月最后一天
        function getMonthLastDay(current){
            var currentMonth = current.getMonth();
            var nextMonth = ++currentMonth;
            var nextMonthDayOne = new Date(current.getFullYear(),nextMonth,1);
            nextMonthDayOne.setDate(nextMonthDayOne.getDate() - 1);
            return dateFormat(nextMonthDayOne);
        }


        //获取指定日期的下月第一天
        function getLastMonthFirstDay(current){
            var currentMonth = current.getMonth();
            var nextMonth = ++currentMonth;
            var nextMonthDayOne = new Date(current.getFullYear(),nextMonth,1);
            return dateFormat(nextMonthDayOne);
        }

        //获取指定日期的本月第一天
        function getCurrentMonthFirstDay(current){
            var currentMonth = current.getMonth();
            var currentMonthDayOne = new Date(current.getFullYear(),currentMonth,1);
            return dateFormat(currentMonthDayOne);
        }

    });
