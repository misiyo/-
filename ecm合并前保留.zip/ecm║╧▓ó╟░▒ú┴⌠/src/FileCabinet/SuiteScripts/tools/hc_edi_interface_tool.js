/**
 * @NApiVersion 2.x
 * @NModuleScope SameAccount
 *
 * Version      Date            Author          Memo
 * 1.0          2023/02/09      John Wang       宜开美：中信保EDI接口通用API
 */
define(['N/https', 'N/record', 'N/runtime'],
/**
 * @param{https} https
 * @param{record} record
 * @param{runtime} runtime
 */
function(https, record, runtime) {
    const LOG_TYPE = 'customrecord_hc_edi_interface_log';//日志类型

    function interfaceParams() {
        var ediUrl = 'https://ediserver.echemi.co/ediserver/gateway.do';//请求地址
        var method = 'POST';
        //JW 生产环境待补充
        if('SANDBOX' != runtime.envType) {
            ediUrl = '';
            method = '';
        }
        return {
            url: ediUrl,
            method: method
        };
    }

    /**
     * 请求中信保EDI接口
     * @param body                  请求Body
     * @param itype                 接口类型
     * @return {{valid: boolean}}       {valid：是否请求成功true/false；data：接口返回数据（json）；logId：日志id，后续数据解析用}
     */
    function requestEdiServer(body, itype) {
        var infParams = interfaceParams();
        var headers = [];
        headers['Content-Type'] = 'application/json; charset=utf-8';
        var rtn = https.post({
            url: infParams.url,
            headers: headers,
            body: JSON.stringify(body)
        });
        log.debug('rtn===', rtn);
        var rtnData = {
            valid: false,
            logId: false
        };
        if(200 == rtn.code && rtn.body) {
            rtnData.valid = true;
            rtnData.data = JSON.parse(rtn.body);
        }
        rtnData.logId = createIntfaceLog(body, itype, rtn);
        return rtnData;
    }

    /**
     * 创建接口日志
     * @param reqData           请求报文
     * @param itype             接口类型id
     * @param rtn               返回数据
     * @return {number}
     */
    function createIntfaceLog(reqData, itype, rtn) {
        var obj = record.create({type: LOG_TYPE});
        obj.setValue({fieldId: 'custrecord_hc_inf_type', value: itype});
        obj.setValue({fieldId: 'custrecord_hc_inf_reqdata', value: JSON.stringify(reqData)});
        obj.setValue({fieldId: 'custrecord_hc_inf_rtndata', value: JSON.stringify(rtn)});
        var logId = obj.save({ignoreMandatoryFields: true});
        return logId;
    }

    
    return {
        requestEdiServer: requestEdiServer
    };
    
});
