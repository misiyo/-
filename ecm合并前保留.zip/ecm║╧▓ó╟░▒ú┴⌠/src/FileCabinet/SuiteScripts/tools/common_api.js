/**
 * @NApiVersion 2.x
 * @NModuleScope Public
 *
 * Version      Date            Author              Memo
 * 1.0          2021/6/21       Author              常用API:数据处理&校验
 * 2.0          2021/6/24       Author              新加：保留小数jw
 *                                                  新加：百分比转数字
 * 3.0          2021/6/26       Author              新加：获取币种方法
 * 4.0          2021/6/29       Author              命名方法变更
 */
define(['N/xml', 'N/runtime', 'N/search', 'N/file'],

    function(xml, runtime, search, file) {
        /**
         * 自定义加法运算
         * @param arg1
         * @param arg2
         * @return {number}
         */
        function accAdd(arg1, arg2) {
            var r1, r2, m, c;
            try {
                r1 = arg1.toString().split(".")[1].length;
            } catch (e) {
                r1 = 0;
            }
            try {
                r2 = arg2.toString().split(".")[1].length;
            } catch (e) {
                r2 = 0;
            }
            c = Math.abs(r1 - r2);
            m = Math.pow(10, Math.max(r1, r2));
            if (c > 0) {
                var cm = Math.pow(10, c);
                if (r1 > r2) {
                    arg1 = Number(arg1.toString().replace(".", ""));
                    arg2 = Number(arg2.toString().replace(".", "")) * cm;
                } else {
                    arg1 = Number(arg1.toString().replace(".", "")) * cm;
                    arg2 = Number(arg2.toString().replace(".", ""));
                }
            } else {
                arg1 = Number(arg1.toString().replace(".", ""));
                arg2 = Number(arg2.toString().replace(".", ""));
            }
            return (arg1 + arg2) / m;
        }
        Number.prototype.add = function (arg) {
            return accAdd(arg, this);
        }

        /**
         * 自定义减法运算
         * @param arg1
         * @param arg2
         * @return {string}
         * @constructor
         */
        function Subtr(arg1, arg2) {
            var r1, r2, m, n;
            try { r1 = arg1.toString().split(".")[1].length; } catch (e) { r1 = 0; }
            try { r2 = arg2.toString().split(".")[1].length; } catch (e) { r2 = 0; }
            m = Math.pow(10, Math.max(r1, r2));
            //动态控制精度长度
            n = (r1 >= r2) ? r1 : r2;
            return ((arg1 * m - arg2 * m) / m).toFixed(n);
        }
        Number.prototype.sub = function (arg) {
            return Subtr(this, arg);
        }

        /**
         * 自定义乘法运算
         * @param arg1
         * @param arg2
         * @return {number}
         */
        function accMul(arg1, arg2) {
            var m = 0, s1 = arg1.toString(), s2 = arg2.toString();
            try { m += s1.split(".")[1].length; } catch (e) { }
            try { m += s2.split(".")[1].length; } catch (e) { }
            return Number(s1.replace(".", "")) * Number(s2.replace(".", "")) / Math.pow(10, m)
        }
        Number.prototype.mul = function (arg) {
            return accMul(arg, this);
        }

        /**
         * 自定义除法运算
         * @param arg1
         * @param arg2
         * @return {number}
         */
        function accDiv(arg1, arg2) {
            var t1 = 0, t2 = 0, r1, r2;
            try { t1 = arg1.toString().split(".")[1].length; } catch (e) { }
            try { t2 = arg2.toString().split(".")[1].length; } catch (e) { }
            with (Math) {
                r1 = Number(arg1.toString().replace(".", ""))
                r2 = Number(arg2.toString().replace(".", ""))
                return (r1 / r2) * pow(10, t2 - t1);
            }
        }
        Number.prototype.div = function (arg) {
            return accDiv(this, arg);
        }

        /**
         * 保留指定小数
         * @param d             保留位数
         * @return {string}
         */
        Number.prototype.toFixedNew = function (d) {
            var s = this + "";
            if(!d) d = 0;
            if(s.indexOf(".") == -1) s += ".";
            s += new Array(d+1).join("0");
            if(new RegExp("^(-|\\+)?(\\d+(\\.\\d{0,"+(d+1)+"})?)\\d*$").test(s)){
                var s="0"+RegExp.$2,pm=RegExp.$1,a=RegExp.$3.length,b=true;
                if( a == d + 2) {
                    a = s.match(/\d/g);
                    if(parseInt(a[a.length-1]) > 4) {
                        for(var i = a.length-2 ; i >= 0; i--) {
                            a[i] = parseInt(a[i]) + 1;
                            if(a[i] == 10) {
                                a[i] = 0;
                                b = i!= 1;
                            } else {
                                break;
                            }
                        }
                    }
                    s = a.join("").replace(new RegExp("(\\d+)(\\d{"+d+"})\\d$"),"$1.$2");
                }
                if(b) s = s.substr(1);
                return (pm + s).replace(/\.$/,"");
            }
            return this + "";
        }

        /**
         * 数字格式化为大写汉字
         * @param num               数字
         * @return {string|{}}      转换后汉字
         */
        function convertNumberToChineseCharacter(num) {
            if (!/^(0|[1-9]\d*)(\.\d+)?$/.test(num)) {
                return "数据非法";
            }

            var unit = "仟佰拾亿仟佰拾万仟佰拾元角分", str = "";
            num += "00";
            var p = num.indexOf('.');
            if (p >= 0) {
                num = num.substring(0, p) + num.substr(p + 1, 2);
            }
            unit = unit.substr(unit.length - num.length);
            for(var i = 0; i < num.length; i++) {
                str += '零壹贰叁肆伍陆柒捌玖'.charAt(num.charAt(i)) + unit.charAt(i);
            }
            return str.replace(/零(仟|佰|拾|角)/g, "零").replace(/(零)+/g, "零").replace(/零(万|亿|元)/g, "$1").replace(/(亿)万|壹(拾)/g, "$1$2").replace(/^元零?|零分/g, "").replace(/元$/g, "元整");
        }

        /**
         * 数字格式转为英文
         * @param num
         * @return {string|*}
         */
        function convertNumberToEnglishCharacter(num) {
            var NumtoEnglish = {},
                n = "",
                xiao = "",
                zheng = "",
                regxinteger = /^([0-9]{1,}([.][0-9]*)?)$/;
            //数字英文写法
            NumtoEnglish.tally = {
                arr1: ["zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine"],
                arr2: ["ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen"],
                arr3: ["twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"],
                arr4: ["hundred", "thousand", "million", "billion", "trillion", "quadrillion"]
            }
            //转换整数部分
            NumtoEnglish.convertInteger = function (n) {
                try {
                    var fenge = NumtoEnglish.toThousands(n).split(',');
                    var result = '';
                    for (var i = 0; i < fenge.length; i++) {
                        if (fenge[i].length == 3) {
                            result += NumtoEnglish.tally.arr1[fenge[i].substring(0, 1)] + " "; //百位
                            result += NumtoEnglish.tally.arr4[0];
                            if (NumtoEnglish.doubledight(fenge[i].substring(1)) != "") {
                                result += " and " + NumtoEnglish.doubledight(fenge[i].substring(1));
                            }
                        } else if (fenge[i].length == 2) {
                            result += NumtoEnglish.doubledight(fenge[i]) //十位
                        } else if (fenge[i].length == 1) {
                            result += NumtoEnglish.tally.arr1[fenge[i]]; //个位
                        }
                        //添加千分位单位（数字超过1000，每三位数字分配一个单位）
                        if (i < fenge.length - 1) {
                            result += " " + NumtoEnglish.tally.arr4[fenge.length - 1 - i] + " ";
                        }
                    }
                    return result;
                } catch (ex) {
                    //console.error(ex);
                }
            }
            //转换小数部分
            NumtoEnglish.convertDecimal = function (n) {
                var d = n.split('');
                var result = '';
                if (d.length > 0) {
                    for(var i = 0; i < d.length; i++) {
                        result += NumtoEnglish.convertInteger(d[i]) + " ";
                    }
                }
                return result;
            }
            //组合两位数
            NumtoEnglish.doubledight = function (n) {
                var result = "";
                if(parseInt(n) != 0) {
                    var dd = n.split('');
                    if(dd[0] < 1) {
                        result = NumtoEnglish.tally.arr1[dd[1]];
                    } else if (dd[0] == 1) {
                        result = NumtoEnglish.tally.arr2[dd[1]];
                    } else {
                        result = NumtoEnglish.tally.arr3[dd[0] - 2] + "-" + NumtoEnglish.tally.arr1[dd[1]];
                    }
                }
                return result;
            }

            //转换千分位显示，例：1000000 = 1,000,000
            NumtoEnglish.toThousands = function (num) {
                var num = (num || 0).toString(),
                    result = '';
                while (num.length > 3) {
                    result = ',' + num.slice(-3) + result;
                    num = num.slice(0, num.length - 3);
                }
                if (num) {
                    result = num + result;
                }
                return result;
            }

            function toEnglish(nn) {
                n = nn;
                if (!regxinteger.test(parseInt(n))) {
                    return "Error：Must in digital format";
                }

                //分割整数和小数（如果有小数的话）
                var NumList = n.toString().split('.'),
                    zheng = NumtoEnglish.convertInteger(NumList[0]); //整数部分
                // xiao = '';
                //如果分割长度是2，说明是小数
                if (NumList.length == 2) {
                    if (NumList[1].length <= 2) {
                        xiao = NumtoEnglish.convertDecimal(NumList[1]);
                    } else {
                        //如果小数超过2位，不转换，返回原数据
                        return n;
                    }
                }
                //返回转换结果
                return zheng + (xiao == "" ? "" : " point " + xiao);
            }
            return toEnglish(num);
        }

        /**
         * 将数字转为千分位显示
         * @param number            数值
         * @param decimals          保留小数位
         * @param decPoint         小数点符号
         * @param thousandsSep     千分位符号
         * @return {string}
         */
        function formatNumberAsThousand(number, decimals, decPoint, thousandsSep) {
            number = (number + '').replace(/[^0-9+-Ee.]/g, '');
            var n = !isFinite(+number) ? 0 : +number,
                prec = !isFinite(+decimals) ? 0 : Math.abs(decimals),
                sep = (typeof thousandsSep === 'undefined') ? ',' : thousandsSep,
                dec = (typeof decPoint === 'undefined') ? '.' : decPoint,
                s = '',
                toFixedFix = function(n, prec) {
                    var k = Math.pow(10, prec);
                    return '' + Math.floor(n * k) / k;
                };
            s = (prec ? toFixedFix(n, prec) : '' + Math.floor(n)).split('.');
            var re = /(-?\d+)(\d{3})/;

            while(re.test(s[0])) {
                s[0] = s[0].replace(re, "$1" + sep + "$2");
            }
            if((s[1] || '').length < prec) {
                s[1] = s[1] || '';
                s[1] += new Array(prec - s[1].length + 1).join('0');
            }
            return s.join(dec);
        }

        /**
         * 获取全部数据
         * @param searchObj
         * @return {Result[]}
         */
        function getAllData(searchObj) {
            var searchRun = searchObj.run();
            var datas = searchRun.getRange({ start: 0, end: 1000 });
            var length = 1000;
            while (datas) {
                if (datas.length == length) {
                    var tResults = searchRun.getRange({ start: length, end: length + 1000 });
                    if (tResults.length > 0) {
                        datas = datas.concat(tResults);
                    }
                    length = length + 1000;
                }
                else {
                    break;
                }
            }
            return datas;
        }

        /**
         * 搜索全部数据
         * @param type              记录类型
         * @param filters           filters
         * @param columns           columns
         * @returns {Result[]}      结果
         */
        function searchAllData(type, filters, columns) {
            var searchObj = search.create({type: type, filters: filters, columns: columns});
            var searchRun = searchObj.run();
            var datas = searchRun.getRange({ start: 0, end: 1000 });
            var length = 1000;
            while (datas) {
                if (datas.length == length) {
                    var tResults = searchRun.getRange({ start: length, end: length + 1000 });
                    if (tResults.length > 0) {
                        datas = datas.concat(tResults);
                    }
                    length = length + 1000;
                }
                else {
                    break;
                }
            }
            return datas;
        }

        /**
         * 将xml解析为json
         * @param xmlStr            待格式化xml文本
         * @param lineNames         重复节点名称
         * @return {string|null}
         */
        function parseXmlToJSON (xmlStr, lineNames) {
            xmlStr = xmlStr.replace(/>\s+</g,'><');
            var xmlObj = xml.Parser.fromString({
                text: xmlStr
            });
            var obj = Object.create(null);
            var xmlNode = xmlObj.documentElement;
            if (xmlNode.nodeType == xml.NodeType.ELEMENT_NODE) { // element
                //xml node不含@attributes不进此方法
                if (xmlNode.hasAttributes()) {
                    obj['@attributes'] = Object.create(null);
                    for (var j in xmlNode.attributes) {
                        if(xmlNode.hasAttribute({name : j})){
                            obj['@attributes'][j] = xmlNode.getAttribute({
                                name : j
                            });
                        }
                    }
                } else {
                }
            } else if (xmlNode.nodeType == xml.NodeType.TEXT_NODE) { // text
                obj = xmlNode.nodeValue;
            }
            if (xmlNode.hasChildNodes()) {
                if(1 == xmlNode.childNodes.length && '#text' == xmlNode.childNodes[0].nodeName) {
                    var childItem = xmlNode.childNodes[0];
                    if(xmlNode.nodeName == 'userDefined1') {
                    }
                    return xmlNode.childNodes[0].textContent;
                } else {
                    for (var i = 0, childLen = xmlNode.childNodes.length; i < childLen; i++) {
                        var childItem = xmlNode.childNodes[i];
                        var nodeName = childItem.nodeName;
                        if (nodeName in obj) {
                            if (!Array.isArray(obj[nodeName])) {
                                obj[nodeName] = [
                                    obj[nodeName]
                                ];
                            }
                            obj[nodeName].push(parseXmlToJSON(childItem, lineNames));
                        } else {
                            if(lineNames.indexOf(nodeName) > -1) {
                                if (!Array.isArray(obj[nodeName])) {
                                    if(obj[nodeName] == 'undefined') {
                                        obj[nodeName] = [
                                            obj[nodeName]
                                        ];
                                    } else {
                                        obj[nodeName] = [];
                                    }
                                }
                                obj[nodeName].push(parseXmlToJSON(childItem, lineNames));
                            } else {
                                obj[nodeName] = parseXmlToJSON(childItem, lineNames);
                            }
                        }
                    }
                }
            } else {
                return '';
            }
            return obj;
        }

        /**
         * 校验参数是否为空
         * @param value
         * @return {boolean}
         */
        function isNull(value) {
            if('object' == typeof value) {
                var arr = Object.keys(value);
                if (arr.length == 0) {
                    return true;
                }
            } else {
                if (value == null || value == '' || value == 'undefined' || value == 0 || 'undefined' == typeof value) {
                    return true;
                }
            }
            return false;
        }

        /**
         * 获取当前日期时间（默认yyyy/mm/dd hh:mm:ss）          Client脚本调用返回本机时间，Server端脚本调用返回服务器时间
         * @param onlyDate          仅日期
         * @return {string}
         */
        function getNowDateTime (onlyDate) {
            var now = new Date();
            var moffset = now.getTimezoneOffset();
            now = new Date(now.getTime() + ((8 * 60 + moffset) * 60 * 1000));
            var t = new Date(now.getTime() + (0 * 60 * 60 * 1000));
            var year = t.getFullYear();
            var month = t.getMonth() + 1;
            var day = t.getDate();
            var hour = t.getHours();
            var minute = t.getMinutes();
            var second = t.getSeconds();
            month = month < 10 ? '0' + month : month;
            day = day < 10 ? '0' + day : day;
            hour = hour < 10 ? '0' + hour : hour;
            minute = minute < 10 ? '0' + minute : minute;
            second = second < 10 ? '0' + second : second;
            var date = year + '/' + month + '/' + day + (false == onlyDate ?  ' ' + hour + ':' + minute + ':' + second : '');
            return date;
        }

        /**
         * 百分比转为小数
         * @param percent   百分比
         * @return {nlobjCredentialBuilder|void|string|*}
         */
        function percentToNumber(percent) {
            var strVal = percent.replace("%", "");
            var numberVal = Number(strVal).div(Number(100)).toFixedNew(2);
            return numberVal;
        }

        /**
         * 数字转为百分数
         * @param val           数值
         * @return {string}
         */
        function numberToPercent(val) {
            if('' == val || !val || 'undefined' == typeof val) {
                return '0.0000%';
            }
            var percent = Number(val).mul(Number(100)).toFixedNew(4);
            percent += '%';
            return percent;
        }

        /**
         * 获取全部币种信息
         * @return {{}}
         */
        function getAllCurrencies() {
            var newfilexp = [];
            var newcolumns= [];
            newcolumns.push(search.createColumn({ name: 'name' }));
            var asearch = search.create({ type: 'currency', columns: newcolumns, filters: newfilexp });
            var json = {};
            asearch.run().each(function (res) {
                json[res.getValue('name')] = res.id;
                return true;
            });
            return json;
        }

        /**
         * 日期增加天数
         * @param days          天数
         * @param date          日期
         * @param connector     连接符
         * @return {string}     返回日期（yyyy-mm-dd）
         */
        function dateAddDays(days, date, connector){
            if('' == connector || !connector || 'undefined' == connector) {
                connector = '-';
            }
            if('' == date || !date) {
                //没有传入值时,默认是当前日期
                var now = new Date();
                var moffset = now.getTimezoneOffset();
                var now = new Date(now.getTime() + ((8 * 60 + moffset) * 60 * 1000));
                date = new Date(now.getTime() + (0 * 60 * 60 * 1000));
                date = date.getFullYear() + '/' + (date.getMonth() + 1) + '/' + date.getDate();
            }
            if(!days) {
                days = 0;
            }
            date += " 00:00:00";//设置为当天凌晨12点
            date = Date.parse(new Date(date))/1000;//转换为时间戳
            date += (86400) * days;//修改后的时间戳
            var newDate = new Date(parseInt(date) * 1000);//转换为时间
            var month = newDate.getMonth() + 1;
            var day = newDate.getDate();
            month = month < 10 ? '0' + month : month;
            day = day < 10 ? '0' + day : day;
            return newDate.getFullYear() + connector + month + connector + day;
        }

        /**
         * 校验当前是否生产环境
         * @return {boolean}    true:生产环境；false:测试环境
         */
        function checkIsProduction() {
            var envType = runtime.envType;
            if('PRODUCTION' == envType) {
                return true;
            }
            return false;
        }

        /**
         * 以传入日期格式格式化日期
         * @param year              年
         * @param month             月
         * @param day               日
         * @param dateformat        日期格式
         * @return {string|boolean}
         */
        function formatDateWithDATEFORMAT(year,month,day,dateformat) {
            if('' == year || '' == month || '' == day || '' == dateformat) {
                return false;
            }
            if('YYYY年M月D日' == dateformat || 'YYYY年MM月DD日' == dateformat) {
                return year + '年' + month + '月' + day + '日';
            } else if('YYYY-M-D' == dateformat || 'YYYY-MM-DD' == dateformat) {
                return year + '-' + month + '-' + day;
            } else if('YYYY M D' == dateformat || 'YYYY MM DD' == dateformat) {
                return year + ' ' + month + ' ' + day;
            } else if('YYYY/M/D' == dateformat || 'YYYY/MM/DD' == dateformat) {
                return year + '/' + month + '/' + day;
            } else if('M/D/YYYY' == dateformat || 'MM/DD/YYYY' == dateformat) {
                return month + '/' + day + '/' + year;
            } else if('D/M/YYYY' == dateformat || 'DD/MM/YYYY' == dateformat) {
                return day + '/' + month + '/' + year;
            } else if('D-Mon-YYYY' == dateformat || 'DD-Mon-YYYY' == dateformat) {
                var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                var tempMonth = months[month-1];
                return day + '-' + month + '月-' + year;
            } else if('D.M.YYYY' == dateformat || 'DD.MM.YYYY' == dateformat) {
                return day + '.' + month + '.' + year;
            }
        }

        /**
         * 校验undefined
         * @param val
         * @return {boolean}
         */
        function checkUndefined(val) {
            if('' === val || undefined === val || 'undefined' == typeof val) {
                return true;
            }
            return false;
        }

        /**
         * CSV文件内容转换为数组
         * @param strData               源数据
         * @param strDelimiter          分隔符
         * @return {[[]]}
         * @constructor
         */
        function cSVToArray(strData, strDelimiter) {
            strDelimiter = (strDelimiter || ",");
            var objPattern = new RegExp(("(\\" + strDelimiter + "|\\r?\\n|\\r|^)" + "(?:\"([^\"]*(?:\"\"[^\"]*)*)\"|" + "([^\"\\" + strDelimiter + "\\r\\n]*))"), "gi");

            var arrData = [[]];
            var arrMatches = null;
            while (arrMatches = objPattern.exec(strData)) {
                var strMatchedDelimiter = arrMatches[1];
                if (strMatchedDelimiter.length && (strMatchedDelimiter != strDelimiter)) {
                    arrData.push([]);
                }
                if (arrMatches[2]) {
                    var strMatchedValue = arrMatches[2].replace(new RegExp("\"\"", "g"), "\"");
                } else {
                    var strMatchedValue = arrMatches[3];
                }
                arrData[arrData.length - 1].push(strMatchedValue);
            }
            return (arrData);
        }

        /**
         * 格式化日期
         * @param datestr               日期
         * @param dateConnector         日期连接符
         * @param withZero              日期是否为0X格式
         * @param onlyDate              仅返回日期
         * @return {string|*}
         */
        function formatDate2String(datestr, dateConnector, withZero, onlyDate) {
            if('' == datestr) {
                var dateOri = new Date();
            } else {
                var dateOri = new Date(datestr);
            }
            var oritime = dateOri.getTime();
            var newdate = new Date(oritime - (8 * 60 * 60 * 1000));
            var year = newdate.getFullYear(), month = newdate.getMonth() + 1, day = newdate.getUTCDate();
            var hour = newdate.getUTCHours(), minute = newdate.getMinutes(), second = newdate.getSeconds();
            var t_date = year + dateConnector + (withZero ? (month < 10 ? '0' + month : month) : month) + dateConnector + (withZero ? (day < 10 ? '0' + day : day) : day);
            var t_time = (withZero ? (hour < 10 ? '0' + hour : hour) : hour ) + ':' + (withZero ? (minute < 10 ? '0' + minute : minute) : minute) + ':' + (withZero ? (second < 10 ? '0' + second : second) : second);

            if(onlyDate) {
                return t_date;
            }
            return t_date + ' ' + t_time;
        }

        /**
         * 日期进行月份加减
         * @param date
         * @param months
         * @return {string}
         */
        function dateAddMonths(date, months) {
            var date = new Date(date);//比如sourceDate传参“2019-03-31”
            var oldDate = date.getDate();//获取原来的月有多少日
            date.setDate(1);//设置为1日（day）
            date.setMonth(date.getMonth() + months);//设置新的月份(从0开始) months 传参-1
            var newDay = new Date(date.getYear(), date.getMonth() + 1, 0).getDate();//获取新得到的月有多少日
            date.setDate(Math.min(oldDate, newDay));
            return date.toLocaleDateString().replace(/-/g, '/');
        }

        /**
         * 校验数字合法性（可含符号）
         * @param amt			数字
         * @return {boolean}
         */
        function judgeAmount(amt) {
            if ('' == amt || 'undefined' == typeof amt) {
                return false;
            }
            var regExp = new RegExp(/^[-]?(([0-9]+.?[0-9]*)|(([1-9][0-9]*)|(([0]\.\d{1,2}|[1-9][0-9]*\.\d{1,9}))))$/);

            return regExp.test(amt);
        }

        /**
         * 获取url全部参数key:value
         * @return {{}}
         */
        function formatHrefParamsAsJson() {
            var paramJson = {};

            var allParams = window.location.search.substring(1);
            var paramArr = allParams.split("&");
            paramArr.forEach(function (param) {
                paramJson[param.split('=')[0]] = param.split('=')[1];
            });
            return paramJson;
        }

        /**
         * 获取url指定参数值
         * @param key           参数key
         * @return {string}
         */
        function getUrlParamValue(key) {
            var href = window.location.href;
            var reg = new RegExp("(^|&)" + key + "=([^&]*)(&|$)", "i");
            var r = href.match(reg);
            if (r != null) return r[2];
            return '';
        }

        /**
         * 获取指定日期的时间戳
         * @param dateStr
         * @return {number}
         */
        function getDateStamp(dateStr) {
            var now = new Date(dateStr);
            var moffset = now.getTimezoneOffset();
            var now2 = new Date(now.getTime() + ((8 * 60 + moffset) * 60 * 1000));
            var t = new Date(now2.getTime() + (0 * 60 * 60 * 1000));

            return t.getTime();
        }

        /**
         * 以0填充流水号
         * @param length            流水号长度
         * @param val               当前编码
         * @return {string}         填充0后编码
         */
        function fillNoWithZero(length, curno) {
            var defZero = '000000000000000000000000000000';
            var newno = defZero + curno;

            return newno.slice(Number(-1).mul(Number(length)));
        }

        /**
         * 文件转换为base64输出
         * @param fileId    文件id
         * @return {string}
         */
        /*function convertFileToBase64(fileId) {
            var fileObj = file.load({id: fileId});
            var contents = fileObj.getContents();
            if(encode.Encoding.BASE_64 == fileObj.encoding) {
                return contents;
            }
            var rstr = encode.convert({
                string: contents,
                inputEncoding: encode.Encoding.UTF_8,
                outputEncoding: encode.Encoding.BASE_64
            });
            return rstr;
        }*/

        /**
         * 替换url中特殊字符
         * @param urlStr            url链接
         * @return {string}
         */
        function replaceUrlCharacter(urlStr) {
            return urlStr.replace(/\%/g, '%25').replace(/\:/g, '%3A').replace(/\//g, '%2F').replace(/\?/g, '%3F').replace(/\=/g, '%3D').replace(/\&/g, '%26').replace(/\#/g, '%23');
        }

        /**
         * 去除字符串首尾空格
         * @param val
         * @return {string|nlobjCredentialBuilder|void|*}
         */
        function removeLeftAngRightEmptyspace(val) {
            if(!val || 'undefined' == typeof val) {
                return '';
            }
            return val.replace(/(^\s*)|(\s*$)/g, "");
        }

        /**
         * 创建推送so日志
         * @param region        站点，hk等
         * @param ids           推送ids
         * @param status        推送状态：1（成功）,2（失败）
         * @param maxId         本次推送最大id
         * @param rtn           请求返回报文
         */
        function createSyncSoLog(region, ids, status, maxId, rtn) {
            var obj = record.create({type: 'customrecord_ant_sync_so_log'});
            obj.setValue('custrecord_ant_sync_so_region', region);
            obj.setValue('custrecord_ant_sync_so_ids', ids);
            obj.setValue('custrecord_ant_sync_so_status', status);
            obj.setValue('custrecord_ant_sync_so_maxid', maxId);
            obj.setValue('custrecord_ant_sync_so_rtnmsg', JSON.stringify(rtn));
            obj.save({ignoreMandatoryFields: true});
        }

        /**
         * 获取so同步上次最末id
         * @param region
         * @returns {number|Date|string|Array|boolean|string[]}
         */
        function getSyncSoLastId(region) {
            var filters = [], columns = [];
            filters.push(['custrecord_ant_sync_so_region', 'is', region]);
            columns.push(search.createColumn({
                name: 'internalid',
                sort: 'DESC'
            }));
            columns.push('custrecord_ant_sync_so_maxid');
            var result = search.create({type: 'customrecord_ant_sync_so_log', columns: columns, filters: filters}).run().getRange({start: 0, end: 10})
            if(result && result.length > 0) {
                return result[0].getValue(columns[1]);
            }
            return 0;
        }

        /**
         * 数字保留指定位数，整数不保留
         * @param val
         * @param fixedLength
         * @returns {string|*}
         */
        function fixedNumber(val, fixedLength) {
            if(String(val).indexOf('.') > -1) {
                var floatLen = String(val).split('.')[1].length;
                return Number(val).toFixedNew(Math.min(floatLen, fixedLength));
            }
            return val;
        }

        return {
            convertNumberToChineseCharacter: convertNumberToChineseCharacter,
            convertNumberToEnglishCharacter: convertNumberToEnglishCharacter,
            formatNumberAsThousand: formatNumberAsThousand,
            getAllData: getAllData,
            searchAllData: searchAllData,
            parseXmlToJSON: parseXmlToJSON,
            isNull: isNull,
            getNowDateTime: getNowDateTime,
            percentToNumber: percentToNumber,
            numberToPercent: numberToPercent,
            getAllCurrencies: getAllCurrencies,
            dateAddDays: dateAddDays,
            checkIsProduction: checkIsProduction,
            formatDateWithDATEFORMAT: formatDateWithDATEFORMAT,
            checkUndefined: checkUndefined,
            cSVToArray: cSVToArray,
            formatDate2String: formatDate2String,
            dateAddMonths: dateAddMonths,
            judgeAmount: judgeAmount,
            formatHrefParamsAsJson: formatHrefParamsAsJson,
            getUrlParamValue: getUrlParamValue,
            getDateStamp: getDateStamp,
            fillNoWithZero: fillNoWithZero,
            replaceUrlCharacter: replaceUrlCharacter,
            removeLeftAngRightEmptyspace: removeLeftAngRightEmptyspace,
            createSyncSoLog: createSyncSoLog,
            getSyncSoLastId: getSyncSoLastId,
            fixedNumber: fixedNumber
        };

    });
