/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 *
 * Version      Date             Author          Memo
 *  1.0         2023.03.01       Neil Tang      【ID1018895】外贸通用PI模板-添加按钮
 *  2.0         2023.03.02       Neil Tang      【ID1018895】外贸通用PI模板-新增字段计算取值
 *  3.0         2023.03.07       Neil Tang      【ID1018895】外贸通用PI模板-新增字段计算取值
 *  4.0         2023.03.09       Neil Tang      【ID1018895】外贸通用PI模板-新增子公司URL取值
 *  5.0         2023.03.29       John Wang      销售合同状态显示自动（1019457）
 *  6.0         2023.04.20       Neil Tang      【ID1018895】外贸通用PI模板-取值变更 custitem_ecm_package_remk_en替换成	custcol_ecm_product_othermemo
 */
define(['N/search','N/xml','N/record','N/file', 'N/ui/serverWidget','N/runtime'],

    (search,xml,record ,file, serverWidget ,runtime ) => {
        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {
            if ('view' == scriptContext.type) {
                const btnId = `custpage_btn_sc_pdf`;
                const {form} = scriptContext;
                const formCSPath = './cs_sc_pdf_print.js';
                form.clientScriptModulePath = formCSPath;
                form.addButton({id: btnId, label: `Print SC`, functionName: `printPdf()`});
            }
            setScStatusText(scriptContext);
        }

        /**
         * 处理销售合同状态显示
         * @param scriptContext
         */
        const setScStatusText = scriptContext => {
            let obj = scriptContext.newRecord;
            try {
                let otype = obj.getValue({fieldId: 'custbody_ecm_ordertype'}),//OrderType:Contract(1)
                    ordsts = obj.getValue({fieldId: 'orderstatus'});//Close(H)
                let contsts = obj.getValue({fieldId: 'custbody_ecm_document_status'});//未生效（4）、生效（2）
                if(1 == otype && 'salesorder' == obj.type && 'H' == ordsts && (2 == contsts || 4 == contsts)) {
                    let form = scriptContext.form;
                    let htmlField = form.addField({id: 'custpage_name_upd', type: serverWidget.FieldType.INLINEHTML, label: '&nbsp;'});
                    htmlField.defaultValue = `<script>jQuery('.uir-record-status').html('${2 == contsts ? 'Valid' : 'Invalid'}');</script>`;
                }
            } catch (e) {
                log.error('updStsError===>' + obj.id, e);
            }
        }

        /**
         * Defines the function definition that is executed before record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const beforeSubmit = (scriptContext) => {
        }


        /**
         * 获取货品的信息
         * @param itemId
         * @returns {{}}
         */
        const getItemUnitTypeInfo = (itemId) => {
            const itemUnitTypeInfo = {};
            let itemSearchObj = search.create({
                type: "item",
                filters:
                    [
                        ['internalid', 'anyof', itemId]
                    ],
                columns:
                    ['internalid','unitstype','custitem_ecm_spec_combine_en','custitem_ecm_brand','custitem_ecm_origincountry','custitem_ecm_package_remk_en','custitem_ecm_case_package_kg','custitem_ecm_wgt_unit']
            });

            let myResult = itemSearchObj.run().getRange({start: 0, end: 1000});

            if (myResult && myResult.length > 0) {
                myResult.forEach(function (result) {
                    let itemId = result.getValue('internalid') || '';
                    itemUnitTypeInfo[itemId] = {
                        unitstype : result.getText('unitstype') || '',
                        custitem_ecm_spec_combine_en : result.getValue('custitem_ecm_spec_combine_en') || '',
                        custitem_ecm_origincountry : result.getText('custitem_ecm_origincountry') || '',
                        custitem_ecm_package_remk_en : result.getText('custitem_ecm_package_remk_en') || '',
                        custitem_ecm_brand : result.getValue('custitem_ecm_brand') || '',
                        custitem_ecm_case_package_kg : result.getValue('custitem_ecm_case_package_kg') || '',
                        custitem_ecm_wgt_unit : result.getText('custitem_ecm_wgt_unit') || '',
                    };
                })

            }
            return itemUnitTypeInfo;
        }
        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {
            if(['delete','xedit'].includes(scriptContext.type))return;
            log.debug('scriptContext.type',scriptContext.type);
            log.debug('script.type',runtime.executionContext);


            try{
                const {type,id} = scriptContext.newRecord;
                const newRecord = record.load({type:type, id:id})
                //Body字段处理
                const total = newRecord.getValue('total');
                const currency = newRecord.getText('currency') || '';
                let totalUpper = '';
                if(total) totalUpper = `${currency} ${convertNumberToEnglishCharacter(total).toUpperCase()} ONLY`;
                newRecord.setValue({fieldId: 'custbody_ecm_totalamt_en', value: totalUpper});

                const itemSublist = 'item';
                const lines = newRecord.getLineCount({sublistId: itemSublist});

                //获取货品信息
                const itemId = [];
                for (let i = 0; i < lines; i++) {
                    itemId.push(newRecord.getSublistValue({sublistId: itemSublist, fieldId: 'item', line: i}));
                }
                const itemUnitTypeInfo = getItemUnitTypeInfo(itemId);

                const subsidiaryId = newRecord.getValue('subsidiary');
                const handseal = newRecord.getValue('custbody_ecm_generate_handseal');
                if(subsidiaryId){
                    const subsidiaryRec = record.load({type: 'subsidiary', id: subsidiaryId});
                    let fileId = '';
                    if(handseal){
                        fileId = subsidiaryRec.getValue('custrecord_ecm_trade_electricseal_sign');
                    }else{
                        fileId = subsidiaryRec.getValue('custrecord_ecm_trade_electricseal');
                    }
                    if(fileId){
                        const fileObj = file.load({id: fileId});
                        newRecord.setValue('custbody_ecm_trade_electricseal_url',fileObj.url)
                    }

                }


                const custbody_ecm_skuspec_isdisplay = newRecord.getValue({fieldId: 'custbody_ecm_skuspec_isdisplay'});//SKU规格信息EN
                const custbody_ecm_skubrand_isdisplay = newRecord.getValue({fieldId: 'custbody_ecm_skubrand_isdisplay'});//品牌
                const custbody_ecm_skuhscode_isdisplay = newRecord.getValue({fieldId: 'custbody_ecm_skuhscode_isdisplay'});//海关编码
                const custbody_isdisplay_origincountry = newRecord.getValue({fieldId: 'custbody_isdisplay_origincountry'});//原产国


                // 3.1 Trade Terms	custbody_ecm_treadeterms_js	text area
                //贸易方式{Sales Contract.custbody_ecm_incoterm}拼接起运港or 目的港or发货地址or收货地址，对应关系见本文件贸易方式sheet页
                const custbody_ecm_incoterm = newRecord.getText('custbody_ecm_incoterm');//贸易方式
                const custbody_ecm_delivery_address = newRecord.getValue('custbody_ecm_delivery_address') || '';//发货地址
                const custbody_ecm_loadingport = newRecord.getValue('custbody_ecm_loadingport') || '';//起运港
                let custbody_ecm_loadingport_text = newRecord.getText('custbody_ecm_loadingport') || '';//起运港
                if(custbody_ecm_loadingport){
                    const startPort = record.load({type:'customrecord_ecm_loaddest_ports',id:custbody_ecm_loadingport});
                    custbody_ecm_loadingport_text = startPort.getValue('custrecord_el_name_en');
                }
                const custbody_ecm_countryof_departure_text = newRecord.getText('custbody_ecm_countryof_departure') || '';//起运国
                const custbody_ecm_countryof_destination_text = newRecord.getText('custbody_ecm_countryof_destination') || '';//目的国
                const custbody_ecm_destination_port = newRecord.getValue('custbody_ecm_destination_port') || '';//目的港
                let custbody_ecm_destination_port_text = newRecord.getText('custbody_ecm_destination_port') || '';//目的港
                if(custbody_ecm_destination_port){
                    const startPort = record.load({type:'customrecord_ecm_loaddest_ports',id:custbody_ecm_destination_port});
                    custbody_ecm_destination_port_text = startPort.getValue('custrecord_el_name_en');
                }
                const shipaddress = newRecord.getValue('shipaddress') || '';//收货地址
                let address3_10 = '';

                //1、EXW+空格+发货地址
                if(['EXW','FCA'].includes(custbody_ecm_incoterm)) address3_10 = custbody_ecm_delivery_address;

                //2、FAS+空格+起运港
                if(['FAS','FOB'].includes(custbody_ecm_incoterm)) address3_10 = custbody_ecm_loadingport_text;

                //3、CFR+空格+目的港
                if(['CFR','CIF','DES','DEQ'].includes(custbody_ecm_incoterm)) address3_10 = custbody_ecm_destination_port_text;

                //4、DDU+空格+收货地址
                if(['DDU','DDP','DAF','DAT','DAP','DPU','CPT','CIP'].includes(custbody_ecm_incoterm)) address3_10 = shipaddress;


                if (address3_10) newRecord.setValue('custbody_ecm_treadeterms_js',`${custbody_ecm_incoterm} ${address3_10}`);
                // if (address3_10) newRecord.setValue('custbody_ecm_treadeterms_js',`${custbody_ecm_incoterm} ${xml.escape(address3_10).replace(/\\n/g, '<br/>')}`);



                // 3.11 Loading Port/Place	custbody_ecm_loadingportplace_js	text area
                //贸易方式EXW/FCA时取{发货地址}
                let address3_11 = '';
                if(['EXW','FCA'].includes(custbody_ecm_incoterm)) {

                    address3_11 =  `${custbody_ecm_delivery_address}`;
                }
                // 其他贸易方式时判断起运港，起运港为空或起运港是Any Port时显示Any Port in {起运国}，起运港不为空且不是Any Port显示{起运港}
                else{
                    if(!custbody_ecm_loadingport || 'Any Port' == custbody_ecm_loadingport_text){
                        address3_11 = `Any Port in ${custbody_ecm_countryof_departure_text}`;
                    }else{
                        address3_11 = `${custbody_ecm_loadingport_text}`;
                    }
                }
                if (address3_11) newRecord.setValue('custbody_ecm_loadingportplace_js',`${address3_11}`);
                // if (address3_11) newRecord.setValue('custbody_ecm_loadingportplace_js',`${xml.escape(address3_11).replace(/\\n/g, '<br/>')}`);


                // 3.13 Discharging Port/Place	custbody_ecm_dischargingportplace_js	text area
                //贸易方式CPT/CIP/DDU/DDP/DAF/DAT/DAP/DPU时取{收货地址}，
                let address3_13 = '';
                if(['CPT','CIP','DDU','DDP','DAF','DAT','DAP','DPU'].includes(custbody_ecm_incoterm)) {

                    address3_13 =  `${shipaddress}`;
                }
                // 其他贸易方式时判断目的港，目的港为空或目的港是Any Port时显示Any Port in {目的国}，目的港不为空且目的港不是Any Port显示{目的港},{目的国}
                else{
                    if(!custbody_ecm_destination_port || 'Any Port' == custbody_ecm_destination_port_text){
                        address3_13 = `Any Port in ${custbody_ecm_countryof_destination_text}`;
                    }else{
                        address3_13 = `${custbody_ecm_destination_port_text},${custbody_ecm_countryof_destination_text}`;
                    }
                }
                if (address3_13) newRecord.setValue('custbody_ecm_dischargingportplace_js',`${address3_13}`);
                // if (address3_13) newRecord.setValue('custbody_ecm_dischargingportplace_js',`${xml.escape(address3_13).replace(/\\n/g, '<br/>')}`);



                //明细行赋值
                for (let i = 0; i < lines; i++) {

                    const item = newRecord.getSublistValue({sublistId: itemSublist, fieldId: 'item', line: i});
                    const custcol_ecm_packageremark = newRecord.getSublistValue({sublistId: itemSublist, fieldId: 'custcol_ecm_packageremark', line: i}) || '';
                    const custcol_ecm_product_othermemo = newRecord.getSublistValue({sublistId: itemSublist, fieldId: 'custcol_ecm_product_othermemo', line: i}) || '';

                    const {
                        unitstype,
                        custitem_ecm_spec_combine_en,
                        custitem_ecm_brand,
                        custitem_ecm_origincountry,
                        custitem_ecm_package_remk_en,
                        custitem_ecm_case_package_kg,
                        custitem_ecm_wgt_unit,

                    } = itemUnitTypeInfo[item];

                    let custcol_ecm_packing_js_info = '';
                    if(['Weight','Volume'].includes(unitstype)){
                        custcol_ecm_packing_js_info = 	custcol_ecm_packageremark;
                    }else if(['Package'].includes(unitstype)){
                        custcol_ecm_packing_js_info = 	`${custitem_ecm_case_package_kg} ${custitem_ecm_wgt_unit}/${custitem_ecm_package_remk_en}`;
                        if(custcol_ecm_packageremark) custcol_ecm_packing_js_info ? custcol_ecm_packing_js_info += `<br>${custcol_ecm_packageremark}` : custcol_ecm_packing_js_info = `${custcol_ecm_packageremark}`
                    }

                    const custcol_emc_hscode = newRecord.getSublistValue({sublistId: itemSublist, fieldId: 'custcol_emc_hscode', line: i}) || '';


                    newRecord.setSublistValue({sublistId: itemSublist, fieldId: 'custcol_ecm_packing_js', line: i, value: custcol_ecm_packing_js_info})

                    let custcol_ecm_spec_js_info = '';

                    //SKU规格信息EN
                    if (custbody_ecm_skuspec_isdisplay && custitem_ecm_spec_combine_en) {
                        custcol_ecm_spec_js_info += `${custcol_ecm_spec_js_info ? '<br>' : ''}${custitem_ecm_spec_combine_en}`;
                    }

                    //品牌
                    if (custbody_ecm_skubrand_isdisplay && custitem_ecm_brand) {
                        custcol_ecm_spec_js_info += `${custcol_ecm_spec_js_info ? '<br>' : ''}${custitem_ecm_brand}`;
                    }

                    //海关编码
                    if (custbody_ecm_skuhscode_isdisplay && custcol_emc_hscode) {
                        custcol_ecm_spec_js_info += `${custcol_ecm_spec_js_info ? '<br>' : ''}${custcol_emc_hscode}`;
                    }
                    //原产国
                    if (custbody_isdisplay_origincountry && custitem_ecm_origincountry) {
                        custcol_ecm_spec_js_info += `${custcol_ecm_spec_js_info ? '<br>' : ''}${custitem_ecm_origincountry}`;
                    }
                    // Package Remarks EN -> Other Requirements of Goods
                    if (custcol_ecm_product_othermemo) {
                        custcol_ecm_spec_js_info += `${custcol_ecm_spec_js_info ? '<br>' : ''}${custcol_ecm_product_othermemo}`;
                    }


                    // const custcol_ecm_product_othermemo = newRecord.getSublistValue({sublistId: itemSublist, fieldId: 'custcol_ecm_product_othermemo', line: i});
                    // if (custcol_ecm_product_othermemo) custcol_ecm_spec_js_info += `${custcol_ecm_spec_js_info ? '<br>' : ''}${custcol_ecm_product_othermemo}`;

                    newRecord.setSublistValue({sublistId: itemSublist, fieldId: 'custcol_ecm_spec_js', line: i, value: custcol_ecm_spec_js_info})

                }

                const mainEmail = setMainEmail(newRecord);
                if(mainEmail) newRecord.setValue('custbody_ecm_contract_email',mainEmail);
                newRecord.save({ignoreMandatoryFields:true,enableSourcing:true})
            }catch (e) {
                log.error('beforeSubmit error',e)
            }



        }


        /**
         * 数字格式转为英文
         * @param num
         * @return {string|*}
         */
        const convertNumberToEnglishCharacter = (num) => {
            var NumtoEnglish = {},
                n = "",
                xiao = "",
                zheng = "",
                regxinteger = /^([0-9]{1,}([.][0-9]*)?)$/;
            //数字英文写法
            NumtoEnglish.tally = {
                arr1: ["zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine"],
                arr2: ["ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen"],
                arr3: ["twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"],
                arr4: ["hundred", "thousand", "million", "billion", "trillion", "quadrillion"]
            }
            //转换整数部分
            NumtoEnglish.convertInteger = function (n) {
                try {
                    var fenge = NumtoEnglish.toThousands(n).split(',');
                    var result = '';
                    for (var i = 0; i < fenge.length; i++) {
                        if (fenge[i].length == 3) {
                            result += NumtoEnglish.tally.arr1[fenge[i].substring(0, 1)] + " "; //百位
                            result += NumtoEnglish.tally.arr4[0];
                            if (NumtoEnglish.doubledight(fenge[i].substring(1)) != "") {
                                result += " and " + NumtoEnglish.doubledight(fenge[i].substring(1));
                            }
                        } else if (fenge[i].length == 2) {
                            result += NumtoEnglish.doubledight(fenge[i]) //十位
                        } else if (fenge[i].length == 1) {
                            result += NumtoEnglish.tally.arr1[fenge[i]]; //个位
                        }
                        //添加千分位单位（数字超过1000，每三位数字分配一个单位）
                        if (i < fenge.length - 1) {
                            result += " " + NumtoEnglish.tally.arr4[fenge.length - 1 - i] + " ";
                        }
                    }
                    return result;
                } catch (ex) {
                    //console.error(ex);
                }
            }
            //转换小数部分
            NumtoEnglish.convertDecimal = function (n) {
                var d = n.split('');
                var result = '';
                if (d.length > 0) {
                    for(var i = 0; i < d.length; i++) {
                        result += NumtoEnglish.convertInteger(d[i]) + " ";
                    }
                }
                return result;
            }
            //组合两位数
            NumtoEnglish.doubledight = function (n) {
                var result = "";
                if(parseInt(n) != 0) {
                    var dd = n.split('');
                    if(dd[0] < 1) {
                        result = NumtoEnglish.tally.arr1[dd[1]];
                    } else if (dd[0] == 1) {
                        result = NumtoEnglish.tally.arr2[dd[1]];
                    } else {
                        result = NumtoEnglish.tally.arr3[dd[0] - 2] + "-" + NumtoEnglish.tally.arr1[dd[1]];
                    }
                }
                return result;
            }

            //转换千分位显示，例：1000000 = 1,000,000
            NumtoEnglish.toThousands = function (num) {
                var num = (num || 0).toString(),
                    result = '';
                while (num.length > 3) {
                    result = ',' + num.slice(-3) + result;
                    num = num.slice(0, num.length - 3);
                }
                if (num) {
                    result = num + result;
                }
                return result;
            }

            function toEnglish(nn) {
                n = nn;
                if (!regxinteger.test(parseInt(n))) {
                    return "Error：Must in digital format";
                }

                //分割整数和小数（如果有小数的话）
                var NumList = n.toString().split('.'),
                    zheng = NumtoEnglish.convertInteger(NumList[0]); //整数部分
                // xiao = '';
                //如果分割长度是2，说明是小数
                if (NumList.length == 2) {
                    if (NumList[1].length <= 2) {
                        xiao = NumtoEnglish.convertDecimal(NumList[1]);
                    } else {
                        //如果小数超过2位，不转换，返回原数据
                        return n;
                    }
                }
                //返回转换结果
                return zheng + (xiao == "" ? "" : " point " + xiao);
            }
            return toEnglish(num);
        }


        const setMainEmail = (newRecord) =>{
            let email = '';
            search.create({
                type: "salesorder",
                filters:
                    [
                        ["internalid","anyof",newRecord.id],
                        "AND",
                        ["mainline","is","F"],
                        "AND",
                        ["taxline","is","F"],
                    ],
                columns:
                    [
                        search.createColumn({
                            name: "email",
                            join: "contactPrimary",
                            label: "电子邮件"
                        })
                    ]
            }).run().getRange({start:0,end:1}).forEach(function (result) {
                email = result.getValue(search.createColumn({name: "email", join: "contactPrimary", label: "电子邮件"}));
            });

            return email;
        }
        return {beforeLoad, beforeSubmit, afterSubmit}

    });
