/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 *
 * Version      Date            Author          Memo
 * 1.0          2023/02/16      John Wang       SalesContract下推ShippingSchedule（1018529）
 * 2.0          2023/03/01      John Wang       新增明细行带值字段（1018529）
 * 3.0          2023/04/05      John Wang       变更：shipVia&loadingPort&destinationPort取值变更（1018529）
 */
define(['N/currentRecord', 'N/search', 'N/url', '/SuiteScripts/tools/common_api.js'],
/**
 * @param{currentRecord} currentRecord
 * @param{url} url
 */
function(currentRecord, search, url, commonApi) {
    const SUBLIST_ID = 'ecm_list';
    const ssBodyFieldsMapping = {
        tranid: 'custrecord_ssc_scnumber',
        port: 'custrecord_ssc_loadingport',
        shipvia: 'custrecord_ssc_shipping_method',
        destination: 'custrecord_ssc_destinationport',
        location: 'custrecord_ssc_location',
        sctype: 'custrecord_ssc_order_type'
    };
    const ssLineFieldsMapping = {
        lineno: 'custrecord_sscd_number',
        lineid: 'custrecord_sscd_sclineid',
        item: 'custrecord_sscd_scsku',
        qty: 'custrecord_sscd_scqty',
        thisqty: 'custrecord_sscd_ssqty',
        isfilm: 'custrecord_sscd_ispalletstretch',
        rate: 'custrecord_sscd_rate',
        taxcode: 'custrecord_sscd_taxcode',
        taxrate: 'custrecord_sscd_taxreate',
        othercost: 'custrecord_sscd_other_cost',
        termcost: 'custrecord_sscd_payment_term_cost',
        palletcost: 'custrecord_sscd_pallet_cost',
        profit: 'custrecord_sscd_profit',
        freight: 'custrecord_sscd_landfreight',
        tariff: 'custrecord_sscd_tariff',
        ofreight: 'custrecord_sscd_oceanfreight',
        insurancefee: 'custrecord_sscd_insurancefee',
        clearancefee: 'custrecord_sscd_customs_clearancefee',
        storagefee: 'custrecord_sscd_storagefee',
        certififee: 'custrecord_sscd_inspe_certifi_fee',
        netweight: 'custrecord_sscd_netwgt',
        grossweight: 'custrecord_sscd_grosswgt',
    };

    /**
     * Function to be executed after page is initialized.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.mode - The mode in which the record is being accessed (create, copy, or edit)
     *
     * @since 2015.2
     */
    function pageInit(scriptContext) {
        var obj = scriptContext.currentRecord;
        var sctype = obj.getValue({fieldId: 'custpage_sctype'});
        if(5 == sctype) {
            nlapiDisableField('custpage_location', false);
        } else {
            nlapiDisableField('custpage_location', true);
        }
    }

    /**
     * Function to be executed when field is changed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
     * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
     *
     * @since 2015.2
     */
    var subLocationData = {};//{subId:{locData}}
    function fieldChanged(scriptContext) {
        var obj = scriptContext.currentRecord,
            fieldId = scriptContext.fieldId;
        if('custpage_tranid' == fieldId) {
            var scid = obj.getValue({fieldId: fieldId});
            if('' != scid && -1 != scid) {
                var soFields = search.lookupFields({
                    type: 'salesorder',
                    id: scid,
                    columns: ['entity', 'subsidiary', 'custbody_ecm_contract_type', 'location',
                        'custbody_ecm_shipping_method', 'custbody_ecm_loadingport', 'custbody_ecm_destination_port']});
                console.log('sofields===>' + JSON.stringify(soFields));
                var subid = soFields.subsidiary[0].value,
                    sctype = soFields.custbody_ecm_contract_type[0].value,
                    location = soFields.location.length > 0 ? soFields.location[0].value : '';
                var locData = subLocationData[subid];
                if('undefined' == typeof locData) {
                    locData = formatLocationData(subid);
                    subLocationData[subid] = locData;
                }
                obj.setValue({fieldId: 'custpage_customer', value: soFields.entity[0].value, ignoreFieldChange: true});
                obj.setValue({fieldId: 'custpage_sctype', value: sctype, ignoreFieldChange: true});
                if(soFields.custbody_ecm_shipping_method && soFields.custbody_ecm_shipping_method.length > 0) {
                    obj.setValue({fieldId: 'custpage_shipvia', value: soFields.custbody_ecm_shipping_method[0].value, ignoreFieldChange: true});
                }
                if(soFields.custbody_ecm_loadingport && soFields.custbody_ecm_loadingport.length > 0) {
                    obj.setValue({fieldId: 'custpage_port', value: soFields.custbody_ecm_loadingport[0].value, ignoreFieldChange: true});
                }
                if(soFields.custbody_ecm_destination_port && soFields.custbody_ecm_destination_port.length > 0) {
                    obj.setValue({fieldId: 'custpage_destination', value: soFields.custbody_ecm_destination_port[0].value, ignoreFieldChange: true});
                }
                //修改sc no子公司一致，不对子公司&location修改
                var nowSubId = obj.getValue({fieldId: 'custpage_subsidiary'});
                if(nowSubId != subid) {
                    obj.setValue({fieldId: 'custpage_subsidiary', value: subid, ignoreFieldChange: true});
                    var locField = obj.getField({fieldId: 'custpage_location'});
                    locField.removeSelectOption({value: null});
                    locField.insertSelectOption({value: -1, text: ' '});
                    for(key in locData) {
                        locField.insertSelectOption({value: key, text: locData[key]});
                    }
                }
                if(5 == sctype) {
                    nlapiDisableField('custpage_location', false);
                    obj.setValue({fieldId: 'custpage_location', value: location, ignoreFieldChange: true});
                } else {
                    nlapiDisableField('custpage_location', true);
                    obj.setValue({fieldId: 'custpage_location', value: -1, ignoreFieldChange: true});
                }
            } else {
                obj.setValue({fieldId: 'custpage_customer', value: '', ignoreFieldChange: true});
                obj.setValue({fieldId: 'custpage_sctype', value: '', ignoreFieldChange: true});
                obj.setValue({fieldId: 'custpage_subsidiary', value: -1, ignoreFieldChange: true});
                obj.setValue({fieldId: 'custpage_location', value: '', ignoreFieldChange: true});
            }
        } else if ('custpage_thisqty' == fieldId) {
            var index = nlapiGetCurrentLineItemIndex(SUBLIST_ID);
            obj.selectLine({sublistId: SUBLIST_ID, line: index - 1});
            var capacity = obj.getCurrentSublistValue({sublistId: SUBLIST_ID, fieldId: 'custpage_capacity'}),
                thisqty = obj.getCurrentSublistValue({sublistId: SUBLIST_ID, fieldId: 'custpage_thisqty'}) || 0,
                lastqty = obj.getCurrentSublistValue({sublistId: SUBLIST_ID, fieldId: 'custpage_lastqty'});
            if(Number(thisqty) <= 0) {
                alert('QTY(This Turn) must be greater than 0!');
                obj.setCurrentSublistValue({sublistId: SUBLIST_ID, fieldId: 'custpage_selected', value: false, ignoreFieldChange: true});
                obj.setCurrentSublistValue({sublistId: SUBLIST_ID, fieldId: 'custpage_thisqty', value: '', ignoreFieldChange: true});
                return;
            } else if(Number(lastqty) < Number(thisqty)) {
                alert('QTY(This Turn) must be less than or equal to ' + lastqty + '!');
                obj.setCurrentSublistValue({sublistId: SUBLIST_ID, fieldId: 'custpage_selected', value: false, ignoreFieldChange: true});
                obj.setCurrentSublistValue({sublistId: SUBLIST_ID, fieldId: 'custpage_thisqty', value: '', ignoreFieldChange: true});
                return;
            } else {
                var pricingQty = Number(thisqty).mul(Number(capacity || 1));
                obj.setCurrentSublistValue({sublistId: SUBLIST_ID, fieldId: 'custpage_qty_pricing', value: pricingQty, ignoreFieldChange: true});
            }
        } else if('custpage_selected' == fieldId) {
            var index = nlapiGetCurrentLineItemIndex(SUBLIST_ID);
            obj.selectLine({sublistId: SUBLIST_ID, line: index - 1});
            var lastqty = obj.getCurrentSublistValue({sublistId: SUBLIST_ID, fieldId: 'custpage_lastqty'}),
                thisqty = obj.getCurrentSublistValue({sublistId: SUBLIST_ID, fieldId: 'custpage_thisqty'}) || 0;
            if(0 == Number(thisqty) || '' == Number(thisqty)) {
                alert('Invalid QTY(This Turn)!');
                obj.setCurrentSublistValue({sublistId: SUBLIST_ID, fieldId: 'custpage_selected', value: false, ignoreFieldChange: true});
                return;
            }
            if(Number(lastqty) < Number(thisqty)) {
                alert('QTY(This Turn) must be less than or equal to ' + lastqty + '!');
                obj.setCurrentSublistValue({sublistId: SUBLIST_ID, fieldId: 'custpage_selected', value: false, ignoreFieldChange: true});
                return;
            }

        }
    }

    /**
     * 根据子公司格式化子公司数据
     * @param subid
     * @return {{}}
     */
    function formatLocationData(subid) {
        var locData = {},
            filters = [], columns = [];
        if(!subid || '' == subid) {
            return locData;
        }
        filters.push(['subsidiary', 'anyof', subid]);
        filters.push('and');
        filters.push(['isinactive', 'is', false]);
        columns.push('name');
        var results = search.create({type: 'location', filters: filters, columns: columns}).run().getRange({start: 0, end: 1000});
        if(results && results.length > 0) {
            results.forEach(function (data) {
                locData[data.id] = data.getValue(columns[0]);
            });
        }
        console.log(subid + '=仓库数据=====>' + JSON.stringify(locData));
        return locData;
    }

    /**
     * Function to be executed when field is slaved.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     *
     * @since 2015.2
     */
    function postSourcing(scriptContext) {

    }

    /**
     * Function to be executed after sublist is inserted, removed, or edited.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @since 2015.2
     */
    function sublistChanged(scriptContext) {

    }

    /**
     * Function to be executed after line is selected.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @since 2015.2
     */
    function lineInit(scriptContext) {

    }

    /**
     * Validation function to be executed when field is changed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
     * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
     *
     * @returns {boolean} Return true if field is valid
     *
     * @since 2015.2
     */
    function validateField(scriptContext) {

    }

    /**
     * Validation function to be executed when sublist line is committed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateLine(scriptContext) {

    }

    /**
     * Validation function to be executed when sublist line is inserted.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateInsert(scriptContext) {

    }

    /**
     * Validation function to be executed when record is deleted.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateDelete(scriptContext) {

    }

    /**
     * Validation function to be executed when record is saved.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @returns {boolean} Return true if record is valid
     *
     * @since 2015.2
     */
    function saveRecord(scriptContext) {
        var obj = scriptContext.currentRecord;
        var length = obj.getLineCount({sublistId: SUBLIST_ID}),
            scid = obj.getValue({fieldId: 'custpage_tranid'}),
            scType = obj.getValue({fieldId: 'custpage_sctype'}),//id=5时location必填
            location = obj.getValue({fieldId: 'custpage_location'});
        if(!scid || '' == scid || -1 == scid) {
            alert('请选择SC NO.');
            return false;
        }
        if(5 == scType && ('' == location || -1 == location)) {
            alert('Please Enter Location.');
            return false;
        }
        var body = {};
        for(key in ssBodyFieldsMapping) {
            var val = obj.getValue({fieldId: 'custpage_' + key});
            body[ssBodyFieldsMapping[key]] = -1 == val ? '' : val;
        }
        body.custrecord_ssc_vessel_deadline = obj.getText({fieldId: 'custpage_shipdate'});
        var selectedData = [];
        for(var i = 0; i < length; i++) {
            var isSelected = obj.getSublistValue({sublistId: SUBLIST_ID, fieldId: 'custpage_selected', line: i});
            if(true == isSelected || 'T' == isSelected) {
                var line = {};
                line.custrecord_sscd_scno = body.custrecord_ssc_scnumber;

                for(key in ssLineFieldsMapping) {
                    line[ssLineFieldsMapping[key]] = obj.getSublistValue({sublistId: SUBLIST_ID, fieldId: 'custpage_' + key, line: i});
                }
                selectedData.push(line);
            }
        }
        if(0 == selectedData.length) {
            alert('Please select at least one line!');
            return false;
        }
        var allData = {body: body, lines: selectedData};
        obj.setValue({fieldId: 'custpage_alldata', value: JSON.stringify(allData), ignoreFieldChange: true});
        return true;
    }
    
    function doSearch() {
        var obj = currentRecord.get();
        var scid = obj.getValue({fieldId: 'custpage_tranid'});
        if(!scid || '' == scid || -1 == scid) {
            alert('请选择SC NO.');
            return;
        }
        var entity = obj.getValue({fieldId: 'custpage_customer'}),
            subsidiary = obj.getValue({fieldId: 'custpage_subsidiary'}),
            sctype = obj.getValue({fieldId: 'custpage_sctype'}),
            location = obj.getValue({fieldId: 'custpage_location'}),
            shipvia = obj.getValue({fieldId: 'custpage_shipvia'}),
            port = obj.getValue({fieldId: 'custpage_port'}),
            destination = obj.getValue({fieldId: 'custpage_destination'});
        var turl = url.resolveScript({scriptId: 'customscript_ecm_contract2schedule_sl', deploymentId: 'customdeploy_ecm_contract2schedule_sl'});
        setWindowChanged(window, false);
        window.location.href = turl + '&scid=' + encodeURIComponent(scid) + '&entity=' + encodeURIComponent(entity)
            + '&subid=' + encodeURIComponent(subsidiary) + '&sctype=' + encodeURIComponent(sctype) + '&location=' + encodeURIComponent(location)
            + '&shipvia=' + encodeURIComponent(shipvia) + '&port=' + encodeURIComponent(port) + '&destination=' + encodeURIComponent(destination);
    }

    function doRefresh() {
        var turl = url.resolveScript({scriptId: 'customscript_ecm_contract2schedule_sl', deploymentId: 'customdeploy_ecm_contract2schedule_sl'});
        setWindowChanged(window, false);

        window.location.href = turl;
    }

    return {
        pageInit: pageInit,
        fieldChanged: fieldChanged,
        /*postSourcing: postSourcing,
        sublistChanged: sublistChanged,
        lineInit: lineInit,
        validateField: validateField,
        validateLine: validateLine,
        validateInsert: validateInsert,
        validateDelete: validateDelete,*/
        saveRecord: saveRecord,
        doSearch: doSearch,
        doRefresh: doRefresh
    };
    
});
