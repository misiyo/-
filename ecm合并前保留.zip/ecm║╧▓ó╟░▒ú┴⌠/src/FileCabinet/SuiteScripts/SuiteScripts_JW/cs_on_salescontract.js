/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 *
 * Version      Date            Author          Memo
 * 1.0          2023/01/04      John Wang       报价单带值销售合同（1017890）
 * 2.0          2023/03/21      John Wang       custcol_ecm_freight_cost->custcol_ecm_oceanfreight（1017891）
 * 3.0          2023/04/03      John Wang       custcol_ecm_pallet_cost=>custcol_ecm_sinosurecost（1017891）
 */
define(['N/currentRecord', 'N/record', '/SuiteScripts/tools/common_api.js'],
/**
 * @param{currentRecord} currentRecord
 * @param{record} record
 */
function(currentRecord, record, commonApi) {
    const BODY_FIELDS = ['memo', 'leadsource', 'partner', 'salesrep', 'department', 'class', 'discountitem', 'discountrate', 'shipaddresslist', 'shipaddress', 'billaddresslist', 'billaddress', 'currency', 'exchangerate', 'vatregnum', 'custbody_ecm_incoterm'];
    const LINE_FIELDS = ['item', 'quantity', 'units', 'description', 'price', 'rate', 'custcol_ecm_price_list_display', 'custcol_ecm_reference_price', 'taxcode', 'location_display', 'custcol_ecm_oceanfreight', 'custcol_ecm_sinosurecost', 'custcol_ecm_other_cost', 'custcol_ecm_profit', 'custcol_ecm_payment_term_cost', 'custcol_ecm_containers_type', 'custcol_ecm_ispallet', 'custcol_ecm_loading_port', 'custcol_ecm_item_customs_declaration_display'];
    /**
     * Function to be executed after page is initialized.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.mode - The mode in which the record is being accessed (create, copy, or edit)
     *
     * @since 2015.2
     */
    function pageInit(scriptContext) {
        var estimateId = commonApi.getUrlParamValue('estimate');
        if(estimateId && 'undefined' != typeof estimateId) {
            initEstimateData(estimateId, scriptContext.currentRecord);
        }
    }

    function initEstimateData(estId, obj) {
        var estObj = record.load({type: 'estimate', id: estId});
        obj.setValue({fieldId: 'entity', value: estObj.getValue({fieldId: 'entity'})});
        obj.setValue({fieldId: 'subsidiary', value: estObj.getValue({fieldId: 'subsidiary'})});
        obj.setValue({fieldId: 'terms', value: estObj.getValue({fieldId: 'custbody_ecm_paymentterm'})});
        obj.setValue({fieldId: 'createdfrom', value: estId});

        ['trandate', 'startdate', 'enddate'].forEach(function (fid) {
            obj.setText({fieldId: fid, text: estObj.getText({fieldId: fid})});
        });
        BODY_FIELDS.forEach(function (fid) {
            var bval = estObj.getValue({fieldId: fid});
            if(bval && '' != bval && bval.length != 0) {
                console.log(fid + '=====>' + bval);
                obj.setValue({fieldId: fid, value: bval, ignoreFieldChange: true});
            }
        });
        var location = estObj.getValue({fieldId: 'location'});
        var itemLen = estObj.getLineCount('item');
        for(var i = 0; i < itemLen; i++) {
            obj.selectNewLine({sublistId: 'item'});
            LINE_FIELDS.forEach(function (fid) {
                var val = estObj.getSublistValue({sublistId: 'item', fieldId: fid, line: i});
                if(val && '' != val && val.length != 0) {
                    obj.setCurrentSublistValue({sublistId: 'item', fieldId: fid, value: val, forceSyncSourcing: true});
                }
                obj.setCurrentSublistValue({sublistId: 'item', fieldId: 'location', value: location, forceSyncSourcing: true});
            });
            obj.commitLine({sublistId: 'item'});
        }
        console.log(clear_splits('salesteam'));
        var teamLen = estObj.getLineCount('salesteam');
        for(var j = 0; j < teamLen; j++) {
            obj.selectNewLine({sublistId: 'salesteam'});
            ['employee', 'salesrole', 'isprimary'].forEach(function (fid) {
                var tval = estObj.getSublistValue({sublistId: 'salesteam', fieldId: fid, line: j});
                obj.setCurrentSublistValue({sublistId: 'salesteam', fieldId: fid, value: tval, forceSyncSourcing: true});
            });
            var percent = estObj.getSublistValue({sublistId: 'salesteam', fieldId: 'contribution', line: j});
            // console.log('percet====>' + percent);
            obj.setCurrentSublistText({sublistId: 'salesteam', fieldId: 'contribution', text: (percent + '').replace('%',''), forceSyncSourcing: true});
            obj.commitLine({sublistId: 'salesteam'});
        }
        setTimeout(function () {
            obj.setValue({fieldId: 'opportunity', value: estObj.getValue({fieldId: 'opportunity'})});
            obj.setValue({fieldId: 'location', value: location});
        }, 500);
    }

    /**
     * Function to be executed when field is changed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
     * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
     *
     * @since 2015.2
     */
    function fieldChanged(scriptContext) {
        /*if('opportunity' == scriptContext.fieldId || 'location' == scriptContext.fieldId && 'item' != scriptContext.sublistId) {
        }*/
        if('item' != scriptContext.sublistId) {
            //console.log(scriptContext.fieldId + '===fc===>' + scriptContext.currentRecord.getValue(scriptContext.fieldId))
        }
    }

    /**
     * Function to be executed when field is slaved.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     *
     * @since 2015.2
     */
    function postSourcing(scriptContext) {

    }

    /**
     * Function to be executed after sublist is inserted, removed, or edited.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @since 2015.2
     */
    function sublistChanged(scriptContext) {

    }

    /**
     * Function to be executed after line is selected.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @since 2015.2
     */
    function lineInit(scriptContext) {

    }

    /**
     * Validation function to be executed when field is changed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
     * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
     *
     * @returns {boolean} Return true if field is valid
     *
     * @since 2015.2
     */
    function validateField(scriptContext) {

    }

    /**
     * Validation function to be executed when sublist line is committed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateLine(scriptContext) {

    }

    /**
     * Validation function to be executed when sublist line is inserted.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateInsert(scriptContext) {

    }

    /**
     * Validation function to be executed when record is deleted.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateDelete(scriptContext) {

    }

    /**
     * Validation function to be executed when record is saved.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @returns {boolean} Return true if record is valid
     *
     * @since 2015.2
     */
    function saveRecord(scriptContext) {

    }

    return {
        pageInit: pageInit,
        fieldChanged: fieldChanged,
        /*postSourcing: postSourcing,
        sublistChanged: sublistChanged,
        lineInit: lineInit,
        validateField: validateField,
        validateLine: validateLine,
        validateInsert: validateInsert,
        validateDelete: validateDelete,
        saveRecord: saveRecord*/
    };
    
});
