/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 *
 * Version      Date            Author          Memo
 * 1.0          2022/12/19      John Wang       采购安排创建PO页面（1017755）
 */
define(['N/config', 'N/record', 'N/redirect', 'N/runtime', 'N/search', 'N/task', 'N/ui/serverWidget', '/SuiteScripts/tools/common_api.js'],
    /**
 * @param{record} record
 * @param{redirect} redirect
 * @param{runtime} runtime
 * @param{search} search
 * @param{task} task
 * @param{serverWidget} serverWidget
 */
    (config, record, redirect, runtime, search, task, serverWidget, commonApi) => {
        const _PREFIX = 'custpage_';//ID固定前缀
        const SEARCH_ID = 'customsearch_ecm_pendind_po_l';//待生成采购安排数据id
        const PD_TYPE = 'customrecord_nvci_pd_nt';//采购安排
        const PD_SUBID = 'recmachcustrecord_nvci_pd_nt_parent';
        const LOG_TYPE = 'customrecord_ecm_order_generate_log';

        const formConfig = () => {
            let configObj = config.load({type: config.Type.USER_PREFERENCES});
            let lang = configObj.getValue({fieldId: 'LANGUAGE'});
            let isEng = 'zh_CN' == lang;
            let title = isEng ? '生成采购订单' : '生成采购订单';
            let cusButtons = [
                {id: 'dosearch', label: isEng ? '搜索' : '搜索', funcName: 'doSearch'}
            ];
            let submitBtn = isEng ? '生成采购订单' : '生成采购订单';
            let filterGroup = isEng ? '查询条件' : '查询条件';
            let filterFields = [
                {id: 'pano', type: 'text', label: isEng ? '采购安排号' : '采购安排号', key: 'pano', fkey: 'custrecord_nvci_pd_nt_parent.name', operator: 'contains'},
                {id: 'item', type: 'select', source: 'item', label: isEng ? 'SKU' : 'SKU', key: 'item', fkey: 'custrecord_nvci_pd_nt_l_model', operator: 'anyof'}
            ];
            let resultsLabel = isEng ? '查询结果' : '查询结果';
            let resultFields = [
                {id: 'l_select', type: 'checkbox', label: isEng ? '选中' : '选中'},
                {id: 'l_item', type: 'select', source: 'item', label: isEng ? '货品' : '货品', key: 'item', wid: 'item', displayType: serverWidget.FieldDisplayType.INLINE},
                {id: 'l_qty', type: 'text', label: isEng ? '采购安排数量' : '采购安排数量', key: 'qty', wid: 'quantity'},
                {id: 'l_unit', type: 'select', source: 'unitstype', label: isEng ? '单位' : '单位', key: 'unit', displayType: serverWidget.FieldDisplayType.INLINE},
                {id: 'l_coa', type: 'select', source: 'customrecord_ecm_core_attributes', label: isEng ? 'COA' : 'COA', key: 'coa', displayType: serverWidget.FieldDisplayType.INLINE},
                {id: 'l_packinfo', type: 'select', source: 'customrecord_ecm_packinginfo', label: isEng ? '包装信息' : '包装信息', key: 'packinfo', displayType: serverWidget.FieldDisplayType.INLINE},
                {id: 'l_pano', type: 'select', source: 'customrecord_nvci_pd_nt', label: isEng ? '采购安排号' : '采购安排号', key: 'pano', displayType: serverWidget.FieldDisplayType.INLINE},
                {id: 'l_vendor', type: 'select', source: 'vendor', label: isEng ? '供应商' : '供应商', key: 'vendor', wid: 'entity', displayType: serverWidget.FieldDisplayType.ENTRY},
                {id: 'l_cuy', type: 'select', source: 'currency', label: isEng ? '默认币种-h' : '默认币种-h', key: 'cuy', wid: 'currency', displayType: serverWidget.FieldDisplayType.HIDDEN},
                {id: 'l_cuy_html', type: 'select', label: isEng ? '默认币种' : '默认币种', displayType: serverWidget.FieldDisplayType.ENTRY},
                {id: 'l_rate', type: 'currency', label: isEng ? '采购单价' : '采购单价', key: 'rate', displayType: serverWidget.FieldDisplayType.ENTRY},
                {id: 'l_soid', type: 'text', label: isEng ? 'SO ID' : 'SO ID', key: 'soid', displayType: serverWidget.FieldDisplayType.NORMAL},
                {id: 'l_palid', type: 'text', label: isEng ? '采购安排行ID' : '采购安排行ID', key: 'palid', displayType: serverWidget.FieldDisplayType.NORMAL},
                {id: 'l_lineid', type: 'text', label: isEng ? '行ID' : '行ID', key: 'lineid', displayType: serverWidget.FieldDisplayType.HIDDEN},
            ];
            return {lang, title, submitBtn, cusButtons, filterGroup, filterFields, resultsLabel, resultFields};
        }
        /**
         * Defines the Suitelet script trigger point.
         * @param {Object} scriptContext
         * @param {ServerRequest} scriptContext.request - Incoming request
         * @param {ServerResponse} scriptContext.response - Suitelet response
         * @since 2015.2
         */
        const onRequest = (scriptContext) => {
            let request = scriptContext.request,
                response = scriptContext.response;
            let params = request.parameters;
            if('GET' == request.method) {
                let form = ceateForm(params);

                response.writePage(form);
            } else {
                let soData = params[`${_PREFIX}alldata`];
                if(soData && '' != soData) {
                    let obj = record.create({type: LOG_TYPE});
                    obj.setValue({fieldId: 'custrecord_ecm_order_log_type', value: 1});//po
                    obj.setValue({fieldId: 'custrecord_ecm_order_log_status', value: 1});//未处理
                    obj.setValue({fieldId: 'custrecord_ecm_order_log_ori_data', value: soData});//待处理数据
                    let logId = obj.save({ignoreMandatoryFields: true});

                    let schTask = task.create({
                        taskType: task.TaskType.SCHEDULED_SCRIPT,
                        scriptId: 'customscript_ecm_pa_create_po_sch',
                        params: {
                            custscript_ecm_po_create_logid: logId
                        }
                    });
                    schTask.submit();
                }
                redirect.toSuitelet({scriptId: 'customscript_ecm_purarrange2po_sl', deploymentId: 'customdeploy_ecm_purarrange2po_sl'});
            }
        }

        const ceateForm = params => {
            let {lang, title, submitBtn, cusButtons, filterGroup, filterFields, resultsLabel, resultFields} = formConfig();
            let form = serverWidget.createForm({title: title});
            form.clientScriptModulePath = '/SuiteScripts/SuiteScripts_JW/cs_purchase_arrange2po_page.js';

            let poProcessing = checkPoCreateProcessing();
            if(true == poProcessing) {
                let msgField = form.addField({id: `${_PREFIX}msg`, label: 'Message', type: serverWidget.FieldType.INLINEHTML});
                msgField.defaultValue = `<span style="color:red">采购订单创建中，请稍候！</span>`;
                return form;
            }
            form.addField({id: `${_PREFIX}lang`, type: 'text', label: '语言'}).updateDisplayType({displayType: serverWidget.FieldDisplayType.HIDDEN}).defaultValue = lang;
            form.addField({id: `${_PREFIX}alldata`, type: serverWidget.FieldType.LONGTEXT, label: '选中数据'}).updateDisplayType({displayType: serverWidget.FieldDisplayType.HIDDEN});

            form.addSubmitButton({label: submitBtn});
            cusButtons.forEach(function (btn) {
                form.addButton({id: `${_PREFIX}${btn.id}`, label: btn.label, functionName: btn.funcName});
            });

            //分页
            let curPageField = form.addField({id: 'custpage_current_page', type: 'text', label: '当前页'});
            curPageField.updateDisplayType({displayType: serverWidget.FieldDisplayType.HIDDEN});
            let totalPageField = form.addField({id: 'custpage_total_page', type: 'text', label: '总页数'});
            totalPageField.updateDisplayType({displayType: serverWidget.FieldDisplayType.HIDDEN});

            form.addFieldGroup({id: `${_PREFIX}filters`, label: filterGroup});
            filterFields.forEach(function (field) {
                let _field = form.addField({id: `${_PREFIX}${field.id}`, label: field.label, type: field.type, source: 'select' == field.type ? field.source : '', container: `${_PREFIX}filters`});
                if(params[field.key]) {
                    _field.defaultValue = params[field.key];
                }
            });
            let resultList = form.addSublist({id: `hc_list`, type: 'list', label: resultsLabel});
            resultFields.forEach(function (field) {
                let _field = resultList.addField({id: `${_PREFIX}${field.id}`, type: field.type, label: field.label, source: 'select' == field.type ? field.source : ''});
                if(field.displayType) {
                    _field.updateDisplayType({displayType: field.displayType});
                }
            });
            let soData = formatPendingData(params, filterFields, resultFields);
            if(soData && soData.length > 0) {
                let resultDataFields = resultFields.filter(field => 'undefined' != typeof field.key);
                soData.forEach(function (data, index) {
                    resultDataFields.forEach(function (field) {
                        if('undefined' != typeof data[field.key] && '' != data[field.key]) {
                            resultList.setSublistValue({id: `${_PREFIX}${field.id}`, value: data[field.key] || '', line: index});
                        }
                    });
                });

            }
            return form;
        }

        const formatPendingData = (params, filterFields, resultFields) => {
            let soData = [];

            let searchObj = search.load({id: SEARCH_ID});
            let columns = searchObj.columns;
            let filterExpression = searchObj.filterExpression;
            filterFields.forEach(function (field) {
                if(params[field.key]) {
                    filterExpression.push('and');
                    filterExpression.push([field.fkey, field.operator, params[field.key]]);
                }
            });
            searchObj.filterExpression = filterExpression;
            let results = commonApi.getAllData(searchObj);
            log.debug('results==>', results.length);
            if(results && results.length > 0) {
                //let _resultFields = resultFields.filter(field => 'undefined' != typeof field.key);
                results.forEach(function (data) {
                    let json = {};
                    columns.forEach(function (column) {
                        json[column.label.replace(/[\{\}]/g, '')] = data.getValue(column);
                    });
                    soData.push(json);
                });
            }
            log.debug('soData===>' + soData.length, JSON.stringify(soData));
            return soData;
        }

        /**
         * 存在创建中的po
         * @return {boolean}            true:存在创建中PO
         */
        const checkPoCreateProcessing = () => {
            let filters = [],
                columns = [];
            filters.push(['custrecord_ecm_order_log_type', 'anyof', 1]);//类型：PO
            filters.push('and');
            filters.push(['custrecord_ecm_order_log_status', 'anyof', [1, 2]]);//状态：未处理&处理中
            columns.push('internalid');
            let results = search.create({type: LOG_TYPE, filters: filters, columns: columns}).run().getRange({start: 0, end: 1});
            if(results && results.length > 0) {
                return true;
            }
            return false;
        }

        return {onRequest}

    });
