/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 *
 * Version      Date            Author          Memo
 * 1.0          2022/12/18      John Wang       销售订单创建采购安排页面（1017754）
 * 2.0          2022/12/18      John Wang       采购安排改为由销售合同创建（1017877）
 */
define(['N/config', 'N/record', 'N/redirect', 'N/runtime', 'N/search', 'N/task', 'N/ui/serverWidget', '/SuiteScripts/tools/common_api.js', '/SuiteScripts/tools/ramda.min.js'],
    /**
 * @param{record} record
 * @param{redirect} redirect
 * @param{runtime} runtime
 * @param{search} search
 * @param{task} task
 * @param{serverWidget} serverWidget
 */
    (config, record, redirect, runtime, search, task, serverWidget, commonApi, ramda) => {

        const _PREFIX = 'custpage_';//ID固定前缀
        const SEARCH_ID = 'customsearch_ecm_pending_sc_l';//'customsearch_ecm_pending_so2purarrange_l';//待生成采购安排数据id
        const PD_TYPE = 'customrecord_nvci_pd_nt';//采购安排
        const PD_SUBID = 'recmachcustrecord_nvci_pd_nt_parent';
        const SC_TYPE = 'customsale_ecm_sales_contract';//销售合同类型

        const formConfig = () => {
            let configObj = config.load({type: config.Type.USER_PREFERENCES});
            let lang = configObj.getValue({fieldId: 'LANGUAGE'});
            let isEng = 'zh_CN' == lang;
            let title = isEng ? '生成采购安排' : '生成采购安排';
            let cusButtons = [
                {id: 'dosearch', label: isEng ? '搜索' : '搜索', funcName: 'doSearch'}
            ];
            let submitBtn = isEng ? '生成采购安排' : '生成采购安排';
            let filterGroup = isEng ? '查询条件' : '查询条件';
            let filterFields = [
                {id: 'customer', type: 'select', source: 'customer', label: isEng ? '客户' : '客户', key: 'customer', fkey: 'entity', operator: 'anyof', isMandatory: true},
                {id: 'tranid', type: 'text', label: isEng ? '销售合同#' : '销售合同#', key: 'tranid', fkey: 'numbertext', operator: 'contains'},
                {id: 'item', type: 'select', source: 'item', label: isEng ? 'SKU' : 'SKU', key: 'item', fkey: 'item', operator: 'anyof'}
            ];
            let resultsLabel = isEng ? '查询结果' : '查询结果';
            let resultFields = [
                {id: 'l_select', type: 'checkbox', label: isEng ? '选中' : '选中'},
                {id: 'l_item', type: 'select', source: 'item', label: isEng ? '销售合同SKU' : '销售合同SKU', key: 'item', displayType: serverWidget.FieldDisplayType.INLINE, wid: 'custrecord_nvci_pd_nt_l_model'},
                {id: 'l_qty', type: 'text', label: isEng ? '销售合同数量' : '销售合同数量', key: 'qty'},
                {id: 'l_unit', type: 'text', label: isEng ? '单位' : '单位', key: 'unit'},
                {id: 'l_brandunit', type: 'text', label: isEng ? '品牌' : '品牌', key: 'brand'},
                {id: 'l_scno', type: 'select', source: 'customsale_ecm_sales_contract', label: isEng ? '销售合同号' : '销售合同号', key: 'scno', displayType: serverWidget.FieldDisplayType.INLINE},
                {id: 'l_sc_customer', type: 'select', source: 'customer', label: isEng ? '销售合同客户' : '销售合同客户', key: 'customer', displayType: serverWidget.FieldDisplayType.INLINE},
                {id: 'l_type', type: 'select', source: 'customlist_ecm_purchase_arrange_type', label: isEng ? '类型' : '类型', key: 'sctype', wid: 'custrecord_ecm_pd_nt_l_type', displayType: serverWidget.FieldDisplayType.ENTRY},

                {id: 'l_pa_sku', type: 'select', source: 'item', key: 'paItem', label: isEng ? '采购安排SKU' : '采购安排SKU', wid: 'custrecord_ecm_pd_nt_l_sku'},
                {id: 'l_pa_qty', type: serverWidget.FieldType.INTEGER, key: 'thisQty', label: isEng ? '采购安排数量' : '采购安排数量', displayType: serverWidget.FieldDisplayType.ENTRY, wid: 'custrecord_nvci_pd_nt_l_thisquantity'},
                {id: 'l_vendor', type: 'select', source: 'vendor', key: 'vendor', label: isEng ? '供应商' : '供应商', displayType: serverWidget.FieldDisplayType.ENTRY, wid: 'custrecord_nvci_pd_nt_l_factory'},
                {id: 'l_location', type: 'select', source: 'location', key: 'location', label: isEng ? '仓库' : '仓库', displayType: serverWidget.FieldDisplayType.ENTRY},
                {id: 'l_pcno', type: 'text', label: isEng ? '采购合同' : '采购合同'},
                {id: 'l_exp_date', type: serverWidget.FieldType.DATE, key: 'expdate', label: isEng ? '工厂预计交期' : '工厂预计交期', wid: 'custrecord_nvci_pd_nt_l_re_delivery_date', displayType: serverWidget.FieldDisplayType.ENTRY},
                {id: 'l_usedqty', type: 'text', label: isEng ? '已生成采购安排数量' : '已生成采购安排数量', key: 'usedqty'},
                {id: 'l_lastqty', type: serverWidget.FieldType.INTEGER, label: isEng ? '剩余数量' : '剩余数量', key: 'lastqty', displayType: serverWidget.FieldDisplayType.HIDDEN},
                {id: 'l_scid', type: 'text', label: isEng ? '销售合同ID' : '销售合同ID', key: 'scid', displayType: serverWidget.FieldDisplayType.HIDDEN, wid: 'custrecord_ecm_pd_nt_l_soid'},
                {id: 'l_lineid', type: 'text', label: isEng ? '行ID' : '行ID', key: 'lineid', displayType: serverWidget.FieldDisplayType.HIDDEN, wid: 'custrecord_nvci_pd_nt_l_line_id'},
            ];
            return {lang, title, submitBtn, cusButtons, filterGroup, filterFields, resultsLabel, resultFields};
        }
        /**
         * Defines the Suitelet script trigger point.
         * @param {Object} scriptContext
         * @param {ServerRequest} scriptContext.request - Incoming request
         * @param {ServerResponse} scriptContext.response - Suitelet response
         * @since 2015.2
         */
        const onRequest = (scriptContext) => {
            let request = scriptContext.request,
                response = scriptContext.response;
            let params = request.parameters;
            let pdId = false;

            try {
                if('GET' == request.method) {
                    let form = createForm(params);

                    response.writePage(form);
                } else {
                    let soData = params[`${_PREFIX}alldata`];
                    log.audit('待生成paData', soData);
                    if(soData && '' != soData) {
                        soData = JSON.parse(soData);
                        let {lang, title, submitBtn, cusButtons, filterGroup, filterFields, resultsLabel, resultFields} = formConfig();
                        let pdLineFields = resultFields.filter(field => 'undefined' != typeof field.wid);
                        let obj = record.create({type: PD_TYPE, isDynamic: true});
                        obj.setValue({fieldId: 'custrecord_nvci_pd_nt_customer', value: soData[0].customer});
                        for(let i = 0; i < soData.length; i++) {
                            obj.selectNewLine({ sublistId: PD_SUBID});
                            pdLineFields.forEach(function (field) {
                                if('custrecord_nvci_pd_nt_l_re_delivery_date' == field.wid) {
                                    obj.setCurrentSublistText({ sublistId: PD_SUBID, fieldId: field.wid, text: soData[i][field.key]});
                                } else {
                                    obj.setCurrentSublistValue({ sublistId: PD_SUBID, fieldId: field.wid, value: soData[i][field.key]});
                                }
                            })
                            obj.commitLine({sublistId: PD_SUBID});
                        }
                        pdId = obj.save({ignoreMandatoryFields: true, enableSourcing: true});
                        let soDataById = ramda.groupBy(ramda.prop('scid'))(soData);
                        for(scid in soDataById) {
                            let scObj = record.load({type: SC_TYPE, id: scid, isDynamic: true});
                            let thisSoData = soDataById[scid];
                            thisSoData.forEach(function (data) {
                                let index = scObj.findSublistLineWithValue({sublistId: 'item', fieldId: 'lineuniquekey', value: data.lineid});
                                if(-1 != index) {
                                    scObj.selectLine({sublistId: 'item', line: index});
                                    let usedQty = scObj.getCurrentSublistValue({sublistId: 'item', fieldId: 'custcol_nvci_hk_pd_nt_qty'});
                                    let newQty = Number(data.thisQty).add(Number(usedQty || 0));
                                    scObj.setCurrentSublistValue({sublistId: 'item', fieldId: 'custcol_nvci_hk_pd_nt_qty', value: newQty});
                                    scObj.commitLine({sublistId: 'item'});
                                }
                            });
                            scObj.save({ignoreMandatoryFields: true});
                        }
                        redirect.toRecord({type: PD_TYPE, id: pdId});
                    } else {
                        redirect.toSuitelet({scriptId: 'customscript_ecm_so2purarrange_sl', deploymentId: 'customdeploy_ecm_so2purarrange_sl'});
                    }
                }
            } catch (e) {
                log.error('error====>pdid:' + pdId, e);
                if(false != pdId) {
                    record.delete({type: PD_TYPE, id: pdId});
                    redirect.toSuitelet({scriptId: 'customscript_ecm_so2purarrange_sl', deploymentId: 'customdeploy_ecm_so2purarrange_sl'});
                }
            }
        }

        /**
         * 创建form
         * @param params
         * @return {Form}
         */
        const createForm = params => {
            let {lang, title, submitBtn, cusButtons, filterGroup, filterFields, resultsLabel, resultFields} = formConfig();
            let form = serverWidget.createForm({title: title});
            form.clientScriptModulePath = '/SuiteScripts/SuiteScripts_JW/cs_so2purchase_arrange_page.js';

            form.addField({id: `${_PREFIX}lang`, type: 'text', label: '语言'}).updateDisplayType({displayType: serverWidget.FieldDisplayType.HIDDEN}).defaultValue = lang;
            form.addField({id: `${_PREFIX}alldata`, type: serverWidget.FieldType.LONGTEXT, label: '选中数据'}).updateDisplayType({displayType: serverWidget.FieldDisplayType.HIDDEN});

            form.addSubmitButton({label: submitBtn});
            cusButtons.forEach(function (btn) {
                form.addButton({id: `${_PREFIX}${btn.id}`, label: btn.label, functionName: btn.funcName});
            });

            //分页
            let curPageField = form.addField({id: 'custpage_current_page', type: 'text', label: '当前页'});
            curPageField.updateDisplayType({displayType: serverWidget.FieldDisplayType.HIDDEN});
            let totalPageField = form.addField({id: 'custpage_total_page', type: 'text', label: '总页数'});
            totalPageField.updateDisplayType({displayType: serverWidget.FieldDisplayType.HIDDEN});

            form.addFieldGroup({id: `${_PREFIX}filters`, label: filterGroup});
            filterFields.forEach(function (field) {
                let _field = form.addField({id: `${_PREFIX}${field.id}`, label: field.label, type: field.type, source: 'select' == field.type ? field.source : '', container: `${_PREFIX}filters`});
                if(params[field.key]) {
                    _field.defaultValue = params[field.key];
                }
                if(field.isMandatory) {
                    _field.isMandatory = field.isMandatory;
                }
            });
            let resultList = form.addSublist({id: `hc_list`, type: 'list', label: resultsLabel});
            resultFields.forEach(function (field) {
                let _field = resultList.addField({id: `${_PREFIX}${field.id}`, type: field.type, label: field.label, source: 'select' == field.type ? field.source : ''});
                if(field.displayType) {
                    _field.updateDisplayType({displayType: field.displayType});
                }
            });
            if('undefined' != typeof params.customer) {
                let soData = formatPendingData(params, filterFields, resultFields);
                if(soData && soData.length > 0) {
                    let resultDataFields = resultFields.filter(field => 'undefined' != typeof field.key);
                    soData.forEach(function (data, index) {
                        resultDataFields.forEach(function (field) {
                            if('undefined' != typeof data[field.key] && '' != data[field.key]) {
                                resultList.setSublistValue({id: `${_PREFIX}${field.id}`, value: data[field.key] || ' ', line: index});
                            }
                        });
                    });
                }
            }
            return form;
        }

        /**
         * 待创建采购安排SO
         * @param params
         * @param filterFields
         * @param resultFields
         * @return {[]}
         */
        const formatPendingData = (params, filterFields, resultFields) => {
            let soData = [];
            if('undefined' == typeof params.customer && 'undefined' == typeof params.tranid && 'undefined' == params.item) {
                return soData;
            }

            let searchObj = search.load({id: SEARCH_ID});
            let columns = searchObj.columns;
            let filterExpression = searchObj.filterExpression;
            filterFields.forEach(function (field) {
                if(params[field.key]) {
                    filterExpression.push('and');
                    filterExpression.push([field.fkey, field.operator, params[field.key]]);
                }
            });
            searchObj.filterExpression = filterExpression;
            let results = commonApi.getAllData(searchObj);
            log.debug('results==>', results.length);
            if(results && results.length > 0) {
                //let _resultFields = resultFields.filter(field => 'undefined' != typeof field.key);
                results.forEach(function (data) {
                    let json = {};
                    columns.forEach(function (column) {
                        json[column.label.replace(/[\{\}]/g, '')] = data.getValue(column) || ' ';
                    });
                    soData.push(json);
                });
            }
            log.debug('soData===>length:' + soData.length, JSON.stringify(soData));
            return soData;
        }

        return {onRequest}

    });
