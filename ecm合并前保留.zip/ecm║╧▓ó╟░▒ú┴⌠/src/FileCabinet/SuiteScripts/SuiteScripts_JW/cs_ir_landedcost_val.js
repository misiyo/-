/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 *
 * Version      Date            Author          Remark
 * 1.0          2023/03/20      John Wang       手动IR收货带出到岸成本汇总（1018607）
 * 2.0          2023/04/04      John Wang       手动IR新增带值（1018607）
 * 3.0          2023/04/12      John Wang       v1取消（1018607）
 */
define(['N/currentRecord', 'N/record', 'N/search', '/SuiteScripts/tools/common_api.js'],
/**
 * @param{currentRecord} currentRecord
 * @param{record} record
 * @param{search} search
 */
function(currentRecord, record, search, commonApi) {
    
    /**
     * Function to be executed after page is initialized.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.mode - The mode in which the record is being accessed (create, copy, or edit)
     *
     * @since 2015.2
     */
    function pageInit(scriptContext) {
        var mode = scriptContext.mode;
        if('create' == mode || 'copy' == mode) {
            var obj = scriptContext.currentRecord;
            obj.setValue({fieldId: 'landedcostmethod', value: 'VALUE'});
        }
    }

    /**
     * Function to be executed when field is changed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
     * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
     *
     * @since 2015.2
     */
    function fieldChanged(scriptContext) {

    }

    /**
     * Function to be executed when field is slaved.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     *
     * @since 2015.2
     */
    function postSourcing(scriptContext) {

    }

    /**
     * Function to be executed after sublist is inserted, removed, or edited.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @since 2015.2
     */
    function sublistChanged(scriptContext) {

    }

    /**
     * Function to be executed after line is selected.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @since 2015.2
     */
    function lineInit(scriptContext) {

    }

    /**
     * Validation function to be executed when field is changed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
     * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
     *
     * @returns {boolean} Return true if field is valid
     *
     * @since 2015.2
     */
    function validateField(scriptContext) {

    }

    /**
     * Validation function to be executed when sublist line is committed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateLine(scriptContext) {

    }

    /**
     * Validation function to be executed when sublist line is inserted.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateInsert(scriptContext) {

    }

    /**
     * Validation function to be executed when record is deleted.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateDelete(scriptContext) {

    }

    /**
     * Validation function to be executed when record is saved.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @returns {boolean} Return true if record is valid
     *
     * @since 2015.2
     */
    function saveRecord(scriptContext) {
        try {
            sumLandedCost(scriptContext);
        } catch (e) {
            console.error('到岸成本计算error=====' + JSON.stringify(e));
        }
        return true;
    }

    /**
     * 计算到岸成本
     * @param scriptContext
     */
    function sumLandedCost(scriptContext) {
        var obj = scriptContext.currentRecord;
        var length = obj.getLineCount({sublistId: 'item'});
        var lineData = {};//{scdLine:qty}
        for(var i = 0; i < length; i++) {
            var check = obj.getSublistValue({sublistId: 'item', fieldId: 'itemreceive', line: i});
            if(true == check) {
                var qty = obj.getSublistValue({sublistId: 'item', fieldId: 'itemreceive', line: i}),
                    scdLine = obj.getSublistValue({sublistId: 'item', fieldId: 'custcol_ecm_spline', line: i});
                if('' != scdLine) {
                    lineData[scdLine] = qty;
                }
            }
        }
        var costData = formatTotalCost(Object.keys(lineData));//scd明细行到岸成本汇总（单个）
        var totalArray = [0,0,0,0,0,0];
        for(key in lineData) {
            var thisCost = costData[key];
            for(var j = 0; j < 6; j++) {
                var costVal = Number(lineData[key]).mul(Number(thisCost[j]));
                totalArray[j] = Number(totalArray[j]).add(Number(costVal));
            }
        }
        ['landedcostamount5', 'landedcostamount6', 'landedcostamount1' , 'landedcostamount3', 'landedcostamount2', 'landedcostamount4'].forEach(function (fid, index) {
            obj.setValue({fieldId: fid, value: totalArray[index], ignoreFieldChange: true});
        });
    }

    /**
     * SCDLine费用数据
     * @param scdLineArray
     * @return {{}}             {scdLineId：[1,2,3,4,5,6]}按顺序为storage-insp-tarif-seaft-clearf-perc
     */
    function formatTotalCost(scdLineArray) {
        var scdCostTotal = {};//{scdLine:total}
        if(!scdLineArray || 0 == scdLineArray.length) {
            return scdCostTotal;
        }
        var filters = [], columns = [];
        filters.push(['internalid', 'anyof', scdLineArray]);
        columns.push('custrecord_scdline_storagecost');
        columns.push('custrecord_scdline_inspectioncost');
        columns.push('custrecord_scdline_tariffcost');
        columns.push('custrecord_scdline_seafreightcost');
        columns.push('custrecord_scdline_clearancecost');
        columns.push('custrecord_scdline_perscost');
        columns.push('custrecord_scdline_storagecost');
        var results = search.create({type: 'customrecord_ecm_scd_line', filters: filters, columns: columns}).run().getRange({start: 0, end: 1000});
        if(results && results.length > 0) {
            results.forEach(function (data) {
                var thisCost = [];
                thisCost.push(data.getValue(columns[0]) || 0);
                thisCost.push(data.getValue(columns[1]) || 0);
                thisCost.push(data.getValue(columns[2]) || 0);
                thisCost.push(data.getValue(columns[3]) || 0);
                thisCost.push(data.getValue(columns[4]) || 0);
                thisCost.push(data.getValue(columns[5]) || 0);
                scdCostTotal[data.id] = thisCost;
            });
        }
        console.log('scdLine费用明细=====' + JSON.stringify(scdCostTotal));
        return scdCostTotal;
    }



    return {
        pageInit: pageInit,
        /*fieldChanged: fieldChanged,
        postSourcing: postSourcing,
        sublistChanged: sublistChanged,
        lineInit: lineInit,
        validateField: validateField,
        validateLine: validateLine,
        validateInsert: validateInsert,
        validateDelete: validateDelete,*/
        //saveRecord: saveRecord
    };
    
});
