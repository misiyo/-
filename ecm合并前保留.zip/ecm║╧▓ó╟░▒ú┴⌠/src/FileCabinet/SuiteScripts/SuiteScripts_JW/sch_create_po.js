/**
 * @NApiVersion 2.1
 * @NScriptType ScheduledScript
 *
 * Version      Date            Author          Memo
 * 1.0          2022/12/20      John Wang       采购安排创建PO（1017755）
 */
define(['N/record', 'N/runtime', '/SuiteScripts/tools/ramda.min.js'],
    /**
 * @param{record} record
 * @param{runtime} runtime
 */
    (record, runtime, ramda) => {
        const LOG_TYPE = 'customrecord_ecm_order_generate_log';
        const PA_LINE_TYPE = 'customrecord_nvci_pd_nt_line';//采购安排明细行type
        /**
         * Defines the Scheduled script trigger point.
         * @param {Object} scriptContext
         * @param {string} scriptContext.type - Script execution context. Use values from the scriptContext.InvocationType enum.
         * @since 2015.2
         */
        const execute = (scriptContext) => {
            let script = runtime.getCurrentScript();
            let logId = script.getParameter({name: 'custscript_ecm_po_create_logid'});
            log.debug('logid====>', logId);
            let createdPo = [];

            if(logId) {
                try {
                    let logObj = record.load({type: LOG_TYPE, id: logId});
                    let soData = JSON.parse(logObj.getValue('custrecord_ecm_order_log_ori_data'));
                    let dataByKey = ramda.groupBy(ramda.prop('gkey'))(soData);//gkey:[vendor&cuy]
                    log.debug('groupBykey', dataByKey);
                    for(key in dataByKey) {
                        let thisData = dataByKey[key];
                        let poObj = record.create({type: 'purchaseorder', isDynamic: true});
                        poObj.setValue({fieldId: 'entity', value: thisData[0].vendor});
                        poObj.setValue({fieldId: 'currency', value: thisData[0].cuy});
                        thisData.forEach(function (data) {
                            poObj.selectNewLine({sublistId: 'item'});
                            poObj.setCurrentSublistValue({sublistId: 'item', fieldId: 'item', value: data.item});
                            poObj.setCurrentSublistValue({sublistId: 'item', fieldId: 'quantity', value: data.qty});
                            poObj.setCurrentSublistValue({sublistId: 'item', fieldId: 'rate', value: data.rate});
                            poObj.commitLine({sublistId: 'item'});
                        });
                        let poId = poObj.save({ignoreMandatoryFields: true});
                        thisData.forEach(function (data) {
                            record.submitFields({
                                type: PA_LINE_TYPE,
                                id: data.palid,
                                values: {
                                    custrecord_ecm_pd_nt_l_po: poId,
                                    custrecord_nvci_pd_nt_l_factory: thisData[0].vendor
                                },
                                options: {
                                    ignoreMandatoryFields: true
                                }
                            });
                        });
                        createdPo.push(poId);
                    }
                    logObj.setValue({fieldId: 'custrecord_ecm_order_log_status', value: 3});//成功
                    logObj.setValue({fieldId: 'custrecord_ecm_order_log_result', value: createdPo.join('&')});//成功
                    logObj.save({ignoreMandatoryFields: true});
                } catch (e) {
                    log.error('error===>' + logId, e);
                    record.submitFields({
                        type: LOG_TYPE,
                        id: logId,
                        values: {
                            custrecord_ecm_order_log_status: 4,
                            custrecord_ecm_order_log_result: JSON.stringify(e)
                        }
                    });
                    createdPo.forEach(function (poid) {
                        record.delete({type: 'purchaseorder', id: poid});
                    });
                }
            }
        }

        return {execute}

    });
