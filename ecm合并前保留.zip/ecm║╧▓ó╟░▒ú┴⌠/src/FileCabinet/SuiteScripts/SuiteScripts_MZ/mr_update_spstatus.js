/**
 * @NApiVersion 2.1
 * @NScriptType MapReduceScript
 *
 * Version		Date			Author			Remark
 * 1.0          2023/03/16      Mark Z          SP提货状态更新(1018603)
 * 2.0          2023/03/20      Mark Z          待更新状态从未出运=>预估费用已提交
 * 3.0          2023/04/14      Mark Z          非跨境，提货->离港
 */
define(['N/record', 'N/search', '../tools/common_api.js', 'N/config'],
    /**
     * @param{record} record
     * @param{search} search
     */
    (record, search, commonApi, config) => {
        /**
         * Defines the function that is executed at the beginning of the map/reduce process and generates the input data.
         * @param {Object} inputContext
         * @param {boolean} inputContext.isRestarted - Indicates whether the current invocation of this function is the first
         *     invocation (if true, the current invocation is not the first invocation and this function has been restarted)
         * @param {Object} inputContext.ObjectRef - Object that references the input data
         * @typedef {Object} ObjectRef
         * @property {string|number} ObjectRef.id - Internal ID of the record instance that contains the input data
         * @property {string} ObjectRef.type - Type of the record instance that contains the input data
         * @returns {Array|Object|Search|ObjectRef|File|Query} The input data to use in the map/reduce process
         * @since 2015.2
         */

        const getInputData = (inputContext) => {
            let pendingData = [];
            try {
                pendingData = getPendingData();
            } catch (e) {
                log.error('getInputData error', e);
            }
            return pendingData;
        }

        const getPendingData = () => {
            let filters = [];
            let columns = [];
            filters.push(['custrecord_sp_status', 'is', 7]);// 预估费用已提交
            filters.push('AND');
            filters.push(['isinactive', 'is', 'F']);
            columns.push(search.createColumn({name: 'internalid', label: 'Internal ID'}));
            let spSearchObj = search.create({type: 'customrecord_ecm_sp', filters: filters, columns: columns});
            let result = commonApi.getAllData(spSearchObj);
            let spIdArr = [];
            if (result.length > 0) {
                for (let i = 0; i < result.length; i++) {
                    let spId = result[i].getValue(columns[0]);
                    spIdArr.push(spId);
                }
            }
            return spIdArr
        }

        /**
         * Defines the function that is executed when the map entry point is triggered. This entry point is triggered automatically
         * when the associated getInputData stage is complete. This function is applied to each key-value pair in the provided
         * context.
         * @param {Object} mapContext - Data collection containing the key-value pairs to process in the map stage. This parameter
         *     is provided automatically based on the results of the getInputData stage.
         * @param {Iterator} mapContext.errors - Serialized errors that were thrown during previous attempts to execute the map
         *     function on the current key-value pair
         * @param {number} mapContext.executionNo - Number of times the map function has been executed on the current key-value
         *     pair
         * @param {boolean} mapContext.isRestarted - Indicates whether the current invocation of this function is the first
         *     invocation (if true, the current invocation is not the first invocation and this function has been restarted)
         * @param {string} mapContext.key - Key to be processed during the map stage
         * @param {string} mapContext.value - Value to be processed during the map stage
         * @since 2015.2
         */

        const map = (mapContext) => {
            let configObj = config.load({type: config.Type.USER_PREFERENCES});
            let dateformat = configObj.getValue('DATEFORMAT');
            let spId = mapContext.value;
            log.debug('spId', spId);
            try {
                let spRec = record.load({type: 'customrecord_ecm_sp', id: spId});
                const subId = 'recmachcustrecord_scdline_sp';
                let length = spRec.getLineCount({sublistId: subId});
                let lineFlagArr = [];// 每行明细是否满足实际发运数量大于数量
                for (let i = 0; i < length; i++) {
                    let updState = false;
                    let spQty = spRec.getSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_spqty', line: i});// 实际发运数量
                    let qty = spRec.getSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_qty', line: i});// 数量
                    if (Number(spQty) >= Number(qty)) {
                        updState = true
                    }
                    lineFlagArr.push(updState);
                }
                // 所有明细行都满足实际发运数量大于数量
                if (lineFlagArr.indexOf(false) === -1) {
                    let now = formatNowDate(dateformat);
                    let isCross = spRec.getValue({fieldId: 'custrecord_sp_iscross_border'});
                    if ('T' == isCross || true == isCross) {
                        spRec.setValue({fieldId:'custrecord_sp_status', value: 2});// 已提货
                    }
                    else {
                        spRec.setValue({fieldId: 'custrecord_sp_status', value: 3});// 离港
                        if (now) {
                            spRec.setText({fieldId:'custrecord_sp_departuredate', text: now});
                        }
                    }
                    if (now) {
                        spRec.setText({fieldId:'custrecord_sp_deliverycomdate', text: now});
                    }
                }
                spRec.save({ignoreMandatoryFields: true, enableSourcing: true});
            } catch (e) {
                log.error(`map ${spId} update error`, e);
            }
        }

        /**
         * 获取当前日期
         * @param dateformat
         * @return {string|boolean}
         */
        const formatNowDate = (dateformat) => {
            let now = commonApi.getNowDateTime(true);
            let dateArr = now.split('/');
            let year = dateArr[0], month = dateArr[1], day = dateArr[2];
            if ('' == year || '' == month || '' == day || '' == dateformat) {
                return false;
            }
            if ('YYYY年M月D日' == dateformat) {
                return year + '年' + Number(month) + '月' + Number(day) + '日 ';
            } else if ('YYYY年MM月DD日' == dateformat) {
                return year + '年' + month + '月' + day + '日 ';
            } else if ('YYYY-M-D' == dateformat) {
                return year + '-' + Number(month) + '-' + Number(day);
            } else if('YYYY-MM-DD' == dateformat) {
                return year + '-' + month + '-' + day;
            } else if ('YYYY M D' == dateformat) {
                return year + ' ' + Number(month) + ' ' + Number(day);
            } else if ('YYYY MM DD' == dateformat) {
                return year + ' ' + month + ' ' + day;
            } else if ('YYYY/M/D' == dateformat) {
                return year + '/' + Number(month) + '/' + Number(day);
            } else if ('YYYY/MM/DD' == dateformat) {
                return year + '/' + month + '/' + day;
            } else if ('M/D/YYYY' == dateformat) {
                return Number(month) + '/' + Number(day) + '/' + year;
            } else if ('MM/DD/YYYY' == dateformat) {
                return month + '/' + day + '/' + year;
            } else if ('D/M/YYYY' == dateformat) {
                return Number(day) + '/' + Number(month) + '/' + year;
            } else if ('DD/MM/YYYY' == dateformat) {
                return day + '/' + month + '/' + year;
            } else if ('D-Mon-YYYY' == dateformat) {
                var months = ["1", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                var tempMonth = months[month - 1];
                return Number(day) + '-' + tempMonth + '月-' + year;
            } else if ('DD-Mon-YYYY' == dateformat) {
                var months = ["1", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                var tempMonth = months[month - 1];
                return day + '-' + tempMonth + '月-' + year;
            } else if ('D.M.YYYY' == dateformat) {
                return Number(day) + '.' + Number(month) + '.' + year;
            } else if('DD.MM.YYYY' == dateformat) {
                return day + '.' + month + '.' + year;
            }
        }

        /**
         * Defines the function that is executed when the reduce entry point is triggered. This entry point is triggered
         * automatically when the associated map stage is complete. This function is applied to each group in the provided context.
         * @param {Object} reduceContext - Data collection containing the groups to process in the reduce stage. This parameter is
         *     provided automatically based on the results of the map stage.
         * @param {Iterator} reduceContext.errors - Serialized errors that were thrown during previous attempts to execute the
         *     reduce function on the current group
         * @param {number} reduceContext.executionNo - Number of times the reduce function has been executed on the current group
         * @param {boolean} reduceContext.isRestarted - Indicates whether the current invocation of this function is the first
         *     invocation (if true, the current invocation is not the first invocation and this function has been restarted)
         * @param {string} reduceContext.key - Key to be processed during the reduce stage
         * @param {List<String>} reduceContext.values - All values associated with a unique key that was passed to the reduce stage
         *     for processing
         * @since 2015.2
         */
        const reduce = (reduceContext) => {

        }


        /**
         * Defines the function that is executed when the summarize entry point is triggered. This entry point is triggered
         * automatically when the associated reduce stage is complete. This function is applied to the entire result set.
         * @param {Object} summaryContext - Statistics about the execution of a map/reduce script
         * @param {number} summaryContext.concurrency - Maximum concurrency number when executing parallel tasks for the map/reduce
         *     script
         * @param {Date} summaryContext.dateCreated - The date and time when the map/reduce script began running
         * @param {boolean} summaryContext.isRestarted - Indicates whether the current invocation of this function is the first
         *     invocation (if true, the current invocation is not the first invocation and this function has been restarted)
         * @param {Iterator} summaryContext.output - Serialized keys and values that were saved as output during the reduce stage
         * @param {number} summaryContext.seconds - Total seconds elapsed when running the map/reduce script
         * @param {number} summaryContext.usage - Total number of governance usage units consumed when running the map/reduce
         *     script
         * @param {number} summaryContext.yields - Total number of yields when running the map/reduce script
         * @param {Object} summaryContext.inputSummary - Statistics about the input stage
         * @param {Object} summaryContext.mapSummary - Statistics about the map stage
         * @param {Object} summaryContext.reduceSummary - Statistics about the reduce stage
         * @since 2015.2
         */
        const summarize = (summaryContext) => {

        }

        return {getInputData, map/*, reduce, summarize*/}

    });
