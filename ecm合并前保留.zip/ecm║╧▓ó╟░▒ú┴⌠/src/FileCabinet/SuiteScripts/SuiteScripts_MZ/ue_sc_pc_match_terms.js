/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 *
 * Version		Date			Author			Remark
 * 1.0          2023/03/30      Mark Z          SC&PC保存时，匹配合同条款显示
 */
define(['N/record', 'N/search', '../tools/common_api.js'],
    /**
     * @param{record} record
     * @param{search} search
     */
    (record, search, commonApi) => {
        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed before record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const beforeSubmit = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {
            let newObj = scriptContext.newRecord, type = scriptContext.type;
            if ('delete' == type) {
                return;
            }

            let orderType = newObj.getValue('custbody_ecm_ordertype');// Order Type
            if (1 === Number(orderType)) {// Contract
                matchContractTerms(newObj);
            }
        }

        /**
         * 匹配合同条款显示
         * @param newObj
         * @param type
         */
        const matchContractTerms = (newObj) => {
            let obj = record.load({type: newObj.type, id: newObj.id});
            let isCrossBorder = obj.getValue({fieldId: 'custbody_ecm_iscrossborder'});// 是否跨境
            let prePaymentRatio = obj.getValue({fieldId: 'custbody_ecm_prepayment_ratio'}) || 0;// 预款比例
            let prePaymentMethod = obj.getValue({fieldId: 'custbody_ecm_prepay_method'});// 预款支付方式
            let prePaymentNode = obj.getValue({fieldId: 'custbody_ecm_prepay_node'});// 预款支付节点
            let prePaymentDays = obj.getValue({fieldId: 'custbody_ecm_advance_prepaydays'});// 预款支付期/days
            let balanceRatio = Number(100).sub(Number(prePaymentRatio));// 余款比例
            let balanceMethod = obj.getValue({fieldId: 'custbody_ecm_balance_prepay_method'});// 余款支付方式
            let balanceNode = obj.getValue({fieldId: 'custbody_ecm_balance_prepay_node'});// 余款支付节点
            let balanceDays = obj.getValue({fieldId: 'custbody_ecm_balance_termsdays'});// 余款账期/days
            let deliveryDateType = obj.getValue({fieldId: 'custbody_ecm_deliverydate_type'});// 交割日文言
            log.debug('contract fields value', `是否跨境=>${isCrossBorder}||预款比例=>${prePaymentRatio}||预款支付方式=>${prePaymentMethod}||预款支付节点=>${prePaymentNode}||预款支付期/days=>${prePaymentDays}||余款比例=>${balanceRatio}||余款支付方式=>${balanceMethod}||余款支付节点=>${balanceNode}||余款账期/days=>${balanceDays}||交割日文言=>${deliveryDateType}`);
            // 匹配合同条款显示
            let termsObj = searchTerms(newObj.type, isCrossBorder, prePaymentRatio, prePaymentMethod, prePaymentNode, balanceMethod, balanceNode, deliveryDateType);
            if (termsObj.id) {
                obj.setValue({fieldId: 'custbody_ecm_termsmatch', value: termsObj.id});
            }
            if (termsObj.en) {
                obj.setValue({fieldId: 'custbody_ecm_termsdisplay_en', value: replaceFieldValue(termsObj.en, prePaymentRatio, balanceRatio, prePaymentDays, balanceDays)});
            }
            if (termsObj.cn) {
                obj.setValue({fieldId: 'custbody_ecm_termsdisplay_cn', value: replaceFieldValue(termsObj.cn, prePaymentRatio, balanceRatio, prePaymentDays, balanceDays)});
            }
            obj.save({enableSourcing: true, ignoreMandatoryFields: true});
        }

        /**
         * 搜索符合条件的合同条款显示
         * @param recType
         * @param isCrossBorder
         * @param prePaymentRatio
         * @param prePaymentMethod
         * @param prePaymentNode
         * @param balanceMethod
         * @param balanceNode
         * @param deliveryDateType
         * @return {{}}
         */
        const searchTerms = (recType, isCrossBorder, prePaymentRatio, prePaymentMethod, prePaymentNode, balanceMethod, balanceNode, deliveryDateType) => {
            let termsObj = {};
            termsObj.id = '';
            termsObj.en = '';
            termsObj.cn = '';
            let filters = [];
            filters.push(['isinactive', 'is', 'F']);
            if ('T' == isCrossBorder || true == isCrossBorder) {
                filters.push('and');
                filters.push(['custrecord_ecm_iscrossborder1', 'is', 'T']);
            }
            else {
                filters.push('and');
                filters.push(['custrecord_ecm_iscrossborder1', 'is', 'F']);
            }
            if (Number(prePaymentRatio) === 0) {
                filters.push('and');
                filters.push(['custrecord_ecm_prepayment_ratio1', 'equalto', '0']);
            }
            else if (Number(prePaymentRatio) === 100) {
                filters.push('and');
                filters.push(['custrecord_ecm_prepayment_ratio1', 'equalto', '100']);
            }
            else {
                filters.push('and');
                filters.push(['custrecord_ecm_prepayment_ratio1', 'notequalto', '0']);
                filters.push('and');
                filters.push(['custrecord_ecm_prepayment_ratio1', 'notequalto', '100']);
            }
            if (prePaymentMethod) {
                filters.push('and');
                filters.push(['custrecord_ecm_prepay_method1', 'anyof', prePaymentMethod]);
            }
            else {
                filters.push('and');
                filters.push(['custrecord_ecm_prepay_method1', 'anyof', '@NONE@']);
            }
            if (prePaymentNode) {
                filters.push('and');
                filters.push(['custrecord_ecm_prepay_node1', 'anyof', prePaymentNode]);
            }
            else {
                filters.push('and');
                filters.push(['custrecord_ecm_prepay_node1', 'anyof', '@NONE@']);
            }
            if (balanceMethod) {
                filters.push('and');
                filters.push(['custrecord_ecm_balance_prepay_method1', 'anyof', balanceMethod]);
            }
            else {
                filters.push('and');
                filters.push(['custrecord_ecm_balance_prepay_method1', 'anyof', '@NONE@']);
            }
            if (balanceNode) {
                filters.push('and');
                filters.push(['custrecord_ecm_balance_prepay_node1', 'anyof', balanceNode]);
            }
            else {
                filters.push('and');
                filters.push(['custrecord_ecm_balance_prepay_node1', 'anyof', '@NONE@']);
            }
            if (deliveryDateType) {
                filters.push('and');
                filters.push(['custrecord_ecm_deliverydate_type1', 'anyof', deliveryDateType]);
            }
            else {
                filters.push('and');
                filters.push(['custrecord_ecm_deliverydate_type1', 'anyof', '@NONE@']);
            }
            let columns = [];
            columns.push(search.createColumn({name: 'internalid', sort: 'DESC'}));
            if ('salesorder' == recType) {
                columns.push(search.createColumn({name: 'custrecord_ecm_termsdisplay_en_so'}));
                columns.push(search.createColumn({name: 'custrecord_ecm_termsdisplay_cn_so'}));
            }
            else {
                columns.push(search.createColumn({name: 'custrecord_ecm_termsdisplay_en_po'}));
                columns.push(search.createColumn({name: 'custrecord_ecm_termsdisplay_cn_po'}));
            }
            // log.debug('filters', filters);
            // log.debug('columns', columns);
            let termSearchObj = search.create({type: 'customrecord_ecm_termsmatch', filters: filters, columns: columns});
            let results = termSearchObj.run().getRange({start: 0, end: 1});
            if (results && results.length > 0) {
                termsObj.id = results[0].id;
                termsObj.en = results[0].getValue(columns[1]) || '';
                termsObj.cn = results[0].getValue(columns[2]) || '';
            }
            log.debug('termsObj', termsObj);
            return termsObj;
        }

        /**
         * 替换字符串值
         * @param str
         * @param prePaymentRatio
         * @param balanceRatio
         * @param prePaymentDays
         * @param balanceDays
         * @return {string}
         */
        const replaceFieldValue = (str, prePaymentRatio, balanceRatio, prePaymentDays, balanceDays) => {
            return str.replaceAll('{100-{custbody_ecm_prepayment_ratio}}', balanceRatio)
                .replaceAll('{custbody_ecm_prepayment_ratio}', prePaymentRatio)
                .replaceAll('{custbody_ecm_balance_termsdays}', balanceDays)
                .replaceAll('{custbody_ecm_advance_prepaydays}', prePaymentDays);
        }

        return {/*beforeLoad, beforeSubmit,*/ afterSubmit}

    });
