/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 *
 * Version		Date			Author			Remarks
 * 1.0          2023/02/21      Mark Z          下推生成合同配货页面
 * 2.0          2023/03/09      mark z          新增SS显示条件，新增字段带值
 * 3.0          2023/03/13      Mark Z          增加SS显示条件：COMPLETED SCD字段未勾选
 * 4.0          2023/03/21      Mark Z          新增字段取值
 * 5.0          2023/03/27      Mark Z          取消Port Of Departure,Location字段在配货类型=仓库发货时添加SC下子公司可选地点
 * 6.0          2023/04/06      Mark Z          新增字段取值
 * 7.0          2023/04/10      Mark Z          字段取值修改
 * 8.0          2023/04/18      Mark Z          字段取值修改
 */
define(['N/record', 'N/runtime', 'N/search', 'N/ui/serverWidget', '../tools/common_api.js', 'N/redirect'],
    /**
     * @param{record} record
     * @param{runtime} runtime
     * @param{search} search
     * @param{serverWidget} serverWidget
     */
    (record, runtime, search, serverWidget, commonApi, redirect) => {
        /**
         * Defines the Suitelet script trigger point.
         * @param {Object} scriptContext
         * @param {ServerRequest} scriptContext.request - Incoming request
         * @param {ServerResponse} scriptContext.response - Suitelet response
         * @since 2015.2
         */
        const onRequest = (scriptContext) => {
            let request = scriptContext.request;
            let response = scriptContext.response;
            let params = request.parameters;

            if ('GET' == request.method) {
                let ssArr = searchSS();
                let pcArr = searchPC();
                let allSubsidiary = searchAllSub();
                let form = createForm(params, ssArr, pcArr, allSubsidiary);
                response.writePage(form);
            }
            else {
                let ssId = params.custpage_ss_no;
                let ssFields = search.lookupFields({
                    type: 'customrecord_shipping_schedule',
                    id: ssId,
                    columns: ['custrecord_ssc_scnumber']
                });
                let scId = ssFields['custrecord_ssc_scnumber'][0].value;// 销售合同ID
                let ssData = getSSData(ssId);
                let scData = getSCData(scId);
                let mainData = getMainData(params);
                let {lineData, items} = getLineData(request);
                let itemInfos = getItems(items);
                let itemDeclaration = {};
                if (items.length > 0 && scData.countryOfDeparture) {
                    // Item Customs Declaration
                    itemDeclaration = searchItemDeclaration(scData.countryOfDeparture, items);
                }
                let scdId = createSCD(ssData, scData, mainData, lineData, itemInfos, itemDeclaration);
                redirect.toRecord({type: 'customrecord_ecm_scd', id: scdId});
            }
        }

        /**
         * 搜索子公司
         * @return {[]}
         */
        const searchAllSub = () => {
            let subArr = [];
            let subSearchObj = search.create({
                type: 'subsidiary',
                filters: [
                    ['isinactive', 'is', 'F']
                ],
                columns: [
                    search.createColumn({name: 'namenohierarchy'})
                ]
            });
            let columns = subSearchObj.columns;
            let results = commonApi.getAllData(subSearchObj);
            results.forEach(res => {
                subArr.push({
                    value: res.id,
                    text: res.getValue(columns[0])
                });
            });
            return subArr;
        }

        /**
         * 搜索所有单据类型为自营贸易，且状态不等于完结的SS
         * @return {[]}
         */
        const searchSS = () => {
            let ssArr = [];
            let filters = [], columns = [];
            filters.push(['isinactive', 'is', 'F']);
            filters.push('and');
            filters.push(['custrecord_ssc_order_type', 'noneof', '5']);
            filters.push('and');
            filters.push(['formulanumeric: NVL(TO_NUMBER({custrecord_sscd_parent.custrecord_sscd_ssqty}), 0)-NVL(TO_NUMBER({custrecord_sscd_parent.custrecord_sscd_csdty_created}), 0)', 'greaterthan', '0']);
            filters.push('and');
            filters.push(['formulanumeric: NVL(TO_NUMBER({custrecord_ssc_scnumber.custbody_ecm_sumqty}), 0) - NVL(TO_NUMBER({custrecord_ssc_scnumber.custbody_ecm_sumqtyof_sscreated}), 0)', 'lessthanorequalto', '0']);
            filters.push('and');
            filters.push(['custrecord_ssc_scnumber.mainline', 'is', 'T']);
            filters.push('and');
            filters.push(['custrecord_ssc_scnumber.taxline', 'is', 'F']);
            filters.push('and');
            filters.push(['custrecord_ssc_completescd', 'is', 'F']);
            filters.push('and');
            filters.push(['custrecord_ssc_scnumber.custbody_ecm_document_status', 'anyof', '2']);// 生效
            columns.push(search.createColumn({name: 'name'}));
            let ssSearchObj = search.create({type: 'customrecord_shipping_schedule', filters: filters, columns: columns});
            let results = commonApi.getAllData(ssSearchObj);
            results.forEach(res => {
                ssArr.push({value: res.id, text: res.getValue(columns[0])});
            });
            return ssArr;
        }

        /**
         * 搜索单据类型=Contract的PurchaseOrder
         * @return {[]}
         */
        const searchPC = () => {
            let pcArr = [];
            let filters = [], columns = [];
            filters.push(['mainline', 'is', 'T']);
            filters.push('and');
            filters.push(['taxline', 'is', 'F']);
            filters.push('and');
            filters.push(['custbody_ecm_ordertype', 'anyof', '1']);// Contract
            columns.push(search.createColumn({name: 'tranid'}));
            let pcSearchObj = search.create({type: 'purchaseorder', filters: filters, columns: columns});
            let results = commonApi.getAllData(pcSearchObj);
            results.forEach(res => {
                pcArr.push({value: res.id, text: res.getValue(columns[0])});
            });
            return pcArr;
        }

        /**
         * 下推页面
         * @param params
         * @param ssArr
         * @param pcArr
         * @param allSubsidiary
         * @return {Form}
         */
        const createForm = (params, ssArr, pcArr, allSubsidiary) => {
            let form = serverWidget.createForm({title: 'SS Create SCD Page', hideNavBar: false});
            form.clientScriptModulePath = './cs_ss_create_scd_sl.js';
            // Button
            form.addButton({id: 'custpage_search', label: 'Search', functionName: 'searchData'});
            form.addSubmitButton({label: 'Create SCD'});
            // Filters
            form.addFieldGroup({id: 'custpage_filters', label: 'Filters'});
            let ssNo = form.addField({id: 'custpage_ss_no', label: 'SS NO', type: 'select', container: 'custpage_filters'});
            ssNo.isMandatory = true;
            ssNo.addSelectOption({value: '', text: ''});
            ssArr.forEach(ss => {
                ssNo.addSelectOption({value: ss.value, text: ss.text});
            });
            if (params.ssno) {
                ssNo.defaultValue = params.ssno;
            }
            let sourcing = form.addField({id: 'custpage_sourcing', label: 'Sourcing', type: 'select', source: 'employee', container: 'custpage_filters'});
            sourcing.defaultValue = runtime.getCurrentUser().id;
            sourcing.updateDisplayType({displayType: serverWidget.FieldDisplayType.INLINE});
            // Main
            form.addFieldGroup({id: 'custpage_main', label: 'Main'});
            let distributionType = form.addField({id: 'custpage_distribution_type', label: 'Distribution Type', type: 'select', source: 'customlist_ecm_distributiontype', container: 'custpage_main'});
            distributionType.isMandatory = true;
            let location = form.addField({id: 'custpage_location', label: 'Location', type: 'select'/*, source: 'location'*/, container: 'custpage_main'});
            let purchaseContract = form.addField({id: 'custpage_pur_contract', label: 'Purchase Contract', type: 'select', container: 'custpage_main'});
            purchaseContract.addSelectOption({value: '', text: ''});
            pcArr.forEach(pc => {
                purchaseContract.addSelectOption({value: pc.value, text: pc.text});
            });
            let supplyPlanner = form.addField({id: 'custpage_supply_planner', label: 'Supply Planner', type: 'select', source: 'employee', container: 'custpage_main'});
            supplyPlanner.isMandatory = true;
            let supplier = form.addField({id: 'custpage_supplier', label: 'Supplier', type: 'select', container: 'custpage_main'});
            supplier.addSelectOption({value: '', text: ''});
            allSubsidiary.forEach(subObj => {
                supplier.addSelectOption({value: subObj.value, text: subObj.text});
            });
            let vendor = form.addField({id: 'custpage_vendor', label: 'Vendor', type: 'select', source: 'vendor', container: 'custpage_main'});
            let purchaseCurrency = form.addField({id: 'custpage_pur_currency', label: 'Purchase Currency', type: 'select', source: 'currency', container: 'custpage_main'});
            let shippingDate = form.addField({id: 'custpage_shipping_date', label: 'ESTIMATED DATE OF PICKUP', type: 'date', container: 'custpage_main'});
            shippingDate.isMandatory = true;
            // let port = form.addField({id: 'custpage_port', label: 'Port of Departure', type: 'select', source: 'customrecord_ecm_loaddest_ports', container: 'custpage_main'});
            // Line
            let formSublist = form.addSublist({id: 'custpage_line', label: 'Line', type: 'list'});
            formSublist.addMarkAllButtons();
            formSublist.addField({id: 'custpage_line_check', label: 'Check', type: 'checkbox'});
            formSublist.addField({id: 'custpage_line_sslineid', label: 'SS Line ID', type: 'text'}).updateDisplayType({displayType: serverWidget.FieldDisplayType.HIDDEN});
            formSublist.addField({id: 'custpage_line_ss', label: 'SS', type: 'text'}).updateDisplayType({displayType: serverWidget.FieldDisplayType.INLINE});
            formSublist.addField({id: 'custpage_line_item', label: 'SS Item', type: 'select', source: 'item'}).updateDisplayType({displayType: serverWidget.FieldDisplayType.INLINE});
            formSublist.addField({id: 'custpage_line_qty', label: 'SS Quantity', type: 'float'}).updateDisplayType({displayType: serverWidget.FieldDisplayType.INLINE});
            formSublist.addField({id: 'custpage_line_dqty', label: 'Distributed Quantity', type: 'float'}).updateDisplayType({displayType: serverWidget.FieldDisplayType.INLINE});
            formSublist.addField({id: 'custpage_line_scditem', label: 'SCD Item', type: 'select', source: 'item'}).updateDisplayType({displayType: serverWidget.FieldDisplayType.ENTRY});
            formSublist.addField({id: 'custpage_line_scdqty', label: 'SCD Quantity', type: 'float'}).updateDisplayType({displayType: serverWidget.FieldDisplayType.ENTRY});
            formSublist.addField({id: 'custpage_line_unit', label: 'Unit', type: 'text'}).updateDisplayType({displayType: serverWidget.FieldDisplayType.ENTRY}).updateDisplayType({displayType: 'disabled'});
            formSublist.addField({id: 'custpage_line_pclineid', label: 'Purchase Contract LineID', type: 'select'}).updateDisplayType({displayType: serverWidget.FieldDisplayType.ENTRY});
            formSublist.addField({id: 'custpage_line_pcqty', label: 'Purchase Contract Qty', type: 'float'}).updateDisplayType({displayType: serverWidget.FieldDisplayType.ENTRY}).updateDisplayType({displayType: 'disabled'});
            formSublist.addField({id: 'custpage_line_purprice', label: 'Purchase Price', type: 'float'}).updateDisplayType({displayType: serverWidget.FieldDisplayType.ENTRY});
            formSublist.addField({id: 'custpage_line_taxcode', label: 'Tax Code', type: 'select', source: 'salestaxitem'}).updateDisplayType({displayType: serverWidget.FieldDisplayType.ENTRY});
            // 添加明细
            if ('T' == params.iss) {
                let ssLineData = getSS(params.ssno);// 搜索该SS的明细数据
                if (ssLineData && ssLineData.length > 0) {
                    ssLineData.forEach((line, i) => {
                        formSublist.setSublistValue({id: 'custpage_line_sslineid', line: i, value: line.lineId});
                        formSublist.setSublistValue({id: 'custpage_line_ss', line: i, value: line.ssNo});
                        formSublist.setSublistValue({id: 'custpage_line_item', line: i, value: line.itemId});
                        formSublist.setSublistValue({id: 'custpage_line_qty', line: i, value: line.ssQty});
                        formSublist.setSublistValue({id: 'custpage_line_dqty', line: i, value: line.distributedQty});
                        formSublist.setSublistValue({id: 'custpage_line_scditem', line: i, value: line.itemId});
                        formSublist.setSublistValue({id: 'custpage_line_scdqty', line: i, value: line.scdQty});
                        formSublist.setSublistValue({id: 'custpage_line_unit', line: i, value: line.unit});
                    });
                }
            }
            return form;
        }

        /**
         * 搜索符合条件的SS明细
         * @param ssId
         * @return {[]}
         */
        const getSS = (ssId) => {
            let currentUser = runtime.getCurrentUser();// 当前用户
            let ssLines = [];
            let ssObj = record.load({type: 'customrecord_shipping_schedule', id: ssId});
            let ssNo = ssObj.getValue({fieldId: 'name'});
            const subId = 'recmachcustrecord_sscd_parent';
            let lineCount = ssObj.getLineCount({sublistId: subId});
            for (let i = 0; i < lineCount; i++) {
                let lineId = ssObj.getSublistValue({sublistId: subId, fieldId: 'custrecord_sscd_sclineid', line: i});
                let itemId = ssObj.getSublistValue({sublistId: subId, fieldId: 'custrecord_sscd_scsku', line: i});
                let ssQty = ssObj.getSublistValue({sublistId: subId, fieldId: 'custrecord_sscd_ssqty', line: i}) || 0;
                let distributedQty = ssObj.getSublistValue({sublistId: subId, fieldId: 'custrecord_sscd_csdty_created', line: i}) || 0;
                let scdQty = Number(ssQty).sub(Number(distributedQty));// 剩余可配货数量
                let unit = ssObj.getSublistText({sublistId: subId, fieldId: 'custrecord_sscd_unit', line: i});
                let sourcing = ssObj.getSublistValue({sublistId: subId, fieldId: 'custrecord_sscd_sourcing', line: i});// 采购员
                // 剩余可配货数量大于0，当前用户角色不等于管理员时需判断采购员等于当前用户
                if (Number(scdQty) > 0) {
                    let lineJson = {
                        ssNo: ssNo,
                        lineId: lineId,
                        itemId: itemId,
                        ssQty: ssQty,
                        distributedQty: distributedQty,
                        scdQty: scdQty,
                        unit: unit
                    };
                    if (3 != currentUser.role) {
                        if (currentUser.id == sourcing) {
                            ssLines.push(lineJson);
                        }
                    } else {
                        ssLines.push(lineJson);
                    }
                }
            }
            log.debug('ssLines', ssLines);
            return ssLines;
        }

        /**
         * 获取SS
         * @param ssId
         * @return {{}}
         */
        const getSSData = (ssId) => {
            let ssData = {};
            let ssObj = record.load({type: 'customrecord_shipping_schedule', id: ssId});
            ssData.ssId = ssId;
            ssData.orderType = ssObj.getValue({fieldId: 'custrecord_ssc_order_type'});
            ssData.isCross = ssObj.getValue({fieldId: 'custrecord_ssc_iscross_border'});
            ssData.incoterm = ssObj.getValue({fieldId: 'custrecord_ssc_incoterm'});
            ssData.shippingMethod = ssObj.getValue({fieldId: 'custrecord_ssc_shipping_method'});
            ssData.destinationPort = ssObj.getValue({fieldId: 'custrecord_ssc_destinationport'});
            ssData.destinationCountry = ssObj.getValue({fieldId: 'custrecord_ssc_country_destination'});
            ssData.otherMark = ssObj.getValue({fieldId: 'custrecord_ssc_poreq_othemark'});
            ssData.memo = ssObj.getValue({fieldId: 'custrecord_ssc_memo'});
            ssData.port = ssObj.getValue({fieldId: 'custrecord_ssc_loadingport'});// 起运港
            if (ssData.port) {
                let portFields = search.lookupFields({
                    type: 'customrecord_ecm_loaddest_ports',
                    id: ssData.port,
                    columns: ['custrecord_el_country']
                });
                if (portFields['custrecord_el_country'].length > 0) {
                    ssData.country = portFields['custrecord_el_country'][0].value;
                }
            }
            ssData.vesselDeadline = ssObj.getText({fieldId: 'custrecord_ssc_vessel_deadline'}) || '';
            // line
            let lines = [];
            const subId = 'recmachcustrecord_sscd_parent';
            let lineCount = ssObj.getLineCount({sublistId: subId});
            for (let i = 0; i < lineCount; i++) {
                let id = ssObj.getSublistValue({sublistId: subId, fieldId: 'id', line: i});// 明细id
                let lineNo = ssObj.getSublistValue({sublistId: subId, fieldId: 'custrecord_sscd_number', line: i});// 序号
                let scLineId = ssObj.getSublistValue({sublistId: subId, fieldId: 'custrecord_sscd_sclineid', line: i});
                let isPalletStretch = ssObj.getSublistValue({sublistId: subId, fieldId: 'custrecord_sscd_ispalletstretch', line: i});
                let sourcing = ssObj.getSublistValue({sublistId: subId, fieldId: 'custrecord_sscd_sourcing', line: i});
                let json = {
                    id: id,
                    lineNo: lineNo,
                    scLineId: scLineId,
                    isPalletStretch: isPalletStretch,
                    sourcing: sourcing
                };
                lines.push(json);
            }
            ssData.lines = lines;
            log.debug('ssData', ssData);
            return ssData;
        }

        /**
         * 获取销售合同信息
         * @param scId
         * @return {{}}
         */
        const getSCData = (scId) => {
            let scData = {};
            let scObj = record.load({type: 'salesorder', id: scId});
            scData.scId = scId;
            scData.date = scObj.getText({fieldId: 'trandate'});
            scData.exchangeRate = scObj.getValue({fieldId: 'exchangerate'});
            scData.currency = scObj.getValue({fieldId: 'currency'});
            scData.terms = scObj.getValue({fieldId: 'terms'});
            scData.salesRep = scObj.getValue({fieldId: 'salesrep'});
            scData.customerService = scObj.getValue({fieldId: 'custbody_ecm_cusservice'});
            scData.subsidiary = scObj.getValue({fieldId: 'subsidiary'});
            scData.prepaymentRatio = scObj.getValue({fieldId: 'custbody_ecm_prepayment_ratio'});
            scData.prepaymentMethod = scObj.getValue({fieldId: 'custbody_ecm_prepay_method'});
            scData.prepaymentNode = scObj.getValue({fieldId: 'custbody_ecm_prepay_node'});
            scData.prepaymentDays = scObj.getValue({fieldId: 'custbody_ecm_advance_prepaydays'});
            scData.balanceRatio = Number(100).sub(Number(scData.prepaymentRatio));// 余款比例
            scData.balanceNode = scObj.getValue({fieldId: 'custbody_ecm_balance_prepay_node'});
            scData.balanceDays = scObj.getValue({fieldId: 'custbody_ecm_balance_termsdays'});
            scData.balanceMethod = scObj.getValue({fieldId: 'custbody_ecm_balance_prepay_method'});
            scData.deliveryDateType = scObj.getValue({fieldId: 'custbody_ecm_deliverydate_type'});
            scData.termDisplayCN = scObj.getValue({fieldId: 'custbody_ecm_termsdisplay_cn'});
            scData.termDisplayEN = scObj.getValue({fieldId: 'custbody_ecm_termsdisplay_en'});
            scData.warehouseStock = scObj.getValue({fieldId: 'custbody_ecm_iswarehousestock'});
            scData.countryOfDeparture = scObj.getValue({fieldId: 'custbody_ecm_countryof_departure'});
            // item
            let lines = [];
            let lineCount = scObj.getLineCount({sublistId: 'item'});
            for (let i = 0; i < lineCount; i++) {
                let lineNo = scObj.getSublistValue({sublistId: 'item', fieldId: 'custcol_ecm_uniquekey', line: i});
                let rate = scObj.getSublistValue({sublistId: 'item', fieldId: 'rate', line: i});
                let taxCode = scObj.getSublistValue({sublistId: 'item', fieldId: 'taxcode', line: i});
                let taxRate = scObj.getSublistValue({sublistId: 'item', fieldId: 'taxrate1', line: i});
                let landFreight = scObj.getSublistValue({sublistId: 'item', fieldId: 'custcol_ecm_landfreight', line: i});
                let tariff = scObj.getSublistValue({sublistId: 'item', fieldId: 'custcol_ecm_tariff', line: i});
                let oceanFreight = scObj.getSublistValue({sublistId: 'item', fieldId: 'custcol_ecm_oceanfreight', line: i});
                let insuranceFee = scObj.getSublistValue({sublistId: 'item', fieldId: 'custcol_ecm_insurancefee', line: i});
                let clearanceFee = scObj.getSublistValue({sublistId: 'item', fieldId: 'custcol_ecm_customs_clearancefee', line: i});
                let storageFee = scObj.getSublistValue({sublistId: 'item', fieldId: 'custcol_ecm_storagefee', line: i});
                let inspectionCertificationFee = scObj.getSublistValue({sublistId: 'item', fieldId: 'custcol_ecm_inspe_certifi_fee', line: i});
                let shipDate = scObj.getSublistText({sublistId: 'item', fieldId: 'expectedshipdate', line: i});
                let serviceFee = scObj.getSublistValue({sublistId: 'item', fieldId: 'custcol_ecm_commissionunitprice', line: i}) || 0;
                let json = {
                    lineNo: lineNo,
                    rate: rate,
                    taxCode: taxCode,
                    taxRate: taxRate,
                    landFreight: landFreight,
                    tariff: tariff,
                    oceanFreight: oceanFreight,
                    insuranceFee: insuranceFee,
                    clearanceFee: clearanceFee,
                    storageFee: storageFee,
                    inspectionCertificationFee: inspectionCertificationFee,
                    shipDate: shipDate,
                    serviceFee: serviceFee
                }
                lines.push(json);
            }
            scData.lines = lines;
            log.debug('scData', scData);
            return scData;
        }

        /**
         * 获取Main页签下的信息
         * @param params
         * @return {{}}
         */
        const getMainData = (params) => {
            let mainData = {};
            mainData.distributionType = params.custpage_distribution_type || '';
            mainData.supplier = params.custpage_supplier || '';
            mainData.location = params.custpage_location || '';
            mainData.shippingDate = params.custpage_shipping_date || '';
            mainData.vendor = params.custpage_vendor || '';
            mainData.pcId = params.custpage_pur_contract || '';
            mainData.supplyPlanner = params.custpage_supply_planner || '';
            mainData.currency = params.custpage_pur_currency || '';
            // mainData.port = params.custpage_port || '';
            // if (mainData.port) {
            //     let portFields = search.lookupFields({
            //         type: 'customrecord_ecm_loaddest_ports',
            //         id: mainData.port,
            //         columns: ['custrecord_el_country']
            //     });
            //     if (portFields['custrecord_el_country'].length > 0) {
            //         mainData.country = portFields['custrecord_el_country'][0].value;
            //     }
            // }
            log.debug('mainData', mainData);
            return mainData;
        }

        /**
         * 获取下推页面明细信息
         * @param request
         * @return {{items: [], lineData: []}}
         */
        const getLineData = (request) => {
            let lineData = [], items = [];
            let lineCount = request.getLineCount({group: 'custpage_line'});
            if (lineCount && lineCount > 0) {
                for (let i = 0; i < lineCount; i++) {
                    let isCheck = request.getSublistValue({group: 'custpage_line', line: i, name: 'custpage_line_check'});
                    if ('T' == isCheck || true == isCheck) {
                        let json = {
                            ssLineId: request.getSublistValue({group: 'custpage_line', line: i, name: 'custpage_line_sslineid'}) || '',
                            ssNo: request.getSublistValue({group: 'custpage_line', line: i, name: 'custpage_line_ss'}) || '',
                            ssItem: request.getSublistValue({group: 'custpage_line', line: i, name: 'custpage_line_item'}) || '',
                            ssQty: request.getSublistValue({group: 'custpage_line', line: i, name: 'custpage_line_qty'}) || '',
                            ssdQty: request.getSublistValue({group: 'custpage_line', line: i, name: 'custpage_line_dqty'}) || '',
                            scdItem: request.getSublistValue({group: 'custpage_line', line: i, name: 'custpage_line_scditem'}) || '',
                            scdQty: request.getSublistValue({group: 'custpage_line', line: i, name: 'custpage_line_scdqty'}) || '',
                            unit: request.getSublistValue({group: 'custpage_line', line: i, name: 'custpage_line_unit'}) || '',
                            pcLineId: request.getSublistValue({group: 'custpage_line', line: i, name: 'custpage_line_pclineid'}) || '',
                            pcQty: request.getSublistValue({group: 'custpage_line', line: i, name: 'custpage_line_pcqty'}) || '',
                            price: request.getSublistValue({group: 'custpage_line', line: i, name: 'custpage_line_purprice'}) || '',
                            taxCode: request.getSublistValue({group: 'custpage_line', line: i, name: 'custpage_line_taxcode'}) || ''
                        };
                        if (items.indexOf(json.scdItem) === -1) {
                            items.push(json.scdItem);
                        }
                        lineData.push(json);
                    }
                }
            }
            log.debug('lineData', lineData);
            return {lineData, items};
        }

        /**
         * 获取货品信息
         * @param items
         * @return {{}}
         */
        const getItems = (items) => {
            let itemInfos = {};
            let itemSearchObj = search.create({
                type: 'item',
                filters: [
                    ['internalid', 'anyof', items]
                ],
                columns: [
                    search.createColumn({name: 'custitem_ecm_productname_cn'}),
                    search.createColumn({name: 'custitem_ecm_productname_en'}),
                    search.createColumn({name: 'custitem_ecm_cas'}),
                    search.createColumn({name: 'custitem_ecm_wgt_unit'}),
                    search.createColumn({name: 'custitem_ecm_case_package_kg'}),
                    search.createColumn({name: 'custitem_ecm_gross_weight'}),
                    search.createColumn({name: 'custitem_ecm_net_weight'}),
                    search.createColumn({name: 'custitem_ecm_case_volume'}),
                    search.createColumn({name: 'custitem_ecm_msds'}),
                    search.createColumn({name: 'custitem_ecm_certificatebysea'}),
                    search.createColumn({name: 'custitem_ecm_certificatebyair'}),
                    search.createColumn({name: 'custitem_ecm_technicaldescripbyrailway'}),
                    search.createColumn({name: 'custitem_ecm_packaginginstruction'}),
                    search.createColumn({name: 'custitem_ecm_dangerouspackagesyndrome'}),
                    search.createColumn({name: 'custitem_ecm_packingperformanceresutt'}),
                    search.createColumn({name: 'custitem_ecm_package_remk_cn'}),
                    search.createColumn({name: 'unitstype'}),
                ]
            });
            let columns = itemSearchObj.columns;
            let results = itemSearchObj.run().getRange({start: 0, end: 1000});
            results.forEach(res => {
                itemInfos[res.id] = {
                    cn: res.getValue(columns[0]),
                    en: res.getValue(columns[1]),
                    cas: res.getValue(columns[2]),
                    priceUnit: res.getValue(columns[3]),
                    capacity: res.getValue(columns[4]),
                    grossWeight: res.getValue(columns[5]) || 0,
                    netWeight: res.getValue(columns[6]) || 0,
                    volume: res.getValue(columns[7]) || 0,
                    msds: res.getValue(columns[8]) || '',
                    certificateBySea: res.getValue(columns[9]) || '',
                    certificateByAir: res.getValue(columns[10]) || '',
                    certificateByRailway: res.getValue(columns[11]) || '',
                    packagingInstruction: res.getValue(columns[12]) || '',
                    dangerousPackageSyndrome: res.getValue(columns[13]) || '',
                    packingPerformanceResult: res.getValue(columns[14]) || '',
                    packageCN: res.getValue(columns[15]) || '',
                    unitsType: res.getValue(columns[16])
                }
            });
            log.debug('itemInfos', itemInfos);
            return itemInfos;
        }

        /**
         * Item Customs Declaration
         * @param country
         * @param items
         * @return {{}}
         */
        const searchItemDeclaration = (country, items) => {
            let itemDeclaration = {};
            let declarationSearchObj = search.create({
                type: 'customrecord_ecm_customs_declarationinfo',
                filters: [
                    ['isinactive', 'is', 'F'],
                    'and',
                    ['custrecord_ecm_ecd_parent_cust_decl', 'anyof', items],
                    'and',
                    ['custrecord_ecm_ecd_area', 'anyof', country]
                ],
                columns: [
                    search.createColumn({name: 'custrecord_ecm_ecd_parent_cust_decl'}),
                    search.createColumn({name: 'custrecord_ecm_ecd_custom_basicinfo'}),
                    search.createColumn({name: 'custrecord_ecm_ecd_cusdel_name'}),
                    search.createColumn({name: 'custrecord_ecm_ecd_elements_declarati'}),
                    search.createColumn({name: 'custrecord_ecm_ecd_area'}),
                    search.createColumn({name: 'custrecord_ecm_ecd_hs_code'}),
                    search.createColumn({name: 'custrecord_ecm_ecd_conditions_customs'}),
                    search.createColumn({name: 'custrecord_ecm_ecd_taxrefund_rate'}),
                    search.createColumn({name: 'custrecord_ecm_ecd_codition'}),
                    search.createColumn({name: 'custrecord_ecm_ecd_category'}),
                    search.createColumn({name: 'custrecord_ecm_ecd_extax_reftype'}),
                    search.createColumn({name: 'custrecord_ecm_ecd_extax_refund'}),
                    search.createColumn({name: 'custrecord_ecm_ecd_import_tariff_type'}),
                    search.createColumn({name: 'custrecord_ecm_ecd_import_tariffs'}),
                    search.createColumn({name: 'custrecord_ecm_ecd_vat_type'}),
                    search.createColumn({name: 'custrecord_ecm_ecd_vat'}),
                    search.createColumn({name: 'custrecord_ecm_idi_specialcode'}),
                ]
            });
            let columns = declarationSearchObj.columns;
            let results = declarationSearchObj.run().getRange({start: 0, end: 1000});
            results.forEach(res => {
                let itemId = res.getValue(columns[0]);
                itemDeclaration[`${itemId}&${country}`] = {
                    declarationId: res.id,
                    customBasicInfo: res.getValue(columns[1]),
                    cusDelName: res.getValue(columns[2]),
                    declarationElements: res.getValue(columns[3]),
                    area: res.getValue(columns[4]),
                    hsCode: res.getValue(columns[5]),
                    customsConditions: res.getValue(columns[6]),
                    taxRefundRate: res.getValue(columns[7]),
                    codition: res.getValue(columns[8]),
                    category: res.getValue(columns[9]),
                    exRefundType: res.getValue(columns[10]),
                    exRefundTax: res.getValue(columns[11]),
                    importTariffType: res.getValue(columns[12]),
                    importTariffs: res.getValue(columns[13]),
                    vatType: res.getValue(columns[14]),
                    vat: res.getValue(columns[15]),
                    specialCode: res.getValue(columns[16])
                };
            });
            log.debug('itemDeclaration', itemDeclaration);
            return itemDeclaration;
        }

        const createSCD = (ssData, scData, mainData, lineData, itemInfos, itemDeclaration) => {
            // 当配货类型=仓库发货时。supplier取location的子公司，purchase tax code取子公司的仓库提货默认税码
            let locSupplier = '', purTaxCode = '', purCurrency = '';
            if (2 === Number(mainData.distributionType)) {
                let locObj = record.load({type: 'location', id: mainData.location});
                locSupplier = locObj.getValue({fieldId: 'subsidiary'});
                if (locSupplier) {
                    let subObj = record.load({type: 'subsidiary', id: locSupplier});
                    purTaxCode = subObj.getValue({fieldId: 'custrecord_ecm_taxcode'});
                    purCurrency = subObj.getValue({fieldId: 'currency'});
                }
            }
            let ssLines = ssData.lines;
            let scLines = scData.lines;
            let scdObj = record.create({type: 'customrecord_ecm_scd', isDynamic: true});
            scdObj.setValue({fieldId: 'custrecord_scd_sc', value: scData.scId});
            scdObj.setValue({fieldId: 'custrecord_scd_disttype', value: mainData.distributionType});
            scdObj.setValue({fieldId: 'custrecord_scd_vendor', value: mainData.vendor});
            if (2 === Number(mainData.distributionType)) {
                scdObj.setValue({fieldId: 'custrecord_scd_supplier', value: locSupplier});
                scdObj.setValue({fieldId: 'custrecord_scd_purccurrency', value: purCurrency});
            } else {
                scdObj.setValue({fieldId: 'custrecord_scd_supplier', value: mainData.supplier});
                scdObj.setValue({fieldId: 'custrecord_scd_purccurrency', value: mainData.currency});
            }
            scdObj.setValue({fieldId: 'custrecord_scd_location', value: mainData.location});
            scdObj.setText({fieldId: 'custrecord_scd_shipdate', text: mainData.shippingDate});
            scdObj.setValue({fieldId: 'custrecord_scd_portofdeparture', text: ssData.port});
            if (ssData.country) {
                scdObj.setValue({fieldId: 'custrecord_scd_countryofdeparture', value: ssData.country});
            }
            scdObj.setValue({fieldId: 'custrecord_scd_pc', value: mainData.pcId});
            scdObj.setValue({fieldId: 'custrecord_scd_ss', value: ssData.ssId});
            scdObj.setValue({fieldId: 'custrecord_scd_sctype', value: ssData.orderType});
            scdObj.setValue({fieldId: 'custrecord_scd_crossborder', value: ssData.isCross});
            scdObj.setText({fieldId: 'custrecord_scd_dateofsigning', text: scData.date});
            scdObj.setValue({fieldId: 'custrecord_scd_exchangerate', value: scData.exchangeRate});
            scdObj.setValue({fieldId: 'custrecord_scd_currency', value: scData.currency});
            scdObj.setValue({fieldId: 'custrecord_scd_terms', value: scData.terms});
            scdObj.setValue({fieldId: 'custrecord_scd_salesrep', value: scData.salesRep});
            scdObj.setValue({fieldId: 'custrecord_scd_salesservice', value: scData.customerService});
            scdObj.setValue({fieldId: 'custrecord_scd_tradeterms', value: ssData.incoterm});
            scdObj.setValue({fieldId: 'custrecord_scd_demander', value: scData.subsidiary});
            scdObj.setValue({fieldId: 'custrecord_scd_transportmode', value: ssData.shippingMethod});
            scdObj.setValue({fieldId: 'custrecord_scd_portofdestination', value: ssData.destinationPort});
            scdObj.setValue({fieldId: 'custrecord_scd_countryofdestination', value: ssData.destinationCountry});
            scdObj.setValue({fieldId: 'custrecord_scd_otherrequirement', value: ssData.otherMark});
            scdObj.setValue({fieldId: 'custrecord_scd_preproportion', value: scData.prepaymentRatio});
            scdObj.setValue({fieldId: 'custrecord_scd_pretype', value: scData.prepaymentMethod});
            scdObj.setValue({fieldId: 'custrecord_scd_prenode', value: scData.prepaymentNode});
            scdObj.setValue({fieldId: 'custrecord_scd_preday', value: scData.prepaymentDays});
            scdObj.setValue({fieldId: 'custrecord_scd_surpproportion', value: scData.balanceRatio});
            scdObj.setValue({fieldId: 'custrecord_scd_surpnode', value: scData.balanceNode});
            scdObj.setValue({fieldId: 'custrecord_scd_surpday', value: scData.balanceDays});
            scdObj.setValue({fieldId: 'custrecord_scd_surptype', value: scData.balanceMethod});
            scdObj.setValue({fieldId: 'custrecord_scd_japdelivery', value: scData.deliveryDateType});
            scdObj.setValue({fieldId: 'custrecord_scd_paytermscn', value: scData.termDisplayCN});
            scdObj.setValue({fieldId: 'custrecord_scd_paytermsen', value: scData.termDisplayEN});
            scdObj.setValue({fieldId: 'custrecord_scd_memo', value: ssData.memo});
            if ('T' == scData.warehouseStock || true == scData.warehouseStock) {
                scdObj.setValue({fieldId: 'custrecord_scd_warehousestock', value: true});
            }
            scdObj.setValue({fieldId: 'custrecord_scd_supplyplanner', value: mainData.supplyPlanner});

            const subId = 'recmachcustrecord_ecm_scdline_scd';
            if (lineData && lineData.length > 0) {
                lineData.forEach(line => {
                    log.debug('line', line);
                    let lineNo = line.ssLineId;// 合同行ID
                    let newSSLine = ssLines.filter((ssLine) => {
                        return ssLine.scLineId == lineNo;
                    });
                    log.debug('newSSLine', newSSLine);
                    let newSCLine = scLines.filter((scLine) => {
                        return scLine.lineNo == lineNo;
                    });
                    log.debug('newSCLine', newSCLine);
                    scdObj.selectNewLine({sublistId: subId});
                    scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_item', value: line.scdItem});
                    scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_qty', value: line.scdQty});
                    scdObj.setCurrentSublistText({sublistId: subId, fieldId: 'custrecord_scdline_unit', text: line.unit});
                    scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_amt', value: newSCLine[0].rate});
                    scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_taxcode', value: newSCLine[0].taxCode});
                    scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_taxrate', value: newSCLine[0].taxRate});
                    let taxRate = Number(newSCLine[0].taxRate).div(100);
                    let taxAmt = Number(line.scdQty).mul(Number(newSCLine[0].rate)).mul(Number(taxRate));
                    scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_taxgross', value: taxAmt});
                    scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_grossamt', value: Number(line.scdQty).mul(Number(newSCLine[0].rate)).add(Number(taxAmt))});
                    scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_landfreightcost', value: newSCLine[0].landFreight});
                    scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_tariffcost', value: newSCLine[0].tariff});
                    scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_seafreightcost', value: newSCLine[0].oceanFreight});
                    let personCost = Number(newSCLine[0].rate).div(Number(itemInfos[line.scdItem].capacity));
                    personCost = Number(personCost).mul(0.00028).mul(1.1);
                    scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_perscost', value: personCost});
                    scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_clearancecost', value: newSCLine[0].clearanceFee});
                    // scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_storagecost', value: newSCLine[0].storageFee});
                    scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_inspectioncost', value: newSCLine[0].inspectionCertificationFee});
                    scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_punch', value: newSSLine[0].isPalletStretch});
                    scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_sourcing', value: newSSLine[0].sourcing});
                    scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_supplyplanner', value: mainData.supplyPlanner});
                    scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_chname', value: itemInfos[line.scdItem].cn});
                    scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_enname', value: itemInfos[line.scdItem].en});
                    scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_casno', value: itemInfos[line.scdItem].cas});
                    if (ssData.vesselDeadline) {
                        scdObj.setCurrentSublistText({sublistId: subId, fieldId: 'custrecord_scdline_pushipdate', text: ssData.vesselDeadline});
                    }
                    scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_scitem', value: line.ssItem});
                    scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_ssqty', value: line.ssQty});
                    scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_ssscdqty', value: line.ssdQty});
                    scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_priceunit', value: itemInfos[line.scdItem].priceUnit});
                    scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_priceqty', value: Number(line.scdQty).mul(Number(itemInfos[line.scdItem].capacity))});
                    scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_pclineid', value: line.pcLineId});
                    scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_scdlineid', value: newSSLine[0].lineNo});
                    scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_uniquekey', value: newSSLine[0].scLineId});
                    scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_sslineid', value: newSSLine[0].id});
                    scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_purchaseamt', value: line.price});
                    if (2 === Number(mainData.distributionType)) {
                        scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_purchasetaxcode', value: purTaxCode});
                        scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_supplier', value: locSupplier});
                    } else {
                        scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_purchasetaxcode', value: line.taxCode});
                        scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_supplier', value: mainData.supplier});
                    }
                    scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_demander', value: scData.subsidiary});
                    // if (itemInfos[line.scdItem].netWeight) {
                    //     let packingQty = Number(line.scdQty).div(Number(itemInfos[line.scdItem].netWeight));
                    //     scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_packing_qty', value: packingQty});
                    // }
                    // todo package sandbox id = 7 prod id = ?
                    if (7 === Number(itemInfos[line.scdItem].unitsType)) {// 货品主要单位类型=package
                        scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_packing_qty', value: line.scdQty});
                    }
                    let totalGrossWeight = Number(line.scdQty).mul(Number(itemInfos[line.scdItem].grossWeight));
                    scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_gross_weight', value: totalGrossWeight});
                    let totalNetWeight = Number(line.scdQty).mul(Number(itemInfos[line.scdItem].netWeight));
                    scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_net_weight', value: totalNetWeight});
                    let totalVolume = Number(line.scdQty).mul(Number(itemInfos[line.scdItem].volume));
                    scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_volume', value: totalVolume});
                    scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_msds', value: itemInfos[line.scdItem].msds});
                    scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_certifforsea', value: itemInfos[line.scdItem].certificateBySea});
                    scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_certifforair', value: itemInfos[line.scdItem].certificateByAir});
                    scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_technrailway', value: itemInfos[line.scdItem].certificateByRailway});
                    scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_dangpackinginstruction', value: itemInfos[line.scdItem].packagingInstruction});
                    scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_dangsyndrome', value: itemInfos[line.scdItem].dangerousPackageSyndrome});
                    scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_resuttsheet', value: itemInfos[line.scdItem].packingPerformanceResult});
                    let declarationKey = `${line.scdItem}&${scData.countryOfDeparture}`;
                    if (itemDeclaration[declarationKey]) {
                        scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_declarationinfo', value: itemDeclaration[declarationKey].declarationId});
                        if (itemDeclaration[declarationKey].customBasicInfo) {
                            scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_custom_basicinfo', value: itemDeclaration[declarationKey].customBasicInfo});
                        }
                        if (itemDeclaration[declarationKey].cusDelName) {
                            scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_cusdel_name', value: itemDeclaration[declarationKey].cusDelName});
                        }
                        if (itemDeclaration[declarationKey].declarationElements) {
                            let declarationElements = itemDeclaration[declarationKey].declarationElements || '';
                            if (declarationElements) {
                                declarationElements = declarationElements.replaceAll('${package}', itemInfos[line.scdItem].packageCN).replaceAll('${orderDate}', scData.date);
                            }
                            scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_elements_declarati', value: declarationElements});
                        }
                        if (itemDeclaration[declarationKey].area) {
                            scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_area', value: itemDeclaration[declarationKey].area});
                        }
                        if (itemDeclaration[declarationKey].hsCode) {
                            scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_hs_code', value: itemDeclaration[declarationKey].hsCode});
                        }
                        if (itemDeclaration[declarationKey].customsConditions) {
                            scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_conditions_customs', value: String(itemDeclaration[declarationKey].customsConditions).replace('%', '')});
                        }
                        if (itemDeclaration[declarationKey].taxRefundRate) {
                            scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_taxrefund_rate', value: String(itemDeclaration[declarationKey].taxRefundRate).replace('%', '')});
                        }
                        if (itemDeclaration[declarationKey].codition) {
                            scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_codition', value: itemDeclaration[declarationKey].codition});
                        }
                        if (itemDeclaration[declarationKey].category) {
                            scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_category', value: itemDeclaration[declarationKey].category});
                        }
                        if (itemDeclaration[declarationKey].exRefundType) {
                            scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_extax_reftype', value: itemDeclaration[declarationKey].exRefundType});
                        }
                        if (itemDeclaration[declarationKey].exRefundTax) {
                            scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_extax_refund', value: String(itemDeclaration[declarationKey].exRefundTax).replace('%', '')});
                        }
                        // if (itemDeclaration[declarationKey].importTariffType) {
                        //     scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_import_tariff_type', value: itemDeclaration[declarationKey].importTariffType});
                        // }
                        // if (itemDeclaration[declarationKey].importTariffs) {
                        //     scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_import_tariffs', value: String(itemDeclaration[declarationKey].importTariffs).replace('%', '')});
                        // }
                        if (itemDeclaration[declarationKey].vatType) {
                            scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_vat_type', value: itemDeclaration[declarationKey].vatType});
                        }
                        if (itemDeclaration[declarationKey].vat) {
                            scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_vat', value: String(itemDeclaration[declarationKey].vat).replace('%', '')});
                        }
                        if (itemDeclaration[declarationKey].specialCode) {
                            scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_specialcode', value: itemDeclaration[declarationKey].specialCode});
                        }
                    }
                    scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_distributiontype', value: mainData.distributionType});
                    scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_sc', value: scData.scId});
                    scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_ss', value: ssData.ssId});
                    scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_commissionunitprice', value: newSCLine[0].serviceFee});
                    scdObj.setCurrentSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_totalcommission', value: Number(newSCLine[0].serviceFee).mul(Number(line.scdQty))});
                    scdObj.setCurrentSublistText({sublistId: subId, fieldId: 'custrecord_scdline_deliverydate', text: mainData.shippingDate});
                    scdObj.commitLine({sublistId: subId});
                });
            }

            return scdObj.save({enableSourcing: true, ignoreMandatoryFields: true});
        }

        return {onRequest}

    });
