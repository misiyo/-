/**
 * @NApiVersion 2.1
 * @NScriptType ScheduledScript
 *
 * Version		Date			Author			Remarks
 * 1.0          2023/03/01      Mark Z          SP Create Inter PO/IR/SO/IF
 * 2.0          2023/03/16      Mark Z          修改公司间PO/SO税码取值
 * 3.0          2023/03/27      Mark Z          生成成功，勾选公司间交易成功，增加公司间加价比例匹配条件
 * 4.0          2023/03/30      Mark Z          新增ICPO货品单价回写SP Line
 * 5.0          2023/04/07      Mark Z          新增公司间订单日期取值
 * 6.0          2023/04/14      Mark Z          汇率日期取值变更
 * 7.0          2023/04/18      Mark Z          汇率日期再变更
 */
define(['N/query', 'N/record', 'N/runtime', 'N/search', '../tools/common_api.js', '../tools/ramda.min.js', 'N/currency'],
    /**
     * @param{query} query
     * @param{record} record
     * @param{runtime} runtime
     * @param{search} search
     */
    (query, record, runtime, search, commonApi, R, currency) => {

        /**
         * Defines the Scheduled script trigger point.
         * @param {Object} scriptContext
         * @param {string} scriptContext.type - Script execution context. Use values from the scriptContext.InvocationType enum.
         * @since 2015.2
         */
        const execute = (scriptContext) => {
            let spId = runtime.getCurrentScript().getParameter({name: 'custscript_hc_spid'});
            log.debug('spId', spId);
            // let spDate = runtime.getCurrentScript().getParameter({name: 'custscript_hc_spdate'});
            // log.debug('spDate', spDate);
            // 搜索需生成公司间交易单据的明细行
            let {spMainData, spLines, spLineIds, pcIds, scIds} = searchSPLines(spId);
            // 搜索批次
            let spLineLots = searchSPLineLots(spLineIds);
            // 采购合同行备注
            let pcLineMemo = {};
            if (pcIds && pcIds.length > 0) {
                pcLineMemo = searchPC(pcIds);
            }
            // 搜索汇率日期
            let exchangeRateDateArr = [];
            if (scIds && scIds.length > 0) {
                exchangeRateDateArr = searchExchangeRateDate(scIds);
                if (exchangeRateDateArr.length > 0) {
                    // 根据日期排序
                    exchangeRateDateArr.sort((a, b) => {
                        let date1 = new Date(a).getTime();
                        let date2 = new Date(b).getTime();
                        return date1 - date2;
                    });
                }
            }
            let exchangeRateDate = exchangeRateDateArr[0] || '';
            log.debug('exchangeRateDate', exchangeRateDate);
            let handledLines = [];
            let checkFieldsFlag = true;
            // 搜索合同子公司的关联在途虚拟仓&关联客户
            if (spMainData.contractSubsidiary) {
                let subFieldsObj = search.lookupFields({
                    type: 'subsidiary',
                    id: spMainData.contractSubsidiary,
                    columns: ['custrecord_ecm_location', 'custrecord_ecm_relatedcustomer']
                });
                if (subFieldsObj['custrecord_ecm_location'].length > 0) {
                    spMainData.csLocation = subFieldsObj['custrecord_ecm_location'][0].value;
                }
                if (subFieldsObj['custrecord_ecm_relatedcustomer'].length > 0) {
                    spMainData.csRelatedCustomer = subFieldsObj['custrecord_ecm_relatedcustomer'][0].value;
                }
            }

            if (checkFieldsFlag) {
                // 根据供方和需方搜公司间加价比例
                let allICRates = searchInterCompanyRate();
                // 按照明细供方和需方+SCD的采购币种分组
                let groupData = R.groupBy(R.path(['groupKey']))(spLines);
                for (let key in groupData) {
                    let newLines = groupData[key];
                    log.debug(`${key} newLines start`, newLines);
                    let icPO = newLines[0].poId,
                        icSO = newLines[0].soId,
                        icIR = newLines[0].irId,
                        icIF = newLines[0].ifId;
                    let error = '';// 错误信息
                    let keyArr = key.split('&');
                    let pcCurrency = keyArr[0],// 采购币种
                        supplier = keyArr[1],// 供方
                        demander = keyArr[2];// 需方
                    if (!pcCurrency) {
                        error = 'SCD表头的采购币种不能为空';
                    }
                    if (!error) {
                        let exchangeRate = 1;// 默认币种相同汇率为1
                        if (spMainData.contractCurrency != pcCurrency) {
                            // 当SCD采购币种不等于SP签约币种，取当前汇率
                            if (exchangeRateDate) {
                                exchangeRate = currency.exchangeRate({
                                    source: pcCurrency,
                                    target: spMainData.contractCurrency,
                                    date: new Date(exchangeRateDate)
                                });
                            }
                            else {
                                error = '未取到SP生成公司间单据所需汇率日期';
                            }
                        }
                        let icRate = allICRates[`${supplier}&${demander}&${spMainData.warehouseStock}`];
                        if (!icRate) {
                            error = '未维护公司间加价比例';
                        }
                        if (!error) {
                            let supplierTax = icRate.supplierTax;
                            if (!supplierTax && !icSO) {
                                error += '未维护公司间加价比例中的供方税率;';
                            }
                            let demanderTax = icRate.demanderTax;
                            if (!demanderTax && !icPO) {
                                error += '未维护公司间加价比例中的需方税率;'
                            }
                            if (!error) {
                                // 遍历明细计算明细单价
                                let icRatio = toPoint(icRate.ratio);
                                calcLinesRate(newLines, icRatio, spMainData.warehouseStock, exchangeRate);
                                // 判断ICPO、ICSO、ICIR、ICIF是否生成
                                if (!icPO) {
                                    icPO = createICPO(newLines, spMainData, pcLineMemo, icRate, demanderTax, error, pcCurrency, exchangeRate);
                                }
                                if (!icSO && !error) {
                                    if (icPO) {
                                        icSO = createICSO(icPO, newLines, spMainData, pcLineMemo, icRate, supplierTax, error, pcCurrency, exchangeRate);
                                    }
                                }
                                if (!icIR && !error) {
                                    if (icPO) {
                                        icIR = createICIR(icPO, newLines, spLineLots, spMainData, error);
                                    }
                                }
                                if (!icIF && !error) {
                                    if (icSO && icIR) {
                                        // 先获取IR单的批次信息
                                        let irLots = getIRLots(icIR);
                                        icIF = createICIF(icSO, irLots, newLines, spMainData, error);
                                    }
                                }
                                log.debug(`${key} newLines end`, newLines);
                            }
                        }
                    }

                    newLines.forEach(line => {
                        let newJson = {
                            spLineId: line.scdLineId,
                            icPO: icPO,
                            poLineNo: line.poLineNo,
                            icSO: icSO,
                            soLineNo: line.soLineNo,
                            icIR: icIR,
                            icIF: icIF,
                            errorMsg: line.errorMsg || error,
                            rate: line.rate
                        };
                        handledLines.push(newJson);
                    });
                }
            }

            log.debug('handledLines', handledLines);
            if (handledLines && handledLines.length > 0) {
                let isSuccess = true;// 是否全部生成成功
                // 回写SP
                let spObj = record.load({type:'customrecord_ecm_sp', id: spId});
                // let newOrders = [];
                const spSubId = 'recmachcustrecord_scdline_sp';
                let lineCount = spObj.getLineCount({sublistId: spSubId});
                for (let i = 0; i < lineCount; i++) {
                    let spLineId = spObj.getSublistValue({sublistId: spSubId, fieldId: 'id', line: i});
                    for (let j = 0; j < handledLines.length; j++) {
                        if (handledLines[j].spLineId == spLineId) {
                            let poId = spObj.getSublistValue({sublistId: spSubId, fieldId: 'custrecord_scdline_icpo', line: i});
                            let soId = spObj.getSublistValue({sublistId: spSubId, fieldId: 'custrecord_scdline_icso', line: i});
                            let irId = spObj.getSublistValue({sublistId: spSubId, fieldId: 'custrecord_scdline_icir', line: i});
                            let ifId = spObj.getSublistValue({sublistId: spSubId, fieldId: 'custrecord_scdline_icif', line: i});
                            if (!poId && handledLines[j].icPO) {
                                spObj.setSublistValue({sublistId: spSubId, fieldId: 'custrecord_scdline_icpo', line: i, value: handledLines[j].icPO});
                                spObj.setSublistValue({sublistId: spSubId, fieldId: 'custrecord_scdline_icpoline', line: i, value: handledLines[j].poLineNo});
                            }
                            if (!soId && handledLines[j].icSO) {
                                spObj.setSublistValue({sublistId: spSubId, fieldId: 'custrecord_scdline_icso', line: i, value: handledLines[j].icSO});
                                spObj.setSublistValue({sublistId: spSubId, fieldId: 'custrecord_scdline_icsoline', line: i, value: handledLines[j].soLineNo});
                            }
                            if (!irId && handledLines[j].icIR) {
                                spObj.setSublistValue({sublistId: spSubId, fieldId: 'custrecord_scdline_icir', line: i, value: handledLines[j].icIR});
                            }
                            if (!ifId && handledLines[j].icIF) {
                                spObj.setSublistValue({sublistId: spSubId, fieldId: 'custrecord_scdline_icif', line: i, value: handledLines[j].icIF});
                            }
                            spObj.setSublistValue({sublistId: spSubId, fieldId: 'custrecord_scdline_error', line: i, value: handledLines[j].errorMsg});
                            if (handledLines[j].errorMsg) {
                                isSuccess = false;
                            }
                            if (handledLines[j].rate && (poId || handledLines[j].icPO)) {
                                spObj.setSublistValue({sublistId: spSubId, fieldId: 'custrecord_adm_icporate', line: i, value: handledLines[j].rate});
                            }
                            break;
                        }
                    }
                }
                // 全部公司间交易生成成功，勾选字段
                if (isSuccess == true) {
                    spObj.setValue({fieldId: 'custrecord_sp_ictransaction', value: true});
                }
                spObj.save({enableSourcing: true, ignoreMandatoryFields: true});
            }
        }

        /**
         * 创建ICIF
         * @param icSO
         * @param irLots
         * @param newLines
         * @param spMainData
         * @param error
         * @return {string}
         */
        const createICIF = (icSO, irLots, newLines, spMainData, error) => {
            let ifId = '';
            try {
                let ifObj = record.transform({
                    fromType: 'salesorder',
                    fromId: icSO,
                    toType: 'itemfulfillment',
                    isDynamic: true
                });
                if (spMainData.date) {
                    ifObj.setText({fieldId: 'trandate', text: spMainData.date});
                }
                let supplierLocation = newLines[0].supplierLocation;// 供方在途虚拟仓
                if (supplierLocation) {
                    // 给明细添加批次
                    let lineCount = ifObj.getLineCount({sublistId: 'item'});
                    for (let i = 0; i < lineCount; i++) {
                        ifObj.selectLine({sublistId: 'item', line: i});
                        let spLineId = ifObj.getCurrentSublistValue({sublistId: 'item', fieldId: 'custcol_ecm_spline'});
                        if (spLineId) {
                            let lotArr = irLots[spLineId] || [];
                            if (lotArr && lotArr.length > 0) {
                                ifObj.setCurrentSublistValue({sublistId: 'item', fieldId: 'location', value: supplierLocation});
                                let inventoryDetailObj = ifObj.getCurrentSublistSubrecord({sublistId: 'item', fieldId: 'inventorydetail'});
                                lotArr.forEach(lotObj => {
                                    inventoryDetailObj.selectNewLine({sublistId: 'inventoryassignment'});
                                    inventoryDetailObj.setCurrentSublistValue({sublistId: 'inventoryassignment', fieldId: 'issueinventorynumber', value: lotObj.lotid});
                                    inventoryDetailObj.setCurrentSublistValue({sublistId: 'inventoryassignment', fieldId: 'quantity', value: lotObj.lotqty});
                                    inventoryDetailObj.commitLine({sublistId: 'inventoryassignment'});
                                });
                                ifObj.commitLine({sublistId: 'item'});
                            }
                            else {
                                error += `splineid:${spLineId}行批次不足;`;
                            }
                        }
                    }
                }
                else {
                    error = '供方关联在途虚拟仓为空;';
                }
                if (!error) {
                    ifId = ifObj.save({enableSourcing: true, ignoreMandatoryFields: true});
                }
            } catch (e) {
                log.error('create icif error', e);
                error = e.message;
            }
            // if (!error) {
            //     newLines.forEach(line => {
            //         line.ifId = ifId;
            //     });
            // }
            // else {
            //     newLines.forEach(line => {
            //         line.errorMsg = error;
            //     });
            // }
            if (error) {
                newLines.forEach(line => {
                    line.errorMsg = error;
                });
            }
            return ifId;
        }

        /**
         * 获取IR明细批次
         * @param irId
         * @return {any}
         */
        const getIRLots = (irId) => {
            let sql = `
                        SELECT BUILTIN_RESULT.TYPE_INTEGER("TRANSACTION"."ID") AS "ID" /*{id#RAW}*/, 
                                BUILTIN_RESULT.TYPE_INTEGER(transactionLine.custcol_ecm_spline) AS splineid /*{transactionlines.custcol_ecm_spline#RAW}*/, 
                                BUILTIN_RESULT.TYPE_INTEGER(inventoryAssignment_SUB.inventorynumber) AS lotid /*{transactionlines.inventoryassignment.inventorynumber#RAW}*/, 
                                BUILTIN_RESULT.TYPE_STRING(inventoryAssignment_SUB.inventorynumber_0) AS lotno /*{transactionlines.inventoryassignment.inventorynumber.inventorynumber#RAW}*/, 
                                BUILTIN_RESULT.TYPE_FLOAT(inventoryAssignment_SUB.quantity) AS lotqty /*{transactionlines.inventoryassignment.quantity#RAW}*/ 
                        FROM 
                            "TRANSACTION", 
                            (SELECT inventoryAssignment."TRANSACTION" AS transaction_join, inventoryAssignment.transactionline AS transactionline_join, inventoryAssignment.inventorynumber AS inventorynumber, inventoryNumber.inventorynumber AS inventorynumber_0, inventoryAssignment.quantity AS quantity, inventoryAssignment.quantity AS quantity_crit, inventoryAssignment.inventorynumber AS inventorynumber_crit FROM inventoryAssignment, inventoryNumber WHERE inventoryAssignment.inventorynumber = inventoryNumber."ID"(+) ) inventoryAssignment_SUB, 
                            transactionLine 
                        WHERE 
                            (
                                (
                                    (
                                        transactionLine."TRANSACTION" = inventoryAssignment_SUB.transaction_join(+) 
                                        AND 
                                        transactionLine."ID" = inventoryAssignment_SUB.transactionline_join(+)
                                    ) 
                                    AND 
                                    "TRANSACTION"."ID" = transactionLine."TRANSACTION"
                                )
                            )
                            AND 
                            (
                                (
                                    "TRANSACTION"."TYPE" IN ('InvTrnfr', 'ItemRcpt') 
                                    AND 
                                    NVL(transactionLine.mainline, 'F') = ? 
                                    AND 
                                    NVL(transactionLine.taxline, 'F') = ? 
                                    AND 
                                    inventoryAssignment_SUB.quantity_crit > ? 
                                    AND
                                    NOT( inventoryAssignment_SUB.inventorynumber_crit IS NULL ) 
                                    AND 
                                    "TRANSACTION"."ID" = ?
                                )
                            ) 
                        ORDER BY "TRANSACTION"."ID" ASC NULLS LAST`;
            let results = query.runSuiteQL({
                query: sql,
                params:[false,false,0,irId]
            }).asMappedResults();
            let irLots = R.groupBy(R.path(['splineid']))(results);
            log.debug('irLots', irLots);
            return irLots;
        }

        /**
         * 创建ICSO
         * @param icPO
         * @param newLines
         * @param spMainData
         * @param pcLineMemo
         * @param icRate
         * @param supplierTax
         * @param error
         * @param pcCurrency
         * @param exchangeRate
         * @return {string}
         */
        const createICSO = (icPO, newLines, spMainData, pcLineMemo, icRate, supplierTax, error, pcCurrency, exchangeRate) => {
            let soId = '';
            let soObj = record.create({type: 'salesorder', isDynamic: true});
            try {
                soObj.setValue({fieldId: 'entity', value: spMainData.csRelatedCustomer});
                soObj.setValue({fieldId: 'subsidiary', value: newLines[0].supplier});
                soObj.setValue({fieldId: 'custbody_ecm_sp', value: spMainData.spId});
                soObj.setValue({fieldId: 'custbody_ecm_icposo_transaction', value: icPO});
                soObj.setValue({fieldId: 'custbody_ecm_intercompany', value: icRate.id});
                soObj.setValue({fieldId: 'custbody_ecm_interco_ratio', value: String(icRate.ratio).replace('%', '')});
                soObj.setValue({fieldId: 'custbody_ecm_ordertype', value: 3});
                soObj.setValue({fieldId: 'orderstatus', value: 'B'});
                soObj.setValue({fieldId: 'currency', value: spMainData.contractCurrency});
                soObj.setValue({fieldId: 'custbody_echemi_currencyconversion', value: exchangeRate});
                soObj.setValue({fieldId: 'custbody_echemi_purchasecurrency', value: pcCurrency});
                if (spMainData.date) {
                    soObj.setText({fieldId: 'trandate', text: spMainData.date});
                }
                // line
                newLines.forEach((line, i) => {
                    soObj.selectNewLine({sublistId: 'item'});
                    soObj.setCurrentSublistValue({sublistId: 'item', fieldId: 'custcol_ecm_spline', value: line.scdLineId});
                    soObj.setCurrentSublistValue({sublistId: 'item', fieldId: 'custcol_emc_line_no', value: i + 1});
                    soObj.setCurrentSublistValue({sublistId: 'item', fieldId: 'item', value: line.item});
                    soObj.setCurrentSublistValue({sublistId: 'item', fieldId: 'units', value: line.unit});
                    soObj.setCurrentSublistValue({sublistId: 'item', fieldId: 'quantity', value: line.shipQty});
                    soObj.setCurrentSublistValue({sublistId: 'item', fieldId: 'rate', value: line.rate});
                    soObj.setCurrentSublistValue({sublistId: 'item', fieldId: 'taxcode', value: supplierTax});
                    if (line.pcId && line.pcLineId) {
                        if (pcLineMemo[line.pcId]) {
                            if (pcLineMemo[line.pcId][line.pcLineId]) {
                                soObj.setCurrentSublistValue({sublistId: 'item', fieldId: 'description', value: pcLineMemo[line.pcId][line.pcLineId]});
                            }
                        }
                    }
                    soObj.commitLine({sublistId: 'item'});
                    newLines[i].soLineNo = (i + 1);
                });
                soId = soObj.save({enableSourcing: true, ignoreMandatoryFields: true});
            } catch (e) {
                log.error('create icso error', e);
                error = e.message;
            }
            if (!error) {
                if (soId) {
                    // 将so回写到po
                    record.submitFields({
                        type: 'purchaseorder',
                        id: icPO,
                        values: {
                            custbody_ecm_icposo_transaction: soId
                        },
                        options: {
                            enablesourcing: true,
                            ignoreMandatoryFields: true
                        }
                    });
                    // newLines.forEach(line => {
                    //     line.soId = soId;
                    // });
                }
                // return poId;
            }
            else {
                newLines.forEach(line => {
                    line.errorMsg = error;
                });
            }
            return soId;
        }

        /**
         * 创建ICIR
         * @param poId
         * @param newLines
         * @param spLinesLots
         * @param spMainData
         * @param error
         * @return {string}
         */
        const createICIR = (poId, newLines, spLinesLots, spMainData, error) => {
            let irId = '';
            try {
                let irObj = record.transform({
                    fromType: 'purchaseorder',
                    fromId: poId,
                    toType: 'itemreceipt',
                    isDynamic: true
                });
                if (spMainData.date) {
                    irObj.setText({fieldId: 'trandate', text: spMainData.date});
                }
                // 给明细塞仓库+批次
                let lineCount = irObj.getLineCount({sublistId: 'item'});
                for (let i = 0; i < lineCount; i++) {
                    irObj.selectLine({sublistId: 'item', line: i});
                    let spLineId = irObj.getCurrentSublistValue({sublistId: 'item', fieldId: 'custcol_ecm_spline'});
                    let quantity = irObj.getCurrentSublistValue({sublistId: 'item', fieldId: 'quantity'});
                    let lotArr = spLinesLots[spLineId];
                    if (lotArr && lotArr.length > 0) {
                        let totalLotQty = 0;
                        lotArr.forEach(lotObj => {
                            totalLotQty = Number(totalLotQty).add(Number(lotObj.lotqty));
                        });
                        if (totalLotQty != quantity) {
                            error += `spLineId:${spLineId}批次不足;`;
                        }
                        else {
                            irObj.setCurrentSublistValue({sublistId: 'item', fieldId: 'location', value: spMainData.csLocation});
                            let inventoryDetailObj = irObj.getCurrentSublistSubrecord({sublistId: 'item', fieldId: 'inventorydetail'});
                            lotArr.forEach(lotObj => {
                                inventoryDetailObj.selectNewLine({sublistId: 'inventoryassignment'});
                                inventoryDetailObj.setCurrentSublistValue({sublistId: 'inventoryassignment', fieldId: 'receiptinventorynumber', value: lotObj.lotno});
                                inventoryDetailObj.setCurrentSublistValue({sublistId: 'inventoryassignment', fieldId: 'quantity', value: lotObj.lotqty});
                                inventoryDetailObj.commitLine({sublistId: 'inventoryassignment'});
                            });
                            irObj.commitLine({sublistId: 'item'});
                        }
                    }
                    else {
                        error += `spLineId:${spLineId}批次不足;`;
                    }
                }
                if (!error) {
                    irId = irObj.save({enableSourcing: true, ignoreMandatoryFields: true});
                }
            } catch (e) {
                log.error('create icir error', e);
                error = e.message;
            }
            // if (!error) {
            //     newLines.forEach(line => {
            //         line.irId = irId;
            //     });
            // }
            // else {
            //     newLines.forEach(line => {
            //         line.errorMsg = error;
            //     });
            // }
            if (error) {
                newLines.forEach(line => {
                    line.errorMsg = error;
                });
            }
            return irId;
        }

        /**
         * 创建ICPO
         * @param newLines
         * @param spMainData
         * @param pcLineMemo
         * @param icRate
         * @param demanderTax
         * @param error
         * @param pcCurrency
         * @param exchangeRate
         * @return {string|number}
         */
        const createICPO = (newLines, spMainData, pcLineMemo, icRate, demanderTax, error, pcCurrency, exchangeRate) => {
            let poId = '';
            let poObj = record.create({type: 'purchaseorder', isDynamic: true});
            try {
                poObj.setValue({fieldId: 'entity', value: newLines[0].supplierVendor});
                poObj.setValue({fieldId: 'subsidiary', value: spMainData.contractSubsidiary});
                poObj.setValue({fieldId: 'custbody_ecm_sp', value: spMainData.spId});
                poObj.setValue({fieldId: 'custbody_ecm_intercompany', value: icRate.id});
                poObj.setValue({fieldId: 'custbody_ecm_interco_ratio', value: String(icRate.ratio).replace('%', '')});
                poObj.setValue({fieldId: 'custbody_ecm_ordertype', value: 3});// 默认值
                poObj.setValue({fieldId: 'currency', value: spMainData.contractCurrency});
                poObj.setValue({fieldId: 'approvalstatus', value: 2});// Approved
                poObj.setValue({fieldId: 'custbody_echemi_currencyconversion', value: exchangeRate});
                poObj.setValue({fieldId: 'custbody_echemi_purchasecurrency', value: pcCurrency});
                if (spMainData.date) {
                    poObj.setText({fieldId: 'trandate', text: spMainData.date});
                }
                // line
                newLines.forEach((line, i) => {
                    poObj.selectNewLine({sublistId: 'item'});
                    poObj.setCurrentSublistValue({sublistId: 'item', fieldId: 'custcol_ecm_spline', value: line.scdLineId});
                    poObj.setCurrentSublistValue({sublistId: 'item', fieldId: 'custcol_emc_line_no', value: i + 1});
                    poObj.setCurrentSublistValue({sublistId: 'item', fieldId: 'item', value: line.item});
                    poObj.setCurrentSublistValue({sublistId: 'item', fieldId: 'units', value: line.unit});
                    poObj.setCurrentSublistValue({sublistId: 'item', fieldId: 'quantity', value: line.shipQty});
                    poObj.setCurrentSublistValue({sublistId: 'item', fieldId: 'rate', value: line.rate});
                    poObj.setCurrentSublistValue({sublistId: 'item', fieldId: 'taxcode', value: demanderTax});
                    if (line.pcId && line.pcLineId) {
                        if (pcLineMemo[line.pcId]) {
                            if (pcLineMemo[line.pcId][line.pcLineId]) {
                                poObj.setCurrentSublistValue({sublistId: 'item', fieldId: 'description', value: pcLineMemo[line.pcId][line.pcLineId]});
                            }
                        }
                    }
                    poObj.commitLine({sublistId: 'item'});
                    newLines[i].poLineNo = (i + 1);
                });
                poId = poObj.save({enableSourcing: true, ignoreMandatoryFields: true});
            } catch (e) {
                log.error('create icpo error', e);
                error = e.message;
            }
            // if (!error) {
            //     if (poId) {
            //         newLines.forEach(line => {
            //             line.poId = poId;
            //         });
            //     }
            //     return poId;
            // }
            // else {
            //     newLines.forEach(line => {
            //         line.errorMsg = error;
            //     });
            // }
            if (error) {
                newLines.forEach(line => {
                    line.errorMsg = error;
                });
            }
            return poId;
        }

        /**
         * 计算公司间交易单价
         * @param newLines
         * @param icRatio
         * @param warehouseStock
         * @param exchangeRate
         */
        const calcLinesRate = (newLines, icRatio, warehouseStock, exchangeRate) => {
            newLines.forEach(line => {
                let purchaseRate = Number(line.purRate).mul(exchangeRate);
                if ('T' == warehouseStock || true == warehouseStock) {
                    // 勾选库存备货，公司间交易单价=采购价格*(1+公司间加价比例)
                    line.rate = Number(purchaseRate).mul((1 + Number(icRatio)));
                }
                else {
                    // 不勾选库存备货，公司间交易单价=（采购价格+预估费用）*(1+公司间加价比例)
                    // 预估费用=（明细行的每一个预估费用字段值*Item的UNIT CAPACITY）保留2位再汇总
                    let landCost = Number(line.landFreight).mul(Number(line.itemUnitCapacity)).toFixedNew(2);
                    let tariffCost = Number(line.tariff).mul(Number(line.itemUnitCapacity)).toFixedNew(2);
                    let seaCost = Number(line.seaFreight).mul(Number(line.itemUnitCapacity)).toFixedNew(2);
                    let personCost = Number(line.personCost).mul(Number(line.itemUnitCapacity)).toFixedNew(2);
                    let inspectionCost = Number(line.inspectionCost).mul(Number(line.itemUnitCapacity)).toFixedNew(2);
                    let storageCost = Number(line.storageCost).mul(Number(line.itemUnitCapacity)).toFixedNew(2);
                    let clearanceCost = Number(line.clearanceCost).mul(Number(line.itemUnitCapacity)).toFixedNew(2);
                    let totalEstCost = Number(landCost).add(tariffCost).add(seaCost).add(personCost).add(inspectionCost).add(storageCost).add(clearanceCost);
                    line.rate = (Number(purchaseRate).add(Number(totalEstCost))).mul((1 + Number(icRatio)));
                }
            });
        }

        /**
         * 搜索供应商对应SP合同子公司的税码
         * @param vendorId
         * @param spContractSubsidiary
         * @return {string}
         */
        const getVendorTaxItem = (vendorId, spContractSubsidiary) => {
            let taxItem = '';
            let vendorObj = record.load({type: 'vendor', id: vendorId});
            let subLineCount = vendorObj.getLineCount({sublistId: 'submachine'});
            for (let i = 0; i < subLineCount; i++) {
                let subsidiaryId = vendorObj.getSublistValue({sublistId: 'submachine', fieldId: 'subsidiary', line: i});
                if (subsidiaryId == spContractSubsidiary) {
                    taxItem = vendorObj.getSublistValue({sublistId: 'submachine', fieldId: 'taxitem', line: i});
                    break;
                }
            }
            return taxItem;
        }

        /**
         * 根据供方和需方搜公司间加价比例
         * @return {{}}
         */
        const searchInterCompanyRate = () => {
            let icRate = {};
            let icSearchObj = search.create({
                type: 'customrecord_ecm_intercompany',
                filters: [
                    ['isinactive', 'is', 'F']
                ],
                columns: [
                    search.createColumn({name: 'custrecord_ecm_interco_supplier'}),
                    search.createColumn({name: 'custrecord_ecm_interco_demand'}),
                    search.createColumn({name: 'custrecord_ecm_interco_ratio'}),
                    search.createColumn({name: 'custrecord_ecm_interco_suppliertax'}),
                    search.createColumn({name: 'custrecord_ecm_interco_demandtax'}),
                    search.createColumn({name: 'custrecord_ecm_stock'})
                ]
            });
            let columns = icSearchObj.columns;
            let results = commonApi.getAllData(icSearchObj);
            results.forEach(res => {
                let supplier = res.getValue(columns[0]);
                let demander = res.getValue(columns[1]);
                let isStock = res.getValue(columns[5]);
                if ('T' == isStock || true == isStock) {
                    isStock = 'T';
                } else {
                    isStock = 'F';
                }
                icRate[`${supplier}&${demander}&${isStock}`] = {
                    id: res.id,
                    ratio: res.getValue(columns[2]) || '0.0%',
                    supplierTax: res.getValue(columns[3]) || '',
                    demanderTax: res.getValue(columns[4]) || ''
                };
            });
            return icRate;
        }

        // 百分比转小数
        const toPoint = (percent) => {
            let strVal = percent.replace("%", "");
            let numberVal = Number(strVal).div(Number(100));
            return numberVal;
        }

        /**
         * 搜索对应SP明细汇率日期
         * @param scIds
         * @return {[]}
         */
        const searchExchangeRateDate = scIds => {
            let exchangeRateDateArr = [];
            let scSearchObj = search.create({
                type: 'salesorder',
                filters: [
                    ['mainline', 'is', 'T'],
                    'and',
                    ['taxline', 'is', 'F'],
                    'and',
                    ['internalid', 'anyof', scIds]
                ],
                columns: [
                    search.createColumn({name: 'trandate', label: 'Date'}),
                    search.createColumn({name: 'createdfrom', label: 'Created From'}),
                    search.createColumn({
                        name: 'trandate',
                        join: 'createdFrom',
                        label: 'Date'
                    }),
                    search.createColumn({
                        name: 'type',
                        join: 'createdFrom',
                        label: 'Type'
                    })
                ]
            });
            let columns = scSearchObj.columns;
            let results = commonApi.getAllData(scSearchObj);
            results.forEach(res => {
                let date = res.getValue(columns[0]);
                let createdFrom = res.getValue(columns[1]) || '';
                if (createdFrom) {
                    let createdFromType = res.getValue(columns[3]) || '';
                    if ('Estimate' == createdFromType) {
                        date = res.getValue(columns[2])
                    }
                }
                exchangeRateDateArr.push(date);
            });
            return exchangeRateDateArr;
        }

        /**
         * 搜索采购合同行备注
         * @param pcIds
         * @return {{}}
         */
        const searchPC = pcIds => {
            let memo = {};
            let pcSearchObj = search.create({
                type: 'purchaseorder',
                filters: [
                    ['mainline', 'is', 'F'],
                    'and',
                    ['taxline', 'is', 'F'],
                    'and',
                    ['internalid', 'anyof', pcIds]
                ],
                columns: [
                    search.createColumn({name: 'internalid', label: '内部标识', sort: 'ASC'}),
                    search.createColumn({name: 'custcol_emc_line_no', label: '行序号'}),
                    search.createColumn({name: 'memo', label: 'Memo'})
                ]
            });
            let columns = pcSearchObj.columns;
            let results = pcSearchObj.run().getRange({start: 0, end: 1000});
            results.forEach(res => {
                let pcId = res.id;
                let lineNo = res.getValue(columns[1]);
                if (!memo[pcId]) {
                    memo[pcId] = {};
                }
                memo[pcId][lineNo] = res.getValue(columns[2]) || '';
            });
            log.debug('采购合同行备注', memo);
            return memo;
        }

        /**
         * 搜索SP明细相关批次
         * @param spLineIds
         * @return {*}
         */
        const searchSPLineLots = spLineIds => {
            let sql = `
                        SELECT BUILTIN_RESULT.TYPE_INTEGER("TRANSACTION"."ID") AS "ID" /*{id#RAW}*/, 
                                BUILTIN_RESULT.TYPE_INTEGER(transactionLine.custcol_ecm_spline) AS splineid /*{transactionlines.custcol_ecm_spline#RAW}*/, 
                                BUILTIN_RESULT.TYPE_INTEGER(inventoryAssignment_SUB.inventorynumber) AS lotid /*{transactionlines.inventoryassignment.inventorynumber#RAW}*/, 
                                BUILTIN_RESULT.TYPE_STRING(inventoryAssignment_SUB.inventorynumber_0) AS lotno /*{transactionlines.inventoryassignment.inventorynumber.inventorynumber#RAW}*/, 
                                BUILTIN_RESULT.TYPE_FLOAT(inventoryAssignment_SUB.quantity) AS lotqty /*{transactionlines.inventoryassignment.quantity#RAW}*/ 
                        FROM 
                            "TRANSACTION", 
                            (SELECT inventoryAssignment."TRANSACTION" AS transaction_join, inventoryAssignment.transactionline AS transactionline_join, inventoryAssignment.inventorynumber AS inventorynumber, inventoryNumber.inventorynumber AS inventorynumber_0, inventoryAssignment.quantity AS quantity, inventoryAssignment.quantity AS quantity_crit, inventoryAssignment.inventorynumber AS inventorynumber_crit FROM inventoryAssignment, inventoryNumber WHERE inventoryAssignment.inventorynumber = inventoryNumber."ID"(+) ) inventoryAssignment_SUB, 
                            transactionLine 
                        WHERE 
                            (
                                (
                                    (
                                        transactionLine."TRANSACTION" = inventoryAssignment_SUB.transaction_join(+) 
                                        AND 
                                        transactionLine."ID" = inventoryAssignment_SUB.transactionline_join(+)
                                    ) 
                                    AND 
                                    "TRANSACTION"."ID" = transactionLine."TRANSACTION"
                                )
                            )
                            AND 
                            (
                                (
                                    "TRANSACTION"."TYPE" IN ('InvTrnfr', 'ItemRcpt') 
                                    AND 
                                    NVL(transactionLine.mainline, 'F') = ? 
                                    AND 
                                    NVL(transactionLine.taxline, 'F') = ? 
                                    AND 
                                    inventoryAssignment_SUB.quantity_crit > ? 
                                    AND
                                    NOT( inventoryAssignment_SUB.inventorynumber_crit IS NULL ) 
                                    AND 
                                    transactionLine.custcol_ecm_spline IN (${spLineIds.toString()})
                                )
                            ) 
                        ORDER BY "TRANSACTION"."ID" ASC NULLS LAST`;
            let results = query.runSuiteQL({
                query: sql,
                params:[false,false,0]
            }).asMappedResults();
            let lots = R.groupBy(R.path(['splineid']))(results);
            log.debug('lots', lots);
            return lots;
        }

        /**
         * 搜索SP生成公司间交易单据相关信息
         * @param spId
         * @return {{spMainData: {}, spLines: [], spLineIds: [], pcIds: [], scIds: []}}
         */
        const searchSPLines = (spId) => {
            let spMainData = {}, spLines = [], spLineIds = [], pcIds = [], scIds = [];
            spMainData.spId = spId;
            // spMainData.date = spDate;
            let spSearchObj = search.create({
                type: 'customrecord_ecm_scd_line',
                filters: [
                    ['custrecord_scdline_sp', 'anyof', spId],
                    'and',
                    ['custrecord_scdline_demander', 'noneof', '@NONE@'],
                    'and',
                    ['custrecord_scdline_supplier', 'noneof', '@NONE@'],
                    'and',
                    ['formulanumeric: CASE WHEN {custrecord_scdline_supplier} <> {custrecord_scdline_demander} THEN 1 ELSE 0 END', 'equalto', '1'],
                    'and',
                    [
                        ['custrecord_scdline_icpo', 'anyof', '@NONE@'],
                        'or',
                        ['custrecord_scdline_icso', 'anyof', '@NONE@'],
                        'or',
                        ['custrecord_scdline_icir', 'anyof', '@NONE@'],
                        'or',
                        ['custrecord_scdline_icif', 'anyof', '@NONE@']
                    ]
                ],
                columns: [
                    search.createColumn({name: 'custrecord_ecm_scdline_scd', label: 'Sales Contract Distribution'}),
                    search.createColumn({
                        name: 'custrecord_scd_pc',
                        join: 'CUSTRECORD_ECM_SCDLINE_SCD',
                        label: 'Purchase Contract'
                    }),
                    search.createColumn({name: 'custrecord_scdline_pclineid', label: 'Purchase Contract LineID'}),
                    search.createColumn({
                        name: 'custrecord_scd_purccurrency',
                        join: 'CUSTRECORD_ECM_SCDLINE_SCD',
                        label: 'Purchase Currency'
                    }),
                    search.createColumn({name: 'custrecord_scdline_sp', label: 'Shipping Plan'}),
                    search.createColumn({
                        name: 'custrecord_sp_sccurrency',
                        join: 'CUSTRECORD_SCDLINE_SP',
                        label: 'Contract Currency'
                    }),
                    search.createColumn({
                        name: 'custrecord_sp_scsubsidiary',
                        join: 'CUSTRECORD_SCDLINE_SP',
                        label: 'Contract Subsidiary'
                    }),
                    search.createColumn({
                        name: 'custrecord_sp_warehousestock',
                        join: 'CUSTRECORD_SCDLINE_SP',
                        label: 'Warehouse Stock'
                    }),
                    search.createColumn({name: 'custrecord_scdline_item', label: 'Item'}),
                    search.createColumn({name: 'custrecord_scdline_unit', label: 'Unit'}),
                    search.createColumn({name: 'custrecord_scdline_spqty', label: 'Actual shipment Qty'}),
                    search.createColumn({name: 'custrecord_scdline_purchaseamt', label: 'Purchase Rate'}),
                    search.createColumn({name: 'custrecord_scdline_supplier', label: 'Supplier'}),
                    search.createColumn({
                        name: 'custrecord_relatedvendor',
                        join: 'CUSTRECORD_SCDLINE_SUPPLIER',
                        label: '关联供应商记录'
                    }),
                    search.createColumn({
                        name: 'custrecord_ecm_taxcode',
                        join: 'CUSTRECORD_SCDLINE_SUPPLIER',
                        label: '公司间默认税码'
                    }),
                    search.createColumn({
                        name: 'custrecord_ecm_location',
                        join: 'CUSTRECORD_SCDLINE_SUPPLIER',
                        label: '关联在途虚拟仓'
                    }),
                    search.createColumn({name: 'custrecord_scdline_demander', label: 'Demander'}),
                    search.createColumn({name: 'custrecord_scdline_icpo', label: 'ICPO'}),
                    search.createColumn({name: 'custrecord_scdline_icso', label: 'ICSO'}),
                    search.createColumn({name: 'custrecord_scdline_icir', label: 'IC IR'}),
                    search.createColumn({name: 'custrecord_scdline_icif', label: 'IC IF'}),
                    search.createColumn({name: 'custrecord_scdline_landfreightcost', label: 'Land Freight cost'}),// 陆运费
                    search.createColumn({name: 'custrecord_scdline_tariffcost', label: 'Tariff Cost'}),// 关税
                    search.createColumn({name: 'custrecord_scdline_seafreightcost', label: 'Sea Freight Cost'}),// 海运费
                    search.createColumn({name: 'custrecord_scdline_perscost', label: 'Personal premium Cost'}),// 人保费
                    search.createColumn({name: 'custrecord_scdline_inspectioncost', label: 'Inspection and certification Cost'}),// 检验认证费
                    search.createColumn({name: 'custrecord_scdline_storagecost', label: 'Storage Cost'}),// 仓储费
                    search.createColumn({name: 'custrecord_scdline_clearancecost', label: 'Customs clearance Cost'}),// 清关费
                    search.createColumn({name: 'custitem_ecm_case_package_kg', join: 'CUSTRECORD_SCDLINE_ITEM'}),
                    search.createColumn({name: 'custrecord_scdline_sc'})
                ]
            });
            let columns = spSearchObj.columns;
            let results = commonApi.getAllData(spSearchObj);
            results.forEach((res, index) => {
                if (index === 0) {
                    spMainData.contractCurrency = res.getValue(columns[5]) || '';
                    spMainData.contractSubsidiary = res.getValue(columns[6]) || '';
                    let warehouseStock = res.getValue(columns[7]);
                    if ('T' == warehouseStock || true == warehouseStock) {
                        spMainData.warehouseStock = 'T';
                    } else {
                        spMainData.warehouseStock = 'F';
                    }
                }
                let lineJson = {
                    scdLineId: res.id,
                    scdId: res.getValue(columns[0]),
                    pcId: res.getValue(columns[1]),
                    pcLineId: res.getValue(columns[2]),
                    pcCurrency: res.getValue(columns[3]),
                    item: res.getValue(columns[8]),
                    unit: res.getValue(columns[9]),
                    shipQty: res.getValue(columns[10]),
                    purRate: res.getValue(columns[11]),
                    supplier: res.getValue(columns[12]),
                    supplierVendor: res.getValue(columns[13]),
                    supplierTaxCode: res.getValue(columns[14]),
                    supplierLocation: res.getValue(columns[15]),
                    demander: res.getValue(columns[16]),
                    poId: res.getValue(columns[17]) || '',
                    soId: res.getValue(columns[18]) || '',
                    irId: res.getValue(columns[19]) || '',
                    ifId: res.getValue(columns[20]) || '',
                    landFreight: res.getValue(columns[21]) || 0,
                    tariff: res.getValue(columns[22]) || 0,
                    seaFreight: res.getValue(columns[23]) || 0,
                    personCost: res.getValue(columns[24]) || 0,
                    inspectionCost: res.getValue(columns[25]) || 0,
                    storageCost: res.getValue(columns[26]) || 0,
                    clearanceCost: res.getValue(columns[27]) || 0,
                    itemUnitCapacity: res.getValue(columns[28]) || 1,
                    scId: res.getValue(columns[29]) || ''
                };
                lineJson.groupKey = `${lineJson.pcCurrency}&${lineJson.supplier}&${lineJson.demander}`;
                spLines.push(lineJson);
                spLineIds.push(lineJson.scdLineId);
                if (lineJson.pcId && pcIds.indexOf(lineJson.pcId) === -1) {
                    pcIds.push(lineJson.pcId);
                }
                if (lineJson.scId && scIds.indexOf(lineJson.scId) === -1) {
                    scIds.push(lineJson.scId);
                }
            });
            log.debug('spMainData', spMainData);
            log.debug('spLines', spLines);
            log.debug('spLineIds', spLineIds);
            log.debug('pcIds', pcIds);
            log.debug('scIds', scIds);
            return {spMainData, spLines, spLineIds, pcIds, scIds};
        }

        return {execute}

    });
