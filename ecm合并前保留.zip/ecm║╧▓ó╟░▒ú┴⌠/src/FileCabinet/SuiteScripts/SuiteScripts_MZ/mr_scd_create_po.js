/**
 * @NApiVersion 2.1
 * @NScriptType MapReduceScript
 *
 * Version      Date            Author              Memo
 * 1.0          2023/02/27      Mark Zhang          合同配货类型为以销定采和采购合同时生成PO
 * 2.0          2023/03/13      Mark Zhang          PO子公司取SCD supplier，回写明细PO
 * 3.0          2023/03/24      Mark Zhang          生成PO时关联SP
 * 4.0          2023/03/27      Mark Zhang          新增带值
 */
define(['N/record', 'N/runtime', 'N/search', '../tools/common_api.js'],
    /**
     * @param{record} record
     * @param{runtime} runtime
     * @param{search} search
     */
    (record, runtime, search, commonApi) => {
        /**
         * Defines the function that is executed at the beginning of the map/reduce process and generates the input data.
         * @param {Object} inputContext
         * @param {boolean} inputContext.isRestarted - Indicates whether the current invocation of this function is the first
         *     invocation (if true, the current invocation is not the first invocation and this function has been restarted)
         * @param {Object} inputContext.ObjectRef - Object that references the input data
         * @typedef {Object} ObjectRef
         * @property {string|number} ObjectRef.id - Internal ID of the record instance that contains the input data
         * @property {string} ObjectRef.type - Type of the record instance that contains the input data
         * @returns {Array|Object|Search|ObjectRef|File|Query} The input data to use in the map/reduce process
         * @since 2015.2
         */

        const getInputData = (inputContext) => {
            try {
                return getPendingData();
            } catch (e) {
                log.error('getInputData:error', e);
            }
            return [];
        }

        /**
         * 获取需要生成PO的合同配货
         * @return {[]}
         */
        const getPendingData = () => {
            let data = [];
            let filters = [];
            filters.push(['isinactive', 'is', 'F']);
            filters.push('and');
            filters.push(['custrecord_scd_po', 'anyof', '@NONE@']);
            filters.push('and');
            filters.push(['custrecord_scd_disttype', 'anyof', '1', '3']);
            let scdSearchObj = search.create({
                type: 'customrecord_ecm_scd',
                filters: filters,
                columns: [
                    search.createColumn({name: 'internalid'})
                ]
            });
            let results = commonApi.getAllData(scdSearchObj);
            results.forEach(res => {
                data.push(res.id);
            });
            log.debug('data', data);
            return data;
        }

        /**
         * Defines the function that is executed when the map entry point is triggered. This entry point is triggered automatically
         * when the associated getInputData stage is complete. This function is applied to each key-value pair in the provided
         * context.
         * @param {Object} mapContext - Data collection containing the key-value pairs to process in the map stage. This parameter
         *     is provided automatically based on the results of the getInputData stage.
         * @param {Iterator} mapContext.errors - Serialized errors that were thrown during previous attempts to execute the map
         *     function on the current key-value pair
         * @param {number} mapContext.executionNo - Number of times the map function has been executed on the current key-value
         *     pair
         * @param {boolean} mapContext.isRestarted - Indicates whether the current invocation of this function is the first
         *     invocation (if true, the current invocation is not the first invocation and this function has been restarted)
         * @param {string} mapContext.key - Key to be processed during the map stage
         * @param {string} mapContext.value - Value to be processed during the map stage
         * @since 2015.2
         */

        const map = (mapContext) => {
            let scdId = mapContext.value;
            log.debug('scdId', scdId);
            try {
                let scdObj = record.load({type: 'customrecord_ecm_scd', id: scdId});
                let scdData = getSCD(scdObj);
                // 创建PO
                let poInfos = createPO(scdData);
                let poLines = poInfos.poLines;
                // 回写SCD
                scdObj.setValue({fieldId: 'custrecord_scd_po', value: poInfos.poId});
                const subId = 'recmachcustrecord_ecm_scdline_scd';
                let lineCount = scdObj.getLineCount({sublistId: subId});
                for (let i = 0; i < lineCount; i++) {
                    // 将PO填入明细
                    scdObj.setSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_purchaseorder', value: poInfos.poId, line: i});
                    let scdLineId = scdObj.getSublistValue({sublistId: subId, fieldId: 'id', line: i});
                    let poLine = poLines.filter((line) => {
                        return line.scdLineId == scdLineId;
                    });
                    if (poLine && poLine.length > 0) {
                        scdObj.setSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_polineid', line: i, value: poLine[0].poLineNo});
                        scdObj.setSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_poqty', line: i, value: poLine[0].poQty});
                    }
                }
                scdObj.save({enableSourcing: true, ignoreMandatoryFields: true});
            } catch (e) {
                log.error('map:error', e);
            }
        }

        /**
         * 创建PO
         * @param scdData
         * @return {{}}
         */
        const createPO = (scdData) => {
            let poInfos = {};
            let pcLines = [];
            let poObj = record.create({type: 'purchaseorder', isDynamic: true});
            poObj.setValue({fieldId: 'entity', value: scdData.vendor});
            poObj.setValue({fieldId: 'subsidiary', value: scdData.subsidiary});
            poObj.setValue({fieldId: 'currency', value: scdData.currency});
            poObj.setValue({fieldId: 'custbody_ecm_ordertype', value: 2});// 默认-Order
            poObj.setValue({fieldId: 'custbody_ecm_bankinfoma', value: scdData.bankInfo});
            poObj.setValue({fieldId: 'custbody_ecm_bankaccount', value: scdData.bankAccount});
            poObj.setValue({fieldId: 'custbody_ecm_loadingport', value: scdData.loadingPort});
            poObj.setValue({fieldId: 'custbody_ecm_destination_port', value: scdData.destinationPort});
            poObj.setValue({fieldId: 'custbody_ecm_countryof_departure', value: scdData.departureOfCountry});
            poObj.setValue({fieldId: 'custbody_ecm_countryof_destination', value: scdData.destinationOfCountry});
            poObj.setValue({fieldId: 'custbody_ecm_scd', value: scdData.scdId});
            poObj.setValue({fieldId: 'custbody_ecm_sp', value: scdData.spId});
            poObj.setValue({fieldId: 'employee', value: scdData.owner});
            poObj.setValue({fieldId: 'custbody_ecm_supplyplanner', value: scdData.supplyPlanner});
            if (3 === Number(scdData.distributionType)) {// 采购合同
                pcLines = scdData.pcLines;
                poObj.setValue({fieldId: 'custbody_ecm_pcfrom', value: scdData.pcId});
                poObj.setValue({fieldId: 'custbody_ecm_suppliercontractno', value: scdData.supplierContractNo});
                poObj.setValue({fieldId: 'custbody_ecm_signaddress_en', value: scdData.signaddressEn});
                poObj.setValue({fieldId: 'custbody_ecm_signaddress_cn', value: scdData.signaddressCn});
                poObj.setValue({fieldId: 'custbody_ecm_vendoremp', value: scdData.supplierPrincipal});
                poObj.setValue({fieldId: 'custbody_ecm_incoterm', value: scdData.incoterm});
                poObj.setValue({fieldId: 'custbody_ecm_shippingaddress', value: scdData.shippingAddress});
                poObj.setValue({fieldId: 'location', value: scdData.location});
                poObj.setValue({fieldId: 'memo', value: scdData.memo});
                poObj.setValue({fieldId: 'class', value: scdData.class});
                poObj.setValue({fieldId: 'department', value: scdData.department});
                poObj.setValue({fieldId: 'exchangerate', value: scdData.exchangeRate});
            }
            let poLines = [];
            let scdLines = scdData.scdLines;
            for (let i = 0; i < scdLines.length; i++) {
                let lineNo = i + 1;// 行号
                poObj.selectNewLine({sublistId: 'item'});
                poObj.setCurrentSublistValue({sublistId: 'item', fieldId: 'item', value: scdLines[i].item});
                poObj.setCurrentSublistValue({sublistId: 'item', fieldId: 'quantity', value: scdLines[i].qty});
                poObj.setCurrentSublistValue({sublistId: 'item', fieldId: 'units', value: scdLines[i].unit});
                poObj.setCurrentSublistValue({sublistId: 'item', fieldId: 'rate', value: scdLines[i].price});
                poObj.setCurrentSublistValue({sublistId: 'item', fieldId: 'taxcode', value: scdLines[i].taxCode});
                poObj.setCurrentSublistValue({sublistId: 'item', fieldId: 'custcol_ecm_spline', value: scdLines[i].id});
                if (3 === Number(scdData.distributionType)) {
                    let pcLineId = scdLines[i].pcLineId;
                    if (pcLineId) {
                        poObj.setCurrentSublistValue({sublistId: 'item', fieldId: 'custcol_ecm_pcline', value: pcLineId});
                        let pcLine = pcLines.filter((line) => {
                            return line.lineNo == pcLineId;
                        });
                        if (pcLine && pcLine.length > 0) {
                            poObj.setCurrentSublistValue({sublistId: 'item', fieldId: 'description', value: pcLine[0].description});
                        }
                    }
                }
                poObj.setCurrentSublistValue({sublistId: 'item', fieldId: 'custcol_emc_line_no', value: lineNo});
                poObj.commitLine({sublistId: 'item'});
                poLines.push({scdLineId: scdLines[i].id, poLineNo: lineNo, poQty: scdLines[i].qty});
            }
            let poId = poObj.save({enableSourcing: true, ignoreMandatoryFields: true});
            poInfos.poId = poId;
            poInfos.poLines = poLines;
            log.debug('poInfos', poInfos);
            return poInfos;
        }

        /**
         * 获取SCD相关信息
         * @param scdObj
         * @return {{}}
         */
        const getSCD = (scdObj) => {
            let data = {};
            data.scdId = scdObj.id;
            data.spId = '';
            data.distributionType = scdObj.getValue({fieldId: 'custrecord_scd_disttype'});// 配货类型
            data.subsidiary = scdObj.getValue({fieldId: 'custrecord_scd_supplier'});
            data.owner = scdObj.getValue({fieldId: 'owner'});
            data.supplyPlanner = scdObj.getValue({fieldId: 'custrecord_scd_supplyplanner'});
            if (3 === Number(data.distributionType)) {// 采购合同
                data.pcId = scdObj.getValue({fieldId: 'custrecord_scd_pc'}) || '';
                if (data.pcId) {
                    let pcData = getPC(data.pcId);
                    data.supplierContractNo = pcData.supplierContractNo;
                    data.signaddressEn = pcData.signaddressEn;
                    data.signaddressCn = pcData.signaddressCn;
                    data.vendor = pcData.vendor;
                    data.supplierPrincipal = pcData.supplierPrincipal;
                    data.currency = pcData.currency;
                    data.bankInfo = pcData.bankInfo;
                    data.bankAccount = pcData.bankAccount;
                    data.incoterm = pcData.incoterm;
                    data.loadingPort = pcData.loadingPort;
                    data.destinationPort = pcData.destinationPort;
                    data.departureOfCountry = pcData.departureOfCountry;
                    data.destinationOfCountry = pcData.destinationOfCountry;
                    data.shippingAddress = pcData.shippingAddress;
                    data.location = pcData.location;
                    data.memo = pcData.memo;
                    data.class = pcData.class;
                    data.department = pcData.department;
                    data.exchangeRate = pcData.exchangeRate;
                    data.pcLines = pcData.lines;
                }
            }
            if (1 === Number(data.distributionType)) {// 以销定采
                data.vendor = scdObj.getValue({fieldId: 'custrecord_scd_vendor'}) || '';
                data.currency = scdObj.getValue({fieldId: 'custrecord_scd_purccurrency'}) || '';
                data.bankInfo = '';
                data.bankAccount = '';
                if (data.vendor && data.currency) {
                    let bankData = searchBankInfo(data.vendor, data.currency);
                    data.bankInfo = bankData.bankId;
                    data.bankAccount = bankData.bankAccount;
                }
                data.loadingPort = scdObj.getValue({fieldId: 'custrecord_scd_portofdeparture'}) || '';
                data.destinationPort = scdObj.getValue({fieldId: 'custrecord_scd_portofdestination'}) || '';
                data.departureOfCountry = scdObj.getValue({fieldId: 'custrecord_scd_countryofdeparture'}) || '';
                data.destinationOfCountry = scdObj.getValue({fieldId: 'custrecord_scd_countryofdestination'}) || '';
            }
            const subId = 'recmachcustrecord_ecm_scdline_scd';
            let lineCount = scdObj.getLineCount({sublistId: subId});
            let lines = [];
            for (let i = 0; i < lineCount; i++) {
                let spId = scdObj.getSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_sp', line: i}) || '';
                if (spId && !data.spId) {
                    data.spId = spId;
                }
                let lineJson = {
                    id: scdObj.getSublistValue({sublistId: subId, fieldId: 'id', line: i}),
                    item: scdObj.getSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_item', line: i}),
                    unit: scdObj.getSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_unit', line: i}),
                    qty: scdObj.getSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_qty', line: i}),
                    price: scdObj.getSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_purchaseamt', line: i}),
                    taxCode: scdObj.getSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_purchasetaxcode', line: i}),
                    pcLineId: scdObj.getSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_pclineid', line: i}) || ''
                };
                lines.push(lineJson);
            }
            data.scdLines = lines;
            log.debug('data', data);
            return data;
        }

        /**
         * 根据供应商+币种匹配BankInfo记录
         * @param vendor
         * @param currency
         * @return {{}}
         */
        const searchBankInfo = (vendor, currency) => {
            let data = {};
            let bankSearchObj = search.create({
                type: 'customrecord_ecm_bankinfo',
                filters: [
                    ['isinactive', 'is', 'F'],
                    'and',
                    ['custrecord_ecm_vendorbankinfo', 'anyof', vendor],
                    'and',
                    ['custrecord_ecm_bankinfocurrency', 'anyof', currency]
                ],
                columns: [
                    search.createColumn({name: 'custrecord_ecm_bankaccount'})
                ]
            });
            let columns = bankSearchObj.columns;
            let results = bankSearchObj.run().getRange({start: 0, end: 10});
            if (results && results.length > 0) {
                data.bankId = results[0].id;
                data.bankAccount = results[0].getValue(columns[0]) || '';
            }
            return data;
        }

        /**
         * 获取采购合同信息
         * @param pcId
         * @return {{}}
         */
        const getPC = (pcId) => {
            let pcData = {};
            let pcObj = record.load({type: 'purchaseorder', id: pcId});
            pcData.supplierContractNo = pcObj.getValue({fieldId: 'custbody_ecm_suppliercontractno'}) || '';
            pcData.signaddressEn = pcObj.getValue({fieldId: 'custbody_ecm_signaddress_en'}) || '';
            pcData.signaddressCn = pcObj.getValue({fieldId: 'custbody_ecm_signaddress_cn'}) || '';
            pcData.vendor = pcObj.getValue({fieldId: 'entity'});
            pcData.supplierPrincipal = pcObj.getValue({fieldId: 'custbody_ecm_vendoremp'}) || '';
            pcData.currency = pcObj.getValue({fieldId: 'currency'});
            pcData.bankInfo = pcObj.getValue({fieldId: 'custbody_ecm_bankinfoma'}) || '';
            pcData.bankAccount = '';
            if (pcData.bankInfo) {
                let bankFields = search.lookupFields({
                    type: 'customrecord_ecm_bankinfo',
                    id: pcData.bankInfo,
                    columns: ['custrecord_ecm_bankaccount']
                });
                if (bankFields['custrecord_ecm_bankaccount']) {
                    pcData.bankAccount = bankFields['custrecord_ecm_bankaccount'];
                }
            }
            pcData.incoterm = pcObj.getValue({fieldId: 'incoterm'}) || '';
            pcData.loadingPort = pcObj.getValue({fieldId: 'custbody_ecm_loadingport'}) || '';
            pcData.destinationPort = pcObj.getValue({fieldId: 'custbody_ecm_destination_port'}) || '';
            pcData.departureOfCountry = pcObj.getValue({fieldId: 'custbody_ecm_countryof_departure'}) || '';
            pcData.destinationOfCountry = pcObj.getValue({fieldId: 'custbody_ecm_countryof_destination'}) || '';
            pcData.shippingAddress = pcObj.getValue({fieldId: 'custbody_ecm_shippingaddress'}) || '';
            pcData.location = pcObj.getValue({fieldId: 'location'}) || '';
            pcData.memo = pcObj.getValue({fieldId: 'memo'}) || '';
            pcData.class = pcObj.getValue({fieldId: 'class'}) || '';
            pcData.department = pcObj.getValue({fieldId: 'department'}) || '';
            pcData.exchangeRate = pcObj.getValue({fieldId: 'exchangerate'}) || '';
            let lineCount = pcObj.getLineCount({sublistId: 'item'});
            let lines = [];
            for (let i = 0; i < lineCount; i++) {
                let lineNo = pcObj.getSublistValue({sublistId: 'item', fieldId: 'custcol_emc_line_no', line: i});
                let description = pcObj.getSublistValue({sublistId: 'item', fieldId: 'description', line: i});
                let json = {
                    lineNo: lineNo,
                    description: description
                };
                lines.push(json);
            }
            pcData.lines = lines;
            log.debug('pcData', pcData);
            return pcData;
        }

        /**
         * Defines the function that is executed when the reduce entry point is triggered. This entry point is triggered
         * automatically when the associated map stage is complete. This function is applied to each group in the provided context.
         * @param {Object} reduceContext - Data collection containing the groups to process in the reduce stage. This parameter is
         *     provided automatically based on the results of the map stage.
         * @param {Iterator} reduceContext.errors - Serialized errors that were thrown during previous attempts to execute the
         *     reduce function on the current group
         * @param {number} reduceContext.executionNo - Number of times the reduce function has been executed on the current group
         * @param {boolean} reduceContext.isRestarted - Indicates whether the current invocation of this function is the first
         *     invocation (if true, the current invocation is not the first invocation and this function has been restarted)
         * @param {string} reduceContext.key - Key to be processed during the reduce stage
         * @param {List<String>} reduceContext.values - All values associated with a unique key that was passed to the reduce stage
         *     for processing
         * @since 2015.2
         */
        const reduce = (reduceContext) => {

        }


        /**
         * Defines the function that is executed when the summarize entry point is triggered. This entry point is triggered
         * automatically when the associated reduce stage is complete. This function is applied to the entire result set.
         * @param {Object} summaryContext - Statistics about the execution of a map/reduce script
         * @param {number} summaryContext.concurrency - Maximum concurrency number when executing parallel tasks for the map/reduce
         *     script
         * @param {Date} summaryContext.dateCreated - The date and time when the map/reduce script began running
         * @param {boolean} summaryContext.isRestarted - Indicates whether the current invocation of this function is the first
         *     invocation (if true, the current invocation is not the first invocation and this function has been restarted)
         * @param {Iterator} summaryContext.output - Serialized keys and values that were saved as output during the reduce stage
         * @param {number} summaryContext.seconds - Total seconds elapsed when running the map/reduce script
         * @param {number} summaryContext.usage - Total number of governance usage units consumed when running the map/reduce
         *     script
         * @param {number} summaryContext.yields - Total number of yields when running the map/reduce script
         * @param {Object} summaryContext.inputSummary - Statistics about the input stage
         * @param {Object} summaryContext.mapSummary - Statistics about the map stage
         * @param {Object} summaryContext.reduceSummary - Statistics about the reduce stage
         * @since 2015.2
         */
        const summarize = (summaryContext) => {

        }

        return {getInputData, map, reduce, summarize}

    });
