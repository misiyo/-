/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 * Version      Date            Author              Memo
 * 1.0          2023/04/17      Will                到账类型页面
 */
define(['N/http', 'N/record', 'N/redirect', 'N/search', 'N/ui/serverWidget', 'N/config','N/file'],
    /**
     * @param{http} http
     * @param{record} record
     * @param{redirect} redirect
     * @param{search} search
     * @param{serverWidget} serverWidget
     * @param{config} config
     * @param{file} file
     */
    (http, record, redirect, search, serverWidget, config,file) => {
        /**
         * Defines the Suitelet script trigger point.
         * @param {Object} scriptContext
         * @param {ServerRequest} scriptContext.request - Incoming request
         * @param {ServerResponse} scriptContext.response - Suitelet response
         * @since 2015.2
         */
        const onRequest = (scriptContext) => {
            let request = scriptContext.request;
            let response = scriptContext.response;
            let params = request.parameters;
            // log.debug('params', params);
            // log.debug('request', request);
            try {
                if ('GET' == request.method) {
                    let form = createForm(params);
                    response.writePage(form);
                }
            } catch (e) {
                log.error('Error===>', e);
            }
        }

        //创建页面
        function createForm(params) {
            let form = serverWidget.createForm({title:'Select Shipping Plan', hideNavBar: true});
            form.clientScriptModulePath = './cs_collectiontype_info_page.js';
            form.addButton({id: 'custpage_btn_submit', label: 'Submit', functionName: 'doSubmit'});
            form.addButton({id: 'custpage_btn_cancel', label: 'Cancel', functionName: 'doCancel'});

            let ctField = form.addField({id : 'custpage_ct', label : '到款类型', type : 'select', source:'customlist_ecm_collectiontype'});
            ctField.isMandatory = true;

            let idField = form.addField({id : 'custpage_rid', label : 'type', type : 'text'});
            idField.updateDisplayType({displayType : serverWidget.FieldDisplayType.HIDDEN});
            idField.defaultValue = params.rid;

            return form;
        }

        return {onRequest}

    });
