/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 * Version        Date            Author          Memo
 * 1.0            2023/03/24      Will            预收款的认领(1018615)
 * 2.0            2023/03/28      Will            添加表单校验(1018615)
 * 3.0            2023/04/17      Will            校验变更,增加点击到账类型弹出页面(1018615)
 * 4.0            2023/04/18      Will            校验变更(1018615)
 */
define(['N/currentRecord', 'N/runtime', 'N/search', 'N/url'],
    /**
     * @param{currentRecord} currentRecord
     * @param runtime
     * @param search
     */
    function (currentRecord, runtime, search, url) {
        /**
         * Function to be executed after page is initialized.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.mode - The mode in which the record is being accessed (create, copy, or edit)
         *
         * @since 2015.2
         */
        function pageInit(scriptContext) {
            window.writeBack = writeBack;
            window.writeBackCt = writeBackCt;
            InitializePage(scriptContext);
        }

        function InitializePage(scriptContext) {
            var curRec = scriptContext.currentRecord;
            var customForm = curRec.getValue('customform');
            if (customForm == 122) { //TODO Echemi存款表单
                var role = runtime.getCurrentUser().role;
                console.log('role', role);

                // var length = curRec.getLineCount('other');
                // for (var i = 0; i < length; i++) {
                //     var sp = curRec.getSublistValue({sublistId: 'other', fieldId: 'memo', line: i});
                // }
                // if((role != '1127' || role != 1127) || (role != '3' || role != 3)) {
                //     var field = curRec.getField('total');
                //     field.isDisabled = true;
                // }
                var id = curRec.id;
                console.log('id', id);
                jQuery('#other_entity_display').attr('disabled', "true");
                jQuery('#other_account_display').attr('disabled', "true");
                // jQuery('#other_memo_fs').attr('readOnly', "true");
                jQuery('#other_memo_fs').click(function () {
                    var slUrl = url.resolveScript({
                        scriptId: 'customscript_ecm_sl_sp_info_page',
                        deploymentId: 'customdeploy_ecm_sl_sp_info_page'
                    });
                    window.open(slUrl + '&rid=' + encodeURIComponent(id), '_bank', 'height=500,width=500,top=150,left=500');
                });


                jQuery('#other_refnum_fs').click(function () {
                    var slUrl = url.resolveScript({
                        scriptId: 'customscript_ecm_sl_collectiontype_page',
                        deploymentId: 'customdeploy_ecm_sl_collectiontype_page'
                    });
                    window.open(slUrl + '&rid=' + encodeURIComponent(id), '_bank', 'height=500,width=500,top=150,left=500');
                });
            }
        }

        function writeBack(sp) {
            var curRec = currentRecord.get();
            curRec.setCurrentSublistValue({sublistId: 'other', fieldId: 'memo', value: sp});
            // console.log(nlapiSetCurrentLineItemValue('other','memo',sp));
            // console.log(jQuery('#other_memo_fs').parent().attr('disabled', 'true'));
            // console.log(jQuery('input[name="memo"]').attr('disabled','true'));
        }

        function writeBackCt(ct) {
            var curRec = currentRecord.get();
            curRec.setCurrentSublistValue({sublistId: 'other', fieldId: 'refnum', value: ct});
        }

        /**
         * Function to be executed when field is changed.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         * @param {string} scriptContext.fieldId - Field name
         * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
         * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
         *
         * @since 2015.2
         */
        function fieldChanged(scriptContext) {
            var fieldId = scriptContext.fieldId;
            var curRec = scriptContext.currentRecord;
            var role = runtime.getCurrentUser().role;
            var customForm = curRec.getValue('customform');
            if (customForm == 122 /*&& (role != '1127' || role != 1127)*/) {   //TODO Echemi存款表单
                setEntity(fieldId, curRec);
                setAccount(fieldId, curRec)
            }
        }

        function setEntity(fieldId, curRec) {
            if (fieldId == 'memo') {
                var sp = curRec.getCurrentSublistValue({sublistId: 'other', fieldId: 'memo'});
                var ct = curRec.getCurrentSublistValue({sublistId: 'other', fieldId: 'refnum'});
                if (ct != '待认领') {
                    var spSearchObj = search.create({
                        type: "customrecord_ecm_sp",
                        filters:
                            [
                                ["idtext", "is", sp]
                            ],
                        columns:
                            [
                                search.createColumn({name: "custrecord_sp_customer"})
                            ]
                    });
                    var spColumns = spSearchObj.columns;
                    var spRes = spSearchObj.run().getRange({start: 0, end: 1000});
                    if (spRes && spRes.length > 0) {
                        var customer = spRes[0].getValue(spColumns[0]);
                        console.log('customer', customer);
                        if (customer != '') {
                            curRec.setCurrentSublistValue({
                                sublistId: 'other',
                                fieldId: 'entity',
                                value: customer,
                                ignoreFieldChange: true
                            });
                        }
                    }
                }
            }
        }

        function setAccount(fieldId, curRec) {
            if (fieldId == 'refnum') {
                var ct = curRec.getCurrentSublistValue({sublistId: 'other', fieldId: 'refnum'});
                console.log('ct', ct);
                if (ct == '待认领') {
                    curRec.setCurrentSublistValue({
                        sublistId: 'other',
                        fieldId: 'entity',
                        value: 52226,
                        ignoreFieldChange: true
                    });
                }
                var ctSearchObj = search.create({
                    type: "customlist_ecm_collectiontype",
                    filters:
                        [
                            ["name", "is", ct]
                        ],
                    columns:
                        [
                            search.createColumn({name: "internalid", label: "内部 ID"})
                        ]
                });
                var columns = ctSearchObj.columns;
                var res = ctSearchObj.run().getRange({start: 0, end: 1000});
                if (res && res.length > 0) {
                    var ctID = res[0].getValue(columns[0]);
                }
                var customrecord_ecm_collectiontypeSearchObj = search.create({
                    type: "customrecord_ecm_collectiontype",
                    filters:
                        [
                            ["custrecord_ecm_ctype", "anyof", ctID]
                        ],
                    columns:
                        [
                            search.createColumn({name: "custrecord_ecm_account", label: "Account"}),
                            search.createColumn({name: "custrecord_ecm_sprelated", label: "是否关联SP"})
                        ]
                });
                var Columns = customrecord_ecm_collectiontypeSearchObj.columns;
                var result = customrecord_ecm_collectiontypeSearchObj.run().getRange({start: 0, end: 1000});
                if (result && result.length > 0) {
                    var account = result[0].getValue(Columns[0]);
                    console.log('account', account);
                    if (account != '') {
                        curRec.setCurrentSublistValue({
                            sublistId: 'other',
                            fieldId: 'account',
                            value: account,
                            ignoreFieldChange: true
                        });
                    }
                }
            }
        }

        /**
         * Function to be executed when field is slaved.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         * @param {string} scriptContext.fieldId - Field name
         *
         * @since 2015.2
         */
        function postSourcing(scriptContext) {

        }

        /**
         * Function to be executed after sublist is inserted, removed, or edited.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         *
         * @since 2015.2
         */
        function sublistChanged(scriptContext) {

        }

        /**
         * Function to be executed after line is selected.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         *
         * @since 2015.2
         */
        function lineInit(scriptContext) {
            var curRec = scriptContext.currentRecord;
            var customForm = curRec.getValue('customform');
            if (customForm == 122) {
                var entity = curRec.getCurrentSublistValue({sublistId: 'other', fieldId: 'entity'});
                var memo = curRec.getCurrentSublistValue({sublistId: 'other', fieldId: 'memo'});
                if (!memo) {
                    curRec.setCurrentSublistValue({
                        sublistId: 'other',
                        fieldId: 'memo',
                        value: '请单击选择Shipping Plan',
                        ignoreFieldChange: true
                    });
                }
                if (!entity) {
                    curRec.setCurrentSublistValue({
                        sublistId: 'other',
                        fieldId: 'entity',
                        value: 52226,
                        ignoreFieldChange: true
                    });
                }
            }
        }

        /**
         * Validation function to be executed when field is changed.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         * @param {string} scriptContext.fieldId - Field name
         * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
         * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
         *
         * @returns {boolean} Return true if field is valid
         *
         * @since 2015.2
         */
        function validateField(scriptContext) {

        }

        /**
         * Validation function to be executed when sublist line is committed.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         *
         * @returns {boolean} Return true if sublist line is valid
         *
         * @since 2015.2
         */
        function validateLine(scriptContext) {
            var curRec = scriptContext.currentRecord;
            var role = runtime.getCurrentUser().role;
            var customForm = curRec.getValue('customform');
            if (customForm == 122 /*&& (role != '1127' || role != 1127)*/) {
                var entity = curRec.getCurrentSublistValue({sublistId: 'other', fieldId: 'entity'});
                var memo = curRec.getCurrentSublistValue({sublistId: 'other', fieldId: 'memo'});
                var account = curRec.getCurrentSublistValue({sublistId: 'other', fieldId: 'account'});
                var amount = curRec.getCurrentSublistValue({sublistId: 'other', fieldId: 'amount'});
                var refnum = curRec.getCurrentSublistValue({sublistId: 'other', fieldId: 'refnum'});

                if (entity != '' && entity != 52226 && ((/^SP-\d{1,6}$/g).test(memo) == false || memo == '')) {
                    alert("请选择Shipping Plan");
                    return false;
                }
                var ctSearchObj = search.create({
                    type: "customlist_ecm_collectiontype",
                    filters:
                        [
                            ["name", "is", refnum]
                        ],
                    columns:
                        [
                            search.createColumn({name: "internalid", label: "内部 ID"})
                        ]
                });
                var ctColumns = ctSearchObj.columns;
                var result = ctSearchObj.run().getRange({start: 0, end: 1000});
                if (result && result.length > 0) {
                    var ctID = result[0].getValue(ctColumns[0]);
                }
                var collectiontypeSearchObj = search.create({
                    type: "customrecord_ecm_collectiontype",
                    filters:
                        [
                            ["custrecord_ecm_account", "anyof", account],
                            "AND",
                            ["custrecord_ecm_ctype", "anyof", ctID]
                        ],
                    columns:
                        [
                            search.createColumn({name: "custrecord_ecm_sprelated", label: "是否关联SP"})
                        ]
                });
                var columns = collectiontypeSearchObj.columns;
                var res = collectiontypeSearchObj.run().getRange({start: 0, end: 1000});
                if (res && res.length > 0) {
                    var sprelated = res[0].getValue(columns[0]);
                    console.log('sprelated', sprelated);
                }

                if (sprelated == true && ((/^SP-\d{1,6}$/g).test(memo) == false || memo == '')) {
                    alert("请选择Shipping Plan");
                    return false;
                }

                // if ((entity == '' || entity == 52226) && memo != '请单击选择Shipping Plan') { //TODO 待定到款客户
                //     alert("输入的认领客户（待定到款客户）非法");
                //     return false;
                // }

                if (Number(amount) > 0 && refnum == '银行扣费') {
                    alert("金额不可以是正数");
                    return false;
                }
            }
            return true
        }

        /**
         * Validation function to be executed when sublist line is inserted.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         *
         * @returns {boolean} Return true if sublist line is valid
         *
         * @since 2015.2
         */
        function validateInsert(scriptContext) {

        }

        /**
         * Validation function to be executed when record is deleted.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         *
         * @returns {boolean} Return true if sublist line is valid
         *
         * @since 2015.2
         */
        function validateDelete(scriptContext) {

        }

        /**
         * Validation function to be executed when record is saved.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @returns {boolean} Return true if record is valid
         *
         * @since 2015.2
         */
        function saveRecord(scriptContext) {
            var curRec = scriptContext.currentRecord;
            var role = runtime.getCurrentUser().role;
            var customForm = curRec.getValue('customform');
            if (customForm == 122 /*&& (role != '1127' || role != 1127)*/) {
                var total = curRec.getValue('total');
                var paymentAmount = curRec.getValue('custbody_ecm_paymentamount');
                if (paymentAmount != '') {
                    if (Number(total) != Number(paymentAmount)) {
                        alert("认领金额与到款金额不符");
                        return false;
                    }
                }

                var length = curRec.getLineCount('other');
                var lineJson = {};
                for (var i = 0; i < length; i++) {
                    var sp = curRec.getSublistValue({sublistId: 'other', fieldId: 'memo', line: i});
                    var amount = curRec.getSublistValue({sublistId: 'other', fieldId: 'amount', line: i});
                    var json = {
                        sp: sp,
                        amount: amount
                    };
                    if (typeof lineJson[json.sp] == 'undefined') {
                        lineJson[json.sp] = json;
                    } else {
                        var existJson = {};
                        existJson = lineJson[json.sp];
                        existJson.amount = Number(existJson.amount) + Number(amount);
                        lineJson[json.sp] = existJson;
                    }
                }
                var errorInventoryInfo = [];
                for (var key in lineJson) {
                    var spSearchObj = search.create({
                        type: "customrecord_ecm_sp",
                        filters:
                            [
                                ["idtext", "is", key]
                            ],
                        columns:
                            [
                                search.createColumn({name: "custrecord_sp_payamount", label: "应付余款金额"}),
                                search.createColumn({name: "custrecord_sp_preamount"})

                            ]
                    });
                    var columns = spSearchObj.columns;
                    var res = spSearchObj.run().getRange({start: 0, end: 1000});
                    if (res && res.length > 0) {
                        var payAmount = res[0].getValue(columns[0]);
                        var preAmount = res[0].getValue(columns[1]);
                    }
                    var totalAmount = lineJson[key].amount;
                    if (Number(totalAmount) > (Number(payAmount) + Number(preAmount))) {
                        errorInventoryInfo.push(key + "当前认领金额已超过Shipping Plan金额");
                    }
                }

                if (errorInventoryInfo.length > 0) {
                    alert(errorInventoryInfo.join('\n'));
                    return false;
                }
            }
            return true
        }
        
        return {
            pageInit: pageInit,
            fieldChanged: fieldChanged,
            // postSourcing: postSourcing,
            // sublistChanged: sublistChanged,
            // lineInit: lineInit,
            // validateField: validateField,
            validateLine: validateLine,
            // validateInsert: validateInsert,
            // validateDelete: validateDelete,
            saveRecord: saveRecord
        };

    });
