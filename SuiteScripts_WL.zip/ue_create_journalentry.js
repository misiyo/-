/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * version      date            author          remark
 * 1.0          2023/03/02      Will            自动生成公司间抵锄1�7日记贄1�7(1018665)
 */
define(['N/currentRecord', 'N/record', 'N/search', 'N/url', 'N/redirect'],
    /**
     * @param{currentRecord} currentRecord
     * @param{record} record
     * @param{search} search
     * @param{url} url
     */
    (currentRecord, record, search, url, redirect) => {
        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed before record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const beforeSubmit = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {
            if (['delete', 'xedit'].includes(scriptContext.type)) return;
            try {
                if ('create' == scriptContext.type) {
                    createJe(scriptContext);
                } else {
                    modifyJe(scriptContext)
                }
            } catch (e) {
                log.error('Error', e);
            }
        }
        function createJe(scriptContext) {
            let newRec = scriptContext.newRecord;
            let curRec = record.load({type: newRec.type, id: newRec.id});
            let orderType = curRec.getValue('custbody_ecm_ordertype');
            log.debug('orderType', orderType);

            if (orderType == 3) { //TODO 环境校验
                let subsidiary = curRec.getValue('subsidiary');
                log.debug('subsidiary',subsidiary);
                let offSetCompanyId;
                if (subsidiary == 1) { //TODO 环境校验
                    let offSetSubFields = search.lookupFields({type: 'subsidiary', id: subsidiary, columns: ['custrecord_ecm_offsetcompany']});
                    offSetCompanyId = offSetSubFields.custrecord_ecm_offsetcompany;
                } else {
                    let subFields = search.lookupFields({type: 'subsidiary', id: subsidiary, columns: ['parent']});
                    let parSubsidiaryId = subFields.parent;
                    let offSetSubFields = search.lookupFields({type: 'subsidiary', id: parSubsidiaryId, columns: ['custrecord_ecm_offsetcompany']});
                    offSetCompanyId = offSetSubFields.custrecord_ecm_offsetcompany;
                }
                log.debug('offSetCompanyId',offSetCompanyId);

                if (newRec.type == 'invoice') {
                    let currency = curRec.getValue('currency');
                    let date = curRec.getValue('trandate');
                    let total = curRec.getValue('total');
                    let sp = curRec.getValue('custbody_ecm_sp');

                    let obj = record.create({type: 'journalentry',isDynamic: true});
                    obj.setValue({fieldId: 'subsidiary', value: offSetCompanyId[0].value});
                    obj.setValue({fieldId: 'currency', value: currency});
                    obj.setValue({fieldId: 'trandate', value: date});
                    obj.setValue({fieldId: 'custbody_ecm_sp', value: sp});
                    obj.setValue({fieldId: 'custbody_ecm_je_invoice', value: newRec.id});
                    obj.setValue({fieldId: 'custbody_ecm_ordertype', value: orderType});
                    obj.setValue({fieldId: 'memo', value: 'Intercompany Elimination'});
                    obj.setValue({fieldId: 'approvalstatus', value: 2}); //TODO 环境校验


                    obj.selectNewLine({sublistId: 'line'});
                    obj.setCurrentSublistValue({sublistId: 'line', fieldId: 'account', value: 1474, ignoreFieldChange: true});
                    obj.setCurrentSublistValue({sublistId: 'line', fieldId: 'debit', value: total, ignoreFieldChange: true});
                    obj.commitLine({sublistId: 'line'});

                    obj.selectNewLine({sublistId: 'line'});
                    obj.setCurrentSublistValue({sublistId: 'line', fieldId: 'account', value: 1476, ignoreFieldChange: true});
                    obj.setCurrentSublistValue({sublistId: 'line', fieldId: 'credit', value: total, ignoreFieldChange: true});
                    obj.commitLine({sublistId: 'line'});

                    let recId = obj.save({ignoreMandatoryFields: true, enablesourcing: false});
                    log.debug('recId', recId);
                    if (recId) {
                        curRec.setValue({fieldId: 'custbody_ecm_je_setoff', value: recId});
                        curRec.save({ignoreMandatoryFields:true, enablesourcing:false});
                    }
                } else if (newRec.type == 'vendorbill') {
                    let currency = curRec.getValue('currency');
                    let date = curRec.getValue('trandate');
                    let total = curRec.getValue('usertotal');
                    let sp = curRec.getValue('custbody_ecm_sp');

                    let obj = record.create({type: 'journalentry',isDynamic: true});
                    obj.setValue({fieldId: 'subsidiary', value: offSetCompanyId[0].value});
                    obj.setValue({fieldId: 'currency', value: currency});
                    obj.setValue({fieldId: 'trandate', value: date});
                    obj.setValue({fieldId: 'custbody_ecm_sp', value: sp});
                    obj.setValue({fieldId: 'custbody_ecm_je_bill', value: newRec.id});
                    obj.setValue({fieldId: 'custbody_ecm_ordertype', value: orderType});
                    obj.setValue({fieldId: 'memo', value: 'Intercompany Elimination'});
                    obj.setValue({fieldId: 'approvalstatus', value: 2}); //TODO 环境校验


                    obj.selectNewLine({sublistId: 'line'});
                    obj.setCurrentSublistValue({sublistId: 'line', fieldId: 'account', value: 1475, ignoreFieldChange: true});
                    obj.setCurrentSublistValue({sublistId: 'line', fieldId: 'debit', value: total, ignoreFieldChange: true});
                    obj.commitLine({sublistId: 'line'});

                    obj.selectNewLine({sublistId: 'line'});
                    obj.setCurrentSublistValue({sublistId: 'line', fieldId: 'account', value: 1474, ignoreFieldChange: true});
                    obj.setCurrentSublistValue({sublistId: 'line', fieldId: 'credit', value: total, ignoreFieldChange: true});
                    obj.commitLine({sublistId: 'line'});

                    let recId = obj.save({ignoreMandatoryFields: true, enablesourcing: false});
                    log.debug('recId', recId);
                    if (recId) {
                        curRec.setValue({fieldId: 'custbody_ecm_je_setoff', value: recId});
                        curRec.save({ignoreMandatoryFields:true, enablesourcing:false});
                    }
                }
            }
        }

        function modifyJe(scriptContext) {
            let newRec = scriptContext.newRecord;
            let curRec = record.load({type: newRec.type, id: newRec.id});
            if (newRec.type == 'invoice' || newRec.type == 'vendorbill') {
                let jeId = curRec.getValue('custbody_ecm_je_setoff');
                if (jeId) {
                    let currency = curRec.getValue('currency');
                    let date = curRec.getValue('trandate');
                    let total = curRec.getValue('total');
                    let sp = curRec.getValue('custbody_ecm_sp');

                    let obj = record.load({type: 'journalentry', id: jeId, isDynamic: true});
                    obj.setValue({fieldId: 'currency', value: currency});
                    obj.setValue({fieldId: 'trandate', value: date});
                    obj.setValue({fieldId: 'custbody_ecm_sp', value: sp});


                    obj.selectLine({sublistId: 'line', line: 0});
                    obj.setCurrentSublistValue({sublistId: 'line', fieldId: 'debit', value: total, ignoreFieldChange: true});
                    obj.commitLine({sublistId: 'line'});

                    obj.selectLine({sublistId: 'line', line: 1});
                    obj.setCurrentSublistValue({sublistId: 'line', fieldId: 'credit', value: total, ignoreFieldChange: true});
                    obj.commitLine({sublistId: 'line'});

                    obj.save({ignoreMandatoryFields: true, enablesourcing: false});
                }
            }
        }

        return {/*beforeLoad, beforeSubmit,*/ afterSubmit}

    });
