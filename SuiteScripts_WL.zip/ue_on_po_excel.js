/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * Version      Date            Author             Remark
 * 1.0          2023/03/14      Will               采购合同(1019161)
 */
define(['N/record', 'N/runtime', 'N/task', 'N/ui/serverWidget', 'N/url'],
    /**
     * @param{record} record
     * @param{runtime} runtime
     * @param{task} task
     * @param{serverWidget} serverWidget
     * @param{url} url
     */
    (record, runtime, task, serverWidget, url) => {
        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {
            try {
                let newRec = scriptContext.newRecord;
                let type = scriptContext.type;
                let orderType = newRec.getValue('custbody_ecm_ordertype');

                if (type == 'view' && orderType == 1) { //TODO 环境校验
                    addButton(scriptContext);
                }
            } catch (e) {
                log.error('Error', e);
            }
            
        }

        function addButton(scriptContext) {
            let newRec = scriptContext.newRecord;
            let form = scriptContext.form;
            let slUrl = url.resolveScript({
                scriptId: 'customscript_ecm_sl_on_po_excel',
                deploymentId: 'customdeploy_ecm_sl_on_po_excel',
            });

            slUrl += '&rid=' + encodeURIComponent(newRec.id);
            let callSL = "window.open('" + slUrl + "', '_self', '')";
            form.addButton({id: 'custpage_btn_print_excel', label: 'Print PC', functionName: callSL});
            log.debug('slUrl', slUrl)
        }


        /**
         * Defines the function definition that is executed before record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const beforeSubmit = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {

        }

        return {beforeLoad, /*beforeSubmit, afterSubmit*/}

    });
