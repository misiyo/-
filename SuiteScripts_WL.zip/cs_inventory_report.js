/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */
define(['N/currentRecord', 'N/search', '../tools/common_api.js'],
    /**
     * @param{currentRecord} currentRecord
     * @param{search} search
     */
    function (currentRecord, search, commonApi) {

        /**
         * Function to be executed when field is changed.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         * @param {string} scriptContext.fieldId - Field name
         * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
         * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
         *
         * @since 2015.2
         */
        function fieldChanged(scriptContext) {
            var fieldId = scriptContext.fieldId;
            var curRec = scriptContext.currentRecord;
            if (fieldId == 'custpage_item') {
                curRec.setValue('custpage_item_fuzzy','');
                var item_fuzzy = curRec.getField('custpage_item_fuzzy');
                item_fuzzy.isDisabled = true;
            }
            if (fieldId == 'custpage_subsidiary') {
                var subsidiary = curRec.getValue('custpage_subsidiary');
                if (subsidiary) {
                    var brList = getLocation(subsidiary);
                    console.log('brList',brList);
                    var location = curRec.getField('custpage_location');
                    location.removeSelectOption({value: null});
                    location.insertSelectOption({value: '', text: ''});
                    for (var i = 0; i < brList.length; i++) {
                        location.insertSelectOption({value: brList[i].value, text: brList[i].name});
                    }
                }
            }
        }

        /**
         * Validation function to be executed when record is saved.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @returns {boolean} Return true if record is valid
         *
         * @since 2015.2
         */
        function saveRecord(scriptContext) {

        }

        // 搜索按钮
        function searchData() {
            var curRec = currentRecord.get();


            var item = curRec.getValue('custpage_item');
            var itemFuzzy = curRec.getValue('custpage_item_fuzzy');
            var location = curRec.getValue('custpage_location');
            var subsidiary = curRec.getValue('custpage_subsidiary');


            var url = window.location.href;
            var urlArr = url.split('&');
            var newUrl = '&iss=T';

            if (item) {
                newUrl += '&item=' + item;
            }
            if (itemFuzzy) {
                newUrl += '&itemFuzzy=' + itemFuzzy;
            }
            if (location) {
                newUrl += '&location=' + location;
            }
            if (subsidiary) {
                newUrl += '&subsidiary=' + subsidiary;
            }
            setWindowChanged(window, false);
            window.location.href = urlArr[0] + "&" + urlArr[1] + newUrl;
        }


        function getLocation(subsidiary) {
            var brList = [];
            var locationSearchObj = search.create({
                type: "location",
                filters:
                    [
                        ["subsidiary","anyof",subsidiary]
                    ],
                columns:
                    [
                        search.createColumn({
                            name: "name",
                            sort: search.Sort.ASC,
                            label: "名称"
                        }),
                        search.createColumn({name: "internalid", label: "内部 ID"})
                    ]
            });
            var columns = locationSearchObj.columns;
            var res = commonApi.getAllData(locationSearchObj);
            if (res && res.length > 0) {
                for (var i = 0; i < res.length; i++) {
                    var locationNum = res[i].getValue(columns[0]);
                    var id = res[i].getValue(columns[1]);
                    var json = {};
                    json.value = id;
                    json.name = locationNum;
                    brList.push(json);
                }
            }
            return brList;
        }

        /**
         * 获取url指定参数值
         * @param key           参数key
         * @return {string}
         */
        function getUrlParamValue(key) {
            var href = window.location.href;
            var reg = new RegExp("(^|&)" + key + "=([^&]*)(&|$)", "i");
            var r = href.match(reg);
            if (r != null) return r[2];
            return '';
        }

        /**
         * 替换url的指定参数
         * @param {*} url 需要替换的url
         * @param {*} name 参数名称
         * @param {*} value 替换的值
         */
        function replaceQueryString(url, name, value) {
            var re = new RegExp(name + '=[^&]*', 'gi');
            return url.replace(re, name + '=' + value);
        }

        return {
            fieldChanged: fieldChanged,
            // saveRecord: saveRecord,
            searchData: searchData
        };

    });
