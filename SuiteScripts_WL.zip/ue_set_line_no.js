/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * Version        Date            Author          Memo
 * 1.0            2023/02/24      Will Liu        采购订单、收货单、发货单自动生成行序号(1018392)
 * 2.0            2023/03/29      Will Liu        采购订单设置行唯一键(1019454)
 * 3.0            2023/03/29      Will Liu        脚本合并采购合同按钮(1019161)
 *
 */
define(['N/currentRecord', 'N/record', 'N/runtime', 'N/search', 'N/task', 'N/ui/serverWidget', 'N/url'],
    /**
     * @param{currentRecord} currentRecord
     * @param{record} record
     * @param{runtime} runtime
     * @param{search} search
     * @param{task} task
     * @param{serverWidget} serverWidget
     * @param url
     */
    (currentRecord, record, runtime, search, task, serverWidget, url) => {
        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {
            try {
                let newRec = scriptContext.newRecord;
                let type = scriptContext.type;
                let orderType = newRec.getValue('custbody_ecm_ordertype');

                if (type == 'view' && orderType == 1) { //TODO 环境校验
                    addButton(scriptContext);
                }
            } catch (e) {
                log.error('Error', e);
            }
        }

        function addButton(scriptContext) {
            let newRec = scriptContext.newRecord;
            let form = scriptContext.form;
            let slUrl = url.resolveScript({
                scriptId: 'customscript_ecm_sl_on_po_excel',
                deploymentId: 'customdeploy_ecm_sl_on_po_excel',
            });

            slUrl += '&rid=' + encodeURIComponent(newRec.id);
            let callSL = "window.open('" + slUrl + "', '_self', '')";
            form.addButton({id: 'custpage_btn_print_excel', label: 'Print PC', functionName: callSL});
            log.debug('slUrl', slUrl)
        }

        /**
         * Defines the function definition that is executed before record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const beforeSubmit = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {
            if (['delete', 'xedit'].includes(scriptContext.type)) return;
            let oldRec;
            if (scriptContext.oldRecord) {
                oldRec = scriptContext.oldRecord;
            }
            let newRec = scriptContext.newRecord;
            let curRec = record.load({type: newRec.type, id: newRec.id});
            let length;
            let sublistId = '';
            if (newRec.type == 'inventorytransfer') {
                length = curRec.getLineCount('inventory');
                sublistId = 'inventory'
            } else {
                length = curRec.getLineCount('item');
                sublistId = 'item'
            }
            try {
                setLine(curRec, length, oldRec,sublistId);
                if (newRec.type == 'purchaseorder') {
                    let orderType = curRec.getValue('custbody_ecm_ordertype');
                    if (orderType == 3) {
                        for(let index = 0; index < length; index++) {
                            let uniqueKey = curRec.getSublistValue({sublistId:'item',fieldId:'custcol_ecm_uniquekey',line:index});
                            if (uniqueKey == '') {
                                let lineUnKty = curRec.getSublistValue({sublistId:'item',fieldId:'lineuniquekey',line:index});
                                curRec.setSublistValue({sublistId:'item',fieldId:'custcol_ecm_uniquekey',line:index,value:lineUnKty});
                            }
                        }
                    }
                }
                curRec.save({ignoreMandatoryFields: true, enableSourcing: true});
            } catch (e) {
                log.error('Error', e);
            }
        }

        /**
         *设置行序号
         * @param curRec
         * @param length
         * @param oldRec
         * @param sublistId
         */
        function setLine(curRec, length, oldRec,sublistId) {
            let lineNoArr = [];
            let needAddNo = false;
            for (let index = 0; index < length; index++) {
                const lineNo = curRec.getSublistValue({sublistId: sublistId, fieldId: 'custcol_emc_line_no', line: index});
                lineNoArr.push(lineNo);
                if (lineNo == '') {
                    needAddNo = true
                }
            }
            // log.debug('lineNoArr', lineNoArr);
            if (oldRec) {
                if (needAddNo == true) {
                    let oldLength = oldRec.getLineCount(sublistId);
                    let maxNo = 0;
                    for (let index = 0; index < oldLength; index++) {
                        const lineNo = oldRec.getSublistValue({
                            sublistId: sublistId,
                            fieldId: 'custcol_emc_line_no',
                            line: index
                        });
                        if (Number(lineNo) > Number(maxNo)) {
                            maxNo = lineNo
                        }
                    }

                    for (let i = 0; i < lineNoArr.length; i++) {
                        if (lineNoArr[i] == '') {
                            curRec.setSublistValue({
                                sublistId: sublistId,
                                fieldId: 'custcol_emc_line_no',
                                line: i,
                                value: maxNo + 1
                            });
                            maxNo = maxNo + 1;
                        }
                    }
                }
            } else {
                for (let index = 0; index < length; index++) {
                    curRec.setSublistValue({
                        sublistId: sublistId,
                        fieldId: 'custcol_emc_line_no',
                        line: index,
                        value: index + 1
                    });
                }
            }
        }
        return {beforeLoad, /*beforeSubmit,*/ afterSubmit}

    });
