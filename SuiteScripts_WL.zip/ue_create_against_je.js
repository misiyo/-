/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * Version        Date            Author            Memo
 * 1.0            2023/04/03      Will              账单生成冲销日记账(1019438)
 */
define(['N/currentRecord', 'N/record', 'N/search', 'N/url', 'N/redirect', 'N/https', 'N/runtime', 'SuiteScripts/tools/common_api.js'],
    /**
     * @param{currentRecord} currentRecord
     * @param{record} record
     * @param{search} search
     * @param{url} url
     * @param redirect
     * @param https
     * @param runtime
     * @param commonApi
     */
    (currentRecord, record, search, url, redirect, https, runtime, commonApi) => {
        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed before record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const beforeSubmit = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {
            if (['delete', 'xedit'].includes(scriptContext.type)) return;
            let newRec = scriptContext.newRecord;
            let curRec = record.load({type: newRec.type, id: newRec.id});
            getData(curRec);
        }

        function createAgainstJe(curRec,obj,orderType) {
            let sp = curRec.getValue('custbody_ecm_sp');
            let subsidiary = obj.getValue('subsidiary');
            let currency = obj.getValue('currency');
            let time = formatNowDate('M/D/YYYY');
            let debit = obj.getSublistValue({sublistId: 'line', fieldId: 'debit', line: 0});

            let jeObj = record.create({type: 'journalentry', isDynamic: true});
            let bill = obj.getValue('custbody_ecm_je_bill');
            jeObj.setValue({fieldId: 'subsidiary', value: subsidiary});
            jeObj.setValue({fieldId: 'currency', value: currency});
            jeObj.setText({fieldId: 'trandate', text: time});
            jeObj.setValue({fieldId: 'custbody_ecm_sp', value: sp});
            jeObj.setValue({fieldId: 'custbody_ecm_je_bill', value: bill});
            jeObj.setValue({fieldId: 'approvalstatus', value: 2});
            jeObj.setValue({fieldId: 'custbody_ecm_ordertype', value: orderType});
            jeObj.setValue({fieldId: 'memo', value: 'Intercompany Elimination'});

            jeObj.selectNewLine({sublistId: 'line'});
            jeObj.setCurrentSublistValue({
                sublistId: 'line',
                fieldId: 'account',
                value: 1474,
                ignoreFieldChange: true
            });
            jeObj.setCurrentSublistValue({
                sublistId: 'line',
                fieldId: 'debit',
                value: debit,
                ignoreFieldChange: true
            });
            jeObj.commitLine({sublistId: 'line'});

            jeObj.selectNewLine({sublistId: 'line'});
            jeObj.setCurrentSublistValue({
                sublistId: 'line',
                fieldId: 'account',
                value: 1475,
                ignoreFieldChange: true
            });
            jeObj.setCurrentSublistValue({
                sublistId: 'line',
                fieldId: 'credit',
                value: debit,
                ignoreFieldChange: true
            });
            jeObj.commitLine({sublistId: 'line'});

            let recId = jeObj.save({ignoreMandatoryFields: true, enablesourcing: false});
            log.debug('recId', recId);
            if (recId) {
                curRec.setValue({fieldId: 'custbody_echemi_writeoffcertificates', value: recId});
                curRec.save({ignoreMandatoryFields: true, enablesourcing: false});
            }
        }

        function getData(curRec) {
            try {
                let length = curRec.getLineCount('apply');
                for (let i = 0; i < length; i++) {
                    let billId = curRec.getSublistValue({sublistId: 'apply', fieldId: 'internalid', line: i});
                    let billObj = record.load({type: 'vendorbill', id: billId, isDynamic: true});
                    let orderType = billObj.getValue('custbody_ecm_ordertype');
                    let status = billObj.getValue('status');
                    let jeId = billObj.getValue('custbody_ecm_je_setoff');
                    let AgainstJe = billObj.getValue('custbody_echemi_writeoffcertificates');
                    if (orderType == 3 && status == '全额付款' && AgainstJe == '' && jeId) {
                        let jeObj = record.load({type: 'journalentry', id: jeId, isDynamic: true});
                        createAgainstJe(billObj,jeObj,orderType);
                    }
                }
            } catch (e) {
                log.error('Error', e);
            }
        }

        /**
         * 获取当前日期
         * @param dateformat
         * @return {string|boolean}
         */
        const formatNowDate = (dateformat) => {
            let now = commonApi.getNowDateTime(true);
            let dateArr = now.split('/');
            let year = dateArr[0], month = dateArr[1], day = dateArr[2];
            if ('' == year || '' == month || '' == day || '' == dateformat) {
                return false;
            }
            if ('YYYY年M月D日' == dateformat) {
                return year + '年' + Number(month) + '月' + Number(day) + '日 ';
            } else if ('YYYY年MM月DD日' == dateformat) {
                return year + '年' + month + '月' + day + '日 ';
            } else if ('YYYY-M-D' == dateformat) {
                return year + '-' + Number(month) + '-' + Number(day);
            } else if ('YYYY-MM-DD' == dateformat) {
                return year + '-' + month + '-' + day;
            } else if ('YYYY M D' == dateformat) {
                return year + ' ' + Number(month) + ' ' + Number(day);
            } else if ('YYYY MM DD' == dateformat) {
                return year + ' ' + month + ' ' + day;
            } else if ('YYYYMMDD' == dateformat) {
                return year + month + day;
            } else if ('YYYY/M/D' == dateformat) {
                return year + '/' + Number(month) + '/' + Number(day);
            } else if ('YYYY/MM/DD' == dateformat) {
                return year + '/' + month + '/' + day;
            } else if ('M/D/YYYY' == dateformat) {
                return Number(month) + '/' + Number(day) + '/' + year;
            } else if ('MM/DD/YYYY' == dateformat) {
                return month + '/' + day + '/' + year;
            } else if ('D/M/YYYY' == dateformat) {
                return Number(day) + '/' + Number(month) + '/' + year;
            } else if ('DD/MM/YYYY' == dateformat) {
                return day + '/' + month + '/' + year;
            } else if ('D-Mon-YYYY' == dateformat) {
                let months = ["1", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                let tempMonth = months[month - 1];
                return Number(day) + '-' + tempMonth + '月-' + year;
            } else if ('DD-Mon-YYYY' == dateformat) {
                let months = ["1", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                let tempMonth = months[month - 1];
                return day + '-' + tempMonth + '月-' + year;
            } else if ('D.M.YYYY' == dateformat) {
                return Number(day) + '.' + Number(month) + '.' + year;
            } else if ('DD.MM.YYYY' == dateformat) {
                return day + '.' + month + '.' + year;
            }
        }

        return {/*beforeLoad, beforeSubmit,*/ afterSubmit}

    });
