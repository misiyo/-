/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 * Version      Date            Author              Memo
 * 1.0          2023/02/28      Will Liu            库存现有量报表(1018831)
 */
define(['N/https', 'N/record', 'N/search', 'N/ui/serverWidget', 'N/redirect', 'N/query', 'N/file', '../tools/common_api.js'],
    /**
     * @param{https} https
     * @param{record} record
     * @param{search} search
     * @param{serverWidget} serverWidget
     * @param{redirect} redirect
     * @param query
     * @param file
     * @param commonApi
     */
    (https, record, search, serverWidget,redirect, query,file, commonApi) => {
        // 明细字段
        const sublistField = [
            {id: 'custpage_line_id', type: 'text', label: 'No.', displayType: serverWidget.FieldDisplayType.INLINE},
            {id: 'custpage_line_item', type: 'select', source:'item', label: 'Item/SKU', displayType: serverWidget.FieldDisplayType.INLINE},
            {id: 'custpage_line_location', type: 'text', label: 'Location', displayType: serverWidget.FieldDisplayType.INLINE},
            {id: 'custpage_line_onhand', type: 'text', label: 'Onhand', displayType: serverWidget.FieldDisplayType.INLINE},
            {id: 'custpage_line_available', type: 'text', label: 'Avaliable', displayType: serverWidget.FieldDisplayType.INLINE},
            {id: 'custpage_line_seriallotnumber', type: 'text', label: 'Serial/lot Number'},
            {id: 'custpage_line_statuses', type: 'text', label: 'Inventory Statuses', displayType: serverWidget.FieldDisplayType.INLINE},
            {id: 'custpage_line_chinese_name', type: 'text', label: 'Chinese Name', displayType: serverWidget.FieldDisplayType.INLINE},
            {id: 'custpage_line_english_name', type: 'text', label: 'English Name', displayType: serverWidget.FieldDisplayType.INLINE},
            {id: 'custpage_line_brand', type: 'text', label: 'Brand', displayType: serverWidget.FieldDisplayType.INLINE},
            {id: 'custpage_line_package_spec', type: 'text', label: 'Package Spec', displayType: serverWidget.FieldDisplayType.INLINE},
            {id: 'custpage_line_delivery_remarks', type: 'text', label: 'Package Remarks EN', displayType: serverWidget.FieldDisplayType.INLINE},
            {id: 'custpage_line_remain_subsidiary', type: 'text', label: 'Subsidiary', displayType: serverWidget.FieldDisplayType.INLINE},
        ];
        /**
         * Defines the Suitelet script trigger point.
         * @param {Object} scriptContext
         * @param {ServerRequest} scriptContext.request - Incoming request
         * @param {ServerResponse} scriptContext.response - Suitelet response
         * @since 2015.2
         */
        const onRequest = (scriptContext) => {
            let request = scriptContext.request;
            let response = scriptContext.response;
            let params = request.parameters;
            // log.debug('params', params);

            if ('GET' == request.method) {
                let form = createForm(params);
                response.writePage(form);
            } else {
                let ret = getData(request);
                let fileRows = [];
                let header =[];
                sublistField.forEach(function (sub) {
                    header.push(sub.label);
                });
                fileRows.push(header.join(','));
                for (let i = 0; i < ret.length; i++) {
                    let line = [];
                    let lineData = ret[i];
                    for (let key in lineData) {
                        let thisVal = lineData[key];
                        thisVal = '"' + thisVal.replace(/\'/g,"'") + '"';
                        line.push(thisVal);
                    }
                    fileRows.push(line.join(','));
                }
                let csvStr = fileRows.join('\n');
                let timestamp = new Date().getTime();
                let newName = 'Inventory Worksheet-' + timestamp;
                let csvFile = file.create({
                    name : newName + '.csv',
                    fileType : file.Type.CSV,
                    contents : csvStr,
                    encoding: file.Encoding.UTF_8
                });
                response.writeFile(csvFile);
            }
        }

        /**
         * 获取需要生成CSV数据
         * @param req
         * @returns {{}}
         */
        function getData(req) {
            let sublistId = 'custpage_sublist_line';
            let list = [];
            let count = req.getLineCount({group:sublistId});
            for(let len = 0; len < count; len++){
                let json = {};
                json.line_id = req.getSublistValue({group: sublistId,name:'custpage_line_id',line:len});
                json.item = req.getSublistValue({group: sublistId,name:'custpage_line_item',line:len});
                json.location = req.getSublistValue({group: sublistId,name:'custpage_line_location',line:len});
                json.onhand = req.getSublistValue({group: sublistId,name:'custpage_line_onhand',line:len});
                json.available = req.getSublistValue({group: sublistId,name:'custpage_line_available',line:len});
                json.seriallotnumber = req.getSublistValue({group: sublistId,name:'custpage_line_seriallotnumber',line:len});
                json.statuses = req.getSublistValue({group: sublistId,name:'custpage_line_statuses',line:len});
                json.cn = req.getSublistValue({group: sublistId,name:'custpage_line_chinese_name',line:len});
                json.en = req.getSublistValue({group: sublistId,name:'custpage_line_english_name',line:len});
                json.brand = req.getSublistValue({group: sublistId,name:'custpage_line_brand',line:len});
                json.spec = req.getSublistValue({group: sublistId,name:'custpage_line_package_spec',line:len});
                json.remarks = req.getSublistValue({group: sublistId,name:'custpage_line_delivery_remarks',line:len});
                json.subsidiary = req.getSublistValue({group: sublistId,name:'custpage_line_remain_subsidiary',line:len});
                list.push(json)
            }
            // log.debug('list',list);
            return list ;
        }


        // 创建页面
        function createForm(params) {
            let form = serverWidget.createForm({title: '库存现有量查询', hideNavBar: false});
            form.clientScriptModulePath = './cs_inventory_report.js';
            form.addSubmitButton({label: 'Export CSV'});
            form.addButton({id: 'custpage_search', label: 'Search', functionName: 'searchData'});

            form.addFieldGroup({id: 'custpage_field_group', label: 'Filter'});

            let itemField = form.addField({id: 'custpage_item', label: 'Item', type: 'select', source:'item', container: 'custpage_field_group'});
            if (params.item) {
                itemField.defaultValue = params.item;
            }

            let itemFuzzyField = form.addField({id: 'custpage_item_fuzzy', label: 'Item Fuzzy', type: 'text', container: 'custpage_field_group'});
            if (params.itemFuzzy) {
                itemFuzzyField.defaultValue = params.itemFuzzy;
            }

            let locationField = form.addField({id: 'custpage_location', label: 'Location', type: 'select', container: 'custpage_field_group'});
            //subsidiary没有值时显示全部location
            if (!params.subsidiary) {
                let allLocationList = getAllLocation();
                locationField.addSelectOption({value: '', text: ''});
                allLocationList.forEach(lc => {
                    locationField.addSelectOption({value: lc.value, text: lc.name});
                });
            }
            if (params.location) {
                locationField.defaultValue = params.location;
            }

            let subsidiaryField = form.addField({id: 'custpage_subsidiary', label: 'Subsidiary', type: 'select', container: 'custpage_field_group'});
            //显示全部有location的subsidiary
            let allSubsidiaryList = getAllSubsidiary();
            subsidiaryField.addSelectOption({value: '', text: ''});
            allSubsidiaryList.forEach(sub => {
                subsidiaryField.addSelectOption({value: sub.value, text: sub.name});
            });
            if (params.subsidiary) {
                subsidiaryField.defaultValue = params.subsidiary;
            }

            //subsidiary有值时显示该subsidiary下的所有location
            if (params.subsidiary) {
                let lcList = getLocation(params.subsidiary);
                lcList.forEach(lc => {
                    locationField.addSelectOption({value: lc.value, text: lc.name});
                });
            }


            // line
            let line = form.addSublist({id: 'custpage_sublist_line', label: 'Search Result', type: 'list'});
            if (sublistField && sublistField.length > 0) {
                sublistField.forEach(function (value) {
                    let line_field;
                    if (value.type == 'select') {
                        line_field = line.addField({
                            id: value.id,
                            type: value.type,
                            label: value.label,
                            source: value.source
                        });
                    } else {
                        line_field = line.addField({id: value.id, type: value.type, label: value.label});
                    }
                    if (value.displayType) {
                        line_field.updateDisplayType({displayType: value.displayType});
                    }
                });
            }
            if ('T' == params.iss) {
                let data = getInventoryData(params);//搜索标准库存数据
                let InventoryDetailData = getInventoryDetailData(params);//搜索自定义库存数据
                if (InventoryDetailData.length > 0) {
                    let newArr = InventoryDetailData.filter((v) => data.some((val) => val.key == v.key));//匹配标准库存数据和自定义库存数据，获取自定义库存数据中匹配成功的那部分
                    // log.debug('newArr',newArr);
                    //根据自定义库存数据中匹配成功的那部分，修改标准库存数据的可用量
                    if (newArr && newArr.length > 0) {
                        for (let i = 0; i < data.length; i++) {
                            let key = data[i].key;
                            for (let j = 0; j < newArr.length; j++) {
                                let newArrKey = newArr[j].key;
                                if (newArrKey == key) {
                                    data[i].available = Number(data[i].onHand) - Number(newArr[j].quantity)
                                }
                            }
                        }
                        log.debug('formatData',data);
                    }
                }
                let index = 0;
                for (let i = 0; i < data.length; i++) {
                    line.setSublistValue({id: 'custpage_line_id', line: index, value: data[i].no});
                    line.setSublistValue({id: 'custpage_line_item', line: index, value: data[i].itemId || ' '});
                    line.setSublistValue({id: 'custpage_line_location', line: index, value: data[i].locationName || ' '});
                    line.setSublistValue({id: 'custpage_line_onhand', line: index, value: data[i].onHand || ' '});
                    line.setSublistValue({id: 'custpage_line_available', line: index, value: data[i].available || ' '});
                    line.setSublistValue({id: 'custpage_line_seriallotnumber', line: index, value: data[i].inventoryNumberName || ' '});
                    line.setSublistValue({id: 'custpage_line_statuses', line: index, value: data[i].status || ' '});
                    line.setSublistValue({id: 'custpage_line_chinese_name', line: index, value: data[i].cn || ' '});
                    line.setSublistValue({id: 'custpage_line_english_name', line: index, value: data[i].en || ' '});
                    line.setSublistValue({id: 'custpage_line_brand', line: index, value: data[i].brand || ' '});
                    line.setSublistValue({id: 'custpage_line_package_spec', line: index, value: data[i].packSpec || ' '});
                    line.setSublistValue({id: 'custpage_line_delivery_remarks', line: index, value: data[i].remarks || ' '});
                    line.setSublistValue({id: 'custpage_line_remain_subsidiary', line: index, value: data[i].subsidiary || ' '});
                    index++;
                }
            }
            return form;
        }

        /**
         * 根据subsidiary，获取subsidiary下的location
         * @param subsidiary
         * @returns {[{name: string, value: number}]}
         */
        function getLocation(subsidiary) {
            let brList = [{"value":0,"name":""}];
            let locationSearchObj = search.create({
                type: "location",
                filters:
                    [
                        ["subsidiary","anyof",subsidiary]
                    ],
                columns:
                    [
                        search.createColumn({
                            name: "name",
                            sort: search.Sort.ASC,
                            label: "名称"
                        }),
                        search.createColumn({name: "internalid", label: "内部 ID"})
                    ]
            });
            let columns = locationSearchObj.columns;
            let res = commonApi.getAllData(locationSearchObj);
            if (res && res.length > 0) {
                for (let i = 0; i < res.length; i++) {
                    let locationNum = res[i].getValue(columns[0]);
                    let id = res[i].getValue(columns[1]);
                    let json = {};
                    json.value = id;
                    json.name = locationNum;
                    brList.push(json);
                }
            }
            // log.debug('brList', brList);
            return brList;
        }

        /**
         * 获取全部location
         * @returns {*[]}
         */
        function getAllLocation() {
            let brList = [];
            let locationSearchObj = search.create({
                type: "location",
                filters:
                    [],
                columns:
                    [
                        search.createColumn({
                            name: "name",
                            sort: search.Sort.ASC,
                            label: "名称"
                        }),
                        search.createColumn({name: "internalid", label: "内部 ID"})
                    ]
            });
            let columns = locationSearchObj.columns;
            let res = commonApi.getAllData(locationSearchObj);
            if (res && res.length > 0) {
                for (let i = 0; i < res.length; i++) {
                    let locationNum = res[i].getValue(columns[0]);
                    let id = res[i].getValue(columns[1]);
                    let json = {};
                    json.value = id;
                    json.name = locationNum;
                    brList.push(json);
                }
            }
            return brList;
        }


        /**
         * 获取全部有location的subsidiary
         * @returns {*[]}
         */
        function getAllSubsidiary() {
            let myLoadedQuery = query.load({id: 'custworkbook3'});
            let mySuiteQLQuery = myLoadedQuery.toSuiteQL();
            // log.debug('mySuiteQLQuery',mySuiteQLQuery.query);
            let results = mySuiteQLQuery.run();
            let mrSet = results.asMappedResults();
            // log.debug('mrSet',mrSet);


            let subIdArr = [];
            let subArr = [];
            for (let i = 0; i < mrSet.length; i++) {
                let subId = mrSet[i].id_1;
                let subName = mrSet[i].subsidiary;
                if (subIdArr.indexOf(subId) == -1) {
                    subIdArr.push(subId);
                    let json = {
                        name : subName,
                        value : subId
                    }
                    subArr.push(json);
                }
            }
            // log.debug('subArr',subArr);
            return subArr;
        }

        /**
         * 获取标准库存数据
         * @param params
         * @returns {*[]}
         */
        function getInventoryData(params) {
            let data = [];
            let filters = [], columns = [];
            if (params.item) {
                filters.push(["item", "anyof", params.item]);
            }
            if (params.itemFuzzy) {
                filters.push([["item.custitem_ecm_productname_en","contains",params.itemFuzzy],
                    "OR",
                    ["item.custitem_ecm_productname_cn","contains",params.itemFuzzy],
                    "OR",
                    ["item.displayname","contains",params.itemFuzzy]]);
            }
            if (!params.item && !params.itemFuzzy && params.location) {
                filters.push(["location", "anyof", params.location]);
            } else if (params.location) {
                filters.push("and");
                filters.push(["location", "anyof", params.location]);
            }

            if (!params.item && !params.itemFuzzy && !params.location && params.subsidiary) {
                let lcList = getLocation(params.subsidiary);
                let lcArr = [];
                lcList.forEach(lc => {
                    lcArr.push(lc.value);
                });
                filters.push(["location", "anyof", lcArr]);
            } else if (!params.location && params.subsidiary) {
                let lcList = getLocation(params.subsidiary);
                let lcArr = [];
                lcList.forEach(lc => {
                    lcArr.push(lc.value);
                });
                filters.push("and");
                filters.push(["location", "anyof", lcArr]);
            }

            columns.push(search.createColumn({name: "item", summary: "GROUP", label: "货品"}));
            columns.push(search.createColumn({name: "location", summary: "GROUP", label: "地点"}));
            columns.push(search.createColumn({name: "onhand", summary: "SUM", label: "现有"}));
            columns.push(search.createColumn({name: "available", summary: "SUM", label: "可用"}));
            columns.push(search.createColumn({name: "inventorynumber", summary: "GROUP", label: "库存编号"}));
            columns.push(search.createColumn({name: "status", summary: "GROUP", label: "状态"}));
            columns.push(search.createColumn({name: "custitem_ecm_productname_cn", join: "item", summary: "GROUP", label: "中文名称"}));
            columns.push(search.createColumn({name: "custitem_ecm_productname_en", join: "item", summary: "GROUP", label: "英文名称"}));
            columns.push(search.createColumn({name: "custitem_ecm_brand", join: "item", summary: "GROUP", label: "品牌"}));
            columns.push(search.createColumn({name: "custitem_ecm_pack_spec", join: "item", summary: "GROUP", label: "Package Spec"}));
            columns.push(search.createColumn({name: "custitem_ecm_package_remk_en", join: "item", summary: "GROUP", label: "Package Remarks EN"}));
            columns.push(search.createColumn({name: "subsidiary", join: "location", summary: "GROUP", label: "子公司"}));


            let ibSearchObj = search.create({type: "inventorybalance", filters: filters, columns: columns});
            let res = commonApi.getAllData(ibSearchObj);

            if(res && res.length > 0){
                for(let i = 0; i < res.length; i++){
                    let item = res[i].getText(columns[0]);
                    let itemId = res[i].getValue(columns[0]);
                    let location = res[i].getValue(columns[1]);
                    let locationName = res[i].getText(columns[1]);
                    let onHand = res[i].getValue(columns[2]);
                    let available = res[i].getValue(columns[3]);
                    let inventoryNumber = res[i].getValue(columns[4]);
                    let inventoryNumberName = res[i].getText(columns[4]);
                    let status = res[i].getText(columns[5]);
                    let cn = res[i].getValue(columns[6]);
                    let en = res[i].getValue(columns[7]);
                    let brand = res[i].getValue(columns[8]);
                    let packSpec = res[i].getValue(columns[9]);
                    let remarks = res[i].getText(columns[10]);
                    let subsidiary = res[i].getValue(columns[11]);
                    let key = itemId + '&' + location + '&' + inventoryNumber + '&' + status;
                    let json = {
                        key : key,
                        no : i + 1,
                        item : item,
                        itemId : itemId,
                        location : location,
                        locationName : locationName,
                        onHand : onHand,
                        available : available,
                        inventoryNumber : inventoryNumber,
                        inventoryNumberName : inventoryNumberName,
                        status : status,
                        cn : cn,
                        en : en,
                        brand : brand,
                        packSpec : packSpec,
                        remarks : remarks,
                        subsidiary : subsidiary,
                    }
                    data.push(json);
                }
            }
            // log.debug('data',data);
            // log.debug('dataLength',data.length);
            return data;
        }


        /**
         * 获取自定义库存数据
         * @param params
         * @returns {*[]}
         */
        function getInventoryDetailData(params) {
            let data = [];
            let filters = [], columns = [];
            if (params.item) {
                filters.push(["custrecord_id_item", "anyof", params.item]);
            }
            if (params.itemFuzzy) {
                filters.push([["custrecord_id_item.custitem_ecm_productname_en","contains",params.itemFuzzy],
                    "OR",
                    ["custrecord_id_item.custitem_ecm_productname_cn","contains",params.itemFuzzy],
                    "OR",
                    ["custrecord_id_item.displayname","contains",params.itemFuzzy]]);
            }


            columns.push(search.createColumn({name: "custrecord_id_item", label: "Item"}));
            columns.push(search.createColumn({name: "custrecord_id_seriallot", label: "SERIAL/LOT NUMBER"}));
            columns.push(search.createColumn({name: "custrecord_id_status", label: "Status"}));
            columns.push(search.createColumn({name: "custrecord_id_quantity", label: "Quantity"}));
            columns.push(search.createColumn({name: "custrecord_id_spline", label: "SP明细"}));



            let inventoryDetailSearchObj = search.create({type: "customrecord_ecm_inventorydetail", filters: filters, columns: columns});
            let res = commonApi.getAllData(inventoryDetailSearchObj);

            let spIdArr = [];
            if(res && res.length > 0){
                for(let i = 0; i < res.length; i++){
                    let item = res[i].getText(columns[0]);
                    let itemId = res[i].getValue(columns[0]);
                    let inventoryNumber = res[i].getValue(columns[1]);
                    let status = res[i].getText(columns[2]);
                    let quantity = res[i].getValue(columns[3]);
                    let spId = res[i].getValue(columns[4]);
                    spIdArr.push(spId);
                    let json = {
                        item : item,
                        itemId : itemId,
                        inventoryNumber : inventoryNumber,
                        status : status,
                        quantity : quantity,
                        spId : spId,
                        location : '',
                        key : ''
                    }
                    data.push(json);
                }
            }
            if (data.length > 0 && spIdArr.length > 0) {
                let locationData = searchScdLine(spIdArr);//根据SP明细id,搜索SP明细父记录Shipping Plan上的location和status
                //将获取到的location赋值到对应的自定义库存数据
                for (let i = 0; i < data.length; i++) {
                    let inventoryDetailInfo = data[i];
                    for (let j = 0; j < locationData.length; j++) {
                        if (inventoryDetailInfo.spId == locationData[j].spId) {
                            inventoryDetailInfo.location = locationData[j].location
                        }
                    }
                }
                //自定义库存数据生成key,用来与标准库存数据匹配
                for (let i = 0; i < data.length; i++) {
                    let itemId = data[i].itemId;
                    let status = data[i].status;
                    let inventoryNumber = data[i].inventoryNumber;
                    let location = data[i].location;
                    data[i].key = itemId + '&' + location + '&' + inventoryNumber + '&' + status;
                }
                // log.debug('InventoryDetailData',data);
            }
            return data;
        }

        /**
         * 根据SP明细id,搜索SP明细父记录Shipping Plan上的location和status
         * @param spIdArr
         * @returns {*[]}
         */
        function searchScdLine(spIdArr) {
            let customrecord_ecm_scd_lineSearchObj = search.create({
                type: "customrecord_ecm_scd_line",
                filters:
                    [
                        ["internalid","anyof",spIdArr]
                    ],
                columns:
                    [
                        search.createColumn({
                            name: "custrecord_sp_status",
                            join: "CUSTRECORD_SCDLINE_SP",
                            label: "Shipping Plan Status"
                        }),
                        search.createColumn({
                            name: "custrecord_sp_location",
                            join: "CUSTRECORD_SCDLINE_SP",
                            label: "Issuing Location"
                        }),
                        search.createColumn({name: "internalid", label: "内部 ID"})
                    ]
            });
            let columns = customrecord_ecm_scd_lineSearchObj.columns;
            let res = commonApi.getAllData(customrecord_ecm_scd_lineSearchObj);
            let locationInfo = [];
            if(res && res.length > 0){
                for(let i = 0; i < res.length; i++){
                    let status = res[i].getValue(columns[0]);
                    let location = res[i].getValue(columns[1]);
                    let spId = res[i].getValue(columns[2]);
                    // 只有在Shipping Plan状态为已到达时,需要赋值对应的自定义库存数据的location
                    if (status == 4) { //TODO 环境校验
                        let json = {
                            location : location,
                            spId : spId
                        }
                        locationInfo.push(json)
                    }
                }
            }
            // log.debug('locationInfo',locationInfo);
            return locationInfo;
        }


        return {onRequest}

    });
