/**
 * @NApiVersion 2.1
 * @NScriptType ScheduledScript
 *
 * Version		Date			Author			Memo
 * 1.0			2023/02/24		Will Liu		SP提货状态更新(1018603)
 */
define(['N/https', 'N/record', 'N/task', 'N/search', '/SuiteScripts/tools/common_api.js', '/SuiteScripts/tools/hc_edi_interface_tool.js', '/SuiteScripts/tools/moment.js', '/SuiteScripts/tools/ramda.min.js'],
    /**
     * @param{https} https
     * @param record
     * @param{task} task
     * @param search
     * @param commonApi
     * @param interfaceTool
     * @param moment
     * @param ramda
     */
    (https, record, task, search, commonApi, interfaceTool, moment, ramda) => {
        /**
         * Defines the Scheduled script trigger point.
         * @param {Object} scriptContext
         * @param {string} scriptContext.type - Script execution context. Use values from the scriptContext.InvocationType enum.
         * @since 2015.2
         */
        const execute = (scriptContext) => {
            try {
                let spIdArr = searchSpId();
                log.debug('spIdArr',spIdArr);
                let date = getDateFormat();
                log.debug('date',date);
                for (let i = 0; i < spIdArr.length; i++) {
                    let spRec = record.load({type: 'customrecord_ecm_sp', id: spIdArr[i]});
                    let length = spRec.getLineCount('recmachcustrecord_scdline_sp');
                    let updState = false;
                    for (let j = 0; j < length; j++) {
                        let spQty = spRec.getSublistValue({sublistId:'recmachcustrecord_scdline_sp',fieldId:'custrecord_scdline_spqty',line:i});//实际发运数量
                        let qty = spRec.getSublistValue({sublistId:'recmachcustrecord_scdline_sp',fieldId:'custrecord_scdline_qty',line:i});//数量
                        if (Number(spQty) >= Number(qty)) {
                            updState = true
                        }
                    }
                    if (updState == true) {
                        spRec.setValue({fieldId:'custrecord_sp_status', value: 2});
                        spRec.setText({fieldId:'custrecord_sp_deliverycomdate', text: date});
                    }
                    spRec.save({ignoreMandatoryFields: true, enableSourcing: true});
                }
            } catch (e) {
                log.error('Error', e);
            }
        }


        /**
         * 搜索状态为待出运的的Shipping Plan id
         * @returns {*[]}
         */
        function searchSpId() {
            let filters = [];
            let columns = [];
            filters.push(['custrecord_sp_status','is',1]);//TODO 单据状态
            filters.push('AND');
            filters.push(['isinactive', 'is', 'false']);
            columns.push(search.createColumn({name: 'internalid', label: 'Internal ID'}));
            let spSearchObj = search.create({type: 'customrecord_ecm_sp', filters: filters, columns: columns});
            let result = commonApi.getAllData(spSearchObj);
            let spIdArr = [];
            if (result.length > 0) {
                for (let i = 0; i < result.length; i++) {
                    let spId = result[i].getValue(columns[0]);
                    spIdArr.push(spId);
                }
            }
            return spIdArr
        }

        function getDateFormat()  {
            let date = new Date();
            let year = date.getFullYear();
            let month = date.getMonth() + 1;
            let day = date.getDate();
            if (month < 10){
                month = '0' + month;
            }
            if (day < 10){
                day = '0' + day;
            }
            return month + '/' + day + '/' + year;
        }



        return {execute}
    });
