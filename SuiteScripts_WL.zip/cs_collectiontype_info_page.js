/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */
define(['N/currentRecord', 'N/record', 'N/runtime', 'N/search', 'SuiteScripts/tools/common_api.js'],
    /**
     * @param{currentRecord} currentRecord
     * @param record
     * @param runtime
     * @param search
     * @param commonApi
     */
    function (currentRecord, record, runtime, search, commonApi) {

        /**
         * Function to be executed after page is initialized.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.mode - The mode in which the record is being accessed (create, copy, or edit)
         *
         * @since 2015.2
         */
        function pageInit(scriptContext) {

        }

        /**
         * Function to be executed when field is changed.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         * @param {string} scriptContext.fieldId - Field name
         * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
         * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
         *
         * @since 2015.2
         */
        function fieldChanged(scriptContext) {

        }


        function doSubmit() {
            var obj = currentRecord.get();
            var ct = obj.getText('custpage_ct');
            setWindowChanged(window, false);
            window.opener.writeBackCt(ct);
            window.close();
        }

        function doCancel() {
            setWindowChanged(window, false);
            window.close();
        }

        return {
            pageInit: pageInit,
            // fieldChanged: fieldChanged,
            doCancel: doCancel,
            doSubmit: doSubmit
        };


    });
