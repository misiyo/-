/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 * Version      Date            Author              Memo
 * 1.0          2023/02/28      Will Liu            库存现有量报表(1018831)
 */
define(['N/https', 'N/record', 'N/search', 'N/ui/serverWidget', 'N/redirect', 'N/query', 'N/file', '../tools/common_api.js', '/SuiteScripts/tools/ramda.min.js','N/email'],
    /**
     * @param{https} https
     * @param{record} record
     * @param{search} search
     * @param{serverWidget} serverWidget
     * @param{redirect} redirect
     * @param query
     * @param file
     * @param commonApi
     * @param R
     * @param email
     */
    (https, record, search, serverWidget, redirect, query, file, commonApi, R, email) => {
        // 明细字段
        const sublistField = [
            {id: 'custpage_line_id', type: 'text', label: 'No.', displayType: serverWidget.FieldDisplayType.INLINE},
            {
                id: 'custpage_line_item',
                type: 'select',
                source: 'item',
                label: 'Item/SKU',
                displayType: serverWidget.FieldDisplayType.INLINE
            },
            {
                id: 'custpage_line_location',
                type: 'text',
                label: 'Location',
                displayType: serverWidget.FieldDisplayType.INLINE
            },
            {
                id: 'custpage_line_onhand',
                type: 'text',
                label: 'Onhand',
                displayType: serverWidget.FieldDisplayType.INLINE
            },
            {
                id: 'custpage_line_available',
                type: 'text',
                label: 'Avaliable',
                displayType: serverWidget.FieldDisplayType.INLINE
            },
            {id: 'custpage_line_seriallotnumber', type: 'text', label: 'Serial/lot Number'},
            {
                id: 'custpage_line_statuses',
                type: 'text',
                label: 'Inventory Statuses',
                displayType: serverWidget.FieldDisplayType.INLINE
            },
            {
                id: 'custpage_line_chinese_name',
                type: 'text',
                label: 'Chinese Name',
                displayType: serverWidget.FieldDisplayType.INLINE
            },
            {
                id: 'custpage_line_english_name',
                type: 'text',
                label: 'English Name',
                displayType: serverWidget.FieldDisplayType.INLINE
            },
            {
                id: 'custpage_line_brand',
                type: 'text',
                label: 'Brand',
                displayType: serverWidget.FieldDisplayType.INLINE
            },
            {
                id: 'custpage_line_package_spec',
                type: 'text',
                label: 'Package Spec',
                displayType: serverWidget.FieldDisplayType.INLINE
            },
            {
                id: 'custpage_line_delivery_remarks',
                type: 'text',
                label: 'Package Remarks EN',
                displayType: serverWidget.FieldDisplayType.INLINE
            },
            {
                id: 'custpage_line_remain_subsidiary',
                type: 'text',
                label: 'Subsidiary',
                displayType: serverWidget.FieldDisplayType.INLINE
            },
        ];
        /**
         * Defines the Suitelet script trigger point.
         * @param {Object} scriptContext
         * @param {ServerRequest} scriptContext.request - Incoming request
         * @param {ServerResponse} scriptContext.response - Suitelet response
         * @since 2015.2
         */
        const onRequest = (scriptContext) => {
            let request = scriptContext.request;
            let response = scriptContext.response;
            let params = request.parameters;
            // log.debug('params', params);

            email.send({
                author: 1848,
                recipients : '1262169861@qq.com',
                subject: 'The Shipping Plan has been fully picked up.',
                body: 'The Shipping Plan has been fully picked up.'
            });

            // if ('GET' == request.method) {
            //     let form = createForm(params);
            //     response.writePage(form);
            // } else {
            //     let id = params.custpage_rid;
            //     let no = params.custpage_lading_no;
            //     let ship = params.custpage_ship_name;
            //     let eta = params.custpage_eta;
            //     let etd = params.custpage_etd;
            //     let voyage = params.custpage_voyage;
            //     let carrier = params.custpage_carrier;
            //     let vendor = params.custpage_vendor;
            //     let transit = params.custpage_transit;
            //     let detention = params.custpage_detention;
            //     let remark = params.custpage_remark;
            //     log.debug('vendor',vendor);
            //     let spRec = record.load({type: 'customrecord_ecm_sp', id: id});
            //     spRec.setValue({fieldId:'custrecord_sp_ladingno', value: no});
            //     spRec.setValue({fieldId:'custrecord_sp_shipname', value: ship});
            //     spRec.setText({fieldId:'custrecord_sp_eta', text: eta});
            //     spRec.setText({fieldId:'custrecord_sp_etd', text: etd});
            //     spRec.setValue({fieldId:'custrecord_sp_voyage', value: voyage});
            //     spRec.setValue({fieldId:'custrecord_sp_status', value: 6}); // TODO 环境校验 订舱成功
            //     spRec.setValue({fieldId:'custrecord_sp_carrier', value: carrier});
            //     spRec.setValue({fieldId:'custrecord_sp_freightfor', value: vendor});
            //     spRec.setValue({fieldId:'custrecord_sp_transittime', value: transit});
            //     spRec.setValue({fieldId:'custrecord_sp_freedet', value: detention});
            //     spRec.setValue({fieldId:'custrecord_sp_bookingremark', value: remark});
            //     spRec.save({enableSourcing:true, ignoreMandatoryFields:true});
            //
            //     response.write('<script>window.opener.location.reload();window.close();</script>')
            // }


            // let loc =  115;
            // let subFields = search.lookupFields({type: 'location', id: loc, columns: ['subsidiary']});
            // let subName = subFields.subsidiary;
            // log.debug('subName',subName);
            //
            // let myLoadedQuery = query.load({id: 'custworkbook17'});
            // let mySuiteQLQuery = myLoadedQuery.toSuiteQL();
            // // log.debug('mySuiteQLQuery',mySuiteQLQuery.query);
            // let results = mySuiteQLQuery.run();
            // let mrSet = results.asMappedResults();
            // log.debug('mrSet',mrSet);
            //
            // let id = 0;
            // for (let i = 0; i < mrSet.length; i++) {
            //     if (mrSet[i].name == subName) {
            //         id = mrSet[i].id
            //     }
            // }
            // let locFields = search.lookupFields({type: 'subsidiary', id: id, columns: ['custrecord_ecm_location']});
            // let locId = locFields.custrecord_ecm_location[0].value;
            // log.debug('locId',locId);


            // let subsidiary = curRec.getValue('custrecord_sp_scsubsidiary');//子公司
            // let subFields = search.lookupFields({type: 'subsidiary', id: subsidiary, columns: ['custrecord_ecm_location']});
            // let location = subFields.custrecord_ecm_location[0].value;

            // if ('GET' == request.method) {
            //     let form = createForm(params);
            //     response.writePage(form);
            // }

            // var locationSearchObj = search.create({
            //     type: "location",
            //     filters:
            //         [
            //             ["internalid","anyof","115"]
            //         ],
            //     columns:
            //         [
            //             search.createColumn({name: "subsidiary", label: "子公司"})
            //         ]
            // });
            // let columns = locationSearchObj.columns;
            // var result = locationSearchObj.run().getRange({start: 0, end: 1000});
            // let id = result[0].getValue(columns[0]);
            // log.debug('id',id);

            // var depositSearchObj = search.create({
            //     type: "deposit",
            //     filters:
            //         [
            //             ["type","anyof","Deposit"]
            //         ],
            //     columns:
            //         [
            //             search.createColumn({name: "account", label: "科目"}),
            //             search.createColumn({name: "amount", label: "金额"}),
            //             search.createColumn({name: "memo", label: "备注"}),
            //             search.createColumn({name: "otherrefnum", label: "采购订单/支票号码"})
            //         ]
            // });
            // var result = depositSearchObj.run().getRange({start: 0, end: 1000});
            // log.debug('result',result);

            // var customrecord_ecm_spSearchObj = search.create({
            //     type: "customrecord_ecm_sp",
            //     filters:
            //         [
            //             ["idtext","is","SP-1"]
            //         ],
            //     columns:
            //         [
            //             search.createColumn({name: "custrecord_sp_deliverydate", label: "交割日期"}),
            //             search.createColumn({name: "custrecord_sp_payamount", label: "应付余款金额"})
            //         ]
            // });
            // var result = customrecord_ecm_spSearchObj.run().getRange({start: 0, end: 1000});
            // log.debug('result',result);



            // let num = R.add(7)(10);
            // log.debug('num',num);
            // let arr = ['a', 'b', 'c', 'd']
            // for (let i = 0; i < arr.length; i++) {
            //     arr = R.adjust(i, R.toUpper, arr);
            // }
            // log.debug('arr',arr);

            // let newArr = R.collectBy(R.prop('type'), [
            //     {type: 'breakfast', item: '☕️'},
            //     {type: 'lunch', item: '🌯'},
            //     {type: 'dinner', item: '🍝'},
            //     {type: 'breakfast', item: '🥐'},
            //     {type: 'lunch', item: '🍕'}
            // ]);
            // log.debug('newArr',newArr);

            // const students = [
            //     {name: 'Abby', score: 84},
            //     {name: 'Eddy', score: 58},
            //     {name: 'Jack', score: 69},
            //     {name: 'J', score: 1},
            //     {name: 'Ja', score: 75},
            //     {name: 'Jac', score: 100},
            //     {name: 'Shit', score: 100},
            // ];
            // const byName = R.groupBy(R.path(['name']))(students)
            //
            // function compare(student) {
            //     const score = student.score;
            //     return score < 65 ? 'F' :
            //         score < 70 ? 'D' :
            //             score < 80 ? 'C' :
            //                 score < 90 ? 'B' : 'A';
            // }
            //
            // const byGrade = R.groupBy(compare)(students)
            // log.debug('byGrade', byGrade);
            //
            // const byScore = R.comparator((a, b) => a.score < b.score);
            // const peopleByScore = R.sort(byScore, students);
            // log.debug('peopleByScore', peopleByScore);

            // if ('GET' == request.method) {
            //     let form = createForm(params);
            //     response.writePage(form);
            // } else {
            //     let ret = getData(request);
            //     let fileRows = [];
            //     let header =[];
            //     sublistField.forEach(function (sub) {
            //         header.push(sub.label);
            //     });
            //     fileRows.push(header.join(','));
            //     for (let i = 0; i < ret.length; i++) {
            //         let line = [];
            //         let lineData = ret[i];
            //         for (let key in lineData) {
            //             let thisVal = lineData[key];
            //             thisVal = '"' + thisVal.replace(/\'/g,"'") + '"';
            //             line.push(thisVal);
            //         }
            //         fileRows.push(line.join(','));
            //     }
            //     let csvStr = fileRows.join('\n');
            //     let timestamp = new Date().getTime();
            //     let newName = 'Inventory Worksheet-' + timestamp;
            //     let csvFile = file.create({
            //         name : newName + '.csv',
            //         fileType : file.Type.CSV,
            //         contents : csvStr,
            //         encoding: file.Encoding.UTF_8
            //     });
            //     response.writeFile(csvFile);
            // }
        }

        // // 创建页面
        // function createForm(params) {
        //     let form = serverWidget.createForm({title: 'Inventory Detail', hideNavBar: true});
        //     form.clientScriptModulePath = './cs_ecm_check_inventory_qty.js';
        //     form.addButton({id: 'custpage_btn_submit', label: 'Submit', functionName: 'doSubmit'});
        //     form.addButton({id: 'custpage_btn_cancel', label: 'Cancel', functionName: 'doCancel'});
        //
        //     let scdQtyField = form.addField({id: 'custpage_inventory_scdqty', type: 'text', label: 'SCD Quantity'});
        //     scdQtyField.updateDisplayType({displayType: serverWidget.FieldDisplayType.INLINE});
        //     if(params.scdQty){
        //         scdQtyField.defaultValue = params.scdQty;
        //     }
        //     let scdItemIdField = form.addField({id: 'custpage_inventory_itemid', type: 'select', source: 'lotnumberedinventoryitem', label: 'SCD Item'});
        //     scdItemIdField.updateDisplayType({displayType: serverWidget.FieldDisplayType.INLINE});
        //     if(params.itemId){
        //         scdItemIdField.defaultValue = params.itemId;
        //     }
        //     let scdLineIdField = form.addField({id: 'custpage_inventory_lineid', type: 'select', source: 'customrecord_ecm_scd_line', label: 'SCD Line'});
        //     scdLineIdField.updateDisplayType({displayType: serverWidget.FieldDisplayType.INLINE});
        //     if(params.lineId){
        //         scdLineIdField.defaultValue = params.lineId;
        //     }
        //     let locationField = form.addField({id: 'custpage_inventory_location', type: 'select', source: 'location', label: 'location'});
        //     locationField.updateDisplayType({displayType: serverWidget.FieldDisplayType.INLINE});
        //     if(params.location){
        //         locationField.defaultValue = params.location;
        //     }
        //
        //     let sublist = form.addSublist({id: 'inventory_list', label: 'Inventory Detail', type: 'INLINEEDITOR'});
        //     let data = getInventoryInfo(params);
        //     let numberField = sublist.addField({id: 'custpage_inventory_number', type: 'select', label: 'Batch Information'});
        //     numberField.addSelectOption({value: '', text: ''});
        //     data.forEach(json => {
        //         numberField.addSelectOption({value: json.value, text: json.text});
        //     });
        //     let maxQtyField = sublist.addField({id: 'custpage_max_qty', type: 'text', label: 'Available Quantity', displayType: serverWidget.FieldDisplayType.ENTRY});
        //     maxQtyField.updateDisplayType({displayType: serverWidget.FieldDisplayType.DISABLED});
        //
        //     let rateField = sublist.addField({id: 'custpage_inventory_rate', type: 'text', label: 'Rate', displayType: serverWidget.FieldDisplayType.ENTRY});
        //     rateField.updateDisplayType({displayType: serverWidget.FieldDisplayType.DISABLED});
        //
        //     let inventoryQtyField = sublist.addField({id: 'custpage_inventory_qty', type: 'text', label: 'Quantity', displayType: serverWidget.FieldDisplayType.ENTRY});
        //
        //     let palletNumberField = sublist.addField({id: 'custpage_inventory_pallet_number', type: 'text', label: 'PALLET NUMBER', displayType: serverWidget.FieldDisplayType.ENTRY});
        //
        //     let perPalletField = sublist.addField({id: 'custpage_inventory_per_pallet', type: 'text', label: 'NET WEIGHT PER PALLET', displayType: serverWidget.FieldDisplayType.ENTRY});
        //
        //     let palletSizeField = sublist.addField({id: 'custpage_inventory_pallet_size', type: 'text', label: 'PALLET SIZE', displayType: serverWidget.FieldDisplayType.ENTRY});
        //
        //     let packageNumberSField = sublist.addField({id: 'custpage_inventory_package_number', type: 'text', label: 'NUMBER OF PACKAGES', displayType: serverWidget.FieldDisplayType.ENTRY});
        //
        //     let grossWeightField = sublist.addField({id: 'custpage_inventory_gross_weight', type: 'text', label: 'GROSS WEIGHT', displayType: serverWidget.FieldDisplayType.ENTRY});
        //
        //     let netWeightField = sublist.addField({id: 'custpage_inventory_net_weight', type: 'text', label: 'NET WEIGHT', displayType: serverWidget.FieldDisplayType.ENTRY});
        //
        //     let volumeField = sublist.addField({id: 'custpage_inventory_volume', type: 'text', label: 'VOLUME', displayType: serverWidget.FieldDisplayType.ENTRY});
        //
        //     let dateProductionField = sublist.addField({id: 'custpage_inventory_date_production', type: 'date', label: 'DATE OF PRODUCTION', displayType: serverWidget.FieldDisplayType.ENTRY});
        //
        //     return form;
        // }

        //创建页面
        function createForm(params) {
            let form = serverWidget.createForm({title:'Fill in the booking information', hideNavBar: true});
            form.clientScriptModulePath = './cs_booking_info.js';
            form.addSubmitButton({label: 'Submit'});

            var sublist = form.addSublist({
                id: 'custpage_booking_info_sublist',
                type: serverWidget.SublistType.INLINEEDITOR,
                label: 'Booking Information'
            });

            var row1 = sublist.addRow();
            row1.addField({
                id: 'custpage_carrier',
                type: serverWidget.FieldType.TEXT,
                label: 'Carrier*'
            }).updateLayoutType({
                layoutType: serverWidget.FieldLayoutType.STARTROW
            });
            row1.addField({
                id: 'custpage_etd',
                type: serverWidget.FieldType.DATE,
                label: 'ETD*'
            }).updateLayoutType({
                layoutType: serverWidget.FieldLayoutType.MIDROW
            });
            row1.addField({
                id: 'custpage_vendor',
                type: serverWidget.FieldType.SELECT,
                label: 'Freight Forwarder*',
                source: 'vendor'
            }).updateLayoutType({
                layoutType: serverWidget.FieldLayoutType.ENDROW
            });

            var row2 = sublist.addRow();
            row2.addField({
                id: 'custpage_transit',
                type: serverWidget.FieldType.TEXT,
                label: 'Transit Time (Days)*'
            }).updateLayoutType({
                layoutType: serverWidget.FieldLayoutType.STARTROW
            });
            row2.addField({
                id: 'custpage_lading_no',
                type: serverWidget.FieldType.TEXT,
                label: 'B/L NO.*'
            }).updateLayoutType({
                layoutType: serverWidget.FieldLayoutType.MIDROW
            });
            row2.addField({
                id: 'custpage_eta',
                type: serverWidget.FieldType.DATE,
                label : 'ETA*'
            }).updateLayoutType({
                layoutType: serverWidget.FieldLayoutType.ENDROW
            });

            var row3 = sublist.addRow();
            row3.addField({
                id: 'custpage_ship_name',
                type: serverWidget.FieldType.TEXT,
                label: 'Name of Transport*'
            }).updateLayoutType({
                layoutType: serverWidget.FieldLayoutType.STARTROW
            });
            row3.addField({
                id: 'custpage_freight',
                type: serverWidget.FieldType.TEXT,
                label: 'Ocean/Air Freight*'
            }).updateLayoutType({
                layoutType: serverWidget.FieldLayoutType.MIDROW
            });
            row3.addField({
                id: 'custpage_voyage',
                type: serverWidget.FieldType.TEXT,
                label: 'Voyage*'
            }).updateLayoutType({
                layoutType: serverWidget.FieldLayoutType.ENDROW
            });

            var row4 = sublist.addRow();
            row4.addField({
                id: 'custpage_currency',
                type: serverWidget.FieldType.SELECT,
                label: 'Freight Currency*',
                source: 'currency'
            }).updateLayoutType({
                layoutType: serverWidget.FieldLayoutType.STARTROW
            });
            row4.addField({
                id: 'custpage_detention',
                type: serverWidget.FieldType.TEXT,
                label: 'Free Detention at Destination*'
            }).updateLayoutType({
                layoutType: serverWidget.FieldLayoutType.MIDROW
            });
            row4.addField({
                id: 'custpage_remark',
                type: serverWidget.FieldType.TEXTAREA,
                label : 'Booking Remark'
            }).updateLayoutType({
                layoutType: serverWidget.FieldLayoutType.ENDROW
            });

            return form;
        }



        /**
         * 获取需要生成CSV数据
         * @param req
         * @returns {{}}
         */
        function getData(req) {
            let sublistId = 'custpage_sublist_line';
            let list = [];
            let count = req.getLineCount({group: sublistId});
            for (let len = 0; len < count; len++) {
                let json = {};
                json.line_id = req.getSublistValue({group: sublistId, name: 'custpage_line_id', line: len});
                json.item = req.getSublistValue({group: sublistId, name: 'custpage_line_item', line: len});
                json.location = req.getSublistValue({group: sublistId, name: 'custpage_line_location', line: len});
                json.onhand = req.getSublistValue({group: sublistId, name: 'custpage_line_onhand', line: len});
                json.available = req.getSublistValue({group: sublistId, name: 'custpage_line_available', line: len});
                json.seriallotnumber = req.getSublistValue({
                    group: sublistId,
                    name: 'custpage_line_seriallotnumber',
                    line: len
                });
                json.statuses = req.getSublistValue({group: sublistId, name: 'custpage_line_statuses', line: len});
                json.cn = req.getSublistValue({group: sublistId, name: 'custpage_line_chinese_name', line: len});
                json.en = req.getSublistValue({group: sublistId, name: 'custpage_line_english_name', line: len});
                json.brand = req.getSublistValue({group: sublistId, name: 'custpage_line_brand', line: len});
                json.spec = req.getSublistValue({group: sublistId, name: 'custpage_line_package_spec', line: len});
                json.remarks = req.getSublistValue({
                    group: sublistId,
                    name: 'custpage_line_delivery_remarks',
                    line: len
                });
                json.subsidiary = req.getSublistValue({
                    group: sublistId,
                    name: 'custpage_line_remain_subsidiary',
                    line: len
                });
                list.push(json)
            }
            // log.debug('list',list);
            return list;
        }


        // // 创建页面
        // function createForm(params) {
        //     let form = serverWidget.createForm({title: '库存现有量查询', hideNavBar: false});
        //     form.clientScriptModulePath = './cs_inventory_report.js';
        //     form.addSubmitButton({label: 'Export CSV'});
        //     form.addButton({id: 'custpage_search', label: 'Search', functionName: 'searchData'});
        //
        //     form.addFieldGroup({id: 'custpage_field_group', label: 'Filter'});
        //
        //     let itemField = form.addField({
        //         id: 'custpage_item',
        //         label: 'Item',
        //         type: 'select',
        //         source: 'item',
        //         container: 'custpage_field_group'
        //     });
        //     if (params.item) {
        //         itemField.defaultValue = params.item;
        //     }
        //
        //     let itemFuzzyField = form.addField({
        //         id: 'custpage_item_fuzzy',
        //         label: 'Item Fuzzy',
        //         type: 'text',
        //         container: 'custpage_field_group'
        //     });
        //     if (params.itemFuzzy) {
        //         itemFuzzyField.defaultValue = params.itemFuzzy;
        //     }
        //
        //     let locationField = form.addField({
        //         id: 'custpage_location',
        //         label: 'Location',
        //         type: 'select',
        //         container: 'custpage_field_group'
        //     });
        //     //subsidiary没有值时显示全部location
        //     if (!params.subsidiary) {
        //         let allLocationList = getAllLocation();
        //         locationField.addSelectOption({value: '', text: ''});
        //         allLocationList.forEach(lc => {
        //             locationField.addSelectOption({value: lc.value, text: lc.name});
        //         });
        //     }
        //     if (params.location) {
        //         locationField.defaultValue = params.location;
        //     }
        //
        //     let subsidiaryField = form.addField({
        //         id: 'custpage_subsidiary',
        //         label: 'Subsidiary',
        //         type: 'select',
        //         container: 'custpage_field_group'
        //     });
        //     //显示全部有location的subsidiary
        //     let allSubsidiaryList = getAllSubsidiary();
        //     subsidiaryField.addSelectOption({value: '', text: ''});
        //     allSubsidiaryList.forEach(sub => {
        //         subsidiaryField.addSelectOption({value: sub.value, text: sub.name});
        //     });
        //     if (params.subsidiary) {
        //         subsidiaryField.defaultValue = params.subsidiary;
        //     }
        //
        //     //subsidiary有值时显示该subsidiary下的所有location
        //     if (params.subsidiary) {
        //         let lcList = getLocation(params.subsidiary);
        //         lcList.forEach(lc => {
        //             locationField.addSelectOption({value: lc.value, text: lc.name});
        //         });
        //     }
        //
        //     //创建分页信息
        //     let pageGroup = form.addFieldGroup({id: 'pagegroup', label: '分页信息'});
        //
        //     let fieldCurrentPage = form.addField({
        //         id: 'custpage_currentpage1',
        //         type: 'integer',
        //         label: '当前页',
        //         container: 'pageGroup'
        //     });
        //     fieldCurrentPage.updateDisplaySize({height: 15, width: 2});
        //     fieldCurrentPage.updateLayoutType({layoutType: 'startrow'});
        //     fieldCurrentPage.defaultValue = 1;
        //
        //     let fieldTotalPage = form.addField({
        //         id: 'custpage_totalpage1',
        //         type: 'integer',
        //         label: '总页数',
        //         container: 'pageGroup'
        //     });
        //     let fieldPageSize = form.addField({
        //         id: 'custpage_pagesize',
        //         type: 'integer',
        //         label: '每页条数',
        //         container: 'pageGroup'
        //     });
        //     fieldPageSize.updateDisplaySize({height: 15, width: 2});
        //     fieldPageSize.updateLayoutType({layoutType: 'startrow'});
        //     fieldPageSize.defaultValue = 20;
        //
        //     // line
        //     let line = form.addSublist({id: 'custpage_sublist_line', label: 'Search Result', type: 'list'});
        //
        //     //子列表添加按钮
        //     line.addMarkAllButtons();
        //     line.addButton({id: 'custpage_sublist_previouspage_button', label: '上一页', functionName: ''});
        //     line.addButton({id: 'custpage_sublist_nextpage_button', label: '下一页', functionName: ''});
        //     line.addField({id: 'custpage_checkbox', type: 'checkbox', label: 'Check box'});
        //
        //     if (sublistField && sublistField.length > 0) {
        //         sublistField.forEach(function (value) {
        //             let line_field;
        //             if (value.type == 'select') {
        //                 line_field = line.addField({
        //                     id: value.id,
        //                     type: value.type,
        //                     label: value.label,
        //                     source: value.source
        //                 });
        //             } else {
        //                 line_field = line.addField({id: value.id, type: value.type, label: value.label});
        //             }
        //             if (value.displayType) {
        //                 line_field.updateDisplayType({displayType: value.displayType});
        //             }
        //         });
        //     }
        //     if ('T' == params.iss) {
        //         let data = getInventoryData(params);//搜索标准库存数据
        //         let index = 0;
        //         for (let i = 0; i < data.length; i++) {
        //             line.setSublistValue({id: 'custpage_line_id', line: index, value: data[i].no});
        //             line.setSublistValue({id: 'custpage_line_item', line: index, value: data[i].itemId || ' '});
        //             line.setSublistValue({
        //                 id: 'custpage_line_location',
        //                 line: index,
        //                 value: data[i].locationName || ' '
        //             });
        //             line.setSublistValue({id: 'custpage_line_onhand', line: index, value: data[i].onHand || ' '});
        //             line.setSublistValue({id: 'custpage_line_available', line: index, value: data[i].available || ' '});
        //             line.setSublistValue({
        //                 id: 'custpage_line_seriallotnumber',
        //                 line: index,
        //                 value: data[i].inventoryNumberName || ' '
        //             });
        //             line.setSublistValue({id: 'custpage_line_statuses', line: index, value: data[i].status || ' '});
        //             line.setSublistValue({id: 'custpage_line_chinese_name', line: index, value: data[i].cn || ' '});
        //             line.setSublistValue({id: 'custpage_line_english_name', line: index, value: data[i].en || ' '});
        //             line.setSublistValue({id: 'custpage_line_brand', line: index, value: data[i].brand || ' '});
        //             line.setSublistValue({
        //                 id: 'custpage_line_package_spec',
        //                 line: index,
        //                 value: data[i].packSpec || ' '
        //             });
        //             line.setSublistValue({
        //                 id: 'custpage_line_delivery_remarks',
        //                 line: index,
        //                 value: data[i].remarks || ' '
        //             });
        //             line.setSublistValue({
        //                 id: 'custpage_line_remain_subsidiary',
        //                 line: index,
        //                 value: data[i].subsidiary || ' '
        //             });
        //             index++;
        //         }
        //     }
        //     return form;
        // }

        /**
         * 根据subsidiary，获取subsidiary下的location
         * @param subsidiary
         * @returns {[{name: string, value: number}]}
         */
        function getLocation(subsidiary) {
            let brList = [{"value": 0, "name": ""}];
            let locationSearchObj = search.create({
                type: "location",
                filters:
                    [
                        ["subsidiary", "anyof", subsidiary]
                    ],
                columns:
                    [
                        search.createColumn({
                            name: "name",
                            sort: search.Sort.ASC,
                            label: "名称"
                        }),
                        search.createColumn({name: "internalid", label: "内部 ID"})
                    ]
            });
            let columns = locationSearchObj.columns;
            let res = commonApi.getAllData(locationSearchObj);
            if (res && res.length > 0) {
                for (let i = 0; i < res.length; i++) {
                    let locationNum = res[i].getValue(columns[0]);
                    let id = res[i].getValue(columns[1]);
                    let json = {};
                    json.value = id;
                    json.name = locationNum;
                    brList.push(json);
                }
            }
            // log.debug('brList', brList);
            return brList;
        }

        /**
         * 获取全部location
         * @returns {*[]}
         */
        function getAllLocation() {
            let brList = [];
            let locationSearchObj = search.create({
                type: "location",
                filters:
                    [],
                columns:
                    [
                        search.createColumn({
                            name: "name",
                            sort: search.Sort.ASC,
                            label: "名称"
                        }),
                        search.createColumn({name: "internalid", label: "内部 ID"})
                    ]
            });
            let columns = locationSearchObj.columns;
            let res = commonApi.getAllData(locationSearchObj);
            if (res && res.length > 0) {
                for (let i = 0; i < res.length; i++) {
                    let locationNum = res[i].getValue(columns[0]);
                    let id = res[i].getValue(columns[1]);
                    let json = {};
                    json.value = id;
                    json.name = locationNum;
                    brList.push(json);
                }
            }
            return brList;
        }


        /**
         * 获取全部有location的subsidiary
         * @returns {*[]}
         */
        function getAllSubsidiary() {
            let myLoadedQuery = query.load({id: 'custworkbook3'});
            let mySuiteQLQuery = myLoadedQuery.toSuiteQL();
            // log.debug('mySuiteQLQuery',mySuiteQLQuery.query);
            let results = mySuiteQLQuery.run();
            let mrSet = results.asMappedResults();
            // log.debug('mrSet',mrSet);


            let subIdArr = [];
            let subArr = [];
            for (let i = 0; i < mrSet.length; i++) {
                let subId = mrSet[i].id_1;
                let subName = mrSet[i].subsidiary;
                if (subIdArr.indexOf(subId) == -1) {
                    subIdArr.push(subId);
                    let json = {
                        name: subName,
                        value: subId
                    }
                    subArr.push(json);
                }
            }
            // log.debug('subArr',subArr);
            return subArr;
        }

        /**
         * 获取标准库存数据
         * @param params
         * @returns {*[]}
         */
        function getInventoryData(params) {
            let data = [];
            let filters = [], columns = [];
            if (params.item) {
                filters.push(["item", "anyof", params.item]);
            }
            if (params.itemFuzzy) {
                filters.push([["item.custitem_ecm_productname_en", "contains", params.itemFuzzy],
                    "OR",
                    ["item.custitem_ecm_productname_cn", "contains", params.itemFuzzy],
                    "OR",
                    ["item.displayname", "contains", params.itemFuzzy]]);
            }
            if (!params.item && !params.itemFuzzy && params.location) {
                filters.push(["location", "anyof", params.location]);
            } else if (params.location) {
                filters.push("and");
                filters.push(["location", "anyof", params.location]);
            }

            if (!params.item && !params.itemFuzzy && !params.location && params.subsidiary) {
                let lcList = getLocation(params.subsidiary);
                let lcArr = [];
                lcList.forEach(lc => {
                    lcArr.push(lc.value);
                });
                filters.push(["location", "anyof", lcArr]);
            } else if (!params.location && params.subsidiary) {
                let lcList = getLocation(params.subsidiary);
                let lcArr = [];
                lcList.forEach(lc => {
                    lcArr.push(lc.value);
                });
                filters.push("and");
                filters.push(["location", "anyof", lcArr]);
            }

            columns.push(search.createColumn({name: "item", summary: "GROUP", label: "货品"}));
            columns.push(search.createColumn({name: "location", summary: "GROUP", label: "地点"}));
            columns.push(search.createColumn({name: "onhand", summary: "SUM", label: "现有"}));
            columns.push(search.createColumn({name: "available", summary: "SUM", label: "可用"}));
            columns.push(search.createColumn({name: "inventorynumber", summary: "GROUP", label: "库存编号"}));
            columns.push(search.createColumn({name: "status", summary: "GROUP", label: "状态"}));
            columns.push(search.createColumn({
                name: "custitem_ecm_productname_cn",
                join: "item",
                summary: "GROUP",
                label: "中文名称"
            }));
            columns.push(search.createColumn({
                name: "custitem_ecm_productname_en",
                join: "item",
                summary: "GROUP",
                label: "英文名称"
            }));
            columns.push(search.createColumn({
                name: "custitem_ecm_brand",
                join: "item",
                summary: "GROUP",
                label: "品牌"
            }));
            columns.push(search.createColumn({
                name: "custitem_ecm_pack_spec",
                join: "item",
                summary: "GROUP",
                label: "Package Spec"
            }));
            columns.push(search.createColumn({
                name: "custitem_ecm_package_remk_en",
                join: "item",
                summary: "GROUP",
                label: "Package Remarks EN"
            }));
            columns.push(search.createColumn({
                name: "subsidiary",
                join: "location",
                summary: "GROUP",
                label: "子公司"
            }));


            let ibSearchObj = search.create({type: "inventorybalance", filters: filters, columns: columns});
            let res = commonApi.getAllData(ibSearchObj);

            if (res && res.length > 0) {
                for (let i = 0; i < res.length; i++) {
                    let item = res[i].getText(columns[0]);
                    let itemId = res[i].getValue(columns[0]);
                    let location = res[i].getValue(columns[1]);
                    let locationName = res[i].getText(columns[1]);
                    let onHand = res[i].getValue(columns[2]);
                    let available = res[i].getValue(columns[3]);
                    let inventoryNumber = res[i].getValue(columns[4]);
                    let inventoryNumberName = res[i].getText(columns[4]);
                    let status = res[i].getText(columns[5]);
                    let cn = res[i].getValue(columns[6]);
                    let en = res[i].getValue(columns[7]);
                    let brand = res[i].getValue(columns[8]);
                    let packSpec = res[i].getValue(columns[9]);
                    let remarks = res[i].getText(columns[10]);
                    let subsidiary = res[i].getValue(columns[11]);
                    let key = itemId + '&' + location + '&' + inventoryNumber + '&' + status;
                    let json = {
                        key: key,
                        no: i + 1,
                        item: item,
                        itemId: itemId,
                        location: location,
                        locationName: locationName,
                        onHand: onHand,
                        available: available,
                        inventoryNumber: inventoryNumber,
                        inventoryNumberName: inventoryNumberName,
                        status: status,
                        cn: cn,
                        en: en,
                        brand: brand,
                        packSpec: packSpec,
                        remarks: remarks,
                        subsidiary: subsidiary,
                    }
                    data.push(json);
                }
            }
            // log.debug('data',data);
            // log.debug('dataLength',data.length);
            return data;
        }

        return {onRequest}

    });
