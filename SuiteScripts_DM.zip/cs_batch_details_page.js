/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 * version      date            author      remark
 * 1.0          2023/03/04      Doris       【ID1018570】SP仓库发货时创建IT单---批次选择页面检验
 * 2.0          2023/03/15      Doris       测试修改
 */
define(['N/currentRecord', 'N/record', 'N/search', 'N/url', '/SuiteScripts/tools/common_api.js', '/SuiteScripts/SuiteScripts_DM/environment_check.js'],
/**
 * @param{currentRecord} currentRecord
 * @param{record} record
 * @param{search} search
 * @param{url} url
 */
function(currentRecord, record, search, url, commonApi, enume) {
    var subid = 'line_data';
    /**
     * Function to be executed after page is initialized.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.mode - The mode in which the record is being accessed (create, copy, or edit)
     *
     * @since 2015.2
     */
    function pageInit(scriptContext) {

    }

    function submitDetail() {
        try {
            var obj = currentRecord.get();
            var validSubmit = false, selectedData = [], selectedTotal = 0;
            var totalQty = obj.getValue('custpage_total');
            var availableQtySum = 0;
            var transferQtySum = 0;
            var lineCount = obj.getLineCount({sublistId:subid});
            if (lineCount <= 0){
                alert('No row data.');
                doCancel();
            }else {
                var batchArr = [];
                for (var i = 0; i < lineCount; i++){
                    var selectBatch = obj.getSublistValue({sublistId:subid, fieldId:'custpage_select_batch', line:i});
                    if ('T' == selectBatch || true == selectBatch){
                        var batchData = {};
                        var batchId = obj.getSublistValue({sublistId:subid, fieldId:'custpage_item_batch_name', line:i});
                        batchArr.push(batchId);
                        var availableQty = Number(obj.getSublistValue({sublistId: subid, fieldId: 'custpage_item_available_qty', line: i}) || 0);   // 可用数量
                        var transferQty = Number(obj.getSublistValue({sublistId: subid, fieldId: 'custpage_line_transfer_qty', line: i}) || 0); // 输入待转移数量
                        if (Number(availableQty) < Number(transferQty)){
                            alert('TRANSFER QTY must be less than or equal to AVAILABLE QTY!');
                            obj.selectLine({sublistId:subid, line:i});
                            obj.setCurrentSublistValue({sublistId:subid, fieldId:'custpage_select_batch', value:false});
                            obj.setCurrentSublistValue({sublistId:subid, fieldId:'custpage_line_transfer_qty', value:''});
                            obj.commitLine({sublistId:subid});
                            return;
                        }
                        batchData.batchId = batchId;
                        batchData.transferQty = transferQty;
                        availableQtySum = Number(availableQty) + Number(availableQtySum);
                        transferQtySum = Number(transferQty) + Number(transferQtySum);
                        validSubmit = true;
                        selectedData.push(batchData);
                        selectedTotal++;
                    }
                }
            }
            var newBatchArr = Array.from(new Set(batchArr));
            var flag = newBatchArr.length < batchArr.length;
            if (true == flag){
                alert('Cannot select the same batch, please reselect!');
                return;
            }
            if (transferQtySum != totalQty && 0 != selectedTotal){
                alert('The total quantity to be transferred  must be equal to '+ totalQty);
                var lineCount = obj.getLineCount({sublistId:subid});
                if (lineCount > 0){
                    for (var i =0; i < lineCount; i++){
                        var selectedBatch = obj.getSublistValue({sublistId:subid, fieldId:'custpage_select_batch', line:i});
                        if (true == selectedBatch || 'T' == selectedBatch){
                            obj.selectLine({sublistId:subid, line:i});
                            obj.setCurrentSublistValue({sublistId:subid, fieldId:'custpage_select_batch', value:false});
                            obj.setCurrentSublistValue({sublistId:subid, fieldId:'custpage_line_transfer_qty', value:''});
                            obj.commitLine({sublistId:subid});
                        }
                    }
                }
                selectedTotal = 0;
                validSubmit = false;
                return;
            }
            if(0 == selectedTotal) {
                alert('Please enter at least one line.');
                return;
            } else if(true == validSubmit) {
                var scdid = obj.getValue('custpage_scdid'),
                    item = obj.getValue('custpage_subitem'),
                    line = obj.getValue('custpage_line'),
                    location = obj.getValue({fieldId:'custpage_location'});
                window.opener.writeBack(scdid, item, line, selectedData, location, transferQtySum);
            }
            doCancel();
        }catch (e){
            console.log('submitDetail--error===>'+e);
        }
    }

    function doCancel() {
        setWindowChanged(window, false);
        window.close();
    }

    /**
     * Function to be executed when field is changed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
     * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
     *
     * @since 2015.2
     */
    function fieldChanged(scriptContext) {
        try {
            var curRec = scriptContext.currentRecord;
            var fieldId = scriptContext.fieldId;
            if ('custpage_item_batch_name' == fieldId){
                var scdlineid = curRec.getValue('custpage_scdid');
                // var seriallotJson = getInventoryDetail(scdlineid);
                var batchId = curRec.getCurrentSublistValue({sublistId:subid, fieldId:'custpage_item_batch_name'});

                var itemId = curRec.getValue('custpage_subitem');
                var location = curRec.getValue('custpage_location');
                var inventoryArr = getItemInventory(itemId, location);

                if (inventoryArr && Object.keys(inventoryArr).length > 0) {
                    var noShippedQty = getNoShippedInv(inventoryArr, scdlineid);
                    for (var invId in inventoryArr) {
                        var invValue = inventoryArr[invId]; // {inventorynumber:'',quantityavailable:0}
                        if (noShippedQty && noShippedQty.length) {
                            for (var j = 0; j < noShippedQty.length; j++) {
                                if (invId == noShippedQty[j].inventorynumber) {
                                    var quantityavailable = Number(invValue.quantityavailable).sub(noShippedQty[j].quantityavailable);
                                    if (Number(0) < Number(quantityavailable)) {
                                        invValue.quantityavailable = quantityavailable;
                                    } else {
                                        delete inventoryArr[invId];
                                    }
                                }
                            }
                        }
                    }
                }
                if (inventoryArr && Object.keys(inventoryArr).length > 0){
                    for (var invId in inventoryArr) {
                        if (invId == batchId){
                            curRec.setCurrentSublistValue({sublistId:subid, fieldId:'custpage_item_available_qty', value:inventoryArr[invId].quantityavailable});
                        }
                    }
                }
            }
            if ('custpage_line_transfer_qty' == fieldId){
                var transferQty = Number(curRec.getCurrentSublistValue({sublistId:subid, fieldId:'custpage_line_transfer_qty'}) || 0);
                var availableQty = Number(curRec.getCurrentSublistValue({sublistId:subid, fieldId:'custpage_item_available_qty'}) || 0);
                if (Number(0) > Number(transferQty)){
                    alert('TRANSFER QTY cannot enter a negative number!');
                    curRec.setCurrentSublistValue({sublistId:subid, fieldId:'custpage_line_transfer_qty', value:''});
                    return false;
                }
                if (Number(transferQty) > Number(availableQty)){
                    alert('The entered quantity of transferQty cannot be greater than the quantity of availableQty!');
                    curRec.setCurrentSublistValue({sublistId:subid, fieldId:'custpage_line_transfer_qty', value:''});
                    return false;
                }
            }
            if ('custpage_select_batch' == fieldId){
                var selectBatch = curRec.getCurrentSublistValue({sublistId:subid, fieldId:'custpage_select_batch'}) || '';
                if ('T' == selectBatch || true == selectBatch){
                    var transferQty = Number(curRec.getCurrentSublistValue({sublistId:subid, fieldId:'custpage_line_transfer_qty'}) || 0);
                    if (Number(0) == Number(transferQty)){
                        alert('Please enter the quantity of transferQty!');
                        curRec.setCurrentSublistValue({sublistId:subid, fieldId:'custpage_line_transfer_qty', value:''});
                        curRec.setCurrentSublistValue({sublistId:subid, fieldId:'custpage_select_batch', value:false});
                        return false;
                    }else {
                        var transferQty = Number(curRec.getCurrentSublistValue({sublistId:subid, fieldId:'custpage_line_transfer_qty'}) || 0);
                        var availableQty = Number(curRec.getCurrentSublistValue({sublistId:subid, fieldId:'custpage_item_available_qty'}) || 0);
                        var totalQty = Number(curRec.getValue('custpage_total') || 0);
                        if (Number(transferQty) > Number(availableQty)){
                            alert('The entered quantity of transferQty cannot be greater than the quantity of availableQty!');
                            curRec.setCurrentSublistValue({sublistId:subid, fieldId:'custpage_line_transfer_qty', value:''});
                            curRec.setCurrentSublistValue({sublistId:subid, fieldId:'custpage_select_batch', value:false});
                            return false;
                        }
                        if (Number(transferQty) > Number(totalQty)){
                            alert('The total number of the selected lines to be transferred is greater than the total number!');
                            curRec.setCurrentSublistValue({sublistId:subid, fieldId:'custpage_line_transfer_qty', value:''});
                            curRec.setCurrentSublistValue({sublistId:subid, fieldId:'custpage_select_batch', value:false});
                            return false;
                        }
                    }
                }
            }
            return true;
        }catch (e){
            console.log('batch_detail fieldChange error==>'+e);
        }


    }

    /**
     * 查询该批次除了本单外未出运的数量
     * @param inventoryArr
     * @param scdLineId
     * @returns {[]}
     */
    function getNoShippedInv(inventoryArr, scdLineId){
        var myFilters = [];
        var invIdArr = Object.keys(inventoryArr);
        myFilters.push(['custrecord_id_spline.custrecord_id_seriallot', 'anyof', invIdArr]);
        myFilters.push('and');
        myFilters.push(['custrecord_scdline_sp.custrecord_sp_status', 'anyof', enume.getAll().ECM_SHIPPING_STATUS_NOT_SHIPPED]);    // sp状态未出运
        myFilters.push('and');
        myFilters.push(['internalid', 'noneof', scdLineId]);
        var myColumns = [];
        myColumns.push({name:'custrecord_id_seriallot', join: 'CUSTRECORD_ID_SPLINE', summary:'GROUP', sort:'ASC'});   // 批次号
        myColumns.push({name:'custrecord_id_quantity', join: 'CUSTRECORD_ID_SPLINE', summary:'SUM'});   // 数量
        var mySearch = search.create({
            type:'customrecord_ecm_scd_line',
            filters:myFilters,
            columns:myColumns
        });
        var myResult = mySearch.run().getRange({start:0, end:1000});
        var inventArr = [];
        if (myResult && myResult.length > 0){
            for (var i = 0; i < myResult.length; i++){
                var inventJson = {};
                inventJson.inventorynumber = myResult[i].getValue(myColumns[0]);
                inventJson.quantityavailable = myResult[i].getValue(myColumns[1]);
                inventArr.push(inventJson);
            }
        }
        return inventArr;
    }

    /**
     * 获取当前货品该地点的库存可用数量
     * @param itemId
     * @param location
     * @returns {{}}
     */
    function getItemInventory(itemId, location){
        var myFilters = [];
        myFilters.push(['item.internalid', 'anyof', itemId]);
        myFilters.push('and');
        myFilters.push(['location', 'anyof', location]);
        myFilters.push('and');
        myFilters.push(['quantityavailable', 'greaterthan', '0']);

        var myColumns = [];
        myColumns.push('inventorynumber');   // 批次号
        myColumns.push('quantityavailable');   // 可用
        myColumns.push('internalid');
        var mySearch = search.create({
            type:'inventorynumber',
            filters:myFilters,
            columns:myColumns
        });
        var myResult = mySearch.run().getRange({start:0, end:1000});
        var inventArr = {};
        if (myResult && myResult.length > 0){
            for (var i = 0; i < myResult.length; i++){
                var invId = myResult[i].getValue(myColumns[2]);
                var inventorynumber = myResult[i].getValue(myColumns[0]) || '';
                var quantityavailable = Number(myResult[i].getValue(myColumns[1]) || 0);
                // 取相同批次id下上次的数据，如果没有就给默认值，没有就是''
                inventArr[invId] = inventArr[invId] || {inventorynumber:'',quantityavailable:0};
                // 上次累加后的数量与本次数量相加
                inventArr[invId].quantityavailable = Number(inventArr[invId].quantityavailable ).add(quantityavailable);
                inventArr[invId].inventorynumber = inventArr[invId].inventorynumber || inventorynumber;
            }
        }
        return inventArr;
    }


    /**
     * Function to be executed when field is slaved.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     *
     * @since 2015.2
     */
    function postSourcing(scriptContext) {

    }

    /**
     * Function to be executed after sublist is inserted, removed, or edited.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @since 2015.2
     */
    function sublistChanged(scriptContext) {

    }

    /**
     * Function to be executed after line is selected.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @since 2015.2
     */
    function lineInit(scriptContext) {

    }

    /**
     * Validation function to be executed when field is changed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
     * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
     *
     * @returns {boolean} Return true if field is valid
     *
     * @since 2015.2
     */
    function validateField(scriptContext) {

    }

    /**
     * Validation function to be executed when sublist line is committed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateLine(scriptContext) {
        try {
            var curRec = scriptContext.currentRecord;
            var batchNum = curRec.getCurrentSublistValue({sublistId:subid, fieldId:'custpage_item_batch_name'});
            if ('' == batchNum){
                curRec.setCurrentSublistValue({sublistId:subid, fieldId:'custpage_line_transfer_qty', value:''});
                alert('BATCH NUM not selected, cannot fill in TRANSFER QTY!');
                return false;
            }
        }catch (e){
            console.log('validateLine--error'+ e);
        }
        return true;
    }

    /**
     * Validation function to be executed when sublist line is inserted.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateInsert(scriptContext) {

    }

    /**
     * Validation function to be executed when record is deleted.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateDelete(scriptContext) {

    }

    /**
     * Validation function to be executed when record is saved.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @returns {boolean} Return true if record is valid
     *
     * @since 2015.2
     */
    function saveRecord(scriptContext) {

    }

    return {
        // pageInit: pageInit,
        fieldChanged: fieldChanged,
        // postSourcing: postSourcing,
        // sublistChanged: sublistChanged,
        // lineInit: lineInit,
        // validateField: validateField,
        validateLine: validateLine,
        // validateInsert: validateInsert,
        // validateDelete: validateDelete,
        // saveRecord: saveRecord,
        submitDetail: submitDetail,
        doCancel: doCancel
    };
    
});
