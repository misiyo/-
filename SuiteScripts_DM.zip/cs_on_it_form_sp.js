/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 * version      date            author      remark
 * 1.0          2023/02/23      Doris       【ID1018549】Shipping Plan提交审批校验
 * 2.0          2023/02/24      Doris       【ID1018570】SP仓库发货时创建IT单--->弃用
 * 3.0          2023/02/28      Doris       【ID1018580】Shipping Plan Create SO&IF
 * 4.0          2023/03/02      Doris       【ID1018570】SP仓库发货时创建IT单---点击按钮跳转it生成页面
 * 5.0          2023/03/10      Mark         SP添加按钮更新公司间价格（1018807）
 * 6.0          2023/03/10      Doris       【ID1018580】Shipping Plan Create SO&IF,变更：拆分为Create SO按钮及Create IF按钮
 * 7.0          2023/03/14      Doris       当Warehouse Stock被勾选时，不需要校验中信保申报状态(ID1018549)
 * 8.0          2023/03/21      Will Liu    添加按钮（1019290）
 * 9.0          2023/03/24      Doris       Shipping Plan提交审批校验变更（1018549）
 * 10.0         2023/03/27      Doris       Shipping Plan提交审批校验变更（1018549）
 * 11.0         2023/03/29      Doris       测试修改（1018549）
 * 12.0         2023/03/30      Doris       测试修改,使用SL脚本回写SP（1018549）
 * 13.0         2023/04/07      Doris       中信保检验变更（1018549）
 * 14.0         2023/04/09      Doris       Shipping Plan提交审批校验变更（1018549）
 * 15.0         2023/04/13      Doris       增加无中信保信息情况相关提示（1018549）
 */
define(['N/currentRecord', 'N/record', 'N/url', 'N/search', 'N/format', '/SuiteScripts/SuiteScripts_DM/environment_check.js'],
    /**
     * @param{currentRecord} currentRecord
     * @param{record} record
     * @param{url} url
     * @param{search} search
     * @param{format} format
     */
    function(currentRecord, record, url, search, format, enume) {
        var SP_SUBLIST_ID = 'recmachcustrecord_scdline_sp';
        /**
         * Function to be executed after page is initialized.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.mode - The mode in which the record is being accessed (create, copy, or edit)
         *
         * @since 2015.2
         */
        function pageInit(scriptContext) {

        }

        /**
         * 点击submit按钮校验sp数据
         * @param spType
         * @param spId
         */
        function submitSp(spType, spId){
            try{
                var spRec = record.load({
                    type:spType,
                    id:spId
                });
                var alertMsg = true;
                var apply = spRec.getValue('custrecord_sp_apply') || '';    // 是否投中信保
                var applyStatus = spRec.getValue('custrecord_sp_applystatus') || '';    // 中信保投保是否成功
                var warehousestock = spRec.getValue('custrecord_sp_warehousestock'); // WAREHOUSE STOCK

                var amount = spRec.getValue('custrecord_sp_topreamount'); // GROSS PREPAYMENT AMOUNT
                var preAmount = spRec.getValue('custrecord_sp_preamount');    // 预付款金额
                var contractType = spRec.getValue('custrecord_sp_contracttype');  // 业务类型

                var recordUrl = url.resolveRecord({
                    recordType:spType,
                    recordId:spId
                });
                var saveRecUrl = '';
                if(enume.getAll().ECM_SHIPPING_CONTRACTTYPE_CHOICE != contractType){
                    var payment = 0;
                    if (Number(preAmount) > Number(amount)){
                        alert('You cannot submit it due to insufficient advance payment.');
                        return;
                    }
                    if (true == apply && false == warehousestock){
                        var customer = spRec.getValue('custrecord_sp_customer');
                        var buyerNo = '';
                        if (customer){
                            var customerRec = record.load({type:'customer', id:customer});
                            var buyerId = customerRec.getValue('custentity_ecm_sinosurebuyerno');
                            if (buyerId){
                                var buyerRec = record.load({type:'customrecord_ecm_sinosure_buyercodeapply', id:buyerId});
                                buyerNo = buyerRec.getValue('custrecord_esbya_buyerno');
                            }
                        }
                        var subsidiary = spRec.getValue('custrecord_sp_scsubsidiary');
                        var policyNo = '';
                        if (subsidiary){
                            var subsidiaryRec = record.load({type:'subsidiary', id:subsidiary});
                            policyNo = subsidiaryRec.getValue('custrecord_policyno');
                        }
                        var surptype = spRec.getValue('custrecord_sp_surptype');    // 余款支付方式
                        var payMethodArr = getPayMethod(surptype);

                        var payMethodId = '';
                        if (payMethodArr && payMethodArr.length > 0){
                            // 查询支付方式
                            payMethodId = getRecordDataJson(payMethodArr, 'customrecord_ecm_sinosure_paymethod', 'name');
                        }

                        if (buyerNo && policyNo && payMethodId && payMethodId.length > 0){
                            payment = getPayment(buyerNo, policyNo, payMethodId);

                        }else {
                            alert('Customer credit limit information is not found in the system, please check! (Sinosure)');
                            return;
                        }
                        var shippingAmount = Number(spRec.getValue('custrecord_sp_shippingamount') || 0);    // 出运总金额
                        var topreAmount = Number(spRec.getValue('custrecord_sp_topreamount') || 0);  // 累计预付款金额
                        var topayAmount = Number(spRec.getValue('custrecord_sp_topayamount') || 0);    //  累计余款金额
                        var amount = Number(shippingAmount) - Number(topreAmount) - Number(topayAmount);

                        if (Number(payment) < Number(amount)){
                            alert('You cannot submit it because the Sinosure application is not successful.');
                            return;
                        }
                    }
                    var lineCount = spRec.getLineCount({sublistId:SP_SUBLIST_ID});
                    if (lineCount > 0){
                        var scIdArr = [];
                        for (var i = 0; i < lineCount; i++){
                            var scId = spRec.getSublistValue({sublistId:SP_SUBLIST_ID, fieldId:'custrecord_scdline_sc', line:i});
                            if (scId && '-1' == scIdArr.indexOf(scId)){
                                scIdArr.push(scId);
                            }
                        }
                        if (scIdArr && scIdArr.length > 0){
                            var scName = getCheckSc(scIdArr);
                            if (scName){
                                alert('The sign back contract of the sales contract'+ scName + 'is not complete and can not be submitted for approval.');
                                return;
                            }
                        }
                    }
                    saveRecUrl = url.resolveScript({
                        scriptId: 'customscript_ecm_sl_submitcheck_save_sp',     // 脚本的内部 ID。该 ID 必须标识 RESTlet 或 Suitelet。
                        deploymentId: 'customdeploy_ecm_sl_submitcheck_save_sp',
                        params:{
                            objRecType:spType,
                            objRecId:spId,
                            payment:payment,
                            alertMsg:alertMsg,
                            recordUrl:recordUrl
                        }// 包含用于描述查询的名称/值对的对象。
                    });
                }else{
                    alertMsg = true;
                    saveRecUrl = url.resolveScript({
                        scriptId: 'customscript_ecm_sl_submitcheck_save_sp',     // 脚本的内部 ID。该 ID 必须标识 RESTlet 或 Suitelet。
                        deploymentId: 'customdeploy_ecm_sl_submitcheck_save_sp',
                        params:{
                            objRecType:spType,
                            objRecId:spId,
                            payment:'',
                            alertMsg:alertMsg,
                            recordUrl:recordUrl
                        }// 包含用于描述查询的名称/值对的对象。
                    });
                }

                window.open(saveRecUrl, '_self', '');

            }catch (e){
                console.log('执行Submit-error===>'+e);
            }
        }

        /**
         * 查询预款/余款支付方式）
         * @param surptype
         * @returns {[]}
         */
        function getPayMethod(surptype){
            var myFilters = [];
            myFilters.push(['isinactive', 'is', 'false']);
            myFilters.push('and');
            myFilters.push(['internalid', 'anyof', surptype]);

            var myColumns = [];
            myColumns.push({name: "custrecord_epma_sinopaymethod", join: "CUSTRECORD_EPMA_PARENT", label: "中信保支付方式"});
            myColumns.push({name: "custrecord_epma_priority", join: "CUSTRECORD_EPMA_PARENT", sort: search.Sort.ASC, label: "优先级"});
            var mySearch = search.create({
                type:'customrecord_ecm_prepay_method',
                filters:myFilters,
                columns:myColumns
            });
            var myResult = mySearch.run().getRange({start:0, end:10});
            var payMethodArr = [];
            if (myResult && myResult.length > 0){
                for (var i = 0; i < myResult.length; i++){
                    var payMethod = myResult[i].getValue(myColumns[0]);
                    payMethodArr.push(payMethod);
                }
            }
            return payMethodArr;
        }

        /**
         * 判断sc的回签合同是否为空
         * @param scIdArr
         * @returns {string}
         */
        function getCheckSc(scIdArr){
            var myFilters = [];
            myFilters.push(['type', 'anyof', 'SalesOrd']);
            myFilters.push('and');
            myFilters.push(['internalid', 'anyof', scIdArr]);

            var myColumns = [];
            myColumns.push('tranid');
            myColumns.push('custbody_ecm_sc_document');
            var mySearch = search.create({type:'salesorder', filters:myFilters, columns:myColumns});
            var myResult = mySearch.run().getRange({start:0, end:1000});
            if (myResult && myResult.length > 0){
                for (var i = 0; i < myResult.length; i++){
                    var name = myResult[i].getValue(myColumns[0]);
                    var document = myResult[i].getValue(myColumns[1]);
                    if ('' == document){
                        return name;
                    }
                }
            }
            return '';
        }

        /**
         * 查询限额余额
         * @param buyerNo
         * @param policyNo
         * @param payMethodId
         * @returns {string}
         */
        function getPayment(buyerNo, policyNo, payMethodId){
            var myFilters = [];
            myFilters.push(['isinactive', 'is', 'false']);
            myFilters.push('and');
            myFilters.push(['custrecord_esl_buyerno', 'is', buyerNo]);
            myFilters.push('and');
            myFilters.push(['custrecord_esl_policyno', 'is', policyNo]);
            myFilters.push('and');
            myFilters.push(['custrecord_esl_paymode', 'anyof', payMethodId]);
            var myColumns = [];
            myColumns.push('custrecord_esl_quotabalance');
            myColumns.push({name:'custrecord_esl_paymode', sort: search.Sort.ASC});
            var mySearch = search.create({type:'customrecord_ecm_sinosure_limitbalance', filters:myFilters, columns:myColumns});
            var myResult = mySearch.run().getRange({start:0, end:10});
            var quotabalanceArr = [];

            if (myResult && myResult.length > 0){
                for (var i = 0; i < myResult.length; i++){
                    var quotabalance = Number(myResult[i].getValue(myColumns[0]) || 0);
                    quotabalanceArr.push(quotabalance);
                }
            }
            if (quotabalanceArr && quotabalanceArr.length == 0){
                quotabalanceArr[0] = 0;
            }
            return quotabalanceArr[0];
        }

        /**
         * 查询记录
         * @param payment
         * @param searchType
         * @param fieldId
         * @returns {{}}
         */
        function getRecordDataJson(payment, searchType, fieldId){
            var myFilters = [];
            myFilters.push(['isinactive', 'is', 'false']);
            var insideFilters = [];
            if (payment && payment.length > 0){
                myFilters.push('and');
                for (var i = 0; i < payment.length; i++){
                    if(0!=i){
                        insideFilters.push('or')
                    }
                    insideFilters.push([fieldId, 'is', payment[i]]);
                }
                myFilters.push(insideFilters);
            }

            var myColumns = [];
            myColumns.push('internalid');
            var mySearch = search.create({
                type:searchType,
                filters:myFilters,
                columns:myColumns
            });
            var myResult = mySearch.run().getRange({start:0, end:10});
            var internalIdArr = [];
            if (myResult && myResult.length > 0){
                for (var i = 0; i < myResult.length; i++){
                    var internalId = myResult[i].getValue(myColumns[0]);
                    internalIdArr.push(internalId);
                }
            }
            return internalIdArr;
        }


        /**
         * 点击Create SO按钮生成so单
         * @param spType
         * @param spId
         */
        var createClick = false;
        function createSo(spType, spId){
            if (createClick){
                alert('Clicked, please wait!')
            }else {
                try{
                    var createUrl = url.resolveScript({
                        scriptId: 'customscript_ecm_sl_on_shipping_plan',     // 脚本的内部 ID。该 ID 必须标识 RESTlet 或 Suitelet。
                        deploymentId: 'customdeploy_ecm_sl_on_shipping_plan',
                        params:{
                            objRecType:spType,
                            objRecId:spId,
                            createType:'createSo'
                        }// 包含用于描述查询的名称/值对的对象。
                    });
                    window.open(createUrl, '_blank', '');
                    createClick = true;
                }catch (e){
                    console.log('执行Create SO-error===>'+e);
                }
            }
        }

        /**
         * 点击Create If按钮生成IF单
         * @param spType
         * @param spId
         */
        var createClick = false;
        function createIf(spType, spId){
            if (createClick){
                alert('Clicked, please wait!')
            }else {
                try{
                    var createUrl = url.resolveScript({
                        scriptId: 'customscript_ecm_sl_on_shipping_plan',     // 脚本的内部 ID。该 ID 必须标识 RESTlet 或 Suitelet。
                        deploymentId: 'customdeploy_ecm_sl_on_shipping_plan',
                        params:{
                            objRecType:spType,
                            objRecId:spId,
                            createType:'createIf'
                        }// 包含用于描述查询的名称/值对的对象。
                    });
                    window.open(createUrl, '_blank', '');
                    createClick = true;
                }catch (e){
                    console.log('执行Create If-error===>'+e);
                }
            }
        }



        /**
         * Warehouse delivery按钮跳转it生成页面
         * @param spType
         * @param spId
         * @param scdlineId
         */
        function warehouseSp(spType, spId, scdlineId){
            try {
                var createUrl = url.resolveScript({
                    scriptId: 'customscript_ecm_sl_batch_info_page',     // 脚本的内部 ID。该 ID 必须标识 RESTlet 或 Suitelet。
                    deploymentId: 'customdeploy_ecm_sl_batch_info_page',
                    params:{
                        objRecType:spType,
                        objRecId:spId,
                        scdlineId:scdlineId
                    }// 包含用于描述查询的名称/值对的对象。
                });
                window.open(createUrl, '_blank', 'height=600, width=800, left=0, top=0;');
            }catch (e){
                console.log('跳转it生成页面error====>'+e);
            }
        }



        /**
         * Function to be executed when field is changed.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         * @param {string} scriptContext.fieldId - Field name
         * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
         * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
         *
         * @since 2015.2
         */
        function fieldChanged(scriptContext) {

        }

        /**
         * Function to be executed when field is slaved.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         * @param {string} scriptContext.fieldId - Field name
         *
         * @since 2015.2
         */
        function postSourcing(scriptContext) {

        }

        /**
         * Function to be executed after sublist is inserted, removed, or edited.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         *
         * @since 2015.2
         */
        function sublistChanged(scriptContext) {

        }

        /**
         * Function to be executed after line is selected.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         *
         * @since 2015.2
         */
        function lineInit(scriptContext) {

        }

        /**
         * Validation function to be executed when field is changed.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         * @param {string} scriptContext.fieldId - Field name
         * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
         * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
         *
         * @returns {boolean} Return true if field is valid
         *
         * @since 2015.2
         */
        function validateField(scriptContext) {

        }

        /**
         * Validation function to be executed when sublist line is committed.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         *
         * @returns {boolean} Return true if sublist line is valid
         *
         * @since 2015.2
         */
        function validateLine(scriptContext) {

        }

        /**
         * Validation function to be executed when sublist line is inserted.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         *
         * @returns {boolean} Return true if sublist line is valid
         *
         * @since 2015.2
         */
        function validateInsert(scriptContext) {

        }

        /**
         * Validation function to be executed when record is deleted.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         *
         * @returns {boolean} Return true if sublist line is valid
         *
         * @since 2015.2
         */
        function validateDelete(scriptContext) {

        }

        /**
         * Validation function to be executed when record is saved.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @returns {boolean} Return true if record is valid
         *
         * @since 2015.2
         */
        function saveRecord(scriptContext) {

        }

        var isClick = false;
        function updateICPrice(spType, spId) {
            if(false == isClick) {
                var slUrl = url.resolveScript({
                    scriptId: 'customscript_ecm_sp_update_ic_price_sl',
                    deploymentId: 'customdeploy_ecm_sp_update_ic_price_sl'
                });
                window.open(slUrl + '&sptype=' + encodeURIComponent(spType) + '&spid=' + encodeURIComponent(spId), '_self');
                isClick = true;
            } else {
                alert('You have already clicked this button, please wait.')
            }
        }

        function bookingInfo(spId) {
            var slUrl = url.resolveScript({
                scriptId: 'customscript_ecm_sl_booking_info',
                deploymentId: 'customdeploy_ecm_sl_booking_info'
            });
            window.open(slUrl + '&spid=' + encodeURIComponent(spId), '_bank','height=1000,width=1000');
        }

        function departureInfo(spId) {
            var slUrl = url.resolveScript({
                scriptId: 'customscript_ecm_sl_departure_info',
                deploymentId: 'customdeploy_ecm_sl_departure_info'
            });
            window.open(slUrl + '&spid=' + encodeURIComponent(spId), '_bank','height=600,width=600');
        }

        return {
            pageInit: pageInit,
            // fieldChanged: fieldChanged,
            // postSourcing: postSourcing,
            // sublistChanged: sublistChanged,
            // lineInit: lineInit,
            // validateField: validateField,
            // validateLine: validateLine,
            // validateInsert: validateInsert,
            // validateDelete: validateDelete,
            // saveRecord: saveRecord,
            warehouseSp:warehouseSp,
            submitSp:submitSp,
            updateICPrice: updateICPrice,
            createSo:createSo,
            createIf:createIf,
            bookingInfo : bookingInfo,
            departureInfo : departureInfo
        };

    });