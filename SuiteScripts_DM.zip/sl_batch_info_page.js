/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 * version      date            author      remark
 * 1.0          2023/03/02      Doris       【ID1018570】SP仓库发货时创建IT单---it生成页面
 * 2.0          2023/03/15      Doris       测试修改
 * 3.0          2023/03/17      Doris       测试修改，子公司取值变更为：取地点列表中的子公司，to location变更为取地点列表中的子公司对应的虚拟仓
 * 4.0          2023/03/21      Doris       变更：仅配货类型为仓库发货的明细行带到页面中
 * 5.0          2023/03/24      Doris       变更：1、由主表中的location生成IT单变更为根据明细行中的location生成IT单；2、获取系统库存的库存状态
 * 6.0          2023/03/27      Doris       测试修改：删除主体location，明细行ACTUAL SHIPMENT QTY字段回写
 */
define(['N/http', 'N/record', 'N/redirect', 'N/search', 'N/ui/serverWidget', 'N/url', 'N/format', '/SuiteScripts/tools/common_api.js', '/SuiteScripts/SuiteScripts_DM/environment_check.js'],
    /**
 * @param{http} http
 * @param{record} record
 * @param{redirect} redirect
 * @param{search} search
 * @param{serverWidget} serverWidget
 * @param{url} url
 * @param{format} format
 */
    (http, record, redirect, search, serverWidget, url, format, commonApi, enume) => {
        const SP_SUBLIST_ID = 'recmachcustrecord_scdline_sp';
        const dataListDetailFields = [
            {id: 'custpage_data_itemid', label: 'Item NO.', type: serverWidget.FieldType.TEXT, key: 'item', hide:true},
            {id: 'custpage_data_itemname', label: 'Item Name.', type: serverWidget.FieldType.TEXT, key: 'itemName'},
            {id: 'custpage_data_unit', label: 'Units.', type: serverWidget.FieldType.TEXT, key: 'unit', hide:true},
            {id: 'custpage_data_location', label: 'Location.', type: serverWidget.FieldType.TEXT, key: 'location', hide:true},
            {id: 'custpage_data_location_name', label: 'Location.', type: serverWidget.FieldType.TEXT, key: 'locationName'},
            {id: 'custpage_data_quantity', label: 'Transfer Qty(This Time).', type: serverWidget.FieldType.INTEGER, key: 'quantity'},  // 本次可转移数量-> 从sp单带
            {id: 'custpage_data_scdlineid', label: 'Scd Line Id.', type: serverWidget.FieldType.TEXT, key: 'scdLineId', hide:true},
            {id: 'custpage_data_batchid', label: 'Batch Id.', type: serverWidget.FieldType.TEXT/*, key: 'batchid', hide:true*/},
            {id: 'custpage_data_actual_transfer_qty', label: 'Actual Transfer Qty', type: serverWidget.FieldType.FLOAT},    // 实际转移数量-> 从detail页面带
            {id: 'custpage_data_detail', label: 'Details', type: serverWidget.FieldType.TEXT},
        ];


        /**
         * Defines the Suitelet script trigger point.
         * @param {Object} scriptContext
         * @param {ServerRequest} scriptContext.request - Incoming request
         * @param {ServerResponse} scriptContext.response - Suitelet response
         * @since 2015.2
         */
        const onRequest = (scriptContext) => {
            let request = scriptContext.request;
            let response = scriptContext.response;
            let params = request.parameters;
            try {
                if('GET' == request.method) {
                    let form = createForm(params);
                    response.writePage(form);
                }else {
                    let ret = {};
                    ret = getData(request, params);
                    try {
                        creatInvTransfer(ret, params);

                        response.write("<script type='text/javascript'>window.opener.location.reload();window.close();</script>");
                    }catch (ex){
                        log.error('创建inventorytransfer-error',ex);
                        response.write("<script type='text/javascript'>window.opener.location.reload();</script>");
                        response.write({output:'创建inventorytransfer-error:'+ ex.message})
                    }
                }

            }catch (e){
                log.error('IT单生成页面有误', e);
            }
        }

        /**
         * 创建IT单
         * @param ret
         * @param params
         */
        const creatInvTransfer = (ret, params) => {
            let mainData = ret.mainData;
            let dataArr = ret.list;
            let batchIdArr = ret.batchIdArr;
            let itemArr = ret.itemArr;
            log.debug('data', {dataArr:dataArr,batchIdArr:batchIdArr,itemArr:itemArr})

            if (dataArr && Object.keys(dataArr).length > 0){
                let batchInfo = [];

                let locationArr = Object.keys(dataArr);
                if (batchIdArr && batchIdArr.length > 0){
                    batchInfo = getInvInfo(itemArr, batchIdArr, locationArr);
                }
                for (const dataArrKey in dataArr) {
                    let subsidiaryId = '';
                    if (dataArrKey){
                        let locationRec = record.load({type:'location', id:dataArrKey});
                        subsidiaryId = locationRec.getValue('subsidiary');
                    }
                    let transferLocationName = '';
                    let transferLocation = '';
                    if (subsidiaryId){
                        let subsidiaryRec = record.load({type:'subsidiary', id:subsidiaryId});
                        transferLocationName = subsidiaryRec.getText('custrecord_ecm_location');
                        transferLocation = subsidiaryRec.getValue('custrecord_ecm_location');
                    }
                    let dataArrValue = dataArr[dataArrKey];
                    let itRec = record.create({type:'inventorytransfer',isDynamic:true});
                    let scdArr = [];

                    let spId = mainData.spId;
                    let trandate = mainData.trandate;
                    let memo = mainData.memo;
                    itRec.setValue({fieldId:'subsidiary', value:subsidiaryId});
                    itRec.setValue({fieldId:'location', value:dataArrKey,forceSyncSourcing:true});
                    itRec.setValue({fieldId:'transferlocation', value:transferLocation, forceSyncSourcing:true});
                    itRec.setValue({fieldId:'custbody_ecm_sp', value:spId});
                    itRec.setText({fieldId:'trandate', text:getFormatDate(trandate)});
                    itRec.setValue({fieldId:'memo', value:memo});

                    let subId = 'inventory';

                    if (dataArrValue && dataArrValue.length > 0){
                        for (let i = 0; i < dataArrValue.length; i++){
                            let scdJson = {};
                            itRec.selectNewLine({sublistId:subId});
                            itRec.setCurrentSublistValue({sublistId:subId, fieldId:'item', value:dataArrValue[i].itemId});
                            itRec.setCurrentSublistValue({sublistId:subId, fieldId:'units', value:dataArrValue[i].itemUnit});
                            itRec.setCurrentSublistValue({sublistId:subId, fieldId:'adjustqtyby', value:dataArrValue[i].transferQty});
                            itRec.setCurrentSublistValue({sublistId:subId, fieldId:'custcol_ecm_spline', value:dataArrValue[i].scdLineId});

                            scdJson.actualQty = dataArrValue[i].transferQty;
                            scdJson.scdLineId = dataArrValue[i].scdLineId;
                            scdArr.push(scdJson);

                            let inventorydetail = itRec.getCurrentSublistSubrecord({
                                sublistId: subId,
                                fieldId: 'inventorydetail'
                            });
                            let inventorySubId = 'inventoryassignment';
                            let batchData = dataArrValue[i].batchData;

                            if (batchData && batchData.length > 0){
                                for (let j = 0; j < batchData.length; j++){
                                    let batchId = batchData[j].batchId;
                                    let transferQty = batchData[j].transferQty;
                                    let batchStatus = '';
                                    if (batchInfo && batchInfo.length > 0){
                                        for (let k = 0; k < batchInfo.length; k++){
                                            if (batchInfo[k].seriallot == batchId){
                                                batchStatus = batchInfo[k].status;
                                            }
                                        }
                                    }
                                    inventorydetail.selectNewLine({sublistId: inventorySubId});
                                    inventorydetail.setCurrentSublistValue({sublistId: inventorySubId, fieldId: 'issueinventorynumber', value: batchId});//序号批次号
                                    inventorydetail.setCurrentSublistValue({sublistId: inventorySubId, fieldId: 'inventorystatus', value: batchStatus, forceSyncSourcing:true});//TODO
                                    inventorydetail.setCurrentSublistValue({sublistId: inventorySubId, fieldId: 'toinventorystatus', value: batchStatus, forceSyncSourcing:true});//TODO
                                    inventorydetail.setCurrentSublistValue({sublistId: inventorySubId, fieldId: 'quantity', value: transferQty, forceSyncSourcing:true});//数量
                                    inventorydetail.commitLine({sublistId: inventorySubId});
                                }
                            }
                            itRec.commitLine({sublistId: subId});
                        }
                    }

                    let itId = itRec.save({enableSourcing:true, ignoreMandatoryFields:true});
                    if (itId){
                        if (scdArr && scdArr.length > 0){
                            for (let i = 0; i < scdArr.length; i++){
                                let scdRec = record.load({type:'customrecord_ecm_scd_line', id:scdArr[i].scdLineId});
                                scdRec.setValue({fieldId:'custrecord_scdline_it', value:itId});
                                scdRec.setValue({fieldId:'custrecord_scdline_spqty', value:Number(scdArr[i].actualQty)})
                                scdRec.save({enableSourcing:true, ignoreMandatoryFields:true});
                            }
                        }
                    }
                }
            }
        }

        /**
         * 获取页面数据
         * @param request
         * @param params
         * @returns {{}}
         */
        const getData = (request, params) => {
            let ret = {};
            let mainData = {};
            mainData.spId = params.custpage_data_shipping_plan;
            mainData.subsidiary = params.custpage_data_subsidiary;
            mainData.transferLocation = params.custpage_data_transferlocation;
            mainData.trandate = params.custpage_data_trandate;
            mainData.memo = params.custpage_data_memo;

            let slid = 'line_data';
            let count = request.getLineCount({group: slid});
            let data = {};
            let itemArr = [];
            let batchIdArr = [];
            for (let i = 0; i < count; i++) {

                let isChecked = request.getSublistValue({group: slid, name: 'custpage_data_select', line: i});
                if ('T' == isChecked || true == isChecked){
                    let itemJson = {}
                    let itemId = request.getSublistValue({group: slid, name: 'custpage_data_itemid', line: i});
                    let itemUnit = request.getSublistValue({group: slid, name: 'custpage_data_unit', line: i});
                    let transferQty = request.getSublistValue({group: slid, name: 'custpage_data_quantity', line: i});
                    let batchData = JSON.parse(request.getSublistValue({group: slid, name: 'custpage_data_batchid', line: i}));
                    let scdLineId = request.getSublistValue({group: slid, name: 'custpage_data_scdlineid', line: i});
                    let location = request.getSublistValue({group:slid, name: 'custpage_data_location', line:i});

                    data[location] = data[location] || [];

                    itemJson.itemId = itemId;
                    itemJson.itemUnit = itemUnit;
                    itemJson.transferQty = transferQty;
                    itemJson.batchData = batchData;
                    itemJson.scdLineId = scdLineId;
                    data[location].push(itemJson);

                    if ('-1' == itemArr.indexOf(itemId) && 'undefined' != typeof itemId){
                        itemArr.push(itemId);
                    }
                    if (batchData && batchData.length > 0){
                        for (let j = 0; j < batchData.length; j++){
                            let batchId = batchData[j].batchId;
                            if ('-1' == batchIdArr.indexOf(batchId) && 'undefined' != typeof batchId){
                                batchIdArr.push(batchId);
                            }
                        }
                    }
                }
            }

            ret.mainData = mainData;
            ret.list = data;
            ret.itemArr = itemArr;
            ret.batchIdArr = batchIdArr;
            return ret;
        }

        /**
         * 创建it生成页面
         * @param params
         * @returns {Form}
         */
        const createForm = (params) => {
            let form = serverWidget.createForm({title: 'Inventory Transfer Generate Page', hideNavBar:true});
            if (params.objRecId){
                form.clientScriptModulePath = '/SuiteScripts/SuiteScripts_DM/cs_batch_info_page.js';

                form.addSubmitButton({label: 'Create Inventory Transfer'});

                createMainFields(form, params);
                createDetailFields(form, params);
                return form;
            }else {
                let tField = form.addField({id:'custpage_page_error', type:serverWidget.FieldType.TEXT, label:'Page Error'});
                tField.defaultValue = 'No sp-related information.';
            }
        }

        const createMainFields = (form, params) => {
            // 添加Main
            let mainInfoField = form.addFieldGroup({
                id:'custpage_main_info',
                label:'Main Info'
            });
            let spData = getSpInfo(params.objRecId);

            let locationId = ''
            if (spData && Object.keys(spData).length > 0){
                for (const spDataKey in spData) {
                    locationId = spData[spDataKey].location;
                }
            }
            let subsidiaryId = '';
            if (locationId){
                let locationRec = record.load({type:'location', id:locationId});
                subsidiaryId = locationRec.getValue('subsidiary');
            }

            let spIdField = form.addField({id: 'custpage_data_shipping_plan', label: 'Shipping Plan Id', type: serverWidget.FieldType.TEXT, container:'custpage_main_info'});
            let spNameField = form.addField({id: 'custpage_data_shipping_plan_name', label: 'Shipping Plan', type: serverWidget.FieldType.TEXT, container:'custpage_main_info'});
            let subsidiaryField = form.addField({id: 'custpage_data_subsidiary', label: 'Subsidiary Id', type: serverWidget.FieldType.TEXT, container:'custpage_main_info'});
            let subsidiaryNameField = form.addField({id: 'custpage_data_subsidiary_name', label: 'Subsidiary', type: serverWidget.FieldType.TEXT, container:'custpage_main_info'});
            let trandateField = form.addField({id: 'custpage_data_trandate', label: 'Trandate', type: serverWidget.FieldType.DATE, container:'custpage_main_info'});
            let memoField = form.addField({id: 'custpage_data_memo', label: 'Memo', type: serverWidget.FieldType.TEXT, container:'custpage_main_info'});
            // 设置Main Info显示
            spIdField.updateDisplayType({displayType: serverWidget.FieldDisplayType.HIDDEN});
            subsidiaryField.updateDisplayType({displayType: serverWidget.FieldDisplayType.HIDDEN});
            spNameField.updateDisplayType({displayType: serverWidget.FieldDisplayType.DISABLED});
            subsidiaryNameField.updateDisplayType({displayType: serverWidget.FieldDisplayType.DISABLED});
            trandateField.updateDisplayType({displayType: serverWidget.FieldDisplayType.DISABLED});

            // 赋值Main Info
            if (spData && Object.keys(spData)){
                for (const spId in spData) {
                    let spValue = spData[spId];
                    let nowDate = commonApi.getNowDateTime(getFormatDate(new Date()));
                    spIdField.defaultValue = spId;
                    subsidiaryField.defaultValue = subsidiaryId;
                    spNameField.defaultValue = spValue.spName;
                    subsidiaryNameField.defaultValue = spValue.subsidiary;
                    trandateField.defaultValue = format.format({value:new Date(nowDate), type:format.Type.DATE});
                }
            }
        }

        /**
         * 创建明细行
         * @param form
         * @param params
         */
        const createDetailFields = (form, params) => {
            let dataList = form.addSublist({id: 'line_data', type: 'list', label: 'Detail Result'});
            let scdLineData = getScdLine(params);
            dataList.addField({id : 'custpage_data_select',label : 'Selected',type : serverWidget.FieldType.CHECKBOX});

            dataListDetailFields.forEach(function (field) {
                let tField = dataList.addField({id: field.id, type: field.type, label: field.label});
                if(true == field.hide) {
                    tField.updateDisplayType({displayType: serverWidget.FieldDisplayType.HIDDEN});
                }

                if ('custpage_data_actual_transfer_qty' == field.id){
                    tField.updateDisplayType({displayType: serverWidget.FieldDisplayType.ENTRY});
                    tField.updateDisplayType({displayType: serverWidget.FieldDisplayType.DISABLED});
                }
                if ('custpage_data_quantity' == field.id){
                    tField.updateDisplayType({displayType: serverWidget.FieldDisplayType.ENTRY});
                    // tField.updateDisplayType({displayType: serverWidget.FieldDisplayType.DISABLED});
                }
                if ('custpage_data_batchid' == field.id){
                    tField.updateDisplayType({displayType: serverWidget.FieldDisplayType.ENTRY});
                    tField.updateDisplayType({displayType: serverWidget.FieldDisplayType.DISABLED});
                    tField.updateDisplayType({displayType: serverWidget.FieldDisplayType.HIDDEN});
                }
            });

            const detailPageLink = url.resolveScript({
                scriptId: 'customscript_ecm_sl_batch_detail_page',
                deploymentId: 'customdeploy_ecm_sl_batch_detail_page'
            });

            scdLineData.forEach(function (data, index) {
                dataListDetailFields.forEach(function (field) {
                    if('undefined' != typeof field.key) {
                        dataList.setSublistValue({id : field.id,line : index,value: serverWidget.FieldType.INTEGER == field.type ? Number(data[field.key] || 0).toFixed(0) : (data[field.key] || ' ')});
                    }
                    let transferQty = dataList.getSublistValue({id:'custpage_data_quantity', line:index});
                    if('custpage_data_detail' == field.id && '' != transferQty) {
                        let tlink = `${detailPageLink}&scdid=${data.scdLineId}&item=${data.item}&line=${index}&spid=${params.objRecId}&total=${transferQty}&location=${data.location}`;
                        let link = `<button onclick="openDetailsPage(${data.scdLineId}, ${data.item}, ${index}, ${params.objRecId}, ${transferQty}, ${data.location});">Details</button>`;

                        dataList.setSublistValue({id: field.id, line: index, value: link});
                    }
                });
            });
        }


        /**
         * 格式化日期
         * @param oldDate
         * @returns {string}
         */
        function getFormatDate(oldDate) {
            var newDate = format.format({
                value:new Date(oldDate),
                type:format.Type.DATE
            });
            return newDate
        }


        /**
         * 根据货品及批次查询自定义批次信息
         * @param itemArr
         * @param batchIdArr
         * @param locationArr
         * @returns {[]}
         */
        function getInvInfo(itemArr, batchIdArr, locationArr){
            let myFilters = [];
            myFilters.push(['item', 'anyof', itemArr]);
            myFilters.push('and');
            myFilters.push(['inventorynumber', 'anyof', batchIdArr]);
            myFilters.push('and');
            myFilters.push(['location', 'anyof', locationArr]);
            let myColumns = [];
            myColumns.push('item');   // 货品id
            myColumns.push('inventorynumber');  // 批号
            myColumns.push('status');   // 状态
            myColumns.push('onhand');   // 数量
            myColumns.push('location');   // 地点

            let mySearch = search.create({
                type:'invtnumberitembalance',
                filters:myFilters,
                columns:myColumns
            });
            let myResult = mySearch.run().getRange({start:0, end:1000});
            let inventArr = [];
            if (myResult && myResult.length > 0){
                for (let i = 0; i < myResult.length; i++){
                    let inventJson = {};
                    let item = myResult[i].getValue(myColumns[0]);
                    let seriallot = myResult[i].getValue(myColumns[1]);
                    let status = myResult[i].getValue(myColumns[2]);
                    let quantity = myResult[i].getValue(myColumns[3]);
                    let location = myResult[i].getValue(myColumns[4]);
                    inventJson.item = item;
                    inventJson.seriallot = seriallot;
                    inventJson.status = status;
                    inventJson.quantity = quantity;
                    inventJson.location = location;
                    inventArr.push(inventJson);
                }
            }
            log.debug('getInvInfo',inventArr)
            return inventArr;
        }


        /**
         * 查询sp主表数据
         * @param spId
         * @returns {{}}
         */
        function getSpInfo(spId){
            var myFilters = [];
            myFilters.push(['isinactive', 'is', 'false']);
            myFilters.push('and');
            myFilters.push(['internalid', 'anyof', spId]);
            var myColumns = [];
            myColumns.push('custrecord_sp_location.subsidiary');   // 子公司
            myColumns.push('custrecord_sp_location');   // 发出仓 from location
            myColumns.push('internalid');   //  spId
            myColumns.push('name');   //  spName
            var mySearch = search.create({
                type:'customrecord_ecm_sp',
                filters:myFilters,
                columns:myColumns
            });
            var myResult = mySearch.run().getRange({start:0, end:1000});
            var spData = {};
            if (myResult && myResult.length > 0){
                for (var i = 0; i < myResult.length; i++) {
                    let spId = myResult[i].getValue(myColumns[2]) || '';
                    var subsidiary = myResult[i].getValue(myColumns[0]) || '';
                    var location = myResult[i].getValue(myColumns[1]) || '';
                    let spName = myResult[i].getValue(myColumns[3]) || '';
                    var locationName = myResult[i].getText(myColumns[1]) || '';
                    spData[spId] = {subsidiary:subsidiary, location:location, spName:spName, locationName:locationName};
                }
            }
            log.debug('getSpInfo',spData)
            return spData;
        }

        /**
         * 查询shipping plan对应的Sales Contract Distribution Line
         * @param params
         * @returns {[]}
         */
        function getScdLine(params){
            var myFilters = [];
            myFilters.push(['isinactive', 'is', 'false']);
            if (params.objRecId){
                myFilters.push('and');
                myFilters.push(['custrecord_scdline_sp', 'anyof', params.objRecId]);
            }
            myFilters.push('and');
            myFilters.push(['custrecord_scdline_distributiontype', 'anyof', enume.getAll().ECM_SHIPPING_DISTRIBUTION_TYPE]);
            myFilters.push('and');
            myFilters.push(['custrecord_scdline_it', 'anyof', '@NONE@']);
            var myColumns = [];
            myColumns.push('internalid');   // scd id
            myColumns.push('custrecord_scdline_item');   //
            myColumns.push('custrecord_scdline_qty');   //
            myColumns.push('custrecord_scdline_unit');   //
            myColumns.push('custrecord_scdline_location'); //地点

            var mySearch = search.create({
                type:'customrecord_ecm_scd_line',
                filters:myFilters,
                columns:myColumns
            });
            var myResult = mySearch.run().getRange({start:0, end:1000});
            var scdLineIdArr = [];
            if (myResult && myResult.length > 0){
                for (var i = 0; i < myResult.length; i++){
                    var thisJson = {};
                    thisJson.scdLineId = myResult[i].getValue(myColumns[0]);
                    thisJson.item = myResult[i].getValue(myColumns[1]);
                    thisJson.itemName = myResult[i].getText(myColumns[1]);
                    thisJson.quantity = myResult[i].getValue(myColumns[2]);
                    thisJson.unit = myResult[i].getValue(myColumns[3]);
                    thisJson.location = myResult[i].getValue(myColumns[4]);
                    thisJson.locationName = myResult[i].getText(myColumns[4]);
                    scdLineIdArr.push(thisJson);
                }
            }
            log.debug('scdLineIdArr',scdLineIdArr)
            return scdLineIdArr;
        }

        return {onRequest}

    });
