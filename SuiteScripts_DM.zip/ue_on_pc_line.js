/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * version      date            author      remark
 * 1.0          2023/02/21      Doris       【ID1018394】采购合同行默认关闭不允许收货等后续操作
 * 2.0          2023/03/29      John Wang   PC页头名称显示（1019313）
 */
define(['N/record', 'N/runtime', 'N/ui/serverWidget', '/SuiteScripts/SuiteScripts_DM/environment_check.js'],
    /**
     * @param{record} record
     * @param{runtime} runtime
     * @param{serverWidget} serverWidget
     */
    (record, runtime, serverWidget, enume) => {
        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {
            try {
                let form = scriptContext.form;
                let newRec = scriptContext.newRecord;
                let type = scriptContext.type;
                let orderType = newRec.getValue('custbody_ecm_ordertype');//OrderType:Contract(1)
                let userRole = runtime.getCurrentUser().role;
                if (('edit' == scriptContext.type) && enume.getAll().PURCHASE_ORDER_TYPE_CONTRACT == orderType && enume.getAll().ECM_ADMIN_ROLE != userRole){
                    disableSublistTab(form, 'item_form')
                }
                log.debug('nameDetails', runtime.executionContext + '|' + orderType)
                if(('view' == type || 'edit' == type) && 'purchaseorder' == newRec.type && 1 == orderType && 'USERINTERFACE' == runtime.executionContext) {
                    changeOrderName(scriptContext);
                }
            }catch (e){
                log.error('error', e);
            }
        }

        /**
         * 设置明细行不可编辑
         * @param form
         * @param disableObj
         */
        const disableSublistTab = (form,disableObj) =>{
            try {
                form.addField({
                    type: 'inlinehtml',
                    label: ' &nbsp; ',
                    id: `custpage_disable_${disableObj}`
                }).defaultValue = `
            <script>
                try{
                    jQuery(function () {
                        const hoverdiv = '<div class="disableSublistTab${disableObj}" style="position: absolute; width: 100%; height: 100%; left: 0px; top: 0px; background: #EEEEEE;opacity: 0.5; filter: alpha(opacity=40);z-index:5;"></div>';
                        jQuery('#item_form').wrap('<div class="position:relative;"></div>');
                        jQuery('#item_form').before(hoverdiv);
                        jQuery('#item_form').data("mask",true);
                    })
                }catch (e) {
                  console.log('disableSublistTab Error:' + e.message)
                }
            </script>`
            } catch (ex) {
                log.error({ title : 'hide view elements error', details : ex });
            }
        }

        /**
         * PC修改单据页头显示名称
         * @param scriptContext
         */
        const changeOrderName = scriptContext => {
            try {
                let form = scriptContext.form;
                let htmlField = form.addField({id: 'custpage_name_upd', type: serverWidget.FieldType.INLINEHTML, label: '&nbsp;'});
                htmlField.defaultValue = `<script>jQuery('.uir-record-type').html('Purchase Contract');</script>`;
            } catch (e) {
                log.error('error', e);
            }
        }
        /**
         * Defines the function definition that is executed before record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const beforeSubmit = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {

        }

        return {beforeLoad/*, beforeSubmit, afterSubmit*/}

    });
