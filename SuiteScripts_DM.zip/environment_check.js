/**
 * @NApiVersion 2.x
 * @NModuleScope SameAccount
 */
define(['N/runtime', 'N/search'],
    /**
     * @param{runtime} runtime
     * @param{search} search
     */
    function(runtime, search) {

        var params = null;

        function getAccountParam(name){
            var accountId = runtime.accountId;
            var envType = runtime.envType;
            if (envType === runtime.EnvType.PRODUCTION) {
                if (!params) {
                    params = product_params();
                }
            } else if (accountId === '7284938_SB1') {
                if (!params) {
                    params = sb1_params();
                }
            } else {
                throw 'aaa';
            }
            return params[name];
        }

        function getAll()  {
            var accountId = runtime.accountId;
            var envType = runtime.envType;
            var rtnObj = {};
            if (envType === runtime.EnvType.PRODUCTION) {
                if (!params) {
                    params = product_params();
                }
            } else if (accountId === '7284938_SB1') {
                if (!params) {
                    params = sb1_params();
                }
            } else {
                throw 'aaa';
            }
            rtnObj = JSON.parse(JSON.stringify(params));
            return rtnObj;
        }

        function product_params(){
            return {
                LC_LIMIT_APPLICATION_APPROVED : 3,   // LC限额申请单据状态审批通过
                LC_LIMIT_APPLICATION_PENDING_APPROVAL : 2,   // LC限额申请单据状态待审批
                ECM_INTERFACE_TYPE_LC_LIMIT_APPLICATION:1,  // 中信保接口——LC限额申请：1
                ECM_INTERFACE_TYPE_NO_LC_LIMIT_APPLICATION:2,   // 中信保接口——非LC限额申请：2
                ECM_INTERFACE_TYPE_FILE_UPLOAD:3,   // 中信保接口——附件上传：3
                ECM_INTERFACE_TYPE_LC_LIMIT_APPLICATION_APPROVED:4, // 中信保接口——限额申请复批：4
                PURCHASE_ORDER_TYPE_CONTRACT:1,  // 	Contract:1
                PURCHASE_ORDER_STATUS_CLOSED:'H', // 订单状态：已关闭
                SALES_ORDER_TYPE_ORDER:2,  // 	order:2
                SALES_ORDER_TYPE_CONTRACT:1,  // 	Contract:1
                ECM_ADMIN_ROLE:3,   // 管理员角色id:3
                ECM_SINOSURE_PASSED:5,   // 信保通过：5
                ECM_SINOSURE_FAILED:6,  // 信保失败：6
                ECM_CLAIM_TYPE:1,       // 认领记录-金额类型-预付款：1
                ECM_SHIPPING_STATUS_NOT_SHIPPED:1,  // shipping plan状态为未出运：1
                ECM_SHIPPING_DISTRIBUTION_TYPE:2,   // 配货类型DISTRIBUTION TYPE=仓库发货：2
                ECM_SHIPPING_APPROVE_STATUS:2,      // shipping plan 审批状态-已批准：2
                ECM_SHIPPING_BOOKING_SUCCEED:6,     // shipping plan状态-订舱成功：6
                ECM_SHIPPING_ESTIMATED_COST_SUBMITTED:7, // shipping plan状态-预估费用已提交：7
                ECM_SHIPPING_END:5,                 // shipping plan状态-完结
                ECM_SHIPPING_PLAN_DEPARTURE:3, // shipping plan状态-离港
                ECM_SUPPLY_PLANNER_ROLE:1131,   // Supply Planner角色id：1131
                ECM_SALES_ROLE:1128,    // Sales角色id:1128
                ECM_CUSTOMER_SERVICE_ROLE:1129, // customer service角色id:1129
                ECM_SHIPPING_CONTRACTTYPE_CHOICE:6,   // shipping plan业务类型-备货：6
                SO_CONTRACT_FILE_FOLDER:1103,    // 回签合同文件夹：1103    Sales Contract

            };
        }

        function sb1_params ()  {
            return {
                LC_LIMIT_APPLICATION_APPROVED : 3,   // LC限额申请单据状态审批通过
                LC_LIMIT_APPLICATION_PENDING_APPROVAL : 2,   // LC限额申请单据状态待审批
                ECM_INTERFACE_TYPE_LC_LIMIT_APPLICATION:1,  // 中信保接口——LC限额申请：1
                ECM_INTERFACE_TYPE_NO_LC_LIMIT_APPLICATION:2,   // 中信保接口——非LC限额申请：2
                ECM_INTERFACE_TYPE_FILE_UPLOAD:3,   // 中信保接口——附件上传：3
                ECM_INTERFACE_TYPE_LC_LIMIT_APPLICATION_APPROVED:4, // 中信保接口——限额申请复批：4
                PURCHASE_ORDER_TYPE_CONTRACT:1,  // 	Contract:1
                PURCHASE_ORDER_STATUS_CLOSED:'H', // 订单状态：已关闭
                SALES_ORDER_TYPE_ORDER:2,  // 	order:2
                SALES_ORDER_TYPE_CONTRACT:1,  // 	Contract:1
                ECM_ADMIN_ROLE:3,   // 管理员角色id:3
                ECM_SINOSURE_PASSED:5,   // 信保通过：5
                ECM_SINOSURE_FAILED:6,  // 信保失败：6
                ECM_CLAIM_TYPE:1,       // 认领记录-金额类型-预付款：1
                ECM_SHIPPING_STATUS_NOT_SHIPPED:1,  // shipping plan状态为未出运：1
                ECM_SHIPPING_DISTRIBUTION_TYPE:2,   // 配货类型DISTRIBUTION TYPE=仓库发货：2
                ECM_SHIPPING_APPROVE_STATUS:2,      // shipping plan 审批状态-已批准：2
                ECM_SHIPPING_BOOKING_SUCCEED:6,     // shipping plan状态-订舱成功：6
                ECM_SHIPPING_ESTIMATED_COST_SUBMITTED:7, // shipping plan状态-预估费用已提交：7
                ECM_SHIPPING_END:5,                 // shipping plan状态-完结
                ECM_SHIPPING_PLAN_DEPARTURE:3, // shipping plan状态-离港
                ECM_SUPPLY_PLANNER_ROLE:1131,   // Supply Planner角色id：1131
                ECM_SALES_ROLE:1128,    // Sales角色id:1128
                ECM_CUSTOMER_SERVICE_ROLE:1129, // customer service角色id:1129
                ECM_SHIPPING_CONTRACTTYPE_CHOICE:6,   // shipping plan业务类型-备货：6
                SO_CONTRACT_FILE_FOLDER:1103,    // 回签合同文件夹：1103    Sales Contract

            };
        }


        return {
            getAccountParam: getAccountParam,
            getAll: getAll,
        };

    });
