/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * version      date            author      remark
 * 1.0          2023/02/23      Doris       【ID1018549】Shipping Plan提交审批校验
 * 2.0          2023/02/28      Doris       【ID1018580】Shipping Plan Create SO&IF
 * 3.0          2023/02/28      Doris       【ID1018570】SP仓库发货时创建IT单，添加“Warehouse delivery”按钮
 * 4.0          2023/03/08      John Wang   SP提货阶段生成费用计提日记账（1018607）
 * 5.0          2023/03/10      Mark Z       SP添加按钮更新公司间价格（1018807）
 * 6.0          2023/03/10      Doris       【ID1018580】Shipping Plan Create SO&IF,变更：拆分为Create SO按钮及Create IF按钮
 * 7.0          2023/03/14      Doris       Warehouse delivery按钮显示条件新增：配货类型等于仓库发货、审批状态等于审批通过（1018570）
 * 8.0          2023/03/15      Doris       Warehouse delivery按钮显示条件新增：shipping plan状态为：3.预估费用已提交（1018570）
 * 9.0          2023/03/16      John Wang   SP费用计提JE（1018607）
 * 10.0         2023/03/17      Doris       生成IT单后it单号回写SP（ID1018570）
 * 11.0         2023/03/20      John Wang   V9子公司变更（1018607）
 * 12.0         2023/03/21      Will Liu    添加按钮（1019290）
 * 13.0         2023/03/21      Doris       按钮显示条件变更：明细行中存在配货类型为仓库发货的明细行（1018570）
 * 14.0         2023/03/23      John Wang   费用计提JE科目变更（1018607）
 * 15.0         2023/03/24      Doris       按钮显示条件变更:明细行中存在IT为空的行（1018570）
 * 16.0         2023/04/03      Doris       按钮显示条件变更:管理员角色、Sales角色和Customer Service角色显示（1018570）
 *                                          按钮显示条件变更:管理员角色和Supply Planner角色显示（1018549）
 * 17.0         2023/04/03      Will Liu    按钮显示添加条件（1019290）
 * 18.0         2023/04/06      Mark Z      按钮显示条件更新（1018807）
 * 19.0         2023/04/07      Doris       Create SO&Create IF按钮生成SO及IF单变更为用MR生成SO及IF单（1018580）
 * 20.0         2023/04/10      John Wang   JE日期&汇率取值变更（1018607）
 * 21.0         2023/04/11      John Wang   提货阶段je去除仓储费（1018607）
 * 22.0         2023/04/12      Will Liu    按钮名称修改（1019290）
 * 23.0         2023/04/14      John Wang   计提JE科目变更；新增计算转换系数等（1018607）
 * 24.0         2023/04/18      John Wang   v21优化；新增JE表单设置（1018607）
 * 25.0         2023/04/18      Doris       按钮显示条件变更:管理员角色、当前用户=custrecord_sp_cusservice显示（1018570）
 * 26.0         2023/04/18      Mark Z      1018807 按钮取消
 */
define(['N/record', 'N/runtime', 'N/currency', 'N/search', 'N/url', '/SuiteScripts/SuiteScripts_DM/environment_check.js', '/SuiteScripts/tools/common_api.js', '/SuiteScripts/tools/ramda.min.js'],
    /**
     * @param{record} record
     * @param{runtime} runtime
     */
    (record, runtime, currency, search, url, enume, commonApi, ramda) => {
        const SP_SUBLIST_ID = 'recmachcustrecord_scdline_sp';

        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {
            try{
                if ('view' == scriptContext.type){
                    let newRec = record.load({type: scriptContext.newRecord.type, id: scriptContext.newRecord.id});
                    let form = scriptContext.form;
                    let userRole = runtime.getCurrentUser().role;
                    let userId = runtime.getCurrentUser().id;
                    let cusservice = newRec.getValue('custrecord_sp_cusservice'); // 销售助理
                    // let createdStatus = newRec.getValue('custrecord_sp_createsoif_iscreated');
                    let submitCheck = newRec.getValue('custrecord_sp_checkpass');
                    let spStatus = newRec.getValue('custrecord_sp_status');
                    // let disttype = newRec.getValue('custrecord_sp_disttype');  // 配货类型
                    let approvestatus = newRec.getValue('custrecord_sp_approvestatus');    // 审批状态
                    let isCrossBorder = newRec.getValue('custrecord_sp_iscross_border');   // 是否跨境
                    let lineCount = newRec.getLineCount({sublistId:SP_SUBLIST_ID});
                    // let whetherCreateIfSum = 0;
                    // let whetherCreateSoSum = 0;
                    let whetherDeliverySp = 0;
                    let lineId = [];
                    if (lineCount > 0){
                        for (let i = 0; i < lineCount; i++){
                            // let isCreateSo = newRec.getSublistValue({sublistId: SP_SUBLIST_ID, fieldId:'custrecord_scdline_sono1', line:i}) || '';
                            // let isCreateIf = newRec.getSublistValue({sublistId: SP_SUBLIST_ID, fieldId:'custrecord_scdline_soif1', line:i}) || '';
                            let inventoryId = newRec.getSublistValue({sublistId:SP_SUBLIST_ID, fieldId:'custrecord_scdline_inventorydetail', line:i});
                            let distributiontype = newRec.getSublistValue({sublistId:SP_SUBLIST_ID, fieldId:'custrecord_scdline_distributiontype', line:i});
                            // let scLine = newRec.getSublistValue({sublistId:SP_SUBLIST_ID, fieldId:'custrecord_scdline_uniquekey', line:i}) || '';
                            let itId = newRec.getSublistValue({sublistId:SP_SUBLIST_ID, fieldId:'custrecord_scdline_it', line:i}) || '';
                            if (inventoryId && inventoryId.length > 0){
                                let scdlineid = newRec.getSublistValue({sublistId:SP_SUBLIST_ID, fieldId:'id', line:i});
                                lineId.push(scdlineid);
                            }
                            // if ('' == isCreateSo && '' != scLine){
                            //     whetherCreateSoSum++;
                            // }
                            // if ('' != isCreateSo && '' == isCreateIf){
                            //     whetherCreateIfSum++;
                            // }
                            if (distributiontype == enume.getAll().ECM_SHIPPING_DISTRIBUTION_TYPE && '' == itId){
                                whetherDeliverySp++;
                            }
                        }
                    }


                    // if (enume.getAll().ECM_ADMIN_ROLE == userRole && false == createdStatus && enume.getAll().ECM_SHIPPING_END == spStatus/* && 901 == runtime.getCurrentUser().id*/){
                    //     form.clientScriptModulePath = './cs_on_it_form_sp.js';
                    //     // let createButton = form.addButton({id:'custpage_create_so_if', label:'Create SO&IF', functionName:`createSoOrIf('${newRec.type}', '${newRec.id}')`});
                    //     if (Number(0) < whetherCreateSoSum){
                    //         let createSoButton = form.addButton({id:'custpage_create_so', label:'Create SO', functionName:`createSo('${newRec.type}', '${newRec.id}')`});
                    //     }
                    //     if (Number(0) < whetherCreateIfSum){
                    //         let createIfButton = form.addButton({id:'custpage_create_if', label:'Create IF', functionName:`createIf('${newRec.type}', '${newRec.id}')`});
                    //     }
                    // }
                    // 按钮显示状态：1.Shipping Status=未出运   2.Check Pass未勾选
                    if ((enume.getAll().ECM_ADMIN_ROLE == userRole || cusservice == userId) && false == submitCheck && enume.getAll().ECM_SHIPPING_STATUS_NOT_SHIPPED == spStatus){
                        form.clientScriptModulePath = './cs_on_it_form_sp.js';
                        let submitButton = form.addButton({id:'custpage_submit_sp', label:'Submit', functionName:`submitSp('${newRec.type}', '${newRec.id}')`});
                    }
                    if ((enume.getAll().ECM_ADMIN_ROLE == userRole || enume.getAll().ECM_SUPPLY_PLANNER_ROLE == userRole) && Number(0) < whetherDeliverySp && enume.getAll().ECM_SHIPPING_APPROVE_STATUS == approvestatus && enume.getAll().ECM_SHIPPING_ESTIMATED_COST_SUBMITTED == spStatus){
                        form.clientScriptModulePath = './cs_on_it_form_sp.js';
                        let wdButton = form.addButton({id:'custpage_warehouse_delivery_sp', label:'Warehouse delivery', functionName:`warehouseSp('${newRec.type}', '${newRec.id}', '${lineId}')`});
                    }
                    // 1、shipping Plan Status = 3 2、已更新 ICPOSO 价格未勾选 3、明细末级需方、需方和供方非空
                    // if (checkRecordStatus(newRec)) {
                    //     form.clientScriptModulePath = './cs_on_it_form_sp.js';
                    //     form.addButton({
                    //         id: 'custpage_update_ic_price',
                    //         label: 'Update ICPOSO Price',
                    //         functionName: `updateICPrice('${newRec.type}', '${newRec.id}')`
                    //     });
                    // }
                    //  Will 按钮显示
                    if (1 == spStatus && enume.getAll().ECM_SHIPPING_APPROVE_STATUS == approvestatus && (userRole == 3 || userRole == 1124 || userRole == 1131)) {
                        form.clientScriptModulePath = './cs_on_it_form_sp.js';
                        form.addButton({
                            id: 'custpage_btn',
                            label: 'Booking',
                            functionName: `bookingInfo('${newRec.id}')`
                        });
                    }
                    if (enume.getAll().ECM_SHIPPING_APPROVE_STATUS == spStatus && true == isCrossBorder && (userRole == 3 || userRole == 1124)) {
                        form.clientScriptModulePath = './cs_on_it_form_sp.js';
                        form.addButton({
                            id: 'custpage_btn_departure',
                            label: 'Departure from port',
                            functionName: `departureInfo('${newRec.id}')`
                        });
                    }
                }
            }catch (e){
                log.error('error', e);
            }
        }

        /**
         * 查询sp生成的IT
         * @param spId
         * @returns {string}
         */
        const getItNum = (spId) => {
            let myFilter = [];
            myFilter.push(['custbody_ecm_sp', 'anyof', spId]);
            let myColumns = [];
            myColumns.push('internalid');
            let mySearch = search.create({type:'inventorytransfer', filters:myFilter, columns:myColumns});
            let myResult = mySearch.run().getRange({start:0, end:1000});
            let itId = '';
            if (myResult && myResult.length > 0){
                for (let i =0; i < myResult.length; i++){
                    itId = myResult[i].getValue(myColumns[0]);
                }
            }
            return itId;
        }

        /**
         * 判断按钮显示条件
         * @param newRec
         * @return {boolean}
         */
        const checkRecordStatus = (newRec) => {
            let obj = record.load({type: newRec.type, id: newRec.id});
            let spStatus = obj.getValue({fieldId: 'custrecord_sp_status'}),
                isUpdatePrice = obj.getValue({fieldId: 'custrecord_sp_isupdated_icposoprice'});// 已更新 ICPOSO 价格
            let lineCount = obj.getLineCount({sublistId: SP_SUBLIST_ID});
            let lineFlag = false;// 是否满足明细末级需方、需方、供方和PO非空
            for (let i = 0; i < lineCount; i++) {
                let finalDemander = obj.getSublistValue({sublistId: SP_SUBLIST_ID, fieldId: 'custrecord_scdline_finaldemander', line: i}) || '';
                let demander = obj.getSublistValue({sublistId: SP_SUBLIST_ID, fieldId: 'custrecord_scdline_demander', line: i}) || '';
                let supplier = obj.getSublistValue({sublistId: SP_SUBLIST_ID, fieldId: 'custrecord_scdline_supplier', line: i}) || '';
                // let icpo = obj.getSublistValue({sublistId: SP_SUBLIST_ID, fieldId: 'custrecord_scdline_icpo', line: i}) || '';
                // let po = obj.getSublistValue({sublistId: SP_SUBLIST_ID, fieldId: 'custrecord_scdline_purchaseorder', line: i}) || '';
                if (finalDemander && demander && supplier) {
                    lineFlag = true;
                    break;
                }
            }
            if (3 == spStatus && ('F' == isUpdatePrice || false == isUpdatePrice) && lineFlag) {
                return true;
            }
            return false;
        }

        /**
         * Defines the function definition that is executed before record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const beforeSubmit = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {
            if('delete' == scriptContext.type) {
                return;
            }
            if('edit' == scriptContext.type) {
                createDeliveryCostJE(scriptContext);
            }
        }

        /**
         * JW 费用计提JE科目常量
         * @status  单据状态：2（提货）
         * @return {{costAccountArray: number[], creditAcc: number}}            {costAccountArray: 费用类型对应科目数组，排序和取值一致, creditAcc: 贷记科目}
         */
        const costJEConstParams = (status) => {
            let landFreightAcc = 972,//陆运费
                storageAcc = 1095,//仓储费
                inspectionAcc = 1801,//港杂费
                tariffCostAcc = 1805,//应交进口关税
                seaFreightAcc = 1802,//海运费
                clearanceCostAcc = 1804,//清关费
                personCostAcc = 1803,//人保
                creditAcc = 112;//贷记：应计购买
            if('SANDBOX' != runtime.envType) {
                landFreightAcc = '';
                storageAcc = '';
                inspectionAcc = '';
                tariffCostAcc = '';
                seaFreightAcc = '';
                clearanceCostAcc = '';
                personCostAcc = '';
                creditAcc = '';
            }
            let costAccountArray = [landFreightAcc, storageAcc, inspectionAcc, tariffCostAcc, seaFreightAcc, clearanceCostAcc, personCostAcc];
            if(2 == status) {
                costAccountArray = [landFreightAcc, inspectionAcc, tariffCostAcc, seaFreightAcc, clearanceCostAcc, personCostAcc];
            }
            return {costAccountArray, creditAcc};
        }

        /**
         * 创建费用计提JE
         * @param scriptContext
         */
        const createDeliveryCostJE = scriptContext => {
            let obj = record.load({type: scriptContext.newRecord.type, id: scriptContext.newRecord.id, isDynamic: true});
            let status = obj.getValue({fieldId: 'custrecord_sp_status'}),//状态：提货（2）离港（3）到达（4）
                isStock = obj.getValue({fieldId: 'custrecord_sp_warehousestock'}),//是否为备货：是备货（true）
                cuy = obj.getValue({fieldId: 'custrecord_sp_sccurrency'}),//币种
                cuyText = obj.getText({fieldId: 'custrecord_sp_sccurrency'}),//币种
                incoterm = obj.getText({fieldId: 'custrecord_sp_incoterm'}),//贸易术语
                saveFlag = false;//保存标记
            let jeDate = obj.getText({fieldId: 2 == status ? 'custrecord_sp_deliverycomdate' : 3 == status ? 'custrecord_sp_departuredate' : 'custrecord_sp_arrivaldate'});
            let nonStockCheck = false == isStock && (['EXW', 'FCA', 'CPT', 'CIP'].indexOf(incoterm) > -1 && 2 == status || ['FAS', 'FOB', 'CFR', 'CIF'].indexOf(incoterm) > -1 && 3 == status || ['DES', 'DEQ', 'DDU', 'DDP', 'DAF'].indexOf(incoterm) > -1 && 4 == status);
            log.debug('nonStockCheck', nonStockCheck)
            try {
                if(true == nonStockCheck || true == isStock && (3 == status || 2 == status)) {
                    let length = obj.getLineCount({sublistId: SP_SUBLIST_ID}),
                        lineData = [],
                        itemCaseData = {},//货品转换系数
                        jeFieldId = (true == isStock && 3 == status) ? 'custrecord_scdline_expensejournal1' : 'custrecord_scdline_expensejournal';//明细行JE字段id

                    for(let i = 0; i < length; i++) {
                        let jeId = obj.getSublistValue({sublistId: SP_SUBLIST_ID, fieldId: jeFieldId, line: i});
                        if('' != jeId) {
                            continue;
                        }
                        let subsidiary = obj.getSublistValue({sublistId: SP_SUBLIST_ID, fieldId:  true == isStock ? 'custrecord_scdline_finaldemander' : 'custrecord_scdline_supplier', line: i}),
                            landFreight = obj.getSublistValue({sublistId: SP_SUBLIST_ID, fieldId: 'custrecord_scdline_landfreightcost', line: i}),//陆运费
                            storage = obj.getSublistValue({sublistId: SP_SUBLIST_ID, fieldId: 'custrecord_scdline_storagecost', line: i}),//仓储费
                            inspection = obj.getSublistValue({sublistId: SP_SUBLIST_ID, fieldId: 'custrecord_scdline_inspectioncost', line: i}),//港杂费
                            tariff = obj.getSublistValue({sublistId: SP_SUBLIST_ID, fieldId: 'custrecord_scdline_tariffcost', line: i}),//关税
                            seaFreight = obj.getSublistValue({sublistId: SP_SUBLIST_ID, fieldId: 'custrecord_scdline_seafreightcost', line: i}),//海运费
                            clearance = obj.getSublistValue({sublistId: SP_SUBLIST_ID, fieldId: 'custrecord_scdline_clearancecost', line: i}),//清关费
                            person = obj.getSublistValue({sublistId: SP_SUBLIST_ID, fieldId: 'custrecord_scdline_perscost', line: i}),//人保费
                            lineId = obj.getSublistValue({sublistId: SP_SUBLIST_ID, fieldId: 'id', line: i}),
                            item = obj.getSublistValue({sublistId: SP_SUBLIST_ID, fieldId: 'custrecord_scdline_item', line: i}),
                            qty = obj.getSublistValue({sublistId: SP_SUBLIST_ID, fieldId: 'custrecord_scdline_qty', line: i});
                        let itemcase = itemCaseData[item];
                        if('undefined' == typeof itemcase) {
                            let itemFields = search.lookupFields({type: 'item', columns: ['custitem_ecm_case_package_kg'], id: item});
                            itemcase = itemFields.custitem_ecm_case_package_kg;
                            itemCaseData[itemFields] = itemcase;
                        }

                        let json = {subsidiary: subsidiary, landFreight: landFreight, storage: storage, inspection: inspection, tariff: tariff, seaFreight: seaFreight, clearance: clearance, person: person, lineId: lineId, qty: qty, itemcase: itemcase || 1};
                        lineData.push(json);
                    }
                    if(lineData.length > 0) {
                        const  {costAccountArray, creditAcc} = costJEConstParams(status);
                        let costKeyArray =  ['landFreight', 'storage', 'inspection', 'tariff', 'seaFreight', 'clearance', 'person'];
                        if(2 == status) {
                            costKeyArray =  ['landFreight', 'inspection', 'tariff', 'seaFreight', 'clearance', 'person'];
                        }
                        let groupedData = ramda.groupBy(ramda.path(['subsidiary']))(lineData);
                        log.debug('提货JElineData====', groupedData);
                        let writeBackJe = {};//je回写明细行【jeId：subsidiary】
                        for(key in groupedData) {
                            let jeObj = record.create({type:'journalentry', isDynamic:true});
                            let subFields = search.lookupFields({type: 'subsidiary', id: key, columns: ['currency']});
                            let subCuy = subFields.currency[0].value,
                                subCuyTxt = subFields.currency[0].text;
                            jeObj.setValue({fieldId: 'customform', value: 'SANDBOX' == runtime.envType ? 127 : 1});//JW ECHEMI日记账（冲预估）
                            jeObj.setValue({fieldId: 'subsidiary', value: key});
                            jeObj.setValue({fieldId: 'currency', value: cuy});
                            jeObj.setValue({fieldId: 'custbody_ecm_sp', value: obj.id});
                            if(jeDate && '' != jeDate) {
                                jeObj.setText({fieldId: 'trandate', text: jeDate});
                            }
                            if(cuyText != subCuyTxt) {
                                let erate = currency.exchangeRate({
                                    source: cuyText,
                                    target: subCuyTxt,
                                    date: new Date(jeDate)
                                });
                                jeObj.setValue({fieldId: 'exchangerate', value: erate});
                            }
                            let thisSubsidiaryLines = groupedData[key];
                            let totalCostArray = 2 == status ? [0, 0, 0, 0, 0, 0] : [0, 0, 0, 0, 0, 0, 0];//各类费用合计，次序和【costKeyArray】一致,[totalLandFreight~]
                            thisSubsidiaryLines.forEach(function (line) {
                                costKeyArray.forEach(function (key, index) {
                                    totalCostArray[index] = Number(totalCostArray[index] || 0).add(Number(line[key]).mul(Number(line.qty)).mul(Number(line.itemcase)));
                                });
                            });
                            log.debug(2 == status ? '提货-data' : 3 == status ? '离港-data' : '到达-data', totalCostArray);
                            let totalAmt = 0,
                                start = false == isStock ? 0 : (2 == status ? 0 : 3),//true == isStock && 3 == status ? 3 : 0,//非备货取全部数据，从0开始；备货&提货从0开始；备货&离港从3开始
                                end = false == isStock ? totalCostArray.length  : (2 == status ? 2 : totalCostArray.length);//true == isStock && 2 == status ? 3 : totalCostArray.length;//非备货取全部数据，到last；备货&提货到3；备货&离港到last
                            for(let i = start; i < end; i++) {
                                if(totalCostArray[i]  > 0) {
                                    setJeLineData(jeObj, costAccountArray[i], true, totalCostArray[i]);
                                    totalAmt = Number(totalAmt).add(Number(totalCostArray[i]));
                                }
                            }
                            /*function test(isStock, status) {
                                let totalCostArray = ['landFreight', 'storage', 'inspection', 'tariff', 'seaFreight', 'clearance', 'person']
                                let start = true == isStock && 3 == status ? 3 : 0,//非备货取全部数据，从0开始；备货&提货从0开始；备货&离港从3开始
                                    end = true == isStock && 2 == status ? 3 : totalCostArray.length;
                                console.log('start：' + start + '======end：' + end);
                                console.log(totalCostArray.slice(start, end));
                            }*/
                            if(totalAmt > 0) {
                                setJeLineData(jeObj, creditAcc, false, totalAmt);
                                let jeId = jeObj.save({ignoreMandatoryFields: true, enableSourcing: true});
                                writeBackJe[jeId] = key;
                            }
                        }
                        log.debug(`${obj.id}===${true == isStock ? '备货' : '非备货'}-SP-${2 == status ? '提货' : '离港'}-JE`, writeBackJe);
                        for(jeId in writeBackJe) {
                            let thisData = groupedData[writeBackJe[jeId]];
                            if(thisData && 'undefined'!= typeof thisData) {
                                thisData.forEach(function (line) {
                                    let index = obj.findSublistLineWithValue({sublistId: SP_SUBLIST_ID, fieldId: 'id', value: line.lineId});
                                    if(index > -1) {
                                        obj.selectLine({sublistId: SP_SUBLIST_ID, line: index});
                                        obj.setCurrentSublistValue({sublistId: SP_SUBLIST_ID, fieldId: jeFieldId, value: jeId});
                                        obj.commitLine({sublistId: SP_SUBLIST_ID});
                                        saveFlag = true;
                                    } else {
                                        log.debug(`JE：${jeId}未匹配数据`, thisData);
                                    }
                                });
                            }
                        }
                        if(true == saveFlag) {
                            obj.save({ignoreMandatoryFields: true, enableSourcing: true});
                        }
                    } else {
                        log.audit('提货不创建je', obj.id);
                    }
                }
            } catch (e) {
                log.error(`${obj.id}===${true == isStock ? '备货' : '非备货'}-SP-${2 == status ? '提货' : '离港'}创建JEError===>` + obj.id, e);
            }
        }

        /**
         * 金额明细行赋值
         * @param jeObj         jeObj
         * @param acc           科目
         * @param isDebit       是否借记
         * @param amount        金额
         */
        const setJeLineData = (jeObj, acc, isDebit, amount) => {
            jeObj.selectNewLine({sublistId: 'line'});
            jeObj.setCurrentSublistValue({sublistId: 'line', fieldId: 'account', value: acc});
            if(true == isDebit) {
                jeObj.setCurrentSublistValue({sublistId: 'line', fieldId: 'debit', value: amount});
            } else {
                jeObj.setCurrentSublistValue({sublistId: 'line', fieldId: 'credit', value: amount});
            }
            jeObj.commitLine('line');
        }

        return {beforeLoad, afterSubmit}

    });