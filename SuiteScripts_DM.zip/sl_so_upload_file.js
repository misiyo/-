/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 * Version      Date            Author      Remark
 * 1.0          2023/04/10      Doris       【ID1019632】销售合同附件上传
 */
define(['N/file', 'N/record', 'N/search', 'N/url', 'N/ui/serverWidget', '/SuiteScripts/SuiteScripts_DM/environment_check.js'],
    /**
 * @param{file} file
 * @param{record} record
 * @param{search} search
 * @param{url} url
 * @param{serverWidget} serverWidget
 */
    (file, record, search, url, serverWidget, enume) => {
        /**
         * Defines the Suitelet script trigger point.
         * @param {Object} scriptContext
         * @param {ServerRequest} scriptContext.request - Incoming request
         * @param {ServerResponse} scriptContext.response - Suitelet response
         * @since 2015.2
         */
        const onRequest = (scriptContext) => {
            let request = scriptContext.request;
            let response = scriptContext.response;
            let params = request.parameters;
            try {
                if ('GET' == request.method){
                    let form = createForm(params);
                    response.writePage(form);
                }else {
                    let file = request.files.custpage_file;     // 服务器请求文件。此属性是只读的。
                    log.debug('file',file)
                    let objRecType = params.custpage_filetype;
                    let objRecId = params.custpage_fileid;

                    file.folder = enume.getAll().SO_CONTRACT_FILE_FOLDER;
                    let fileId = file.save();
                    let soRec = record.load({type:objRecType, id:objRecId});
                    soRec.setValue({fieldId:'custbody_ecm_sc_document', value:fileId});
                    soRec.save({enableSourcing:true, ignoreMandatoryFields:true});
                    response.write('<script>window.opener.location.reload(); window.close();</script>');
                }

            }catch (e){
                log.error('上传文件有误', e);
            }
        }

        const createForm = (params) => {
            let form = serverWidget.createForm({title:'Upload File', hideNavBar:true});
            form.addSubmitButton({label:'Upload'});
            let fileField = form.addField({id:'custpage_file', label:'File', type:serverWidget.FieldType.FILE});
            // 设置必填
            fileField.isMandatory = true;

            let fileType = form.addField({id:'custpage_filetype', type:serverWidget.FieldType.TEXT, label:'filetype'});
            let fileId = form.addField({id:'custpage_fileid', type:serverWidget.FieldType.TEXT, label:'fileid'});

            fileType.updateDisplayType({displayType:serverWidget.FieldDisplayType.HIDDEN});
            fileId.updateDisplayType({displayType:serverWidget.FieldDisplayType.HIDDEN});
            if (params.objRecType){
                fileType.defaultValue = params.objRecType;
            }
            if (params.objRecId){
                fileId.defaultValue = params.objRecId;
            }
            return form;
        }

        return {onRequest}

    });
