/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * version      date            author      remark
 * 1.0          2023/02/15      Doris       【ID1018421】非LC 限额申请
 * 2.0          2023/03/10      Doris       【ID1018421】企业买方代码字段由列表变更为自由文本
 * 3.0          2023/03/13      Doris       【ID1018421】中国信保买方代码传参值下钻至买方代码申请记录：中信保买方代码
 * 4.0          2023/03/23      Doris       商品类别代码字段变更为：custrecord_ego_code
 */
define(['N/record', 'N/search', '/SuiteScripts/tools/common_api.js', '/SuiteScripts/tools/hc_edi_interface_tool.js', '/SuiteScripts/tools/moment.js', '/SuiteScripts/tools/ramda.min.js', '/SuiteScripts/SuiteScripts_DM/environment_check.js'],
    /**
 * @param{record} record
 * @param{search} search
 */
    (record, search, commonApi, interfaceTool, moment, ramda, enume) => {
        const NO_LC_LIMIT_APPLY_TYPE = 'customrecord_ecm_sinosure_nlc_quotaapply';// 非LC限额申请记录id
        const BUYER_APPLY_TYPE = 'customrecord_ecm_sinosure_buyercodeapply';  // 买方代码申请记录id
        const LOG_TYPE = 'customrecord_hc_edi_interface_log';// 日志类型
        const IMETHOD = 'doEdiNoLcQuotaApplyV2';// 接口method
        const FIELD_MAPPING = {
            'customer' : 'custrecord_esncq_customer',    // 客户
            'clientNo' : 'custrecord_esncq_clientno',   // 企业标识
            'policyNo' : 'custrecord_esncq_policyno',   // 保险单号
            'siNoSureBuyerNo' : 'custrecord_esncq_sinosurebuyerno', // 中国信保买方代码
            'corpBuyerNo' : 'custrecord_esncq_corpbuyerno',     // 企业买方代码
            'buyerChnName' : 'custrecord_esncq_buyerchnname',   // 买方中文名称
            'buyerEngName' : 'custrecord_esncq_buyerengname',   // 买方英文名称
            'buyerCountryCode' : 'custrecord_esncq_buyercountrycode',   // 买方国家代码
            'buyerEngAddress' : 'custrecord_esncq_buyerengaddress',     // 买方英文地址
            'buyerChnAddress' : 'custrecord_esncq_buyerchnaddress',     // 买方中文地址
            'creditNo' : 'custrecord_esncq_creditno',   // 统一社会信用代码
            'regionCode' : 'custrecord_esncq_regioncode',       // 美国买方州省代码
            'orgNo' : 'custrecord_esncq_orgno',         // 组织机构代码
            'areaNo' : 'custrecord_esncq_areano',       // 注册区域代码
            'buyerRegNo' : 'custrecord_esncq_buyerregno',    // 买方注册号
            'buyerTel' : 'custrecord_esncq_buyertel',   // 买方电话
            'buyerFax' : 'custrecord_esncq_buyerfax',   // 买方传真
            'warrantorType' : 'custrecord_esncq_warrantortype',    // 是否有担保人
            'sinosureWarrantorNo' : 'custrecord_esncq_sinosurewarrantorno',    // 中国信保担保人代码
            'corpWarrantorNo' : 'custrecord_esncq_corpwarrantorno',    // 企业担保人代码
            'warrantorChnName' : 'custrecord_esncq_warrantorchnname',    // 担保人中文名称
            'warrantorEngName' : 'custrecord_esncq_warrantorengname',    // 担保人英文名称
            'warrantorCountryCode' : 'custrecord_esncq_warrantorcountrycode',    // 担保人国家代码
            'warrantorEngAddress' : 'custrecord_esncq_warrantorengaddress',    // 担保人英文地址
            'warrantorChnAddress' : 'custrecord_esncq_warrantorchnaddress',    // 担保人中文地址
            'warrantorcreditno' : 'custrecord_esncq_warrantorcreditno',    // 担保人统一社会信用代码
            'warrantororgno' : 'custrecord_esncq_warrantororgno',    // 担保人组织机构代码
            'warrantorareano' : 'custrecord_esncq_warrantorareano',    // 担保人注册区域代码
            'warrantorRegNo' : 'custrecord_esncq_warrantorregno',    // 担保人注册号
            'warrantorTel' : 'custrecord_esncq_warrantortel',    // 担保人电话
            'warrantorFax' : 'custrecord_esncq_warrantorfax',    // 担保人传真
            'contractPayMode' : 'custrecord_esncq_contractpaymode',    // 合同支付方式
            'payTermApply' : 'custrecord_esncq_paytermapply',    // 申请信用期限（天）
            'quotaSumApply' : 'custrecord_esncq_quotasumapply',    // 申请信用限额（USD）
            'orderSum' : 'custrecord_esncq_ordersum',    // 当前在手订单金额（USD）
            'armSum' : 'custrecord_esncq_armsum',    // 当前应收账款余额（USD）
            'tradeNameCode' : 'custrecord_esncq_tradenamecode',          // 出口商品类别代码
            'tradeElseName' : 'custrecord_esncq_tradeelsename',    // 出口商品名称
            'tradeTerms' : 'custrecord_esncq_tradeterms',    // 贸易术语
            'TradeElseTerms' : 'custrecord_esncq_tradeelseterms',    // 其他贸易术语名称
            'ifHistTrade' : 'custrecord_esncq_ifhisttrade',    // 是否有历史交易
            'earlyTradeYear' : 'custrecord_esncq_earlytradeyear',    // 最早成交年份（年）
            'startDebtYear' : 'custrecord_esncq_startdebtyear',    // 最早放账年份（年）
            'lastYear1' : 'custrecord_esncq_lastyear1',    // 最近三年交易年份1（年）
            'lastPayMode1' : 'custrecord_esncq_lastpaymode1',    // 最近三年交易结算方式1
            'lastSum1' : 'custrecord_esncq_lastsum1',    // 最近三年交易额1（USD）
            'lastYear2' : 'custrecord_esncq_lastyear2',    // 最近三年交易年份2（年）
            'lastPayMode2' : 'custrecord_esncq_lastpaymode2',    // 最近三年交易结算方式2
            'lastSum2' : 'custrecord_esncq_lastsum2',    // 最近三年交易额2（USD）
            'lastYear3' : 'custrecord_esncq_lastyear3',    // 最近三年交易年份3（年）
            'lastPayMode3' : 'custrecord_esncq_lastpaymode3',    // 最近三年交易结算方式3
            'lastSum3' : 'custrecord_esncq_lastsum3',    // 最近三年交易额3（USD）
            'buyerPayBehave1' : 'custrecord_esncq_buyerpaybehave1',    // 买方当前应付款表现1(应付款日内USD)
            'buyerPayBehave2' : 'custrecord_esncq_buyerpaybehave2',    // 买方当前应付款表现2(应付款日后30天内USD)
            'buyerPayBehave3' : 'custrecord_esncq_buyerpaybehave3',    // 买方当前应付款表现3(应付款日后31-60天USD)
            'buyerPayBehave4' : 'custrecord_esncq_buyerpaybehave4',    // 买方当前应付款表现4(应付款日60天以上USD)
            'buyerOweReasonCode' : 'custrecord_esncq_buyerowereasoncode',    // 逾期原因代码
            'buyerOweElseReason' : 'custrecord_esncq_buyeroweelsereason',    // 其他逾期原因
            'remark' : 'custrecord_esncq_remark',    // 其他说明
            'declaration' : 'custrecord_esncq_declaration',    // 被保险人声明
            'ifapplycredit' : 'custrecord_esncq_ifapplycredit',    // 是否随限额申请发起对买方的资信调查申请
            'employeeName' : 'custrecord_esncq_employeename',    // 员工名称
            'applicant' : 'custrecord_esncq_applicant',    // 申请人
            'applyTime' : 'custrecord_esncq_applytime',    // 申请时间
            'fileNum' : 'custrecord_esncq_filenum',    // 附件个数
            'ifSameWithPolicy' : 'custrecord_esncq_ifsamewithpolicy',    // 是否与保单出运前约定一致
            'precreditterm' : 'custrecord_esncq_precreditterm',    // 出运前信用期限（天）
            'aftercreditterm' : 'custrecord_esncq_aftercreditterm',    // 出运后信用期限（天）
            'ifHaveTradeFinancing' : 'custrecord_esncq_ifhavetradefinancing',    // 在本信用限额项下是否有贸易融资需求
            'ifHaveRelation' : 'custrecord_esncq_ifhaverelation',    // 被保险人及共保人、关联公司、代理人项下是否与买方存在关联关系
            'relationDetail' : 'custrecord_esncq_relationdetail',    // 具体关联情况
            'isSameWithContract' : 'custrecord_esncq_issamewithcontract',    // 被保险人与买方历史交易记录中付款人是否与合同买方一致
            'noSameWithContractReaSo' : 'custrecord_esncq_nosamewithcontractreaso',    // 付款人名称及不一致的原因
            'relationshipexplained' : 'custrecord_esncq_relationshipexplained',    // 已说明关联关系
            'errorCode': 'custrecord_esncq_errorcode',
            'errorMsg': 'custrecord_esncq_errormsg',
            'postsinosure' : 'custrecord_esncq_postsinosure',   // 推送中信保
            'posterromsg' : 'custrecord_esncq_posterromsg',    // 推送失败信息
        };

        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed before record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const beforeSubmit = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {
            if(['delete','xedit'].includes(scriptContext.type)) return ;
            let logUpdVal = {
                    custrecord_hc_inf_process_msg: '',
                    custrecord_hc_inf_errorflag: false
                };
            let newRec = scriptContext.newRecord;

            let rtnData = {};
            try{
                let status = newRec.getValue('custrecord_esncq_status');    // 单据状态
                if (enume.getAll().LC_LIMIT_APPLICATION_APPROVED == status){
                    let nlcRec = record.load({
                        type:newRec.type,
                        id:newRec.id
                    });
                    let customer = nlcRec.getValue(FIELD_MAPPING.customer);
                    let siNoSureBuyerNo = nlcRec.getValue(FIELD_MAPPING.siNoSureBuyerNo);
                    let corpBuyerNo = nlcRec.getValue(FIELD_MAPPING.corpBuyerNo);    // 企业买方代码
                    let buyerEngName = nlcRec.getValue(FIELD_MAPPING.buyerEngName);
                    let buyerEngAddress = nlcRec.getValue(FIELD_MAPPING.buyerEngAddress);
                    let buyerCountryCode = nlcRec.getValue(FIELD_MAPPING.buyerCountryCode); // TODO 中信保-国家代码
                    let regionCode = nlcRec.getValue(FIELD_MAPPING.regionCode); // TODO 中信保-美国州省代码
                    // if ('' == siNoSureBuyerNo && '' != corpBuyerNo && '' != buyerEngName && '' != buyerEngAddress){
                    if ('' == siNoSureBuyerNo && '' != buyerCountryCode && '' == corpBuyerNo){
                        let buyerRec = record.create({
                            type:BUYER_APPLY_TYPE
                        });
                        buyerRec.setValue({fieldId:'custrecord_esbya_customer', value:customer});
                        buyerRec.setValue({fieldId:'custrecord_esbya_engname', value:buyerEngName});
                        buyerRec.setValue({fieldId:'custrecord_esbya_countrycode', value:buyerCountryCode});
                        buyerRec.setValue({fieldId:'custrecord_esbya_engaddress', value:buyerEngAddress});
                        buyerRec.setValue({fieldId:'custrecord_esbya_regioncode', value:regionCode});
                        let buyerId = buyerRec.save({enableSourcing:true, ignoreMandatoryFields:true});
                        let newBuyerRec = record.load({
                            type:BUYER_APPLY_TYPE,
                            id:buyerId
                        });
                        let name = newBuyerRec.getValue('name');
                        nlcRec.setValue({fieldId:FIELD_MAPPING.corpBuyerNo, value:name});
                        nlcRec.save({enableSourcing:true, ignoreMandatoryFields:true});
                        log.debug('创建企业买方代码--成功')
                    }
                    nlcRec = record.load({type:newRec.type, id:newRec.id});
                    corpBuyerNo = nlcRec.getValue(FIELD_MAPPING.corpBuyerNo);    // 企业买方代码

                    let postErrorMsg = nlcRec.getValue(FIELD_MAPPING.posterromsg); // 推送失败信息
                    let postsinosure = nlcRec.getValue(FIELD_MAPPING.postsinosure);   // 推送中信保
                    if ('' == postErrorMsg && false == postsinosure){
                        let ifRepeatArr = [];
                        let countryCodeArr = [];
                        let areaCodeArr = [];
                        let regionCodeArr = [];
                        let lastPayModeArr = [];
                        let name = nlcRec.getValue('name');
                        let clientNo = nlcRec.getValue(FIELD_MAPPING.clientNo);
                        let policyNo = nlcRec.getValue(FIELD_MAPPING.policyNo);
                        let buyerNo = '';
                        if (siNoSureBuyerNo){
                            let buyerRec = record.load({type:'customrecord_ecm_sinosure_buyercodeapply', id:siNoSureBuyerNo});
                            buyerNo = buyerRec.getValue('custrecord_esbya_buyerno');    // 买方代码申请-中信保买方代码
                        }
                        let buyerChnName = nlcRec.getValue(FIELD_MAPPING.buyerChnName);
                        if (buyerCountryCode && '-1' == countryCodeArr.indexOf(buyerCountryCode)) {
                            countryCodeArr.push(buyerCountryCode);
                        }
                        let buyerChnAddress = nlcRec.getValue(FIELD_MAPPING.buyerChnAddress);
                        let creditNo = nlcRec.getValue(FIELD_MAPPING.creditNo);
                        if (regionCode && '-1' == regionCodeArr.indexOf(regionCode)) {
                            regionCodeArr.push(regionCode);
                        }
                        let orgNo = nlcRec.getValue(FIELD_MAPPING.orgNo);
                        let areaNo = nlcRec.getValue(FIELD_MAPPING.areaNo); // 中信保 - 注册区域代码(市区级)
                        if (areaNo && '-1' == areaCodeArr.indexOf(areaNo)) {
                            areaCodeArr.push(areaNo);
                        }
                        let buyerRegNo = nlcRec.getValue(FIELD_MAPPING.buyerRegNo);
                        let buyerTel = nlcRec.getValue(FIELD_MAPPING.buyerTel);
                        let buyerFax = nlcRec.getValue(FIELD_MAPPING.buyerFax);
                        let warrantorType = nlcRec.getValue(FIELD_MAPPING.warrantorType);   //  中信保-是否循环
                        if (warrantorType && '-1' == ifRepeatArr.indexOf(warrantorType)) {
                            ifRepeatArr.push(warrantorType);
                        }
                        let sinosureWarrantorNo = nlcRec.getValue(FIELD_MAPPING.sinosureWarrantorNo);
                        let corpWarrantorNo = nlcRec.getValue(FIELD_MAPPING.corpWarrantorNo);
                        let warrantorChnName = nlcRec.getValue(FIELD_MAPPING.warrantorChnName);
                        let warrantorEngName = nlcRec.getValue(FIELD_MAPPING.warrantorEngName);
                        let warrantorCountryCode = nlcRec.getValue(FIELD_MAPPING.warrantorCountryCode); // 	中信保-国家代码
                        if (warrantorCountryCode && '-1' == countryCodeArr.indexOf(warrantorCountryCode)) {
                            countryCodeArr.push(warrantorCountryCode);
                        }
                        let warrantorEngAddress = nlcRec.getValue(FIELD_MAPPING.warrantorEngAddress);
                        let warrantorChnAddress = nlcRec.getValue(FIELD_MAPPING.warrantorChnAddress);
                        let warrantorcreditno = nlcRec.getValue(FIELD_MAPPING.warrantorcreditno);
                        let warrantororgno = nlcRec.getValue(FIELD_MAPPING.warrantororgno);
                        let warrantorareano = nlcRec.getValue(FIELD_MAPPING.warrantorareano);   //  中信保 - 注册区域代码(市区级)
                        if (warrantorareano && '-1' == areaCodeArr.indexOf(warrantorareano)) {
                            areaCodeArr.push(warrantorareano);
                        }
                        let warrantorRegNo = nlcRec.getValue(FIELD_MAPPING.warrantorRegNo);
                        let warrantorTel = nlcRec.getValue(FIELD_MAPPING.warrantorTel);
                        let warrantorFax = nlcRec.getValue(FIELD_MAPPING.warrantorFax);
                        let contractPayMode = nlcRec.getValue(FIELD_MAPPING.contractPayMode);   // 中信保-支付方式
                        let payCode = '';
                        if (contractPayMode){
                            let payRec = record.load({
                                type:'customrecord_ecm_sinosure_paymethod',
                                id:contractPayMode
                            });
                            payCode = payRec.getValue('custrecord_esp_code');   // 支付代码
                        }
                        let payTermApply = nlcRec.getValue(FIELD_MAPPING.payTermApply);
                        let quotaSumApply = nlcRec.getValue(FIELD_MAPPING.quotaSumApply);
                        let orderSum = nlcRec.getValue(FIELD_MAPPING.orderSum);
                        let armSum = nlcRec.getValue(FIELD_MAPPING.armSum);
                        let tradeNameCode = nlcRec.getValue(FIELD_MAPPING.tradeNameCode);   // 中信保-商品类别代码
                        let goodsCode = '';
                        if (tradeNameCode){
                            let codeRec = record.load({
                                type:'customrecord_ecm_goodscode',
                                id:tradeNameCode
                            });
                            goodsCode = codeRec.getValue('custrecord_ego_code');    // 商品类别代码
                        }
                        let tradeElseName = nlcRec.getValue(FIELD_MAPPING.tradeElseName);
                        let tradeTerms = nlcRec.getValue(FIELD_MAPPING.tradeTerms); // 中信保-贸易术语
                        let termsCode = '';
                        if (tradeTerms) {
                            let termsRec = record.load({
                                type:'customrecord_ecm_sinosure_incoterm',
                                id:tradeTerms
                            });
                            termsCode = termsRec.getValue('custrecord_esi_code');  // 贸易术语代码
                        }
                        let TradeElseTerms = nlcRec.getValue(FIELD_MAPPING.TradeElseTerms);
                        let ifHistTrade = nlcRec.getValue(FIELD_MAPPING.ifHistTrade);   // 中信保-是否循环
                        if (ifHistTrade && '-1' == ifRepeatArr.indexOf(ifHistTrade)) {
                            ifRepeatArr.push(ifHistTrade);
                        }
                        let earlyTradeYear = nlcRec.getValue(FIELD_MAPPING.earlyTradeYear);
                        let startDebtYear = nlcRec.getValue(FIELD_MAPPING.startDebtYear);
                        let lastYear1 = nlcRec.getValue(FIELD_MAPPING.lastYear1);
                        let lastPayMode1 = nlcRec.getValue(FIELD_MAPPING.lastPayMode1); // 中信保-交易结算方式
                        if (lastPayMode1 && lastPayMode1.length > 0){
                            for (let i = 0; i < lastPayMode1.length; i++){
                                if (lastPayMode1[i] && '-1' == lastPayModeArr.indexOf(lastPayMode1[i])) {
                                    lastPayModeArr.push(lastPayMode1[i]);
                                }
                            }
                        }
                        let lastSum1 = nlcRec.getValue(FIELD_MAPPING.lastSum1);
                        let lastYear2 = nlcRec.getValue(FIELD_MAPPING.lastYear2);
                        let lastPayMode2 = nlcRec.getValue(FIELD_MAPPING.lastPayMode2); // 中信保-交易结算方式
                        if (lastPayMode2 && lastPayMode2.length > 0){
                            for (let i = 0; i < lastPayMode2.length; i++){
                                if (lastPayMode2[i] && '-1' == lastPayModeArr.indexOf(lastPayMode2[i])) {
                                    lastPayModeArr.push(lastPayMode2[i]);
                                }
                            }
                        }
                        let lastSum2 = nlcRec.getValue(FIELD_MAPPING.lastSum2);
                        let lastYear3 = nlcRec.getValue(FIELD_MAPPING.lastYear3);
                        let lastPayMode3 = nlcRec.getValue(FIELD_MAPPING.lastPayMode3); // 中信保-交易结算方式
                        if (lastPayMode3 && lastPayMode3.length > 0){
                            for (let i = 0; i < lastPayMode3.length; i++){
                                if (lastPayMode3[i] && '-1' == lastPayModeArr.indexOf(lastPayMode3[i])) {
                                    lastPayModeArr.push(lastPayMode3[i]);
                                }
                            }
                        }
                        let lastSum3 = nlcRec.getValue(FIELD_MAPPING.lastSum3);
                        let buyerPayBehave1 = nlcRec.getValue(FIELD_MAPPING.buyerPayBehave1);
                        let buyerPayBehave2 = nlcRec.getValue(FIELD_MAPPING.buyerPayBehave2);
                        let buyerPayBehave3 = nlcRec.getValue(FIELD_MAPPING.buyerPayBehave3);
                        let buyerPayBehave4 = nlcRec.getValue(FIELD_MAPPING.buyerPayBehave4);
                        let buyerOweReasonCode = nlcRec.getValue(FIELD_MAPPING.buyerOweReasonCode); // 中信保-逾期原因代码
                        let reasonCode = '';
                        if (buyerOweReasonCode){
                            let reasonRec = record.load({
                                type:'customrecord_ecm_sino_buyerowereasoncode',
                                id:buyerOweReasonCode
                            });
                            reasonCode = reasonRec.getValue('custrecord_esbac_code');
                        }
                        let buyerOweElseReason = nlcRec.getValue(FIELD_MAPPING.buyerOweElseReason);
                        let remark = nlcRec.getValue(FIELD_MAPPING.remark);
                        let declaration = nlcRec.getValue(FIELD_MAPPING.declaration);
                        let ifapplycredit = nlcRec.getValue(FIELD_MAPPING.ifapplycredit);   // 中信保-是否循环
                        if (ifapplycredit && '-1' == ifRepeatArr.indexOf(ifapplycredit)) {
                            ifRepeatArr.push(ifapplycredit);
                        }
                        let employeeName = nlcRec.getText(FIELD_MAPPING.employeeName); // 员工
                        let applicant = nlcRec.getText(FIELD_MAPPING.applicant);   // 员工
                        let applyTime = nlcRec.getValue(FIELD_MAPPING.applyTime);
                        let fileNum = nlcRec.getValue(FIELD_MAPPING.fileNum);
                        let ifSameWithPolicy = nlcRec.getValue(FIELD_MAPPING.ifSameWithPolicy); // 中信保-是否循环
                        if (ifSameWithPolicy && '-1' == ifRepeatArr.indexOf(ifSameWithPolicy)) {
                            ifRepeatArr.push(ifSameWithPolicy);
                        }
                        let precreditterm = nlcRec.getValue(FIELD_MAPPING.precreditterm);
                        let aftercreditterm = nlcRec.getValue(FIELD_MAPPING.aftercreditterm);
                        let ifHaveTradeFinancing = nlcRec.getValue(FIELD_MAPPING.ifHaveTradeFinancing); // 中信保-是否循环
                        if (ifHaveTradeFinancing && '-1' == ifRepeatArr.indexOf(ifHaveTradeFinancing)) {
                            ifRepeatArr.push(ifHaveTradeFinancing);
                        }
                        let ifHaveRelation = nlcRec.getValue(FIELD_MAPPING.ifHaveRelation); // 中信保-是否循环
                        if (ifHaveRelation && '-1' == ifRepeatArr.indexOf(ifHaveRelation)) {
                            ifRepeatArr.push(ifHaveRelation);
                        }
                        let relationDetail = nlcRec.getValue(FIELD_MAPPING.relationDetail);
                        let isSameWithContract = nlcRec.getValue(FIELD_MAPPING.isSameWithContract); // 中信保-是否循环
                        if (isSameWithContract && '-1' == ifRepeatArr.indexOf(isSameWithContract)) {
                            ifRepeatArr.push(isSameWithContract);
                        }
                        let noSameWithContractReaSo = nlcRec.getValue(FIELD_MAPPING.noSameWithContractReaSo);
                        let relationshipexplained = nlcRec.getValue(FIELD_MAPPING.relationshipexplained);   // 中信保-是否循环
                        if (relationshipexplained && '-1' == ifRepeatArr.indexOf(relationshipexplained)) {
                            ifRepeatArr.push(relationshipexplained);
                        }

                        let ifRepeatJson = {}, countryCodeJson = {}, areaCodeJson = {}, regionCodeJson = {}, lastPayModeJson = {};
                        if (ifRepeatArr && ifRepeatArr.length > 0){
                            ifRepeatJson = getCode('customrecord_ecm_ifrepeat', ifRepeatArr, 'custrecord_eif_code');
                        }
                        if (countryCodeArr && countryCodeArr.length > 0){
                            countryCodeJson = getCode('customrecord_ecm_countrycode', countryCodeArr, 'custrecord_ec_code');
                        }
                        // 注册区域代码
                        if (areaCodeArr && areaCodeArr.length > 0){
                            areaCodeJson = getCode('customrecord_ecm_areano', areaCodeArr, 'custrecord_ea_area');
                        }
                        if (regionCodeArr && regionCodeArr.length > 0){
                            regionCodeJson = getCode('customrecord_ecm_us_regioncode', regionCodeArr, 'custrecord_eur_code');
                        }
                        // 交易结算代码
                        if (lastPayModeArr && lastPayModeArr.length > 0){
                            lastPayModeJson = getCode('customrecord_ecm_paymode', lastPayModeArr, 'custrecord_epy_code');
                        }

                        let datas = [];
                        let dataJson = {};
                        dataJson.corpSerialNo = name;
                        dataJson.clientNo = clientNo;
                        dataJson.policyNo = policyNo;
                        dataJson.sinosureBuyerNo = buyerNo;
                        dataJson.corpBuyerNo = corpBuyerNo;
                        dataJson.buyerChnName = buyerChnName;
                        dataJson.buyerEngName = buyerEngName;
                        dataJson.buyerCountryCode = countryCodeJson[buyerCountryCode] || '';
                        dataJson.buyerEngAddress = buyerEngAddress;
                        dataJson.buyerChnAddress = buyerChnAddress;
                        dataJson.creditno = creditNo;
                        dataJson.regionCode = regionCodeJson[regionCode] || '';
                        dataJson.orgno = orgNo;
                        dataJson.areaNo = areaCodeJson[areaNo] || ''; // TODO
                        dataJson.buyerRegNo = buyerRegNo;
                        dataJson.buyerTel = buyerTel;
                        dataJson.buyerFax = buyerFax;
                        dataJson.warrantorType = ifRepeatJson[warrantorType] || '';
                        dataJson.sinosureWarrantorNo = sinosureWarrantorNo;
                        dataJson.corpWarrantorNo = corpWarrantorNo;
                        dataJson.warrantorChnName = warrantorChnName;
                        dataJson.warrantorEngName = warrantorEngName;
                        dataJson.warrantorCountryCode = countryCodeJson[warrantorCountryCode] || '';
                        dataJson.warrantorEngAddress = warrantorEngAddress;
                        dataJson.warrantorChnAddress = warrantorChnAddress;
                        dataJson.warrantorcreditno = warrantorcreditno;
                        dataJson.warrantororgno = warrantororgno;
                        dataJson.warrantorareano = areaCodeJson[warrantorareano] || '';
                        dataJson.warrantorRegNo = warrantorRegNo;
                        dataJson.warrantorTel = warrantorTel;
                        dataJson.warrantorFax = warrantorFax;
                        dataJson.contractPayMode = payCode;
                        dataJson.payTermApply = payTermApply;
                        dataJson.quotaSumApply = quotaSumApply;
                        dataJson.orderSum = orderSum;
                        dataJson.armSum = armSum;
                        dataJson.tradeNameCode = goodsCode;
                        dataJson.tradeElseName = tradeElseName;
                        dataJson.tradeTerms = termsCode;
                        dataJson.TradeElseTerms = TradeElseTerms;
                        dataJson.ifHistTrade = ifRepeatJson[ifHistTrade] || '';
                        dataJson.earlyTradeYear = earlyTradeYear;
                        dataJson.startDebtYear = startDebtYear;
                        dataJson.lastYear1 = lastYear1;
                        dataJson.lastPayMode1 = getDatas(lastPayMode1, lastPayModeJson);
                        dataJson.lastSum1 = lastSum1;
                        dataJson.lastYear2 = lastYear2;
                        dataJson.lastPayMode2 = getDatas(lastPayMode2, lastPayModeJson);
                        dataJson.lastSum2 = lastSum2;
                        dataJson.lastYear3 = lastYear3;
                        dataJson.lastPayMode3 = getDatas(lastPayMode3, lastPayModeJson);
                        dataJson.lastSum3 = lastSum3;
                        dataJson.buyerPayBehave1 = buyerPayBehave1;
                        dataJson.buyerPayBehave2 = buyerPayBehave2;
                        dataJson.buyerPayBehave3 = buyerPayBehave3;
                        dataJson.buyerPayBehave4 = buyerPayBehave4;
                        dataJson.buyerOweReasonCode = reasonCode;
                        dataJson.buyerOweElseReason = buyerOweElseReason;
                        dataJson.remark = remark;
                        dataJson.declaration = declaration;
                        dataJson.ifapplycredit = ifRepeatJson[ifapplycredit] || '';
                        dataJson.employeeName = employeeName;
                        dataJson.applicant = applicant;
                        dataJson.applyTime = getDateFormat(applyTime);
                        dataJson.filenum = fileNum;
                        dataJson.ifsamewithpolicy = ifRepeatJson[ifSameWithPolicy] || '';
                        dataJson.precreditterm = precreditterm;
                        dataJson.aftercreditterm = aftercreditterm;
                        dataJson.ifhavetradefinancing = ifRepeatJson[ifHaveTradeFinancing] || '';
                        dataJson.ifhaverelation = ifRepeatJson[ifHaveRelation] || '';
                        dataJson.relationdetail = relationDetail;
                        dataJson.issamewithcontract = ifRepeatJson[isSameWithContract] || '';
                        dataJson.nosamewithcontractreason = noSameWithContractReaSo;
                        dataJson.relationshipexplained = ifRepeatJson[relationshipexplained] || '';
                        datas.push(dataJson);
                        let body = {};
                        body.datas = datas;
                        body.imethod = IMETHOD;
                        log.debug('body',body)
                        try{
                            rtnData = interfaceTool.requestEdiServer(body, enume.getAll().ECM_INTERFACE_TYPE_NO_LC_LIMIT_APPLICATION);// 接口类型：非LC限额申请  // TODO
                            log.debug('rtnData', rtnData)
                            logUpdVal.custrecord_hc_inf_process_msg = newRec.id;
                            record.submitFields({
                                type: LOG_TYPE,
                                id: rtnData.logId,
                                values: logUpdVal
                            });
                            let nlcRec = record.load({type:newRec.type, id:newRec.id});
                            if (true == rtnData.valid && '' == rtnData.data.errormsg){
                                nlcRec.setValue({fieldId:FIELD_MAPPING.postsinosure, value: true});
                                nlcRec.setValue({fieldId:FIELD_MAPPING.posterromsg, value: ''});
                                nlcRec.save({enableSourcing:true, ignoreMandatoryFields:true});
                            }else {
                                nlcRec.setValue({fieldId:FIELD_MAPPING.postsinosure, value: false});
                                nlcRec.setValue({fieldId:FIELD_MAPPING.posterromsg, value: rtnData.data.errormsg});
                                nlcRec.save({enableSourcing:true, ignoreMandatoryFields:true});
                            }
                        }catch (e){
                            logUpdVal.custrecord_hc_inf_process_msg = e.message;
                            logUpdVal.custrecord_hc_inf_errorflag = true;
                            record.submitFields({
                                type: LOG_TYPE,
                                id: rtnData.logId,
                                values: logUpdVal
                            });
                            let nlcRec = record.load({type:newRec.type, id:newRec.id});
                            nlcRec.setValue({fieldId:FIELD_MAPPING.postsinosure, value: false});
                            nlcRec.setValue({fieldId:FIELD_MAPPING.posterromsg, value: rtnData.data.errormsg});
                            nlcRec.save({enableSourcing:true, ignoreMandatoryFields:true});
                        }
                    }
                }
            }catch (e){
                logUpdVal.custrecord_hc_inf_process_msg = e.message;
                logUpdVal.custrecord_hc_inf_errorflag = true;
                record.submitFields({
                    type: LOG_TYPE,
                    id: rtnData.logId,
                    values: logUpdVal
                });
                log.error('非LC限额申请error===>' + rtnData.logId, e);
                let nlcRec = record.load({type: newRec.type, id: newRec.id});
                nlcRec.setValue({fieldId:FIELD_MAPPING.errorMsg, value:e.message});
                nlcRec.save({enableSourcing:true, ignoreMandatoryFields:true});
            }
        }

        /**
         * 日期转换
         * @param date
         * @returns {string}
         */
        const getDateFormat = (date) => {
            date = new Date(date);
            let year = date.getFullYear();
            let month = date.getMonth() + 1;
            let day = date.getDate();
            if (month < 10){
                month = '0' + month;
            }
            if (day < 10){
                day = '0' + day;
            }
            return year + '-' + month + '-' + day;
        }

        /**
         * 数据转换
         * @param code
         * @param codeJson
         * @returns {*}
         */
        const getDatas = (code, codeJson) => {
            let data;
            if (code && code.length > 1){
                let goodCodeArr = '';
                for (let i = 0; i < code.length; i++){
                    if (0!=i){
                        goodCodeArr += ',' ;
                    }
                    goodCodeArr += codeJson[code[i]];
                }
                data = goodCodeArr;
            }else {
                data = codeJson[code] || '';
            }
            return data;
        }

        /**
         * 搜索各记录代码字段
         * @param searchType
         * @param codeArr
         * @param fieldId
         * @returns {{}}
         */
        const getCode = (searchType, codeArr, fieldId) => {
            let myFilters = [];
            myFilters.push(['isinactive', 'is', 'false']);
            let insideFilters = [];
            if (codeArr && codeArr.length > 0){
                myFilters.push('and');
                for (let i = 0; i < codeArr.length; i++){
                    if(0!=i){
                        insideFilters.push('or')
                    }
                    insideFilters.push(['internalid', 'anyof', codeArr[i]]);
                }
                myFilters.push(insideFilters);
            }
            let myColumns = [];
            myColumns.push('internalid');
            myColumns.push(fieldId);
            let mySearch = search.create({
                type:searchType,
                filters:myFilters,
                columns:myColumns
            });
            let myResult = mySearch.run().getRange({start:0, end:1000});
            let codeJson = {};
            if (myResult && myResult.length > 0){
                for (let i = 0; i < myResult.length; i++){
                    let internalid = myResult[i].getValue(myColumns[0]);
                    let code = myResult[i].getValue(myColumns[1]);
                    codeJson[internalid] = code;
                }
            }
            return codeJson;
        }

        return {/*beforeLoad, beforeSubmit, */afterSubmit}

    });
