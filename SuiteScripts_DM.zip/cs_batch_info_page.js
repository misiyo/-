/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 * version      date            author      remark
 * 1.0          2023/03/03      Doris       【ID1018570】SP仓库发货时创建IT单---it生成页面检验
 * 2.0          2023/03/15      Doris       测试修改
 * 3.0          2023/03/27      Doris       测试修改
 */
define(['N/currentRecord', 'N/format', 'N/record', 'N/search', 'N/url'],
/**
 * @param{currentRecord} currentRecord
 * @param{format} format
 * @param{record} record
 * @param{search} search
 * @param{url} url
 */
function(currentRecord, format, record, search, url) {
    var subid = 'line_data';
    var detailPageLink = '';

    /**
     * Function to be executed after page is initialized.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.mode - The mode in which the record is being accessed (create, copy, or edit)
     *
     * @since 2015.2
     */
    function pageInit(scriptContext) {
        window.sessionStorage.clear();
        window.writeBack = setDataToSession;
        window.openDetailsPage = openDetailsPage;
        detailPageLink = url.resolveScript({
            scriptId: 'customscript_ecm_sl_batch_detail_page',
            deploymentId: 'customdeploy_ecm_sl_batch_detail_page'
        });
    }


    function setDataToSession(scdLineId, item, line, data, location, availableQtySum) {
        console.log('writedetails==' + 'scdid=' + scdLineId + '|item=' + item + '|line=' + line + '|availableQtySum=' + availableQtySum + '|data===' + JSON.stringify(data));
        var session = window.sessionStorage;
        session.setItem('shipdata_' + scdLineId + '&' + item, JSON.stringify(data));
        var obj = currentRecord.get();
        obj.selectLine({sublistId: subid,line: line});
        obj.setCurrentSublistValue({sublistId: subid,fieldId: 'custpage_data_actual_transfer_qty',value: availableQtySum});
        obj.setCurrentSublistText({sublistId:subid, fieldId:'custpage_data_batchid', text:JSON.stringify(data)});
        obj.commitLine({sublistId: subid});
    }

    /**
     * details页面
     * @param scdLineId
     * @param item
     * @param line
     * @param spid
     * @param transferQty
     * @param location
     */
    function openDetailsPage(scdLineId, item, line, spid, transferQty, location) {
        var session = window.sessionStorage;
        var reopen = 'F',
            existData = session.getItem('shipdata_' + scdLineId + '&' + item);
        if(null != existData) {
            reopen = 'T';
        }
        if('' == detailPageLink) {
            detailPageLink = url.resolveScript({
                scriptId: 'customscript_ecm_sl_batch_detail_page',
                deploymentId: 'customdeploy_ecm_sl_batch_detail_page'
            });
        }
        var obj = currentRecord.get();
        transferQty = Number(obj.getSublistValue({sublistId:subid, fieldId:'custpage_data_quantity', line:line}) || 0);
        if (Number(0) < Number(transferQty)){
            var tlink = detailPageLink + '&scdlineid=' + encodeURIComponent(scdLineId) +'&item=' + encodeURIComponent(item) + '&line=' + encodeURIComponent(line) + '&spid=' + encodeURIComponent(spid) + '&total=' + encodeURIComponent(transferQty) + '&location=' + encodeURIComponent(location) + '&reopen=' + encodeURIComponent(reopen);
            window.open(tlink, '_blank', 'left=150,top=100,width=900,height=600');
        }else {
            alert('Please enter a number greater than 0 for TRANSFER QTY!');
        }
    }


    /**
     * Function to be executed when field is changed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
     * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
     *
     * @since 2015.2
     */
    function fieldChanged(scriptContext) {
        var curRec = scriptContext.currentRecord;
        var fieldId = scriptContext.fieldId;
        try{
            if ('custpage_data_select' == fieldId){
                var selected = curRec.getCurrentSublistValue({sublistId:subid, fieldId:'custpage_data_select'}) || '';
                if ('T' == selected || true == selected){
                    var remainQty = Number(curRec.getCurrentSublistValue({sublistId:subid, fieldId:'custpage_data_actual_transfer_qty'}) || 0);
                    if (Number(0) == Number(remainQty)){
                        alert('The number of REMAIN QTY in the selected row is empty!Please click Details to select data.');
                        curRec.setCurrentSublistValue({sublistId:subid, fieldId:'custpage_data_select', value: false});
                        return false;
                    }
                    var batchData = curRec.getCurrentSublistValue({sublistId:subid, fieldId:'custpage_data_batchid'}) || '';
                    if ('' == batchData){
                        alert('No batch information.');
                        curRec.setCurrentSublistValue({sublistId:subid, fieldId:'custpage_data_select', value: false});
                        return false;
                    }
                }
            }
            return true;
        }catch (e){
            console.log('fieldChanged-error==>'+e);
            return false;
        }
    }

    /**
     * Function to be executed when field is slaved.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     *
     * @since 2015.2
     */
    function postSourcing(scriptContext) {

    }

    /**
     * Function to be executed after sublist is inserted, removed, or edited.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @since 2015.2
     */
    function sublistChanged(scriptContext) {

    }

    /**
     * Function to be executed after line is selected.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @since 2015.2
     */
    function lineInit(scriptContext) {

    }

    /**
     * Validation function to be executed when field is changed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
     * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
     *
     * @returns {boolean} Return true if field is valid
     *
     * @since 2015.2
     */
    function validateField(scriptContext) {

    }

    /**
     * Validation function to be executed when sublist line is committed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateLine(scriptContext) {

    }

    /**
     * Validation function to be executed when sublist line is inserted.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateInsert(scriptContext) {

    }

    /**
     * Validation function to be executed when record is deleted.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateDelete(scriptContext) {

    }

    /**
     * Validation function to be executed when record is saved.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @returns {boolean} Return true if record is valid
     *
     * @since 2015.2
     */
    function saveRecord(scriptContext) {
        try {
            var curRec = scriptContext.currentRecord;
            var lineCount = curRec.getLineCount({sublistId:subid});
            if (lineCount <= 0) {
                alert('No row data.');
                return ;
            }else {
                var num = 0;
                for (var i = 0; i < lineCount; i++){
                    var isSelected = curRec.getSublistValue({sublistId:subid, fieldId:'custpage_data_select', line:i}) || '';
                    if ('T' == isSelected || true == isSelected){
                        var actualTransferQty = Number(curRec.getSublistValue({sublistId:subid, fieldId:'custpage_data_actual_transfer_qty', line:i}) || 0);
                        var quantity = Number(curRec.getSublistValue({sublistId:subid, fieldId:'custpage_data_quantity', line:i}) || 0);
                        if (Number(0) == Number(actualTransferQty)){
                            alert('The number of ACTUAL TRANSFER QTY in the selected row is empty!');
                            curRec.setSublistValue({sublistId:subid, fieldId:'custpage_data_select', value: false, line:i});
                            return;
                        }
                        if (quantity != actualTransferQty){
                            alert('TRANSFER QTY and ACTUAL TRANSFER QTY are not equal, please click Details to check!');
                            curRec.setSublistValue({sublistId:subid, fieldId:'custpage_data_select', value: false, line:i});
                            return;
                        }
                        var batchData = curRec.getSublistValue({sublistId:subid, fieldId:'custpage_data_batchid', line:i}) || '';
                        if ('' == batchData){
                            alert('No batch information.');
                            curRec.setSublistValue({sublistId:subid, fieldId:'custpage_data_select', value: false, line:i});
                            return;
                        }
                        num++;
                    }
                }
                if (0 == num){
                    alert("The detail line is not checked, and the IT document cannot be generated. Please check!");
                    return;
                }
                return true;
            }
        }catch (e){
            console.log('creat IT error===>'+e);
            return false;
        }
    }

    return {
        pageInit: pageInit,
        fieldChanged: fieldChanged,
        // postSourcing: postSourcing,
        // sublistChanged: sublistChanged,
        // lineInit: lineInit,
        // validateField: validateField,
        // validateLine: validateLine,
        // validateInsert: validateInsert,
        // validateDelete: validateDelete,
        saveRecord: saveRecord,
        openDetailsPage:openDetailsPage,
    };
    
});
