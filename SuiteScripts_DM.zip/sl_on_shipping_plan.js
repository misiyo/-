/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 * version      date            author      remark
 * 1.0          2023/02/28      Doris       【ID1018580】Shipping Plan Create SO&IF
 * 2.0          2023/03/10      Doris       【ID1018580】Shipping Plan Create SO&IF,变更：Create SO按钮及Create IF按钮分别生成SO、IF单
 * 3.0          2023/03/21      Doris       变更：IF单逻辑变更
 * 4.0          2023/03/27      Doris       测试修改
 */
define(['N/record', 'N/search', 'N/format', 'N/redirect', '/SuiteScripts/SuiteScripts_DM/environment_check.js', '/SuiteScripts/tools/common_api.js'],
    /**
 * @param{record} record
 * @param{search} search
 * @param{format} format
 * @param{redirect} redirect
 */
    (record, search, format, redirect, enume, commonApi) => {
        const SP_SUBLIST_ID = 'recmachcustrecord_scdline_sp';

        /**
         * Defines the Suitelet script trigger point.
         * @param {Object} scriptContext
         * @param {ServerRequest} scriptContext.request - Incoming request
         * @param {ServerResponse} scriptContext.response - Suitelet response
         * @since 2015.2
         */
        const onRequest = (scriptContext) => {
            let request = scriptContext.request;
            let response = scriptContext.response;
            let params = request.parameters;
            try{
                if ('GET' == request.method){
                    if ('createSo' == params.createType){
                        let soId = createSo(params,response);
                        // TODO custrecord_sp_createsoif_iscreated字段待重新更新
                        // if (soId && soId.length > 0){
                        //     let spRec = record.load({type:params.objRecType, id:params.objRecId});
                        //     spRec.setValue({fieldId:'custrecord_sp_createsoif_iscreated', value:true});
                        //     spRec.save({enableSourcing: true, ignoreMandatoryFields:true});
                        //     response.write("<script type='text/javascript'>window.opener.reload(); window.close();</script>");
                        // }
                    }else if ('createIf' == params.createType){
                        // let ifId = createIf(params,response);
                        createIfTest(params, response)
                    }
                }
            }catch (e) {
                log.debug('error', e);
                response.write("<script type='text/javascript'>window.close();</script>");
            }
        }

        /**
         * sp生成so
         * @param params
         * @param response
         * @returns {[]}
         */
        const createSo = (params,response) => {
            let spRec = record.load({
                type:params.objRecType,
                id:params.objRecId
            });
            let soId = '';
            let soIdArr = [];
            let lineCount = spRec.getLineCount({sublistId:SP_SUBLIST_ID});
            let scLineArr = [];
            if (lineCount > 0){
                for (let i = 0; i < lineCount; i++){
                    let scLine = spRec.getSublistValue({sublistId:SP_SUBLIST_ID, fieldId:'custrecord_scdline_uniquekey', line:i});
                    let soNo = spRec.getSublistValue({sublistId:SP_SUBLIST_ID, fieldId:'custrecord_scdline_sono1', line:i}) || '';
                    if (scLine && '-1' == scLineArr.indexOf(scLine) && '' == soNo){
                        scLineArr.push(scLine);
                    }
                }
                if (scLineArr && scLineArr.length > 0){
                    let recData = getScInfoTest(scLineArr);

                    let scRecData = recData.scArr;
                    let soRecData = recData.soArr;

                    if (soRecData && Object.keys(soRecData).length > 0){
                        for (const soRecDataKey in soRecData) {
                            try{
                                let soRec = record.load({type:'salesorder', id:soRecDataKey});
                                soRec.setValue({fieldId:'custbody_ecm_sp', value:params.objRecId});
                                soRec.save({enableSourcing:true, ignoreMandatoryFields:true});
                                let soRecDataValue = soRecData[soRecDataKey];
                                if (soRecDataValue && soRecDataValue.length > 0){
                                    for (let i = 0; i < soRecDataValue.length; i++){
                                        for (let j = 0; j < lineCount; j++){
                                            let uniquekey = spRec.getSublistValue({sublistId:SP_SUBLIST_ID, fieldId:'custrecord_scdline_uniquekey', line:j});
                                            if (soRecDataValue[i] == uniquekey){
                                                spRec.setSublistValue({sublistId:SP_SUBLIST_ID, fieldId:'custrecord_scdline_sono1', value:soRecDataKey, line:j});
                                            }
                                        }
                                    }
                                }
                            }catch (soError){
                                log.error('SC直接回写SO-->error', soError);
                            }
                        }
                        spRec.save({enableSourcing:true, ignoreMandatoryFields:true});
                        response.write("<script type='text/javascript'>window.opener.location.reload(); window.close();</script>");
                    }

                    if (scRecData && Object.keys(scRecData).length > 0){
                        for (const scRecDataKey in scRecData) {
                            try {
                                let scRecDataValue = scRecData[scRecDataKey];
                                let lineData = scRecDataValue.lineData;
                                let entity = scRecDataValue.entity;
                                let subsidiary = scRecDataValue.subsidiary;
                                let contractType = scRecDataValue.contractType;
                                let incoterm = scRecDataValue.incoterm;
                                let terms = scRecDataValue.terms;
                                let currency = scRecDataValue.currency;
                                let iscrossborder = scRecDataValue.iscrossborder;
                                let countryof_departure = scRecDataValue.countryof_departure;
                                let exchangerate = scRecDataValue.exchangerate;
                                let leadsource = scRecDataValue.leadsource;
                                let nowDate = getFormatDate(new Date());

                                let soRec = record.create({type:'salesorder',isDynamic:true});

                                soRec.setValue({fieldId:'entity', value:entity});
                                soRec.setText({fieldId:'tradate', text:nowDate});
                                soRec.setValue({fieldId:'subsidiary', value:subsidiary,forceSyncSourcing:true});
                                soRec.setValue({fieldId:'custbody_ecm_contract_type', value:contractType});
                                soRec.setValue({fieldId:'custbody_ecm_incoterm', value:incoterm});
                                soRec.setValue({fieldId:'currency', value:currency});
                                soRec.setValue({fieldId:'custbody_ecm_iscrossborder', value:iscrossborder});
                                soRec.setValue({fieldId:'custbody_ecm_countryof_departure', value:countryof_departure});
                                soRec.setValue({fieldId:'exchangerate', value:exchangerate});
                                soRec.setValue({fieldId:'leadsource', value:leadsource});
                                soRec.setValue({fieldId:'custbody_ecm_ordertype', value:enume.getAll().SALES_ORDER_TYPE_ORDER});
                                soRec.setValue({fieldId:'custbody_sourceformtran', value:scRecDataKey});
                                soRec.setValue({fieldId:'custbody_ecm_sp', value:params.objRecId});
                                soRec.setValue({fieldId:'orderstatus', value:'B'});

                                if (lineData && Object.keys(lineData).length > 0){
                                    for (const lineDataKey in lineData) {
                                        let lineDataValue = lineData[lineDataKey];
                                        let unit = lineDataValue.unit;
                                        let rate = lineDataValue.rate;
                                        let taxCode = lineDataValue.taxCode;

                                        let itemId = '';
                                        let sum = 0;

                                        for (let i = 0; i < lineCount; i++){
                                            let scLine = spRec.getSublistValue({sublistId:SP_SUBLIST_ID, fieldId:'custrecord_scdline_uniquekey', line:i});
                                            if (lineDataKey == scLine){
                                                itemId = spRec.getSublistValue({sublistId:SP_SUBLIST_ID, fieldId:'custrecord_scdline_item', line:i});
                                                let quantity = spRec.getSublistValue({sublistId:SP_SUBLIST_ID, fieldId:'custrecord_scdline_qty', line:i});
                                                sum = Number(sum).add(quantity);
                                            }
                                        }

                                        let amount = Number(sum).mul(Number(rate));
                                        soRec.selectNewLine({sublistId:'item'});
                                        soRec.setCurrentSublistValue({sublistId:'item', fieldId:'item', value:itemId});
                                        soRec.setCurrentSublistValue({sublistId:'item', fieldId:'quantity', value:sum});
                                        soRec.setCurrentSublistValue({sublistId:'item', fieldId:'units', value:unit});
                                        soRec.setCurrentSublistValue({sublistId:'item', fieldId:'taxcode', value:taxCode});
                                        soRec.setCurrentSublistValue({sublistId:'item', fieldId:'amount', value:Number(amount)});
                                        soRec.setCurrentSublistValue({sublistId:'item', fieldId:'rate', value:Number(rate)});
                                        soRec.commitLine({sublistId:'item'});
                                    }
                                }
                                soId = soRec.save({enableSourcing:true, ignoreMandatoryFields:true});
                                if (soId){
                                    soIdArr.push(soId);
                                    spRec = record.load({type:params.objRecType, id:params.objRecId});
                                    spRec.setValue({fieldId:'custrecord_sp_createsoif_erromsg', value:''});
                                    let lineIdArr = Object.keys(lineData);
                                    for (let li = 0; li < lineIdArr.length; li++){
                                        for(let lineId = 0; lineId < lineCount; lineId++){
                                            let uniquekey = spRec.getSublistValue({sublistId:SP_SUBLIST_ID, fieldId:'custrecord_scdline_uniquekey', line:lineId});
                                            if (lineIdArr[li] == uniquekey){
                                                spRec.setSublistValue({sublistId:SP_SUBLIST_ID, fieldId:'custrecord_scdline_sono1', value:soId, line:lineId});
                                            }
                                        }
                                    }

                                    spRec.save({enableSourcing:true, ignoreMandatoryFields:true});
                                }
                            }catch (ex){
                                let errorMsg = '创建so失败，scid:'+ scRecDataKey + '失败原因：' + ex.message;
                                let spRec = record.load({type:params.objRecType, id:params.objRecId});
                                spRec.setValue({fieldId:'custrecord_sp_createsoif_erromsg', value:errorMsg});
                                spRec.save({enableSourcing:true, ignoreMandatoryFields:true});
                                log.debug('创建so失败', ex);
                                response.write("<script type='text/javascript'>window.opener.location.reload(); window.close();</script>");
                            }
                        }
                        response.write("<script type='text/javascript'>window.opener.location.reload(); window.close();</script>");
                    }
                }
            }
            return soIdArr;
        }


        /**
         * 格式化日期
         * @param oldDate
         * @returns {string}
         */
        function getFormatDate(oldDate) {
            let newDate = format.format({
                value:new Date(oldDate),
                type:format.Type.DATETIME
            });
            return newDate
        }


        /**
         * getScInfoTest
         * @param scLineArr
         */
        const getScInfoTest = (scLineArr) => {
            let myFilters = [];
            myFilters.push(['type', 'anyof', 'SalesOrd']);
            let insideFilters = [];
            if (scLineArr && scLineArr.length > 0){
                myFilters.push('and');
                for (let i = 0; i < scLineArr.length; i++){
                    if(0!=i){
                        insideFilters.push('or')
                    }
                    insideFilters.push(['lineuniquekey', 'equalto', scLineArr[i]]);
                }
                myFilters.push(insideFilters);
            }
            let myColumns = [];
            myColumns.push({name:'internalid', sort: search.Sort.ASC});
            myColumns.push('lineuniquekey');
            myColumns.push('entity');
            myColumns.push('subsidiary');
            myColumns.push('custbody_ecm_contract_type');
            myColumns.push('custbody_ecm_incoterm');
            myColumns.push('terms');
            myColumns.push('currency');
            myColumns.push('custbody_ecm_iscrossborder');
            myColumns.push('custbody_ecm_countryof_departure');
            myColumns.push('exchangerate');
            myColumns.push('leadsource');
            myColumns.push('unitid');
            myColumns.push('taxcode');
            myColumns.push('fxrate');
            myColumns.push('custbody_ecm_ordertype');
            let mySearch = search.create({
                type:'salesorder',
                filters:myFilters,
                columns:myColumns
            });
            let myResult = mySearch.run().getRange({start:0, end:1000});
            let scArr = {};
            let lineData = {};
            let soArr = {};
            if (myResult && myResult.length > 0){
                for (let i = 0; i < myResult.length; i++){
                    let scId = myResult[i].getValue(myColumns[0]) || '';
                    let lineuniquekey = myResult[i].getValue(myColumns[1]) || '';

                    let orderType = myResult[i].getValue(myColumns[15]) || '';
                    if (enume.getAll().SALES_ORDER_TYPE_CONTRACT != orderType){
                        soArr[scId] = soArr[scId] || [];
                        soArr[scId].push(lineuniquekey);
                    }else {
                        scArr[scId] = scArr[scId] || {lineData : {},entity:'', subsidiary:'', contractType:'', incoterm:'', terms:'', currency:'', iscrossborder:'',countryof_departure:'',exchangerate:'', leadsource:''};

                        scArr[scId].entity = myResult[i].getValue(myColumns[2]) || '';
                        scArr[scId].subsidiary = myResult[i].getValue(myColumns[3]) || '';
                        scArr[scId].contractType = myResult[i].getValue(myColumns[4]) || '';
                        scArr[scId].incoterm = myResult[i].getValue(myColumns[5]) || '';
                        scArr[scId].terms = myResult[i].getValue(myColumns[6]) || '';
                        scArr[scId].currency = myResult[i].getValue(myColumns[7]) || '';
                        scArr[scId].iscrossborder = myResult[i].getValue(myColumns[8]);
                        scArr[scId].countryof_departure = myResult[i].getValue(myColumns[9]) || '';
                        scArr[scId].exchangerate = myResult[i].getValue(myColumns[10]) || '';
                        scArr[scId].leadsource = myResult[i].getValue(myColumns[11]) || '';

                        scArr[scId].lineData[lineuniquekey] = lineData[lineuniquekey] || {unit:'', rate:'', taxCode :''}
                        scArr[scId].lineData[lineuniquekey].unit = myResult[i].getValue(myColumns[12]) || '';
                        scArr[scId].lineData[lineuniquekey].taxCode = myResult[i].getValue(myColumns[13]) || '';
                        scArr[scId].lineData[lineuniquekey].rate = myResult[i].getValue(myColumns[14]) || '';
                    }
                }
            }
            log.debug('getScInfoTest', {scArr:scArr,soArr:soArr})
            return {scArr:scArr, soArr:soArr};
        }

        const createIfTest = (params, response) => {
            let spRec = record.load({type:params.objRecType, id:params.objRecId});
            let subsidiaryId = spRec.getValue('custrecord_sp_scsubsidiary');
            let location = '';
            if (subsidiaryId){
                let subRec = record.load({type:'subsidiary', id:subsidiaryId});
                location = subRec.getValue('custrecord_ecm_location');
            }
            let lineCount = spRec.getLineCount({sublistId:SP_SUBLIST_ID});
            let poIdArr = [];
            let poJson = {};
            let scdlineIdArr = [];
            let itScdlineArr = [];
            let itIdArr = [];
            let itJson = {};
            if (lineCount > 0){
                for (let i = 0; i < lineCount; i++){
                    let soId = spRec.getSublistValue({sublistId:SP_SUBLIST_ID, fieldId:'custrecord_scdline_sono1', line:i});
                    if (soId){
                        let poId = spRec.getSublistValue({sublistId:SP_SUBLIST_ID, fieldId:'custrecord_scdline_purchaseorder', line:i});
                        let scdlineId = spRec.getSublistValue({sublistId:SP_SUBLIST_ID, fieldId:'id', line:i});
                        let itId = spRec.getSublistValue({sublistId:SP_SUBLIST_ID, fieldId:'custrecord_scdline_it', line:i});
                        // if (poId && '-1' == poIdArr.indexOf(poId)){
                        //     poIdArr.push(poId);
                        //     poJson[poId] = poJson[poId] || [];
                        //     poJson[poId].push(scdlineId);
                        // }
                        if (poId){
                            poIdArr.push(poId);
                            poJson[poId] = poJson[poId] || [];
                            poJson[poId].push(scdlineId);
                        }
                        if ('' == poId && itId){
                            itIdArr.push(itId);
                            itJson[itId] = itJson[itId] || [];
                            itJson[itId].push(scdlineId)
                        }

                    }
                }
            }
            log.debug('poJson', {poJson:poJson, poIdArr:poIdArr})
            log.debug('itJson', {itJson:itJson})

            // let inventoryItInfo = getItInvInfo(itId, noPoScdlineArr);

            let irInventoryInfo = {};
            if (poJson && Object.keys(poJson).length > 0){
                irInventoryInfo = getIrInvInfo(poJson, 'itemreceipt', 'ItemRcpt', '');
            }

            let itLocation = [];
            if (itIdArr && itIdArr.length > 0){
                itLocation = getToLocation(itIdArr,'inventorytransfer', 'InvTrnfr');
            }
            let itInventoryInfo = {};
            if (itJson && Object.keys(itJson).length > 0){
                itInventoryInfo = getIrInvInfo(itJson, 'inventorytransfer', 'InvTrnfr', itLocation);
            }

            let inventoryInfo = Object.assign(irInventoryInfo, itInventoryInfo);
            log.debug('inventoryInfo',inventoryInfo)

            let spData = getSpData(params.objRecId);
            if (spData && Object.keys(spData).length > 0) {
                for (const spDataKey in spData) {
                    try{
                        let ifId = '';
                        let ifRec = record.transform({fromType: 'salesorder', fromId: spDataKey, toType: 'itemfulfillment', isDynamic: true});
                        let ifScdline = [];
                        let spDataValue = spData[spDataKey];
                        ifRec.setText({fieldId:'trandate', text:spDataValue.shipdate});
                        if (spDataValue && Object.keys(spDataValue).length > 0) {
                            let lineCount = ifRec.getLineCount({sublistId: 'item'});
                            if (lineCount > 0) {
                                for (let i = 0; i < lineCount; i++) {
                                    ifRec.selectLine({sublistId: 'item', line: i});
                                    let itemInfo = ifRec.getCurrentSublistValue({
                                        sublistId: 'item',
                                        fieldId: 'item'
                                    });
                                    log.debug('itemInfo',itemInfo)
                                    let itemInfoJson = spDataValue.itemInfo;
                                    for (const itemInfoJsonKey in itemInfoJson) {
                                        let itemInfoValue = itemInfoJson[itemInfoJsonKey];
                                        if (itemInfo == itemInfoJsonKey) {
                                            ifRec.setCurrentSublistValue({
                                                sublistId: 'item',
                                                fieldId: 'item',
                                                value: itemInfoJsonKey
                                            });
                                            ifRec.setCurrentSublistValue({
                                                sublistId: 'item',
                                                fieldId: 'location',
                                                value: location
                                            });
                                            ifRec.setCurrentSublistValue({
                                                sublistId: 'item',
                                                fieldId: 'quantity',
                                                value: itemInfoValue.spqty
                                            });
                                            let inventorydetail = ifRec.getCurrentSublistSubrecord({
                                                sublistId: 'item',
                                                fieldId: 'inventorydetail'
                                            });

                                            let poNo = itemInfoValue.poNo;
                                            let scdLineId = itemInfoValue.scdLineId;

                                            setBatchInfo(inventoryInfo, inventorydetail, scdLineId, itemInfo);


                                            // if (poNo){
                                            //     setBatchInfo(irInventoryInfo, inventorydetail, scdLineId, itemInfo);
                                            //     // ifScdline.push(scdLineId)
                                            // }else {
                                            //     setBatchInfo(itInventoryInfo, inventorydetail, scdLineId, itemInfo);
                                            //     // ifScdline.push(scdLineId)
                                            // }
                                            ifRec.commitLine({sublistId: 'item'});
                                        }
                                    }
                                }
                            }
                        }
                        ifId = ifRec.save({enableSourcing:true, ignoreMandatoryFields:true});
                        if (ifId){
                            let spRec = record.load({type:params.objRecType, id:params.objRecId});
                            spRec.setValue({fieldId:'custrecord_sp_createsoif_erromsg', value:''});
                            let lineCount = spRec.getLineCount({sublistId:SP_SUBLIST_ID});
                            if (lineCount > 0){
                                for (let i = 0; i < lineCount; i++){
                                    let soNo = spRec.getSublistValue({sublistId:SP_SUBLIST_ID, fieldId:'custrecord_scdline_sono1', line:i});
                                    let scdLineId = spRec.getSublistValue({sublistId:SP_SUBLIST_ID, fieldId:'id', line:i});
                                    if (soNo == spDataKey){
                                        spRec.setSublistValue({sublistId:SP_SUBLIST_ID, fieldId:'custrecord_scdline_soif1', value:ifId, line:i});

                                        // if(ifScdline && ifScdline.length > 0){
                                        //     for (let ifline = 0; ifline < ifScdline.length; ifline++){
                                        //         if (scdLineId == ifScdline[ifline]){
                                        //         }
                                        //     }
                                        // }
                                    }
                                }
                            }
                            spRec.save({enableSourcing:true, ignoreMandatoryFields:true});
                        }
                    }catch (iferror){
                        let errorMsg = '创建IF单失败，soid:'+ spDataKey + '失败原因：' + iferror.message;
                        let spRec = record.load({type:params.objRecType, id:params.objRecId});
                        spRec.setValue({fieldId:'custrecord_sp_createsoif_erromsg', value:errorMsg});
                        spRec.save({enableSourcing:true, ignoreMandatoryFields:true});
                        response.write("<script type='text/javascript'>window.opener.location.reload(); window.close();</script>");
                        log.debug('生成IF单errror--->'+spDataKey,iferror);
                    }
                }
                response.write("<script type='text/javascript'>window.opener.location.reload(); window.close();</script>");
            }



            // if (poJson && Object.keys(poJson).length > 0){
            //     let irInfo = getIrInfo(poJson);
            //
            //     let inventoryInfo = getInvInfo(irInfo, itJson);
            //
            //     let irJsonInfo = {};
            //     for (const poJsonKey in poJson) {
            //         irJsonInfo[poJsonKey] = inventoryInfo;
            //     }
            //     log.debug('irJsonInfo',irJsonInfo)
            //
            //     let spData = getSpData(params.objRecId);
            //     if (spData && Object.keys(spData).length > 0) {
            //         for (const spDataKey in spData) {
            //             try {
            //                 let ifId = '';
            //                 let ifRec = record.transform({fromType: 'salesorder', fromId: spDataKey, toType: 'itemfulfillment', isDynamic: true});
            //                 let spDataValue = spData[spDataKey];
            //                 ifRec.setText({fieldId:'trandate', text:spDataValue.shipdate});
            //                 // ifRec.setText({fieldId:'trandate', text:'3/21/2023'});  // TODO
            //
            //                 if (spDataValue && Object.keys(spDataValue).length > 0) {
            //                     let lineCount = ifRec.getLineCount({sublistId: 'item'});
            //                     if (lineCount > 0) {
            //                         for (let i = 0; i < lineCount; i++) {
            //                             ifRec.selectLine({sublistId: 'item', line: i});
            //                             let itemInfo = ifRec.getCurrentSublistValue({
            //                                 sublistId: 'item',
            //                                 fieldId: 'item'
            //                             });
            //                             log.debug('itemInfo',itemInfo)
            //                             let itemInfoJson = spDataValue.itemInfo;
            //                             for (const itemInfoJsonKey in itemInfoJson) {
            //                                 let itemInfoValue = itemInfoJson[itemInfoJsonKey];
            //
            //                                 if (itemInfo == itemInfoJsonKey) {
            //                                     ifRec.setCurrentSublistValue({
            //                                         sublistId: 'item',
            //                                         fieldId: 'item',
            //                                         value: itemInfoJsonKey
            //                                     });
            //                                     ifRec.setCurrentSublistValue({
            //                                         sublistId: 'item',
            //                                         fieldId: 'location',
            //                                         value: location
            //                                     });
            //                                     ifRec.setCurrentSublistValue({
            //                                         sublistId: 'item',
            //                                         fieldId: 'quantity',
            //                                         value: itemInfoValue.spqty
            //                                     });
            //
            //                                     let inventorydetail = ifRec.getCurrentSublistSubrecord({
            //                                         sublistId: 'item',
            //                                         fieldId: 'inventorydetail'
            //                                     });
            //                                     let poNo = itemInfoValue.poNo;
            //                                     let scdLineId = itemInfoValue.scdLineId;
            //                                     if (poNo){
            //                                         if (irJsonInfo && Object.keys(irJsonInfo).length > 0){
            //                                             for (const irJsonInfoKey in irJsonInfo) {
            //                                                 let poInfo = irJsonInfo[irJsonInfoKey];
            //                                                 log.debug('poInfo',poInfo)
            //                                                 if (poNo == irJsonInfoKey){
            //                                                     if (poInfo && Object.keys(poInfo).length > 0){
            //                                                         for (const poInfoKey in poInfo) {
            //                                                             let poInfoValue = poInfo[poInfoKey];
            //                                                             log.debug('poInfoValue',poInfoValue)
            //                                                             if (poInfoValue && Object.keys(poInfoValue).length > 0){
            //                                                                 for (const poInfoValueKey in poInfoValue) {
            //                                                                     let itemInfoKey = poInfoValue[poInfoValueKey];
            //                                                                     if (itemInfoKey && Object.keys(itemInfoKey).length > 0){
            //                                                                         for (const itemInfoKeyKey in itemInfoKey) {
            //                                                                             if (itemInfoKeyKey == itemInfo){
            //                                                                                 let inventorySubId = 'inventoryassignment';
            //                                                                                 let batchData = itemInfoKey[itemInfoKeyKey].lineData;
            //
            //                                                                                 if (batchData && Object.keys(batchData).length > 0) {
            //
            //                                                                                     for (const batchDataKey in batchData) {
            //                                                                                         let bachDataValue = batchData[batchDataKey];
            //                                                                                         inventorydetail.selectNewLine({sublistId: inventorySubId});
            //                                                                                         inventorydetail.setCurrentSublistValue({sublistId: inventorySubId, fieldId: 'issueinventorynumber', value: batchDataKey});//序号批次号
            //                                                                                         inventorydetail.setCurrentSublistValue({sublistId: inventorySubId, fieldId: 'inventorystatus', value: bachDataValue.status, forceSyncSourcing:true});//
            //                                                                                         inventorydetail.setCurrentSublistValue({sublistId: inventorySubId, fieldId: 'quantity', value: bachDataValue.quantity, forceSyncSourcing:true});//数量
            //
            //                                                                                         inventorydetail.commitLine({sublistId: inventorySubId});
            //                                                                                     }
            //                                                                                 }
            //                                                                             }
            //                                                                         }
            //
            //                                                                     }
            //
            //                                                                 }
            //                                                             }
            //                                                         }
            //                                                     }
            //                                                 }
            //                                             }
            //                                         }
            //                                     }
            //                                     // else {
            //                                     //     if (inventoryItInfo && Object.keys(inventoryItInfo).length > 0){
            //                                     //         for (const inventoryItInfoKey in inventoryItInfo) {
            //                                     //             if (scdLineId == inventoryItInfoKey){
            //                                     //                 let inventoryItInfoValue = inventoryItInfo[inventoryItInfoKey];
            //                                     //                 if (inventoryItInfoValue && Object.keys(inventoryItInfoValue).length > 0){
            //                                     //                     for (const inventoryItInfoValueKey in inventoryItInfoValue) {
            //                                     //                         let itemInfoKey = inventoryItInfoValue[inventoryItInfoValueKey];
            //                                     //                         if (itemInfoKey && Object.keys(itemInfoKey).length > 0){
            //                                     //                             for (const itemInfoKeyKey in itemInfoKey) {
            //                                     //                                 if (itemInfoKeyKey == itemInfo){
            //                                     //                                     let inventorySubId = 'inventoryassignment';
            //                                     //                                     let batchData = itemInfoKey[itemInfoKeyKey].lineData;
            //                                     //
            //                                     //                                     if (batchData && Object.keys(batchData).length > 0) {
            //                                     //
            //                                     //                                         for (const batchDataKey in batchData) {
            //                                     //                                             let bachDataValue = batchData[batchDataKey];
            //                                     //                                             inventorydetail.selectNewLine({sublistId: inventorySubId});
            //                                     //                                             inventorydetail.setCurrentSublistValue({sublistId: inventorySubId, fieldId: 'issueinventorynumber', value: batchDataKey});//序号批次号
            //                                     //                                             inventorydetail.setCurrentSublistValue({sublistId: inventorySubId, fieldId: 'inventorystatus', value: bachDataValue.status, forceSyncSourcing:true});//
            //                                     //                                             inventorydetail.setCurrentSublistValue({sublistId: inventorySubId, fieldId: 'quantity', value: bachDataValue.quantity, forceSyncSourcing:true});//数量
            //                                     //
            //                                     //                                             inventorydetail.commitLine({sublistId: inventorySubId});
            //                                     //                                         }
            //                                     //                                     }
            //                                     //                                 }
            //                                     //                             }
            //                                     //                         }
            //                                     //                     }
            //                                     //                 }
            //                                     //             }
            //                                     //         }
            //                                     //     }
            //                                     // }
            //                                     ifRec.commitLine({sublistId: 'item'});
            //                                 }
            //                             }
            //                         }
            //                     }
            //                 }
            //                 // ifId = ifRec.save({enableSourcing:true, ignoreMandatoryFields:true});
            //                 // if (ifId){
            //                 //     let spRec = record.load({type:params.objRecType, id:params.objRecId});
            //                 //     spRec.setValue({fieldId:'custrecord_sp_createsoif_erromsg', value:''});
            //                 //     let lineCount = spRec.getLineCount({sublistId:SP_SUBLIST_ID});
            //                 //     if (lineCount > 0){
            //                 //         for (let i = 0; i < lineCount; i++){
            //                 //             let soNo = spRec.getSublistValue({sublistId:SP_SUBLIST_ID, fieldId:'custrecord_scdline_sono1', line:i});
            //                 //             if (soNo == spDataKey){
            //                 //                 spRec.setSublistValue({sublistId:SP_SUBLIST_ID, fieldId:'custrecord_scdline_soif1', value:ifId, line:i});
            //                 //             }
            //                 //         }
            //                 //     }
            //                 //     spRec.save({enableSourcing:true, ignoreMandatoryFields:true});
            //                 // }
            //             } catch (iferror) {
            //                 let errorMsg = '创建IF单失败，soid:'+ spDataKey + '失败原因：' + iferror.message;
            //                 let spRec = record.load({type:params.objRecType, id:params.objRecId});
            //                 spRec.setValue({fieldId:'custrecord_sp_createsoif_erromsg', value:errorMsg});
            //                 spRec.save({enableSourcing:true, ignoreMandatoryFields:true});
            //                 response.write("<script type='text/javascript'>window.opener.location.reload(); window.close();</script>");
            //                 log.debug('生成IF单errror--->'+spDataKey,iferror);
            //             }
            //         }
            //         response.write("<script type='text/javascript'>window.opener.location.reload(); window.close();</script>");
            //     }
            // }
        }

        const getToLocation = (itId, searchType, filterType) => {
            let myFilters = [];
            myFilters.push(['type', 'anyof', filterType]);

            myFilters.push('and');
            myFilters.push(['internalid', 'anyof', itId]);
            myFilters.push('and');
            myFilters.push(['mainline', 'is', 'T']);
            myFilters.push('and');
            myFilters.push(['taxline', 'is', 'F']);

            let myColumns = [];
            myColumns.push({name: "location"});

            let mySearch = search.create({type:searchType, filters:myFilters, columns:myColumns});
            let myResult = commonApi.getAllData(mySearch);
            let locationArr = [];
            if (myResult && myResult.length > 0) {
                for (let i = 0; i < myResult.length; i++) {
                    let location = myResult[i].getValue(myColumns[0]);
                    if (location && '-1' == locationArr.indexOf(location)){
                        locationArr.push(location);
                    }
                }
            }
            log.debug('locationArr',locationArr)
            return locationArr;
        }

        /**
         * 设置库存详细信息
         * @param inventoryInfo
         * @param inventorydetail
         * @param scdLineId
         * @param itemInfo
         */
        const setBatchInfo = (inventoryInfo, inventorydetail,scdLineId, itemInfo) => {
            if (scdLineId && scdLineId.length > 0){
                for (let i = 0; i < scdLineId.length; i++){
                    if (inventoryInfo && Object.keys(inventoryInfo).length > 0) {
                        for (const scdLineIdKey in inventoryInfo) {
                            if (scdLineId[i] == scdLineIdKey){
                                let batchData = inventoryInfo[scdLineIdKey];
                                if (batchData && batchData.length > 0){
                                    let inventorySubId = 'inventoryassignment';
                                    for (let i = 0; i < batchData.length; i++){
                                        if (itemInfo == batchData[i].itemId){
                                            inventorydetail.selectNewLine({sublistId: inventorySubId});
                                            inventorydetail.setCurrentSublistValue({sublistId: inventorySubId, fieldId: 'issueinventorynumber', value: batchData[i].invId});//序号批次号
                                            inventorydetail.setCurrentSublistValue({sublistId: inventorySubId, fieldId: 'inventorystatus', value: batchData[i].status, forceSyncSourcing:true});//
                                            inventorydetail.setCurrentSublistValue({sublistId: inventorySubId, fieldId: 'quantity', value: batchData[i].quantity, forceSyncSourcing:true});//数量

                                            inventorydetail.commitLine({sublistId: inventorySubId});
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }


            // if (inventoryInfo && Object.keys(inventoryInfo).length > 0){
            //     for (const scdLineIdKey in inventoryInfo) {
            //         if (scdLineId == scdLineIdKey){
            //             let batchData = inventoryInfo[scdLineIdKey];
            //             if (batchData && batchData.length > 0){
            //                 let inventorySubId = 'inventoryassignment';
            //                 for (let i = 0; i < batchData.length; i++){
            //                     if (itemInfo == batchData[i].itemId){
            //                         inventorydetail.selectNewLine({sublistId: inventorySubId});
            //                         inventorydetail.setCurrentSublistValue({sublistId: inventorySubId, fieldId: 'issueinventorynumber', value: batchData[i].invId});//序号批次号
            //                         inventorydetail.setCurrentSublistValue({sublistId: inventorySubId, fieldId: 'inventorystatus', value: batchData[i].status, forceSyncSourcing:true});//
            //                         inventorydetail.setCurrentSublistValue({sublistId: inventorySubId, fieldId: 'quantity', value: batchData[i].quantity, forceSyncSourcing:true});//数量
            //
            //                         inventorydetail.commitLine({sublistId: inventorySubId});
            //                     }
            //                 }
            //             }
            //         }
            //     }
            // }
        }

        /**
         * 搜索IR或IT下的库存详细信息
         * @param poJson
         * @returns {{}}
         */
        const getIrInvInfo = (poJson, searchType, filterType, itLocation) => {
            let myFilters = [];
            myFilters.push(['type', 'anyof', filterType]);
            let scdLineArr = [];

            for (const poJsonKey in poJson) {
                let poJsonValue = poJson[poJsonKey];
                scdLineArr = scdLineArr.concat(poJsonValue);
            }
            if ('itemreceipt' == searchType){
                let poIdArr = Object.keys(poJson);
                myFilters.push('and');
                myFilters.push(['createdfrom', 'anyof', poIdArr]);
            }
            if ('inventorytransfer' == searchType){
                let itIdArr = Object.keys(poJson);
                myFilters.push('and');
                myFilters.push(['internalid', 'anyof', itIdArr]);
            }
            log.debug('scdLineArr',scdLineArr)


            if (itLocation && itLocation.length > 0){
                myFilters.push('and');
                myFilters.push(['location', 'anyof', itLocation]);
            }
            myFilters.push('and');
            myFilters.push(['custcol_ecm_spline', 'anyof', scdLineArr]);
            myFilters.push('and');
            myFilters.push(['mainline', 'is', 'F']);
            myFilters.push('and');
            myFilters.push(['taxline', 'is', 'F']);

            let myColumns = [];
            myColumns.push({name: "inventorynumber", join: "inventoryDetail"});
            myColumns.push({name: "item", join: "inventoryDetail"});
            myColumns.push({name: "quantity", join: "inventoryDetail"});
            myColumns.push({name: "status", join: "inventoryDetail"});
            myColumns.push({name: "expirationdate", join: "inventoryDetail"});
            myColumns.push({name: "location", join: "inventoryDetail"});
            myColumns.push({name:'custcol_ecm_spline'});
            myColumns.push({name:'internalid',join: "inventoryDetail"});

            let mySearch = search.create({type:searchType, filters:myFilters, columns:myColumns});
            let myResult = commonApi.getAllData(mySearch);
            let invJson = {};
            if (myResult && myResult.length > 0) {
                for (let i = 0; i < myResult.length; i++) {
                    let batchJson = {};
                    let invId = myResult[i].getValue(myColumns[0]);
                    let itemId = myResult[i].getValue(myColumns[1]);
                    let quantity = myResult[i].getValue(myColumns[2]);
                    let status = myResult[i].getValue(myColumns[3]);
                    let scdline = myResult[i].getValue(myColumns[6]);
                    let expirationdate = myResult[i].getValue(myColumns[4]);
                    let location = myResult[i].getValue(myColumns[5]);

                    invJson[scdline] = invJson[scdline] || [];
                    batchJson.invId = invId;
                    batchJson.itemId = itemId;
                    batchJson.quantity = quantity;
                    batchJson.status = status;
                    batchJson.expirationdate = expirationdate;
                    batchJson.location = location;
                    invJson[scdline].push(batchJson);
                }
            }
            log.debug('getIrInvInfo--', invJson)
            return invJson;
        }

        // const getItInvInfo = (itId, noPoScdlineArr) => {
        //     let myFilters = [];
        //     myFilters.push(['transaction.posting', 'is', 'T']);
        //     myFilters.push('and');
        //     myFilters.push(['transaction.mainline', 'is', 'F']);
        //     myFilters.push('and');
        //     myFilters.push(['transaction.taxline', 'is', 'F']);
        //     myFilters.push('and');
        //     myFilters.push(['transaction.quantity', 'isnotempty', '']);
        //     myFilters.push('and');
        //     myFilters.push(["formulanumeric: case when {item.inventorylocation.id} = {location.id} then 1 else 0 end","equalto","1"]);
        //     myFilters.push('and');
        //     myFilters.push(["formulanumeric: case when {item.assetaccount.id} = {transaction.account.id} then 1 else 0 end","equalto","1"]);
        //     myFilters.push('and');
        //     myFilters.push(['transaction.type', 'anyof', "InvTrnfr","ItemRcpt"]);
        //     if (noPoScdlineArr && noPoScdlineArr.length > 0){
        //         myFilters.push('and');
        //         myFilters.push(['transaction.custcol_ecm_spline', 'anyof', noPoScdlineArr]);
        //     }
        //
        //     if (itId){
        //         myFilters.push('and');
        //         myFilters.push(['transaction.internalid', 'anyof', itId]);
        //     }
        //     let myColumns = [];
        //     myColumns.push({name:'internalid'});
        //     myColumns.push({name: "item", label: "货品"})
        //     myColumns.push({name: "location", label: "地点"})
        //     myColumns.push({name: "inventorynumber", sort: search.Sort.ASC, label: " 编号"})
        //     myColumns.push({name: "status", label: "状态"})
        //     myColumns.push({name: "quantity", label: "数量"})
        //     myColumns.push({name: "custcol_ecm_spline", join: "transaction", label: "SP Line"})
        //     myColumns.push({name: "type", join: "transaction", label: "类型"});
        //     myColumns.push({name:'internalid', join:'transaction'})
        //     myColumns.push({name:'expirationdate'})
        //
        //     let mySearch = search.create({type:'inventorydetail', filters:myFilters, columns:myColumns});
        //     let myResult = commonApi.getAllData(mySearch);
        //     let invJson = {};
        //     if (myResult && myResult.length > 0){
        //         for (let i = 0; i < myResult.length; i++){
        //             let invId = myResult[i].getValue(myColumns[3]);
        //             let irId = myResult[i].getValue(myColumns[8]);
        //             let itemId = myResult[i].getValue(myColumns[1]);
        //             let quantity = myResult[i].getValue(myColumns[5]);
        //             let status = myResult[i].getValue(myColumns[4]);
        //             let scdline = myResult[i].getValue(myColumns[6]);
        //             let expirationdate = myResult[i].getValue(myColumns[9]);
        //
        //             invJson[scdline] = invJson[scdline] || {itemInfo: {}};
        //             invJson[scdline].itemInfo[itemId] = invJson[scdline].itemInfo[itemId] || {lineData:{}};
        //             invJson[scdline].itemInfo[itemId].lineData[invId] = invJson[scdline].itemInfo[itemId].lineData[invId] || {quantity:0, status:'', expirationdate:''};
        //             invJson[scdline].itemInfo[itemId].lineData[invId].quantity = Number(invJson[scdline].itemInfo[itemId].lineData[invId].quantity).add(Number(quantity))
        //
        //             invJson[scdline].itemInfo[itemId].lineData[invId].status = status;
        //             invJson[scdline].itemInfo[itemId].lineData[invId].expirationdate = expirationdate;
        //         }
        //     }
        //     log.debug('getItInvInfo',invJson)
        //     return invJson;
        // }

        const getInvInfo = (poJson, itJson) => {
            let irIdArr = [];
            let itIdArr = [];
            for (const poJsonKey in poJson) {
                irIdArr = irIdArr.concat(poJson[poJsonKey].irId);
            }
            log.debug('irIdArr',irIdArr)
            if (itJson && Object.keys(itJson).length > 0){
                let itId = Object.keys(itJson);
                itIdArr = itIdArr.concat(itId);
            }
            log.debug('itIdArr',itIdArr)

            let myFilters = [];
            myFilters.push(['transaction.posting', 'is', 'T']);
            myFilters.push('and');
            myFilters.push(['transaction.mainline', 'is', 'F']);
            myFilters.push('and');
            myFilters.push(['transaction.taxline', 'is', 'F']);
            myFilters.push('and');
            myFilters.push(['transaction.quantity', 'isnotempty', '']);
            myFilters.push('and');
            myFilters.push(["formulanumeric: case when {item.inventorylocation.id} = {location.id} then 1 else 0 end","equalto","1"]);
            myFilters.push('and');
            myFilters.push(["formulanumeric: case when {item.assetaccount.id} = {transaction.account.id} then 1 else 0 end","equalto","1"]);
            myFilters.push('and');
            myFilters.push(['transaction.type', 'anyof', "InvTrnfr","ItemRcpt"]);
            myFilters.push('and');
            myFilters.push(['transaction.custcol_ecm_spline', 'noneof', "@NONE@"]);

            if (irIdArr && irIdArr.length > 0){
                myFilters.push('and');
                myFilters.push(['transaction.internalid', 'anyof', irIdArr]);
            }
            if (itIdArr && itIdArr.length > 0){
                myFilters.push('and');
                myFilters.push(['transaction.internalid', 'anyof', itIdArr]);
            }
            let myColumns = [];
            myColumns.push({name:'internalid'});
            myColumns.push({name: "item", label: "货品"})
            myColumns.push({name: "location", label: "地点"})
            myColumns.push({name: "inventorynumber", sort: search.Sort.ASC, label: " 编号"})
            myColumns.push({name: "status", label: "状态"})
            myColumns.push({name: "quantity", label: "数量"})
            myColumns.push({name: "custcol_ecm_spline", join: "transaction", label: "SP Line"})
            myColumns.push({name: "type", join: "transaction", label: "类型"});
            myColumns.push({name:'internalid', join:'transaction'})
            myColumns.push({name:'expirationdate'})

            let mySearch = search.create({type:'inventorydetail', filters:myFilters, columns:myColumns});
            let myResult = commonApi.getAllData(mySearch);
            let invJson = {};
            if (myResult && myResult.length > 0){
                for (let i = 0; i < myResult.length; i++){
                    let invId = myResult[i].getValue(myColumns[3]);
                    let irId = myResult[i].getValue(myColumns[8]);
                    let itemId = myResult[i].getValue(myColumns[1]);
                    let quantity = myResult[i].getValue(myColumns[5]);
                    let status = myResult[i].getValue(myColumns[4]);
                    let scdline = myResult[i].getValue(myColumns[6]);
                    let expirationdate = myResult[i].getValue(myColumns[9]);
                    // invJson[irId] = invJson[irId] || {itemInfo: {}};
                    // invJson[irId].itemInfo[itemId] = invJson[irId].itemInfo[itemId] || {lineData:{}};
                    // invJson[irId].itemInfo[itemId].lineData[invId] = invJson[irId].itemInfo[itemId].lineData[invId] || {quantity:0, status:'', expirationdate:''};
                    // invJson[irId].itemInfo[itemId].lineData[invId].quantity = Number(invJson[irId].itemInfo[itemId].lineData[invId].quantity).add(Number(quantity))
                    //
                    // invJson[irId].itemInfo[itemId].lineData[invId].status = status;
                    // invJson[irId].itemInfo[itemId].lineData[invId].expirationdate = expirationdate;

                    invJson[scdline] = invJson[scdline] || {itemInfo: {}};
                    invJson[scdline].itemInfo[itemId] = invJson[scdline].itemInfo[itemId] || {lineData:{}};
                    invJson[scdline].itemInfo[itemId].lineData[invId] = invJson[scdline].itemInfo[itemId].lineData[invId] || {quantity:0, status:'', expirationdate:''};
                    invJson[scdline].itemInfo[itemId].lineData[invId].quantity = Number(invJson[scdline].itemInfo[itemId].lineData[invId].quantity).add(Number(quantity))

                    invJson[scdline].itemInfo[itemId].lineData[invId].status = status;
                    invJson[scdline].itemInfo[itemId].lineData[invId].expirationdate = expirationdate;
                }
            }
            log.debug('invJson',invJson)
            return invJson;
        }

        // const getIrInfo = (poJson) => {
        //     let irIdArr = [];
        //     for (const poRecKey in poJson) {
        //         let poRec = record.load({type:'purchaseorder', id:poRecKey});
        //         let lineCount = poRec.getLineCount({sublistId:'links'});
        //         if (lineCount > 0){
        //             for (let i = 0; i < lineCount; i++){
        //                 let linkurl = poRec.getSublistValue({sublistId:'links', fieldId:'linkurl', line:i});
        //                 if ('/app/accounting/transactions/itemrcpt.nl?whence=' == linkurl){
        //                     let irId = poRec.getSublistValue({sublistId:'links', fieldId:'id', line:i});
        //                     if (irId){
        //                         irIdArr.push(irId);
        //                     }
        //                 }
        //             }
        //         }
        //         log.debug('irIdArr',irIdArr)
        //         poJson[poRecKey].irId = irIdArr;
        //     }
        //     log.debug('getIrInfo',poJson)
        //     return poJson;
        // }


        const createIf = (params, response) => {
            let spData = getSpData(params.objRecId);
            if (spData && Object.keys(spData).length > 0){
                for (const spDataKey in spData) {
                    try {
                        let ifId = '';
                        let ifRec = record.transform({fromType:'salesorder', fromId:spDataKey, toType:'itemfulfillment', isDynamic:true});
                        let spDataValue = spData[spDataKey];

                        ifRec.setText({fieldId:'trandate', text:spDataValue.shipdate});  // TODO
                        // ifRec.setText({fieldId:'trandate', text:'3/13/2023'});

                        if (spDataValue && Object.keys(spDataValue).length > 0){
                            let lineCount = ifRec.getLineCount({sublistId:'item'});
                            if (lineCount > 0){
                                for (let i = 0; i < lineCount; i++){
                                    ifRec.selectLine({sublistId: 'item', line:i});
                                    let itemInfo = ifRec.getCurrentSublistValue({sublistId:'item', fieldId:'item'});
                                    let itemInfoJson = spDataValue.itemInfo;
                                    for (const itemInfoJsonKey in itemInfoJson) {
                                        let itemInfoValue = itemInfoJson[itemInfoJsonKey];
                                        if (itemInfo == itemInfoJsonKey){
                                            ifRec.setCurrentSublistValue({sublistId:'item', fieldId:'item', value:itemInfoJsonKey});
                                            ifRec.setCurrentSublistValue({sublistId:'item', fieldId:'location', value:itemInfoValue.location});
                                            ifRec.setCurrentSublistValue({sublistId:'item', fieldId:'quantity', value:itemInfoValue.spqty});

                                            let inventorydetail = ifRec.getCurrentSublistSubrecord({
                                                sublistId: 'item',
                                                fieldId: 'inventorydetail'
                                            });

                                            let inventorySubId = 'inventoryassignment';

                                            let batchData = itemInfoValue.lineData;

                                            if (batchData && Object.keys(batchData).length > 0){

                                                for (const batchDataKey in batchData) {
                                                    let bachDataValue = batchData[batchDataKey];
                                                    inventorydetail.selectNewLine({sublistId: inventorySubId});
                                                    inventorydetail.setCurrentSublistValue({sublistId: inventorySubId, fieldId: 'issueinventorynumber', value: batchDataKey});//序号批次号
                                                    inventorydetail.setCurrentSublistValue({sublistId: inventorySubId, fieldId: 'inventorystatus', value: bachDataValue.status, forceSyncSourcing:true});//
                                                    inventorydetail.setCurrentSublistValue({sublistId: inventorySubId, fieldId: 'quantity', value: bachDataValue.quantity, forceSyncSourcing:true});//数量

                                                    inventorydetail.commitLine({sublistId: inventorySubId});
                                                }
                                            }
                                            ifRec.commitLine({sublistId: 'item'});
                                        }
                                    }
                                    // for (const itemInfoKey in spDataValue) {
                                    //
                                    //     let itemInfoValue = spDataValue[itemInfoKey];
                                    //     if (itemInfo == itemInfoKey) {
                                    //         ifRec.setCurrentSublistValue({sublistId:'item', fieldId:'item', value:itemInfoKey});
                                    //         ifRec.setCurrentSublistValue({sublistId:'item', fieldId:'location', value:itemInfoValue.location});
                                    //         ifRec.setCurrentSublistValue({sublistId:'item', fieldId:'quantity', value:itemInfoValue.spqty});
                                    //
                                    //         log.debug('quty',itemInfoValue.spqty)
                                    //         let inventorydetail = ifRec.getCurrentSublistSubrecord({
                                    //             sublistId: 'item',
                                    //             fieldId: 'inventorydetail'
                                    //         });
                                    //
                                    //         let inventorySubId = 'inventoryassignment';
                                    //
                                    //         let batchData = itemInfoValue.lineData;
                                    //         log.debug('batchData',batchData)
                                    //
                                    //         if (batchData && Object.keys(batchData).length > 0){
                                    //
                                    //             for (const batchDataKey in batchData) {
                                    //                 let bachDataValue = batchData[batchDataKey];
                                    //                 log.debug('bachDataValue', {bachDataValue:bachDataValue,itemInfoKey:itemInfoKey })
                                    //                 inventorydetail.selectNewLine({sublistId: inventorySubId});
                                    //                 inventorydetail.setCurrentSublistValue({sublistId: inventorySubId, fieldId: 'issueinventorynumber', value: batchDataKey});//序号批次号
                                    //                 inventorydetail.setCurrentSublistValue({sublistId: inventorySubId, fieldId: 'inventorystatus', value: bachDataValue.status, forceSyncSourcing:true});//
                                    //                 inventorydetail.setCurrentSublistValue({sublistId: inventorySubId, fieldId: 'quantity', value: bachDataValue.quantity, forceSyncSourcing:true});//数量
                                    //
                                    //                 inventorydetail.commitLine({sublistId: inventorySubId});
                                    //             }
                                    //         }
                                    //         ifRec.commitLine({sublistId: 'item'});
                                    //     }
                                    // }
                                }
                            }
                        }
                        ifId = ifRec.save({enableSourcing:true, ignoreMandatoryFields:true});
                        if (ifId){
                            let spRec = record.load({type:params.objRecType, id:params.objRecId});
                            spRec.setValue({fieldId:'custrecord_sp_createsoif_erromsg', value:''});
                            let lineCount = spRec.getLineCount({sublistId:SP_SUBLIST_ID});
                            if (lineCount > 0){
                                for (let i = 0; i < lineCount; i++){
                                    let soNo = spRec.getSublistValue({sublistId:SP_SUBLIST_ID, fieldId:'custrecord_scdline_sono1', line:i});
                                    if (soNo == spDataKey){
                                        spRec.setSublistValue({sublistId:SP_SUBLIST_ID, fieldId:'custrecord_scdline_soif1', value:ifId, line:i});
                                    }
                                }
                            }
                            spRec.save({enableSourcing:true, ignoreMandatoryFields:true});
                        }
                    }catch (iferror){
                        let errorMsg = '创建IF单失败，soid:'+ spDataKey + '失败原因：' + iferror.message;
                        let spRec = record.load({type:params.objRecType, id:params.objRecId});
                        spRec.setValue({fieldId:'custrecord_sp_createsoif_erromsg', value:errorMsg});
                        spRec.save({enableSourcing:true, ignoreMandatoryFields:true});
                        response.write("<script type='text/javascript'>window.opener.location.reload(); window.close();</script>");
                        log.debug('生成IF单errror--->'+spDataKey,iferror);
                    }
                }
                response.write("<script type='text/javascript'>window.opener.location.reload(); window.close();</script>");
            }
        }


        /**
         * 查询sp及其相关记录数据
         * @param spId
         * @returns {{}}
         */
        function getSpData1(spId){
            let myFilters = [];
            myFilters.push(['custrecord_scdline_sp.internalid', 'anyof', spId]);
            myFilters.push('and');
            myFilters.push(['custrecord_scdline_sono1', 'noneof', '@NONE@']);
            myFilters.push('and');
            myFilters.push(['custrecord_scdline_soif1', 'anyof', '@NONE@']);
            let myColumns = [];
            myColumns.push({name:'custrecord_sp_deliverycomdate', join:'CUSTRECORD_SCDLINE_SP', label:'Shipping Date'});
            myColumns.push({name:'internalid', join: 'CUSTRECORD_SCDLINE_SP', label: 'SP 内部 ID'});
            myColumns.push({name:'custrecord_scdline_item', label: 'Item'});
            myColumns.push({name:'custrecord_scdline_qty', label: 'Qty'});
            myColumns.push({name:'custrecord_sp_location', join: 'CUSTRECORD_SCDLINE_SP', label: 'Issuing Location'});
            myColumns.push({name:'custrecord_id_seriallot', join: 'CUSTRECORD_ID_SPLINE', label: 'SERIAL/LOT NUMBER'});
            myColumns.push({name:'custrecord_id_status', join: 'CUSTRECORD_ID_SPLINE', label: 'Status'});
            myColumns.push({name:'custrecord_id_quantity', join: 'CUSTRECORD_ID_SPLINE', label: 'Quantity'});
            myColumns.push({name:'custrecord_scdline_sono1', sort:'ASC', label: 'SO NO1'});
            myColumns.push({name:'custrecord_scdline_purchaseorder', label: 'PO'});
            myColumns.push({name:'internalid', label: 'Scd Line Id'});

            let mySearch = search.create({
                type:'customrecord_ecm_scd_line',
                filters:myFilters,
                columns:myColumns
            });
            let spData = {};

            let myResult = mySearch.run().getRange({start:0, end:1000});
            if (myResult && myResult.length > 0){
                for (let i = 0; i < myResult.length; i++){
                    let shipdate = myResult[i].getValue(myColumns[0]) || '';
                    let item = myResult[i].getValue(myColumns[2]) || '';
                    let spqty = myResult[i].getValue(myColumns[3]) || '';
                    let location = myResult[i].getValue(myColumns[4]) || '';
                    let seriallot = myResult[i].getValue(myColumns[5]) || '';
                    let status = myResult[i].getValue(myColumns[6]) || '';
                    let quantity = myResult[i].getValue(myColumns[7]) || '';
                    let soNo = myResult[i].getValue(myColumns[8]) || '';
                    let poNo = myResult[i].getValue(myColumns[9]) || '';
                    let scdLineId = myResult[i].getValue(myColumns[10]) || '';

                    spData[soNo] = spData[soNo] || {itemInfo:{}, shipdate};
                    spData[soNo].shipdate = shipdate;

                    spData[soNo].itemInfo[item] = spData[soNo].itemInfo[item] || {lineData:{}, location:'', spqty:0, poNo:'', scdLineId:''};
                    spData[soNo].itemInfo[item].location = location;
                    spData[soNo].itemInfo[item].spqty = Number(spqty);
                    spData[soNo].itemInfo[item].poNo = poNo;
                    spData[soNo].itemInfo[item].scdLineId = scdLineId;

                    spData[soNo].itemInfo[item].lineData[seriallot] = spData[soNo].itemInfo[item].lineData[seriallot] || {quantity:0, status:''};
                    spData[soNo].itemInfo[item].lineData[seriallot].quantity = Number(spData[soNo].itemInfo[item].lineData[seriallot].quantity).add(Number(quantity));
                    spData[soNo].itemInfo[item].lineData[seriallot].status = status;
                }
            }
            log.debug('getSpData',spData)
            return spData;
        }

        /**
         * 查询sp及其相关记录数据
         * @param spId
         * @returns {{}}
         */
        function getSpData(spId){
            let myFilters = [];
            myFilters.push(['custrecord_scdline_sp.internalid', 'anyof', spId]);
            myFilters.push('and');
            myFilters.push(['custrecord_scdline_sono1', 'noneof', '@NONE@']);
            myFilters.push('and');
            myFilters.push(['custrecord_scdline_soif1', 'anyof', '@NONE@']);
            let myColumns = [];
            myColumns.push({name:'custrecord_sp_deliverycomdate', join:'CUSTRECORD_SCDLINE_SP', label:'Shipping Date'});
            myColumns.push({name:'internalid', join: 'CUSTRECORD_SCDLINE_SP', label: 'SP 内部 ID'});
            myColumns.push({name:'custrecord_scdline_item', label: 'Item'});
            myColumns.push({name:'custrecord_scdline_qty', label: 'Qty'});
            myColumns.push({name:'custrecord_sp_location', join: 'CUSTRECORD_SCDLINE_SP', label: 'Issuing Location'});
            myColumns.push({name:'custrecord_id_seriallot', join: 'CUSTRECORD_ID_SPLINE', label: 'SERIAL/LOT NUMBER'});
            myColumns.push({name:'custrecord_id_status', join: 'CUSTRECORD_ID_SPLINE', label: 'Status'});
            myColumns.push({name:'custrecord_id_quantity', join: 'CUSTRECORD_ID_SPLINE', label: 'Quantity'});
            myColumns.push({name:'custrecord_scdline_sono1', sort:'ASC', label: 'SO NO1'});
            myColumns.push({name:'custrecord_scdline_purchaseorder', label: 'PO'});
            myColumns.push({name:'internalid', label: 'Scd Line Id'});

            let mySearch = search.create({
                type:'customrecord_ecm_scd_line',
                filters:myFilters,
                columns:myColumns
            });
            let spData = {};

            let myResult = mySearch.run().getRange({start:0, end:1000});
            if (myResult && myResult.length > 0){
                for (let i = 0; i < myResult.length; i++){
                    let shipdate = myResult[i].getValue(myColumns[0]) || '';
                    let item = myResult[i].getValue(myColumns[2]) || '';
                    let spqty = myResult[i].getValue(myColumns[3]) || '';
                    let location = myResult[i].getValue(myColumns[4]) || '';
                    let seriallot = myResult[i].getValue(myColumns[5]) || '';
                    let status = myResult[i].getValue(myColumns[6]) || '';
                    let quantity = myResult[i].getValue(myColumns[7]) || '';
                    let soNo = myResult[i].getValue(myColumns[8]) || '';
                    let poNo = myResult[i].getValue(myColumns[9]) || '';
                    let scdLineId = myResult[i].getValue(myColumns[10]) || '';

                    spData[soNo] = spData[soNo] || {itemInfo:{}, shipdate};
                    spData[soNo].shipdate = shipdate;

                    spData[soNo].itemInfo[item] = spData[soNo].itemInfo[item] || {location:'', spqty:0, poNo:'', scdLineId:[]};
                    spData[soNo].itemInfo[item].location = location;
                    spData[soNo].itemInfo[item].spqty = Number(spData[soNo].itemInfo[item].spqty).add(Number(spqty));
                    spData[soNo].itemInfo[item].poNo = poNo;
                    spData[soNo].itemInfo[item].scdLineId.push(scdLineId);
                }
            }
            log.debug('getSpData',spData)
            return spData;
        }

        return {onRequest}

    });
