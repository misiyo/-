/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 */
define(['N/ui/dialog'],

    (dialog) => {
        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */

        const beforeLoad = (scriptContext) => {
            if (scriptContext.type == 'view') {
                var form = scriptContext.form
                var buttonClick = ''
                buttonClick += "try{"
                buttonClick += "alert('你好');"
                buttonClick += "} catch (e) {"
                buttonClick += "alert('ERroR!');"
                buttonClick += "}"
                buttonClick += "console.log();"
                buttonClick += "return false;"
                buttonClick += "console.log();"
                form.addButton({
                    id: 'custpage_buttonid',
                    label: 'Hello',
                    functionName: buttonClick
                })
            }
        }



        /**
         * Defines the function definition that is executed before record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const beforeSubmit = (scriptContext) => {
            var nowRecord = scriptContext.newRecord
            var nowValue = nowRecord.getValue({ fieldId: 'custrecord48' })
            if (nowValue == '') {
                dialog.alert({ title: '提示：', message: '请选择性别' })
                // error.create()
            }
        }

        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {

        }

        return { beforeLoad, beforeSubmit }

    });
