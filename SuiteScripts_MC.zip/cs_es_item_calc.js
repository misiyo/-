/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */
define(['N/currency'],

    function (currency) {

        /**
         * Function to be executed after page is initialized.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.mode - The mode in which the record is being accessed (create, copy, or edit)
         *
         * @since 2015.2
         */
        function pageInit(scriptContext) {

        }

        /**
         * Function to be executed when field is changed.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         * @param {string} scriptContext.fieldId - Field name
         * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
         * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
         *
         * @since 2015.2
         */
        function fieldChanged(scriptContext) {
            var form = scriptContext.currentRecord
            var fieldId = scriptContext.fieldId
            var sublistId = scriptContext.sublistId
            if (sublistId == 'item' && ['custcol_ecm_oceanfreight', 'custcol_ecm_other_cost', 'custcol_ecm_profit'].includes(fieldId)) {
                var reference_price = form.getCurrentSublistValue({ sublistId: 'item', fieldId: 'custcol_ecm_ref_sellingprice1' }) || 0
                // console.log('reference_price', reference_price);

                calc(form, reference_price)

            } else if (['custbody_ecm_prepayment_ratio', 'custbody_ecm_balance_termsdays', 'custbody_ecm_balance_prepay_method'].includes(fieldId)) {
                var count = form.getLineCount({ sublistId: 'item' });
                var prepayment_ratio = Number(form.getValue('custbody_ecm_prepayment_ratio')) || 0;
                // console.log('prepayment_ratio', prepayment_ratio);
                var balance_termsdays = Number(form.getValue('custbody_ecm_balance_termsdays')) || 0;
                // console.log('balance_termsdays', balance_termsdays);
                var balance_prepay_method = String(form.getValue('custbody_ecm_balance_prepay_method'));
                // console.log('balance_prepay_method', balance_prepay_method);
                for (var i = 0; i < count; i++) {
                    form.selectLine({ sublistId: 'item', line: i });
                    var reference_price = form.getCurrentSublistValue({ sublistId: 'item', fieldId: 'custcol_ecm_ref_sellingprice1' }) || 0;
                    // console.log('reference_price+' + i + ':', reference_price);

                    var oceanfreight = form.getCurrentSublistValue({ sublistId: 'item', fieldId: 'custcol_ecm_oceanfreight' }) || 0;
                    // console.log('oceanfreight+' + i + ':', oceanfreight);

                    var other_cost = form.getCurrentSublistValue({ sublistId: 'item', fieldId: 'custcol_ecm_other_cost' }) || 0;
                    // console.log('other_cost+' + i + ':', other_cost);

                    var profit = form.getCurrentSublistValue({ sublistId: 'item', fieldId: 'custcol_ecm_profit' }) || 0;
                    // console.log('profit+' + i + ':', profit);

                    var financial = Number((reference_price + oceanfreight + other_cost + profit) * ((100 - prepayment_ratio) / 100) * 0.0002 * balance_termsdays).toFixedNew(2);
                    // console.log('financial+' + i + ':', financial);

                    form.setCurrentSublistValue({ sublistId: 'item', fieldId: 'custcol_ecm_payment_term_cost', value: financial, ignoreFieldChange: true });

                    var sino = (reference_price + oceanfreight + other_cost + profit + Number(financial || 0)) * ((100 - prepayment_ratio) / 100);
                    var sinosure;
                    if (['', null, undefined].includes(balance_termsdays) || !balance_prepay_method) {
                        form.setCurrentSublistValue({ sublistId: 'item', fieldId: 'custcol_ecm_sinosurecost', value: 0, ignoreFieldChange: true });
                    } else {
                        if (['3', '4'].includes(balance_prepay_method)) {
                            if (balance_termsdays < 91) {
                                sinosure = Number(sino * 0.004).toFixedNew(2)
                            } else if (balance_termsdays > 90 && balance_termsdays < 121) {
                                sinosure = Number(sino * 0.009).toFixedNew(2)
                            } else {
                                sinosure = Number(sino * 0.03).toFixedNew(2)
                            }
                        } else {
                            if (balance_termsdays < 91) {
                                sinosure = Number(sino * 0.0052).toFixedNew(2)
                            } else if (balance_termsdays > 90 && balance_termsdays < 121) {
                                sinosure = Number(sino * 0.024).toFixedNew(2)
                            } else {
                                sinosure = Number(sino * 0.03).toFixedNew(2)
                            }
                        }
                        form.setCurrentSublistValue({ sublistId: 'item', fieldId: 'custcol_ecm_sinosurecost', value: sinosure, ignoreFieldChange: true });
                    }

                    var bot_gmr = (reference_price + oceanfreight + other_cost + profit + Number(financial || 0) + Number(sinosure || 0))
                    // console.log('bot_gmr' + i + ':', bot_gmr);
                    var gmr
                    if (bot_gmr) {
                        gmr = Number(profit * 100 / bot_gmr).toFixedNew(2)
                        // console.log('gmr' + i + ':', gmr);
                        form.setCurrentSublistValue({ sublistId: 'item', fieldId: 'custcol_ecm_gmr', value: gmr });
                    } else {
                        form.setCurrentSublistValue({ sublistId: 'item', fieldId: 'custcol_ecm_gmr', value: 0 });
                    }

                    var unit_price = Number(reference_price + oceanfreight + other_cost + profit + Number(sinosure || 0) + Number(financial || 0)).toFixedNew(8)
                    form.setCurrentSublistValue({ sublistId: 'item', fieldId: 'custcol_ecm_price_packunit', value: unit_price, ignoreFieldChange: true })

                    var weightPerPac = form.getCurrentSublistValue({ sublistId: 'item', fieldId: 'custcol_ecm_case_package_kg' }) //单件装重量
                    var rate = Number(unit_price).mul(Number(weightPerPac || 1)).toFixedNew(8);
                    form.setCurrentSublistValue({ sublistId: 'item', fieldId: 'rate', value: rate, ignoreFieldChange: false });
                    form.commitLine({ sublistId: 'item' });
                }
            } else if (sublistId == 'item' && fieldId == 'custcol_ecm_price_book') {
                var mainCuy = form.getText({ fieldId: 'currency' })
                var timer = setInterval(function () {
                    var lineCuy = form.getCurrentSublistValue({ sublistId: 'item', fieldId: 'custcol_ecm_currency' })//行币种
                    if (lineCuy) {
                        clearInterval(timer);
                        var reference_price = form.getCurrentSublistValue({ sublistId: 'item', fieldId: 'custcol_ecm_reference_price' }) || 0
                        console.log('reference_price', reference_price);
                        var erate = 1;//汇率
                        if (lineCuy != mainCuy) {
                            erate = currency.exchangeRate({ source: lineCuy, target: mainCuy });
                        }
                        console.log('erate', erate);
                        reference_price = reference_price * erate
                        form.setCurrentSublistValue({ sublistId: 'item', fieldId: 'custcol_ecm_ref_sellingprice1', value: reference_price });

                        calc(form, reference_price)
                    }
                }, 500)
            } else if (['custcol_ecm_commissionunitprice', 'custcol_ecm_qty_packunit'].includes(fieldId)) {
                var commissionunitprice = form.getCurrentSublistValue({ sublistId: 'item', fieldId: 'custcol_ecm_commissionunitprice' }) || 0
                var packunit = form.getCurrentSublistValue({ sublistId: 'item', fieldId: 'custcol_ecm_qty_packunit' }) || 0
                var totalcommission = commissionunitprice * packunit
                form.setCurrentSublistValue({ sublistId: 'item', fieldId: 'custcol_ecm_totalcommission', value: totalcommission });
            }
        }

        function calc(form, reference_price) {
            var oceanfreight = form.getCurrentSublistValue({ sublistId: 'item', fieldId: 'custcol_ecm_oceanfreight' }) || 0
            // console.log('oceanfreight', oceanfreight);

            var other_cost = form.getCurrentSublistValue({ sublistId: 'item', fieldId: 'custcol_ecm_other_cost' }) || 0
            // console.log('other_cost', other_cost);

            var profit = form.getCurrentSublistValue({ sublistId: 'item', fieldId: 'custcol_ecm_profit' }) || 0
            // console.log('profit', profit);

            var prepayment_ratio = Number(form.getValue('custbody_ecm_prepayment_ratio')) || 0;
            // console.log('prepayment_ratio', prepayment_ratio);

            var balance_termsdays = Number(form.getValue('custbody_ecm_balance_termsdays')) || 0;
            // console.log('balance_termsdays', balance_termsdays);

            var financial = ((reference_price + oceanfreight + other_cost + profit) * ((100 - prepayment_ratio) / 100) * 0.0002 * balance_termsdays).toFixedNew(2);
            // console.log('financial', financial);

            form.setCurrentSublistValue({ sublistId: 'item', fieldId: 'custcol_ecm_payment_term_cost', value: financial, ignoreFieldChange: true });

            var balance_prepay_method = form.getValue('custbody_ecm_balance_prepay_method');
            // console.log('balance_prepay_method', balance_prepay_method);

            var sino = (reference_price + oceanfreight + other_cost + profit + Number(financial || 0)) * ((100 - prepayment_ratio) / 100);
            // console.log('sino', sino);
            var sinosure;
            if (['', null, undefined].includes(balance_termsdays) || !balance_prepay_method) {
                form.setCurrentSublistValue({ sublistId: 'item', fieldId: 'custcol_ecm_sinosurecost', value: 0, ignoreFieldChange: true });
            } else {
                if (['3', '4'].includes(balance_prepay_method)) {
                    if (balance_termsdays <= 90) {
                        sinosure = Number(sino * 0.004).toFixedNew(2)
                    } else if (balance_termsdays > 90 && balance_termsdays <= 120) {
                        sinosure = Number(sino * 0.009).toFixedNew(2)
                    } else {
                        sinosure = Number(sino * 0.03).toFixedNew(2)
                    }
                } else {
                    if (balance_termsdays <= 90) {
                        sinosure = Number(sino * 0.0052).toFixedNew(2)
                    } else if (balance_termsdays > 90 && balance_termsdays <= 120) {
                        sinosure = Number(sino * 0.024).toFixedNew(2)
                    } else {
                        sinosure = Number(sino * 0.03).toFixedNew(2)
                    }
                }
                form.setCurrentSublistValue({ sublistId: 'item', fieldId: 'custcol_ecm_sinosurecost', value: sinosure, ignoreFieldChange: true });
            }

            // console.log('bugreference_price', reference_price);
            // console.log('bugoceanfreight', oceanfreight);
            // console.log('bugother_cost', other_cost);
            // console.log('bugprofit', profit);
            // console.log('bugfinancial', Number(financial || 0));
            // console.log('bugsinosure', Number(sinosure || 0));
            var bot_gmr = (reference_price + oceanfreight + other_cost + profit + Number(financial || 0) + Number(sinosure || 0))
            // console.log('bot_gmr', bot_gmr);
            var gmr
            if (bot_gmr) {
                gmr = Number(profit * 100 / bot_gmr).toFixedNew(2)
                // console.log('gmr', gmr);
                form.setCurrentSublistValue({ sublistId: 'item', fieldId: 'custcol_ecm_gmr', value: gmr  });
            } else {
                form.setCurrentSublistValue({ sublistId: 'item', fieldId: 'custcol_ecm_gmr', value: 0 });
            }

            var unit_price = Number(reference_price + oceanfreight + other_cost + profit + Number(sinosure || 0) + Number(financial || 0)).toFixedNew(8)
            form.setCurrentSublistValue({ sublistId: 'item', fieldId: 'custcol_ecm_price_packunit', value: unit_price, ignoreFieldChange: true })

            var weightPerPac = form.getCurrentSublistValue({ sublistId: 'item', fieldId: 'custcol_ecm_case_package_kg' }) //单件装重量
            var rate = Number(unit_price).mul(Number(weightPerPac || 1)).toFixedNew(8);
            form.setCurrentSublistValue({ sublistId: 'item', fieldId: 'rate', value: rate, ignoreFieldChange: false });
        }

        /**
         * Function to be executed when field is slaved.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         * @param {string} scriptContext.fieldId - Field name
         *
         * @since 2015.2
         */
        function postSourcing(scriptContext) {

        }

        /**
         * Function to be executed after sublist is inserted, removed, or edited.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         *
         * @since 2015.2
         */
        function sublistChanged(scriptContext) {

        }

        /**
         * Function to be executed after line is selected.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         *
         * @since 2015.2
         */
        function lineInit(scriptContext) {

        }

        /**
         * Validation function to be executed when field is changed.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         * @param {string} scriptContext.fieldId - Field name
         * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
         * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
         *
         * @returns {boolean} Return true if field is valid
         *
         * @since 2015.2
         */
        function validateField(scriptContext) {

        }

        /**
         * Validation function to be executed when sublist line is committed.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         *
         * @returns {boolean} Return true if sublist line is valid
         *
         * @since 2015.2
         */
        function validateLine(scriptContext) {

        }

        /**
         * Validation function to be executed when sublist line is inserted.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         *
         * @returns {boolean} Return true if sublist line is valid
         *
         * @since 2015.2
         */
        function validateInsert(scriptContext) {

        }

        /**
         * Validation function to be executed when record is deleted.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         *
         * @returns {boolean} Return true if sublist line is valid
         *
         * @since 2015.2
         */
        function validateDelete(scriptContext) {

        }

        /**
         * Validation function to be executed when record is saved.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @returns {boolean} Return true if record is valid
         *
         * @since 2015.2
         */
        function saveRecord(scriptContext) {

        }

        return {
            // pageInit: pageInit,
            fieldChanged: fieldChanged,
            // postSourcing: postSourcing,
            // sublistChanged: sublistChanged,
            // lineInit: lineInit,
            // validateField: validateField,
            // validateLine: validateLine,
            // validateInsert: validateInsert,
            // validateDelete: validateDelete,
            // saveRecord: saveRecord
        };

    });
