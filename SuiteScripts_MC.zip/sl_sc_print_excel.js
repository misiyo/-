/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 */
define(['N/encode', 'N/record', 'N/render', 'N/file', 'N/search', 'SuiteScripts/tools/common_api.js'],
    /**
 * @param{encode} encode
 * @param{file} file
 * @param{record} record
 * @param{render} render
 * @param{search} search
 */
    (encode, record, render, file, search, commonApi) => {
        /**
         * Defines the Suitelet script trigger point.
         * @param {Object} scriptContext
         * @param {ServerRequest} scriptContext.request - Incoming request
         * @param {ServerResponse} scriptContext.response - Suitelet response
         * @since 2015.2
         */
        const onRequest = (scriptContext) => {
            let request = scriptContext.request;
            let response = scriptContext.response;
            if (request.method == 'GET') {
                let plId = request.parameters.rec_id;
                let plType = request.parameters.type;
                let excel_type = request.parameters.excel_type
                let xmlStr = getXml(plId, plType, excel_type);
                //写文件
                response.writeFile(xmlStr);
            }
        }

        function getXml(plId, plType, excel_type) {
            let customerPrintFormat = {
                Sale_Contract_Excel: 'SuiteScripts/SuiteScripts_MC/自营贸易-跨境-通用.txt',
                Sale_Contract_Netherlands: 'SuiteScripts/SuiteScripts_MC/仓库直发-荷兰.txt',
                Sale_Contract_Germany: 'SuiteScripts/SuiteScripts_MC/仓库直发-德国.txt',
                Sale_Contract_America: 'SuiteScripts/SuiteScripts_MC/仓库直发-美国.txt',
                Sale_Contract_Pl: 'SuiteScripts/SuiteScripts_MC/PI-通用.txt',
                Sale_Contract_Vip: 'SuiteScripts/SuiteScripts_MC/网站会员服务合同（海外）.txt'
            };

            let plObj = record.load({
                type: 'salesorder',
                id: plId
            });
            let xlsName = plObj.getValue('tranid');
            // let template = plObj.getValue('custrecord_amg_pl_download'); //文件类型

            let printFormat;
            if (plType == 'pi') {
                printFormat = customerPrintFormat.Sale_Contract_Pl;
            } else {
                if (excel_type == 1) {
                    printFormat = customerPrintFormat.Sale_Contract_Excel;
                } else if (excel_type == 2) {
                    printFormat = customerPrintFormat.Sale_Contract_Netherlands;
                } else if (excel_type == 3) {
                    printFormat = customerPrintFormat.Sale_Contract_Germany;
                } else if (excel_type == 4) {
                    printFormat = customerPrintFormat.Sale_Contract_America;
                } else if (excel_type == 7) {
                    printFormat = customerPrintFormat.Sale_Contract_Vip
                }
            }
            let tempFile = file.load({
                id: printFormat
            });

            let t_render = render.create();
            //模板的内容
            t_render.templateContent = tempFile.getContents();

            let allData = getData(plId, plType, excel_type);

            t_render.addCustomDataSource({
                alias: 'data',
                format: render.DataSource.OBJECT,
                data: allData
            });

            let excel_str = t_render.renderAsString();

            //将字符串转换为另一种类型的编码
            let fstr = encode.convert({
                string: excel_str,
                inputEncoding: encode.Encoding.UTF_8,
                outputEncoding: encode.Encoding.BASE_64
            });

            let name = xlsName + ' Sales Order' + '.xls';

            let excel = file.create({
                name: name,
                fileType: file.Type.EXCEL,
                //folder : 369,
                contents: fstr
            });
            return excel;
        }

        function getData(plId, plType, excel_type) {
            let data = {};

            let filters = [];

            filters.push(['type', 'anyof', "SalesOrd"]);
            filters.push('and');
            filters.push(['internalid', 'anyof', plId]);
            filters.push('and');
            filters.push(["mainline", "is", "F"],);
            filters.push('and');
            filters.push(["taxline", "is", "F"]);
            filters.push('and');
            filters.push(['item', "noneof", "@NONE@"]);

            let columns = [];

            columns = getSalesOrderColumns(columns)

            let mySearch = search.create({
                type: 'salesorder',
                filters: filters,
                columns: columns
            });
            let result = commonApi.getAllData(mySearch);
            log.debug('res', result);
            if (result) {
                data = getSalesOrderResult(result, columns, plId, plType, excel_type);
            }
            log.debug('data', JSON.stringify(data));
            return data;
        }

        function getSalesOrderColumns(columns) {
            columns.push(search.createColumn({
                name: 'custrecord_ecm_subname_en',
                join: 'Subsidiary'
            }));
            columns.push(search.createColumn({
                name: 'tranid'
            }));
            columns.push(search.createColumn({
                name: 'otherrefnum'
            }));
            columns.push(search.createColumn({
                name: 'custbody_ecm_signaddress_en'
            }));
            columns.push(search.createColumn({
                name: 'trandate'
            }));
            columns.push(search.createColumn({
                name: 'custrecord_ecm_subaddress_en',
                join: 'Subsidiary'
            }));
            columns.push(search.createColumn({
                name: 'custrecord37',
                join: 'Subsidiary'
            }));
            columns.push(search.createColumn({
                name: 'fax',
                join: 'Subsidiary'
            }));
            columns.push(search.createColumn({
                name: 'entity'
            }));
            columns.push(search.createColumn({
                name: 'phone',
                join: 'customer'
            }));
            columns.push(search.createColumn({
                name: 'fax',
                join: 'customer'
            }));
            columns.push(search.createColumn({
                name: 'vatregnumber',
                join: 'customer'
            }));
            columns.push(search.createColumn({
                name: 'currency'
            }));
            columns.push(search.createColumn({
                name: 'custcol_ecm_productname_en',
            }));
            columns.push(search.createColumn({
                name: 'custentity_ecm_licenseno',
                join: 'customer'
            }));
            columns.push(search.createColumn({
                name: 'custitem_ecm_productname_en',
                join: 'item'
            }));
            columns.push(search.createColumn({
                name: 'custbody_shipmentdate_descrip',
            }));
            columns.push(search.createColumn({
                name: 'custbody_ecm_shipping_method',
            }));
            columns.push(search.createColumn({
                name: 'custbody_ecm_termsdisplay_en',
            }));
            columns.push(search.createColumn({
                name: 'custbody_ecm_bankinfomation'
            }));
            columns.push(search.createColumn({
                name: 'custbody_ecm_supplementary_terms',
            }));
            columns.push(search.createColumn({
                name: 'custbody_ecm_incoterm',
            }));
            columns.push(search.createColumn({
                name: 'custbody_ecm_countryof_departure',
            }));
            columns.push(search.createColumn({
                name: 'shipaddress',
            }));
            columns.push(search.createColumn({
                name: 'custitem_ecm_spec_combine_en',
                join: 'item'
            }));
            columns.push(search.createColumn({
                name: 'custitem_ecm_brand',
                join: 'item'
            }));
            columns.push(search.createColumn({
                name: 'custrecord_ecm_trade_electricseal_sign',
                join: 'subsidiary'
            }));
            columns.push(search.createColumn({
                name: 'custitem_ecm_origincountry',
                join: 'item'
            }));
            columns.push(search.createColumn({
                name: 'custcol_ecm_product_othermemo'
            }));
            columns.push(search.createColumn({
                name: 'custbody_ecm_skuspec_isdisplay'
            }));
            columns.push(search.createColumn({
                name: 'custbody_ecm_skubrand_isdisplay'
            }));
            columns.push(search.createColumn({
                name: 'custbody_ecm_skuhscode_isdisplay'
            }));
            columns.push(search.createColumn({
                name: 'custbody_isdisplay_origincountry'
            }));
            columns.push(search.createColumn({
                name: 'custbody_ecm_generate_handseal'
            }));
            columns.push(search.createColumn({
                name: 'unitstype',
                join: 'item'
            }));
            columns.push(search.createColumn({
                name: 'custcol_ecm_packageremark'
            }));
            columns.push(search.createColumn({
                name: 'custitem_ecm_case_package_kg',
                join: 'item'
            }));
            columns.push(search.createColumn({
                name: 'custitem_ecm_wgt_unit',
                join: 'item'
            }));
            columns.push(search.createColumn({
                name: 'custitem_ecm_package_remk_en',
                join: 'item'
            }));
            columns.push(search.createColumn({
                name: 'custbody_ecm_loadingport'
            }));
            columns.push(search.createColumn({
                name: 'custbody_ecm_destination_port'
            }));
            columns.push(search.createColumn({
                name: 'custbody_ecm_countryof_destination'
            }));
            columns.push(search.createColumn({
                name: 'custrecord_ecm_trade_electricseal',
                join: 'subsidiary'
            }));
            columns.push(search.createColumn({
                name: 'custbody_ecm_delivery_address'
            }));
            columns.push(search.createColumn({
                name: 'salesrep'
            }));
            columns.push(search.createColumn({
                name: 'custbody_ecm_totalamt_en',
            }));
            columns.push(search.createColumn({
                name: 'custitem_ecm_serviceperiod',
                join: 'item'
            }));
            columns.push(search.createColumn({
                name: 'custitem_ecm_servicedetail',
                join: 'item'
            }));

            return columns
        }

        function getSalesOrderResult(result, columns, plId, plType, excel_type) {
            let data = {};
            let list1 = [];
            let quantity_sum = 0;

            result.forEach((x, i) => {
                let sales_order = record.load({
                    type: 'salesorder',
                    id: plId
                })
                if (i == 0) {
                    let companyName = x.getValue(columns[0]);
                    let tranid = x.getValue(columns[1]);
                    let otherrefnum = x.getValue(columns[2]);
                    let custbody_ecm_signaddress_en = x.getValue(columns[3]);
                    let trandate = x.getValue(columns[4]);
                    let seller_address = x.getValue(columns[5]);
                    let seller_phone = x.getValue(columns[6]);
                    let seller_fax = x.getValue(columns[7]);
                    let buyer_phone = x.getValue(columns[9]);
                    let buyer_fax = x.getValue(columns[10]);
                    let vatregnumber = x.getValue(columns[11]);
                    let currency = x.getText(columns[12]);
                    let license_no = x.getValue(columns[14])
                    let shipment_time = x.getValue(columns[16]);
                    let shipping_type = x.getText(columns[17]);
                    let payment_port = x.getValue(columns[18]);
                    let bankdetail = x.getValue(columns[19]);
                    let other_message = x.getValue(columns[20]);
                    let trade_type = x.getText(columns[21]);
                    let department_country = x.getText(columns[22]);
                    let shipaddress = x.getValue(columns[23]);
                    let sign_id = x.getValue(columns[26])
                    let hasSign = x.getValue(columns[33]);
                    let department_port_v = x.getValue(columns[39]);
                    let destination_port_v = x.getValue(columns[40]);
                    let destination_country = x.getText(columns[41]);
                    let seal_id = x.getValue(columns[42])
                    let delivery_address = x.getValue(columns[43]);
                    let salesrep = x.getText(columns[44]);
                    let num_en = x.getValue(columns[45]);


                    let unittotal = sales_order.getSublistText({
                        sublistId: 'item',
                        fieldId: 'custcol_ecm_wgt_unit',
                        line: i
                    })
                    let amounttotal = sales_order.getValue('total');
                    let subtotal = sales_order.getValue('subtotal')
                    let taxtotal = sales_order.getValue('taxtotal');
                    let tax_rate = sales_order.getSublistValue({
                        sublistId: 'item',
                        fieldId: 'taxrate1',
                        line: i
                    })
                    let seller_id = sales_order.getValue('subsidiary')
                    let seller_company = record.load({
                        type: 'subsidiary',
                        id: seller_id
                    })
                    let federalidnumber = seller_company.getValue('federalidnumber')

                    let seller_person = sales_order.getValue('salesrep')
                    let seller_message, email;
                    if (seller_person) {
                        seller_message = record.load({
                            type: 'employee',
                            id: seller_person
                        })
                        email = seller_message.getValue('email')
                    }

                    let customer_id = x.getValue(columns[8])
                    let customer, buyer_address;
                    if (customer_id) {
                        let customer_message = record.load({
                            type: 'customer',
                            id: customer_id
                        })
                        customer = customer_message.getValue('custentity_ecm_nameen')
                        buyer_address = customer_message.getValue('defaultaddress')
                    }

                    let picFile, picData
                    let sign = hasSign ? sign_id : seal_id
                    let picObj = {
                        common: '------=_NextPart_01D96E26.8D57BB90\n'
                            + 'Content-Location: file:///C:/24D4AC68/file7544.files/seal\n'
                            + 'Content-Transfer-Encoding: base64\n'
                            + 'Content-Type: image/png\n\n',
                        netherlands: '------=_NextPart_01D96E29.3450DF10\n'
                            + 'Content-Location: file:///C:/7F39F450/file4528.files/seal\n'
                            + 'Content-Transfer-Encoding: base64\n'
                            + 'Content-Type: image/png\n\n',
                        germany: '------=_NextPart_01D96E28.035AA680\n'
                            + 'Content-Location: file:///C:/7F3581DD/file3085.files/seal\n'
                            + 'Content-Transfer-Encoding: base64\n'
                            + 'Content-Type: image/png\n\n',
                        america: '------=_NextPart_01D96E2A.26B024A0\n'
                            + 'Content-Location: file:///C:/7F397CBD/file3917.files/seal\n'
                            + 'Content-Transfer-Encoding: base64\n'
                            + 'Content-Type: image/png\n\n',
                        pi: '------=_NextPart_01D96E1B.0D867BF0\n'
                            + 'Content-Location: file:///C:/E6F58D31/file2145.files/seal\n'
                            + 'Content-Transfer-Encoding: base64\n'
                            + 'Content-Type: image/png\n\n',
                        vip: '------=_NextPart_01D96E2B.AC83FB00\n'
                            + 'Content-Location: file:///C:/1205FDC9/file2537.files/seal\n'
                            + 'Content-Transfer-Encoding: base64\n'
                            + 'Content-Type: image/png\n\n'
                    }
                    let picSource;
                    if (plType == 'pi') {
                        picSource = picObj.pi
                    } else {
                        if (excel_type == 1) {
                            picSource = picObj.common;
                        } else if (excel_type == 2) {
                            picSource = picObj.netherlands;
                        } else if (excel_type == 3) {
                            picSource = picObj.germany;
                        } else if (excel_type == 4) {
                            picSource = picObj.america;
                        } else if (excel_type == 7) {
                            picSource = picObj.vip;
                        }
                    }
                    if (sign) {
                        picFile = file.load({ id: sign });
                        picData = picSource + picFile.getContents();
                    }

                    let trade_term, department_port = '', destination_port = '';
                    if (department_port_v) {
                        let loading_list = record.load({
                            type: 'customrecord_ecm_loaddest_ports',
                            id: department_port_v
                        })
                        department_port = loading_list.getValue('custrecord_el_name_en')
                    }
                    if (destination_port_v) {
                        let loading_list = record.load({
                            type: 'customrecord_ecm_loaddest_ports',
                            id: destination_port_v
                        })
                        destination_port = loading_list.getValue('custrecord_el_name_en')
                    }
                    if (['FAS', 'FOB'].includes(trade_type)) {
                        trade_term = trade_type + ' ' + department_port
                    } else if (['CFR', 'CIF', 'DES', 'DEQ'].includes(trade_type)) {
                        trade_term = trade_type + ' ' + destination_port
                    } else if (['CPT', 'CIP', 'DDU', 'DDP', 'DAF', 'DAT', 'DAP', 'DPU'].includes(trade_type)) {
                        trade_term = trade_type + ' ' + shipaddress
                    } else if (['EXW', 'FCA'].includes(trade_type)) {
                        trade_term = trade_type + ' ' + delivery_address
                    }

                    let loading_port;
                    if (['EXW', 'FCA'].includes(trade_type)) {
                        loading_port = delivery_address
                    } else {
                        if (department_port == '' || department_port_v == '11728') {
                            loading_port = 'Any Port in ' + department_country
                        } else {
                            loading_port = department_port
                        }
                    }

                    let anyport;
                    if (['CPT', 'CIP', 'DDU', 'DDP', 'DAF', 'DAT', 'DAP', 'DPU'].includes(trade_type)) {
                        anyport = shipaddress
                    } else {
                        if (destination_port == '' || destination_port == '11728') {
                            anyport = 'Any Port in ' + destination_country
                        } else {
                            anyport = destination_port + ', ' + destination_country
                        }
                    }

                    let json = getCustomerName(plId)

                    if (bankdetail) {
                        bankdetail = bankdetail.replace(/\n/g, '<br>')
                    }

                    data.name = isNull(companyName)
                    data.tranid = isNull(tranid)
                    data.otherrefnum = isNull(otherrefnum)
                    data.custbody_ecm_signaddress_en = isNull(custbody_ecm_signaddress_en)
                    data.trandate = isNull(trandate)
                    data.seller_address = isNull(seller_address)
                    data.seller_phone = isNull(seller_phone)
                    data.seller_fax = isNull(seller_fax)
                    data.federalidnumber = isNull(federalidnumber)
                    data.email = isNull(email)
                    data.customer = isNull(customer)
                    data.buyer_address = isNull(buyer_address)
                    data.buyer_phone = isNull(buyer_phone)
                    data.buyer_fax = isNull(buyer_fax)
                    data.vatregnumber = isNull(vatregnumber)
                    data.customer_email = json.email
                    data.currency = isNull(currency)
                    data.shipment_time = isNull(shipment_time)
                    data.shipping_type = isNull(shipping_type)
                    data.payment_port = isNull(payment_port)
                    data.bankdetail = isNull(bankdetail)
                    data.other_message = isNull(other_message)
                    data.unittotal = isNull(unittotal)
                    data.trade_term = isNull(trade_term)
                    data.loading_port = isNull(loading_port)
                    data.anyport = isNull(anyport)
                    data.picname = 'seal'
                    data.picdata = isNull(picData)
                    data.tax_rate = isNull(tax_rate)
                    data.taxtotal = isNull(taxtotal)
                    data.salesrep = isNull(salesrep)
                    data.customer_em = json.name
                    data.num_en = isNull(num_en)
                    data.amounttotal = isNull(Number(amounttotal).toFixed(2))
                    data.license_no = isNull(license_no)
                    data.subtotal = isNull(subtotal)
                }
                let detail_name = x.getValue(columns[13]);
                let hscode = sales_order.getSublistValue({
                    sublistId: 'item',
                    fieldId: 'custcol_emc_hscode',
                    line: i
                })
                let arr1 = []
                arr1.push(x.getValue(columns[24]))
                arr1.push(x.getValue(columns[25]))
                arr1.push(hscode)
                arr1.push(x.getText(columns[27]))
                arr1.push(x.getValue(columns[28]))
                let arr2 = []
                arr2.push(x.getValue(columns[29]))
                arr2.push(x.getValue(columns[30]))
                arr2.push(x.getValue(columns[31]))
                arr2.push(x.getValue(columns[32]))

                let detail_specification = ''
                for (let y = 0; y < arr1.length; y++) {
                    if (y < arr2.length) {
                        if (arr1[y] != '' && arr2[y]) {
                            detail_specification += arr1[y]
                            detail_specification += "<br>"
                        }
                    } else {
                        if (arr1[y] != '') {
                            detail_specification += arr1[y]
                        }
                    }
                }


                let unittype = x.getValue(columns[34]);
                log.debug('unittype' + i, unittype)
                let detail_packing,
                    pack_info = sales_order.getSublistValue({
                        sublistId: 'item',
                        fieldId: 'custcol_ecm_packageremark',
                        line: i
                    });;
                if (unittype == 7) {
                    detail_packing = x.getValue(columns[36]) + x.getText(columns[37]) + '/' + x.getText(columns[38]) + ";<br>"
                        + pack_info;
                } else {
                    detail_packing = pack_info;
                }
                let detail_unit_price = sales_order.getSublistValue({
                    sublistId: 'item',
                    fieldId: 'custcol_ecm_price_packunit',
                    line: i
                });
                let detail_quantity = sales_order.getSublistValue({
                    sublistId: 'item',
                    fieldId: 'custcol_ecm_qty_packunit',
                    line: i
                });
                let detail_unit = sales_order.getSublistText({
                    sublistId: 'item',
                    fieldId: 'custcol_ecm_wgt_unit',
                    line: i
                });
                let detail_amount = sales_order.getSublistValue({
                    sublistId: 'item',
                    fieldId: 'amount',
                    line: i
                });
                quantity_sum += Number(detail_quantity)

                let good_name = x.getValue(columns[15])
                let server_date = x.getValue(columns[46])
                let remark = x.getValue(columns[47])

                let line = {
                    good_name,
                    'commodity_name': detail_name,
                    'specification': detail_specification,
                    'packing': detail_packing != "/;<br>" ? detail_packing : '',
                    'unit_price': detail_unit_price ? Number(detail_unit_price).toFixed(2) : 0,
                    unit_price_1: detail_unit_price ? Number(detail_unit_price).toFixed(2) : 0 + data.currency,
                    'quantity': detail_quantity,
                    'unit': detail_unit,
                    'amount': detail_amount ? detail_amount.toFixed(2) : 0,
                    amount_currency: detail_amount + data.currency,
                    server_date,
                    remark
                }

                list1.push(line)
            })

            data.quantitytotal = quantity_sum

            data.list = list1

            return data;
        }

        // 如果取值为空则单元格为空
        function isNull(someValue) {
            if (someValue == '' || someValue == null) {
                return '';
            } else {
                if (isNaN(someValue) && someValue.indexOf("&") >= 0) {
                    someValue = someValue.replace(/&/g, "&amp;");
                }
                return someValue;
            }
        }

        function getCustomerName(scId) {
            let salesorderSearchObj = search.create({
                type: "salesorder",
                filters: [
                    ["type", "anyof", "SalesOrd"],
                    "AND",
                    ["mainline", "is", "F"],
                    "AND",
                    ["taxline", "is", "F"],
                    "AND",
                    ["internalid", "anyof", scId]],
                columns: [
                    search.createColumn({
                        name: "entityid",
                        join: "contactPrimary",
                        label: "名称"
                    }),
                    search.createColumn({
                        name: "email",
                        join: "contactPrimary",
                        label: "名称"
                    }),
                ]
            });
            let columns = salesorderSearchObj.columns;
            let result = salesorderSearchObj.run().getRange({ start: 0, end: 1000 })
            if (result && result.length > 0) {
                return {
                    name: result[0].getValue(columns[0]),
                    email: result[0].getValue(columns[1]),
                }
            }
        }

        return { onRequest }

    });
