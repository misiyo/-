/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 */
define(['N/encode', 'N/file', 'N/record', 'N/render', 'N/search', 'N/compress', 'SuiteScripts/tools/common_api.js', 'SuiteScripts/SuiteScripts_MC/common.js','N/currency'],
    /**
     * @param{encode} encode
     * @param{file} file
     * @param{record} record
     * @param{render} render
     * @param{search} search
     * @param{compress} compress
     */
    (encode, file, record, render, search, compress, commonApi, commonUtil,currency) => {
        /**
         * Defines the Suitelet script trigger point.
         * @param {Object} scriptContext
         * @param {ServerRequest} scriptContext.request - Incoming request
         * @param {ServerResponse} scriptContext.response - Suitelet response
         * @since 2015.2
         */
        const onRequest = (scriptContext) => {
            let request = scriptContext.request;
            let response = scriptContext.response;
            if (request.method == 'GET') {
                let plId = request.parameters.rec_id;
                let xmlStr = getXml(plId);
                //写文件
                response.writeFile(xmlStr);
            }
        }

        function getXml(plId) {
            let customerPrintFormat = {
                Shipping_Plan_Excel: 'SuiteScripts/SuiteScripts_MC/关检资料.txt',
            };

            let plObj = record.load({
                type: 'customrecord_ecm_sp',
                id: plId
            });
            let xlsName = plObj.getValue('name');
            // let template = plObj.getValue('custrecord_amg_pl_download'); //文件类型
            let count = plObj.getLineCount({sublistId: 'recmachcustrecord_scdline_sp'})
            let supplierLists = []
            for (let i = 0; i < count; i++) {
                let supplier = plObj.getSublistValue({
                    sublistId: 'recmachcustrecord_scdline_sp',
                    fieldId: 'custrecord_scdline_supplier',
                    line: i
                })
                supplierLists.push(supplier)
            }
            let supplierList = [...new Set(supplierLists)]

            let printFormat = customerPrintFormat.Shipping_Plan_Excel;
            let tempFile = file.load({
                id: printFormat
            });
            let archiver, files
            if (supplierList.length > 1) {
                archiver = compress.createArchiver();
            }
            log.debug('supplierList Length',supplierList.length);
            log.debug('supplierList',supplierList.toString());
            supplierList.forEach((x, i) => {
                log.debug('supplier',x)
                let t_render = render.create();
                //模板的内容
                t_render.templateContent = tempFile.getContents();

                let allData = getData(plId, x);

                t_render.addCustomDataSource({
                    alias: 'data',
                    format: render.DataSource.OBJECT,
                    data: allData
                });

                let excel_str = t_render.renderAsString();

                //将字符串转换为另一种类型的编码
                let fstr = encode.convert({
                    string: excel_str,
                    inputEncoding: encode.Encoding.UTF_8,
                    outputEncoding: encode.Encoding.BASE_64
                });

                let name = xlsName + ' Shipping Plan' + i + '.xls';

                let excel = file.create({
                    name: name,
                    fileType: file.Type.EXCEL,
                    //folder : 369,
                    contents: fstr
                });
                if (supplierList.length > 1) {
                    archiver.add({
                        file: excel
                    })
                } else {
                    files = excel
                }
            })
            if (supplierList.length > 1) {
                files = archiver.archive({
                    name: 'myarchive.zip'
                });
            }

            return files;
        }

        function getData(plId, supplier) {
            let data = {};

            let filters = [];
            filters.push(['internalid', 'anyof', plId]);
            // filters.push('and');
            // filters.push(["mainline", "is", "F"],);
            // filters.push('and');
            // filters.push(["taxline", "is", "F"])

            let columns = [];

            columns = getShippingPlanColumns(columns)

            let mySearch = search.create({
                type: 'customrecord_ecm_sp',
                filters: filters,
                columns: columns
            });
            let result = commonApi.getAllData(mySearch);
            if (result) {
                data = getShippingPlanResult(result, columns, supplier);
            }
            return data;
        }

        function getShippingPlanColumns(columns) {
            //0
            columns.push(search.createColumn({
                name: 'name'
            }));
            //1
            columns.push(search.createColumn({
                name: 'custrecord_sp_loadingport'
            }));
            //2
            columns.push(search.createColumn({
                name: 'custrecord_sp_country_loading'
            }));
            //3
            columns.push(search.createColumn({
                name: 'custrecord_sp_destinationport'
            }));
            //4
            columns.push(search.createColumn({
                name: 'custrecord_sp_country_destination'
            }));
            //5
            columns.push(search.createColumn({
                name: 'custrecord_ecm_scdline_scd',
                join: 'custrecord_scdline_sp'
            }));
            //6
            columns.push(search.createColumn({
                name: 'custrecord_scdline_taxrate',
                join: 'custrecord_scdline_sp'
            }));
            //7
            columns.push(search.createColumn({
                name: 'custrecord_scdline_enname',
                join: 'custrecord_scdline_sp'
            }));
            //8
            columns.push(search.createColumn({
                name: 'custrecord_scdline_net_weight',
                join: 'custrecord_scdline_sp'
            }));
            //9
            columns.push(search.createColumn({
                name: 'custrecord_scdline_grossamt',
                join: 'custrecord_scdline_sp'
            }));
            //10
            columns.push(search.createColumn({
                name: 'custrecord_scdline_taxgross',
                join: 'custrecord_scdline_sp'
            }));
            //11
            columns.push(search.createColumn({
                name: 'custrecord_scdline_priceqty',
                join: 'custrecord_scdline_sp'
            }));
            //12
            columns.push(search.createColumn({
                name: 'custrecord_scdline_priceunit',
                join: 'custrecord_scdline_sp'
            }));
            //13 采购合同我司签约方
            columns.push(search.createColumn({
                name: 'custrecord_scdline_supplier',
                join: 'custrecord_scdline_sp'
            }));
            //14 销售合同我司签约方
            columns.push(search.createColumn({
                name: 'custrecord_scdline_demander',
                join: 'custrecord_scdline_sp'
            }));
            //15 客户公司名称
            columns.push(search.createColumn({
                name: 'companyname',
                join: 'custrecord_sp_customer'
            }));
            //16
            columns.push(search.createColumn({
                name: 'custrecord_ecm_subname_en',
                join: 'custrecord_sp_scsubsidiary'
            }));
            //17
            columns.push(search.createColumn({
                name: 'custrecord_ecm_subaddress_en',
                join: 'custrecord_sp_scsubsidiary'
            }));
            //18
            columns.push(search.createColumn({
                name: 'custrecord_sp_customer',
            }));
            //19
            columns.push(search.createColumn({
                name: 'custrecord_scdline_gross_weight',
                join: 'custrecord_scdline_sp'
            }));
            //20
            columns.push(search.createColumn({
                name: 'custrecord_scdline_volume',
                join: 'custrecord_scdline_sp'
            }));
            //21
            columns.push(search.createColumn({
                name: 'custrecord_scdline_packing_qty',
                join: 'custrecord_scdline_sp'
            }));
            //22
            columns.push(search.createColumn({
                name: 'custrecord_scdline_item',
                join: 'custrecord_scdline_sp'
            }));
            //23
            columns.push(search.createColumn({
                name: 'country',
                join: 'custrecord_sp_scsubsidiary'
            }));
            //24
            columns.push(search.createColumn({
                name: 'custrecord_ecm_trade_electricseal',
                join: 'custrecord_sp_scsubsidiary'
            }));
            //25
            columns.push(search.createColumn({
                name: 'custrecord_sp_lcl',
            }));
            //26
            columns.push(search.createColumn({
                name: 'custrecord_scdline_palletno',
                join: 'custrecord_scdline_sp'
            }));
            //27
            columns.push(search.createColumn({
                name: 'custrecord_scdline_seafreightcost',
                join: 'custrecord_scdline_sp'
            }));
            //28
            columns.push(search.createColumn({
                name: 'custrecord_scdline_qty',
                join: 'custrecord_scdline_sp'
            }));
            //29
            columns.push(search.createColumn({
                name: 'custrecord_scdline_domesticsource',
                join: 'custrecord_scdline_sp'
            }));
            //30
            columns.push(search.createColumn({
                name: 'custrecord_scdline_commodityinspection',
                join: 'custrecord_scdline_sp'
            }));
            //31 报关品名
            columns.push(search.createColumn({
                name: 'custrecord_scdline_cusdel_name',
                join: 'custrecord_scdline_sp'
            }));
            //32
            columns.push(search.createColumn({
                name: 'custrecord_scdline_hs_code',
                join: 'custrecord_scdline_sp'
            }));
            //33 签约币种
            columns.push(search.createColumn({
                name: 'custrecord_sp_sccurrency',
            }));
            //34 申报要素
            columns.push(search.createColumn({
                name: 'custrecord_scdline_elements_declarati',
                join: 'custrecord_scdline_sp'
            }));
            //35业务类型
            columns.push(search.createColumn({
                name: 'custrecord_sp_contracttype'
            }));
            //36 配货类型
            columns.push(search.createColumn({
                name: 'custrecord_scdline_distributiontype',
                join: 'custrecord_scdline_sp'
            }));
            //37 采购单价
            columns.push(search.createColumn({
                name: 'custrecord_scdline_purchaseamt',
                join: 'custrecord_scdline_sp'
            }));
            //38 销售单价
            columns.push(search.createColumn({
                name: 'custrecord_scdline_amt',
                join: 'custrecord_scdline_sp'
            }));
            //39 数量
            columns.push(search.createColumn({
                name: 'custrecord_scdline_qty',
                join: 'custrecord_scdline_sp'
            }));
            //40 海运费
            columns.push(search.createColumn({
                name: 'custrecord_scdline_seafreightcost',
                join: 'custrecord_scdline_sp'
            }));
            //41 陆运费
            columns.push(search.createColumn({
                name: 'custrecord_scdline_landfreightcost',
                join: 'custrecord_scdline_sp'
            }));
            //42 港杂费
            columns.push(search.createColumn({
                name: 'custrecord_scdline_inspectioncost',
                join: 'custrecord_scdline_sp'
            }));
            //43 货运保险费
            columns.push(search.createColumn({
                name: 'custrecord_scdline_perscost',
                join: 'custrecord_scdline_sp'
            }));
            //44 关税
            columns.push(search.createColumn({
                name: 'custrecord_scdline_tariffcost',
                join: 'custrecord_scdline_sp'
            }));
            //45 目的港费用
            columns.push(search.createColumn({
                name: 'custrecord_scdline_clearancecost',
                join: 'custrecord_scdline_sp'
            }));
            //46 是否备货
            columns.push(search.createColumn({
                name: 'custrecord_sp_warehousestock'
            }));
            //47 采购合同
            columns.push(search.createColumn({
                name: 'custrecord_scdline_purchaseorder',
                join: 'custrecord_scdline_sp'
            }));
            return columns
        }

        function getShippingPlanResult(result, columns, supplier) {
            let data = {}, list = [], list1 = [];
            let tax_sum = 0,
                volume_sum = 0,
                qyt_sum = 0,
                palletno_sum = 0,
                sea_fee_sum = 0,
                gweight_total = 0,
                weight_total = 0,
                totalamount_tax = 0,
                packing_type
            let rateDate;
            //业务类型  4 自营贸易 5 仓库直发 6 备货
            let contract_type = result[0].getValue(columns[35]);
            result.forEach(o =>{
                let scd = record.load({
                    type: 'customrecord_ecm_scd',
                    id: o.getValue(columns[5])
                })
                let sc_id = scd.getValue('custrecord_scd_sc')
                let sc = record.load({
                    type: 'salesorder',
                    id: sc_id
                })
                let rateDateA;
                if (contract_type === '6') {
                    rateDateA = sc.getValue('trandate');
                }else {
                    let estimateId = sc.getValue('createdfrom');
                    if (estimateId) {
                        var estimate = record.load({
                            type: 'estimate',
                            id: estimateId
                        });
                        rateDateA = estimate.getValue('trandate')
                    }
                }
                if (rateDate) {
                    if (rateDate > rateDateA) {
                        rateDate = rateDateA;
                    }
                }else {
                    rateDate = rateDateA;
                }
            })
            result.forEach((x, i) => {
                //采购合同我司签约方
                let company_id = x.getValue(columns[13])
                log.debug('company_id',company_id);
                if (company_id === supplier) {
                    //配货类型   1 以销定采 2 配自库存  3 配自合同
                    let distribution_type = x.getValue(columns[36])
                    //是否仓库备货
                    let warehouse_stock = x.getValue(columns[46])
                    let hasInterCompany = true;
                    if (isNull(x.getValue(columns[13])) === isNull(x.getValue(columns[14]))) {
                        hasInterCompany = false;
                    }
                    log.debug('采购合同签约方',x.getValue(columns[13]));
                    log.debug('销售合同签约方',x.getValue(columns[14]));
                    log.debug('是否公司间交易',hasInterCompany)
                    let sccurrency = x.getText(columns[33])

                    let scd = record.load({
                        type: 'customrecord_ecm_scd',
                        id: x.getValue(columns[5])
                    })
                    let sc_id = scd.getValue('custrecord_scd_sc')
                    let sc = record.load({
                        type: 'salesorder',
                        id: sc_id
                    })
                    let country_port = sc.getText('custbody_ecm_countryof_destination')

                    let goods_id = x.getValue(columns[22])
                    let goods_message, packing
                    if (goods_id) {
                        goods_message = record.load({
                            type: 'lotnumberedinventoryitem',
                            id: goods_id
                        })
                        packing = goods_message.getText('custitem_ecm_package_remk_en')
                    }
                        let company;
                        if (company_id) {
                            company = record.load({
                                type: 'subsidiary',
                                id: company_id
                            })

                            data.phone = company.getValue('custrecord37')
                            data.fax = company.getValue('fax')
                            data.address = company.getValue('custrecord_ecm_subaddress_en')
                            data.company_name = company.getValue('custrecord_ecm_subname_en')
                            data.company_name_cn = company.getValue('custrecord_ecm_subname_cn')
                        }
                        let companyB;
                        log.debug('demander',x.getValue(columns[14]))
                        if (x.getValue(columns[14])) {
                            companyB = record.load({
                                type: 'subsidiary',
                                id: x.getValue(columns[14])
                            })
                        }
                        //境内发货人
                        //采购合同我司签约方
                       if (company) {
                           data.domestic_shipper = company.getValue('custrecord_ecm_subname_en');
                       }
                        //境外收货人
                        //销售合同我司签约方
                        let overseas_consignee = companyB.getValue('custrecord_ecm_subname_en');
                        if (!hasInterCompany) {
                            //客户名称
                            overseas_consignee = x.getValue(columns[15]);
                        }
                        data.overseas_consignee = overseas_consignee
                        let target_currency;
                        if (x.getValue(columns[47])) {
                            let po = record.load({
                                type: 'purchaseorder',
                                id: x.getValue(columns[47])
                            })
                            target_currency = po.getValue('currency')
                        }else {
                            target_currency = company.getValue('currency');
                        }
                        let customer_id = x.getValue(columns[18])
                        let customer_message, customer_add, customer_country;
                        if (customer_id) {
                            customer_message = record.load({
                                type: 'customer',
                                id: customer_id
                            })
                            customer_add = customer_message.getValue('defaultaddress')
                            let length = customer_message.getLineCount({sublistId: 'addressbook'});
                            log.debug('length', length)
                            if (length) {
                                let subrec = customer_message.getSublistSubrecord({
                                    sublistId: 'addressbook',
                                    fieldId: 'addressbookaddress',
                                    line: 0
                                });
                                customer_country = subrec.getText({fieldId: 'country'});
                                log.debug('cty==>', customer_country)
                            }
                        }
                        let trading_nations = customer_country;
                        if (hasInterCompany) {
                            trading_nations = companyB.getText('country');
                        }
                        data.trading_nations = trading_nations;
                        let spno = x.getValue(columns[0])

                        let department_port_w = x.getValue(columns[1]);
                        let destination_port_w = x.getValue(columns[3]);
                        let loading1 = '', loading2 = ''
                        if (department_port_w) {
                            let loading_list = record.load({
                                type: 'customrecord_ecm_loaddest_ports',
                                id: department_port_w
                            })
                            loading1 = loading_list.getValue('custrecord_el_name_en')
                        }
                        if (destination_port_w) {
                            let loading_list = record.load({
                                type: 'customrecord_ecm_loaddest_ports',
                                id: destination_port_w
                            })
                            loading2 = loading_list.getValue('custrecord_el_name_en')
                        }

                        let loadingport = loading1 + ' ' + x.getText(columns[2])
                        let destinationport = loading2 + ' ' + x.getText(columns[4])
                        let date = new Date()
                        let tax_rate = x.getValue(columns[6])
                        let demander_id = x.getValue(columns[14])
                        let customer_en = x.getValue(columns[15])
                        let seller_en = x.getValue(columns[16])
                        let seller_add = x.getValue(columns[17])
                        let seller_country = x.getText(columns[23])
                        let seal_id = x.getValue(columns[24])
                        let totalamount_tax = x.getValue(columns[33])
                        let trade_term;
                        let trade_type = sc.getText('custbody_ecm_incoterm');
                        let department_port_v = sc.getValue('custbody_ecm_loadingport');
                        let destination_port_v = sc.getValue('custbody_ecm_destination_port');
                        let shipaddress = sc.getValue('shipaddress');
                        let delivery_address = sc.getValue('custbody_ecm_delivery_address');
                        let department_port = '', destination_port = ''
                        if (department_port_v) {
                            let loading_list = record.load({
                                type: 'customrecord_ecm_loaddest_ports',
                                id: department_port_v
                            })
                            department_port = loading_list.getValue('custrecord_el_name_en')
                        }
                        if (destination_port_v) {
                            let loading_list = record.load({
                                type: 'customrecord_ecm_loaddest_ports',
                                id: destination_port_v
                            })
                            destination_port = loading_list.getValue('custrecord_el_name_en')
                        }
                        if (['FAS', 'FOB'].includes(trade_type)) {
                            trade_term = trade_type + ' ' + department_port
                        } else if (['CFR', 'CIF', 'DES', 'DEQ'].includes(trade_type)) {
                            trade_term = trade_type + ' ' + destination_port
                        } else if (['CPT', 'CIP', 'DDU', 'DDP', 'DAF', 'DAT', 'DAP', 'DPU'].includes(trade_type)) {
                            trade_term = trade_type + ' ' + shipaddress
                        } else if (['EXW', 'FCA'].includes(trade_type)) {
                            trade_term = trade_type + ' ' + delivery_address
                        }
                        let customer_address, customer_name, country_from
                        if (company_id == demander_id) {
                            customer_name = customer_en
                            customer_address = customer_add
                            country_from = customer_country
                        } else {
                            customer_name = seller_en
                            customer_address = seller_add
                            country_from = seller_country
                        }

                        let picFile, picData
                        let picObj = '------=_NextPart_01D96EBB.6D2DFB50\n'
                            + 'Content-Location: file:///C:/17D1C351/file2993.files/seal\n'
                            + 'Content-Transfer-Encoding: base64\n'
                            + 'Content-Type: image/png\n\n'
                        if (seal_id) {
                            picFile = file.load({id: seal_id});
                            picData = picObj + picFile.getContents();
                        }

                        packing_type = x.getValue(columns[25])
                        let pack_type
                        if (packing_type == 1) {
                            pack_type = 'PALLET'
                        } else if (packing_type == 2) {
                            pack_type = packing
                        }

                        let premium
                        if (['CIP', 'CIF', 'DES', 'DEQ', 'DDU', 'DDP', 'DAF', 'DAT', 'DAP', 'DPU'].includes(trade_type)) {
                            premium = sccurrency + ' ' + (totalamount_tax * 1.1 * 0.00045).toFixed(2)
                        }
                        let bank_info = sc.getValue('custbody_ecm_bankinfomation')
                        if (bank_info) {
                            bank_info = bank_info.replace(/\n/g, '<br>')
                        }

                        data.spno = isNull(spno)
                        data.loadingport = isNull(loadingport)
                        data.destinationport = isNull(destinationport)
                        data.today = date.toLocaleDateString()
                        data.trade_term = isNull(trade_term)
                        data.tax_rate = isNull(tax_rate)
                        data.currency = isNull(sccurrency)
                        data.payment_term = isNull(sc.getValue('custbody_ecm_termsdisplay_en'))
                        data.bank_info = isNull(bank_info)
                        data.customer_name = isNull(customer_name)
                        data.customer_address = isNull(customer_address)
                        data.shipping_method = isNull(sc.getText('custbody_ecm_shipping_method'))
                        data.country_from = isNull(country_from)
                        data.country_to = isNull(country_port)
                        data.destination_port = isNull(destination_port)
                        data.trade_type = isNull(trade_type)
                        data.picname1 = 'seal'
                        data.picdata1 = picData
                        data.picname2 = 'seal'
                        data.picdata2 = picData
                        data.picname3 = 'seal'
                        data.picdata3 = picData
                        data.pack_type = isNull(pack_type)
                        data.premium = isNull(premium)
                    let goods = x.getValue(columns[7])
                    let weight = Number(x.getValue(columns[8]))
                    let amount = Number(x.getValue(columns[9]))
                    let tax = Number(x.getValue(columns[10]))
                    let unit_price = x.getValue(columns[11])
                    let unit = x.getText(columns[12])
                    let gweight = Number(x.getValue(columns[19]))
                    let volume = Number(x.getValue(columns[20]))
                    let qyt = Number(x.getValue(columns[21]))
                    let palletno = Number(x.getValue(columns[26]))
                    let sea_fee = Number(x.getValue(columns[27]))
                    let quantity = Number(x.getValue(columns[28]))
                    let in_place = x.getValue(columns[29])
                    let check = x.getValue(columns[30])

                    tax_sum += tax
                    volume_sum += volume
                    qyt_sum += qyt
                    palletno_sum += palletno
                    sea_fee_sum += sea_fee * quantity
                    gweight_total += gweight
                    weight_total += weight
                    totalamount_tax += amount
                    let total_price;
                    log.debug('rateDate',rateDate)
                    var rate = currency.exchangeRate({
                        source: target_currency,
                        target: x.getValue(columns[33]),
                        date: new Date(rateDate)
                    });
                    let add_rate_str = '0%';
                    if (hasInterCompany) {
                        var customrecord_ecm_intercompanySearchObj = search.create({
                            type: "customrecord_ecm_intercompany",
                            filters:
                                [
                                    ["custrecord_ecm_interco_supplier", "anyof",  x.getValue(columns[13])],
                                    "AND",
                                    ["custrecord_ecm_interco_demand", "anyof",  x.getValue(columns[14])],
                                    "AND",
                                    ["custrecord_ecm_stock", "is", warehouse_stock]
                                ],
                            columns:
                                [
                                    search.createColumn({name: "custrecord_ecm_interco_ratio", label: "加价比例"})
                                ]
                        });
                        customrecord_ecm_intercompanySearchObj.run().each(function (result) {
                            add_rate_str = result.getValue('custrecord_ecm_interco_ratio');
                            return true;
                        })
                    }
                    let add_rate = Number(add_rate_str.slice(0, -1));
                    if (!hasInterCompany) {
                        total_price = Number(isNull(x.getValue(columns[38]))) * Number(isNull(x.getValue(columns[39])))
                    } else if (contract_type === '4') {
                        total_price = Number(isNull(x.getValue(columns[37]))) * Number(isNull(x.getValue(columns[39]))) * (1 + add_rate / 100) * rate
                    } else {
                        let sum_price = Number(isNull(x.getValue(columns[37])))
                            + Number(isNull(x.getValue(columns[40])))
                            + Number(isNull(x.getValue(columns[41])))
                            + Number(isNull(x.getValue(columns[42])))
                            + Number(isNull(x.getValue(columns[43])))
                            + Number(isNull(x.getValue(columns[44])))
                            + Number(isNull(x.getValue(columns[45])));
                        total_price = sum_price * Number(isNull(x.getValue(columns[39]))) * (1 + add_rate / 100)*rate;
                    }
                    let unit_price1 = Number(isNull(unit_price))
                    if (x.getValue(columns[8])) {
                        unit_price1 = total_price/Number(qyt);
                    }
                    let unit_price_i =  total_price/Number(weight)
                    let line = {
                        goods: goods,
                        weight: weight,
                        unit_price: unit_price1.toFixed(4) + sccurrency + '/' + packing,
                        unit_price_i: unit_price_i.toFixed(4),
                        amount: total_price.toFixed(2) + sccurrency,
                        gweight: gweight,
                        volume: volume,
                        qyt: qyt + ' ' + packing
                    }
                    list.push(line)

                    let hscode = x.getValue(columns[32])
                    let goods_name = x.getValue(columns[31])
                    let item = x.getValue(columns[34])

                    let unit_price2 = Number(isNull(unit_price))
                    if (x.getValue(columns[8])) {
                        unit_price2 = total_price/Number(x.getValue(columns[8]));
                    }
                    let line1 = {
                        num: i + 1,
                        goods_name: goods_name,
                        hscode: isNull(hscode),
                        weight: isNull(weight),
                        weight_mt: isNull(weight / 1000),
                        currency: isNull(sccurrency),
                        country_port: isNull(country_port),
                        unit_price: unit_price2.toFixed(4),
                        total_price: total_price.toFixed(2),
                        in_place: isNull(in_place),
                        is_check: check ? '商检' : '',
                        item: isNull(item)
                    }

                    list1.push(line1)
                }
            })

            data.list = list
            data.list1 = list1
            data.taxamount = tax_sum
            data.volume_total = volume_sum
            data.qyt_total = qyt_sum
            data.trade_fee = data.currency + ' ' + sea_fee_sum
            data.gweight_total = gweight_total
            data.gweight_totalen = commonUtil.translate(gweight_total)
            data.weight_total = weight_total
            data.weight_totalen = commonUtil.translate(weight_total)
            data.totalamount_tax = totalamount_tax.toFixedNew(2)
            data.totalamount_taxen = commonUtil.translate(totalamount_tax.toFixedNew(2))

            if (packing_type == 1) {
                data.pack_num = palletno_sum
            } else if (packing_type == 2) {
                data.pack_num = qyt_sum
            }

            return data
        }

        // 如果取值为空则单元格为空
        function isNull(someValue) {
            if (someValue == '' || someValue == null) {
                return '';
            } else {
                if (isNaN(someValue) && someValue.indexOf("&") >= 0) {
                    someValue = someValue.replace(/&/g, "&amp;");
                }
                return someValue;
            }
        }


        return {onRequest}

    });
