/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 */
define(['N/url', 'N/record', 'N/runtime'],
    /**
 * @param{url} url
 * @param{record} record
 */
    (url, record, runtime) => {
        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {
            let typeObj = scriptContext.type;
            let newRec = scriptContext.newRecord;
            let curForm = scriptContext.form;
            if (typeObj == 'view') {
                let urlObjType = url.resolveScript({
                    scriptId: 'customscript_sl_sp_print_excel',
                    deploymentId: 'customdeploy_sl_sp_print_excel',
                })
                let printExcel = "window.open('" + urlObjType + "&rec_id=" + newRec.id + "','_self')";
                curForm.addButton({
                    id: 'custpage_dl_1',
                    label: 'Clearance Doc',
                    functionName: printExcel
                })
                let urlObjType1 = url.resolveScript({
                    scriptId: 'customscript_sl_sp_order_excel',
                    deploymentId: 'customdeploy_sl_sp_order_excel',
                })
                let printExcel1 = "window.open('" + urlObjType1 + "&rec_id=" + newRec.id + "','_self')";
                curForm.addButton({
                    id: 'custpage_dl_2',
                    label: 'Order Req',
                    functionName: printExcel1
                })
            }
        }

        /**
         * Defines the function definition that is executed before record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const beforeSubmit = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {
            let form = scriptContext.newRecord
            let SCarr = [];
            let operation = form.getValue('custrecord_sp_docofficer2');
            if (operation) {
                let item = form.getLineCount({ sublistId: 'recmachcustrecord_scdline_sp' });
                for (let i = 0; i < item; i++) {
                    let sc_no = form.getSublistValue({ sublistId: 'recmachcustrecord_scdline_sp', fieldId: 'custrecord_scdline_sc', line: i });
                    if (sc_no && !SCarr.includes(sc_no)) {
                        SCarr.push(sc_no);
                        let sc = record.load({
                            type: 'salesorder',
                            id: sc_no
                        })
                        let salesteam = sc.getLineCount({ sublistId: 'salesteam' });
                        let haveSale = false;
                        for (let n = 0; n < salesteam; n++) {
                            let saler = sc.getSublistValue({ sublistId: 'salesteam', fieldId: 'employee', line: n });
                            if (saler == operation) {
                                haveSale = true;
                            }
                        }
                        if (!haveSale) {
                            sc.setSublistValue({ sublistId: 'salesteam', fieldId: 'employee', value: operation, line: salesteam });
                            sc.setSublistValue({ sublistId: 'salesteam', fieldId: 'salesrole', value: '1', line: salesteam });
                            sc.setSublistValue({ sublistId: 'salesteam', fieldId: 'contribution', value: '0', line: salesteam });
                            sc.save({ ignoreMandatoryFields: true })
                        }
                    }
                }
            }
        }

        return {
            beforeLoad,
            // beforeSubmit,
            afterSubmit
        }

    });
