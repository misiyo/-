/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 */
define(['N/encode', 'N/file', 'N/record', 'N/render', 'N/search', 'SuiteScripts/tools/common_api.js', 'SuiteScripts/SuiteScripts_MC/common.js'],
    /**
 * @param{encode} encode
 * @param{file} file
 * @param{record} record
 * @param{render} render
 * @param{search} search
 */
    (encode, file, record, render, search, commonApi, commonUtil) => {
        /**
         * Defines the Suitelet script trigger point.
         * @param {Object} scriptContext
         * @param {ServerRequest} scriptContext.request - Incoming request
         * @param {ServerResponse} scriptContext.response - Suitelet response
         * @since 2015.2
         */
        const onRequest = (scriptContext) => {
            let request = scriptContext.request;
            let response = scriptContext.response;
            if (request.method == 'GET') {
                let plId = request.parameters.rec_id;
                let xmlStr = getXml(plId);
                //写文件
                response.writeFile(xmlStr);
            }
        }

        function getXml(plId) {
            let customerPrintFormat = {
                Invoince_Excel: 'SuiteScripts/SuiteScripts_MC/财务发票.txt',
                Invoince_OutSea_Excel: 'SuiteScripts/SuiteScripts_MC/海外仓财务发票.txt'
            };

            let plObj = record.load({
                type: 'invoice',
                id: plId
            });
            let sc_id = plObj.getValue('createdfrom')
            let sc_type
            if (sc_id) {
                let sc = record.load({
                    type: 'salesorder',
                    id: sc_id
                })
                sc_type = sc.getValue('custbody_ecm_contract_type')
            }
            log.debug('sc_type', sc_type)
            let xlsName = plObj.getValue('tranid');
            // let template = plObj.getValue('custrecord_amg_pl_download'); //文件类型
            let printFormat
            if (sc_type == 4) {
                printFormat = customerPrintFormat.Invoince_Excel;
            } else if (sc_type == 5) {
                printFormat = customerPrintFormat.Invoince_OutSea_Excel;
            }
            let tempFile = file.load({
                id: printFormat
            });

            let t_render = render.create();
            //模板的内容
            t_render.templateContent = tempFile.getContents();

            let allData = getData(plId);

            t_render.addCustomDataSource({
                alias: 'data',
                format: render.DataSource.OBJECT,
                data: allData
            });

            let excel_str = t_render.renderAsString();

            //将字符串转换为另一种类型的编码
            let fstr = encode.convert({
                string: excel_str,
                inputEncoding: encode.Encoding.UTF_8,
                outputEncoding: encode.Encoding.BASE_64
            });

            let name = xlsName + '.xls';

            let excel = file.create({
                name: name,
                fileType: file.Type.EXCEL,
                //folder : 369,
                contents: fstr
            });
            return excel;
        }

        function getData(plId) {
            let data = {};

            let filters = [];
            filters.push(['internalid', 'anyof', plId]);
            filters.push('and');
            filters.push(["mainline", "is", "F"],);
            filters.push('and');
            filters.push(["taxline", "is", "F"])

            let columns = [];

            columns = getSalesOrderColumns(columns)

            let mySearch = search.create({
                type: 'invoice',
                filters: filters,
                columns: columns
            });
            let result = commonApi.getAllData(mySearch);
            log.debug('res', result);
            if (result) {
                data = getSalesOrderResult(result, columns, plId);
            }
            log.debug('data', JSON.stringify(data));
            return data;
        }

        function getSalesOrderColumns(columns) {
            columns.push(search.createColumn({
                name: 'tranid'
            }));
            columns.push(search.createColumn({
                name: 'salesrep'
            }));
            columns.push(search.createColumn({
                name: 'custbody_ecm_bankinfomation'
            }));
            columns.push(search.createColumn({
                name: 'name',
                join: 'custbody_ecm_sp'
            }));
            columns.push(search.createColumn({
                name: 'custrecord_sp_pono',
                join: 'custbody_ecm_sp'
            }));
            columns.push(search.createColumn({
                name: 'entity',
            }));
            columns.push(search.createColumn({
                name: 'createdfrom',
            }));
            columns.push(search.createColumn({
                name: 'custrecord_sp_deliverydate',
                join: 'custbody_ecm_sp'
            }));
            columns.push(search.createColumn({
                name: 'custrecord_ecm_subname_en',
                join: 'subsidiary'
            }));
            columns.push(search.createColumn({
                name: 'custrecord_ecm_subaddress_en',
                join: 'subsidiary'
            }));
            columns.push(search.createColumn({
                name: 'custrecord37',
                join: 'subsidiary'
            }));
            columns.push(search.createColumn({
                name: 'fax',
                join: 'subsidiary'
            }));
            columns.push(search.createColumn({
                name: 'subsidiary',
            }));
            columns.push(search.createColumn({
                name: 'custitem_ecm_productname_en',
                join: 'item'
            }));
            columns.push(search.createColumn({
                name: 'currency',
            }));
            columns.push(search.createColumn({
                name: 'custbody_ecm_sp',
            }));
            columns.push(search.createColumn({
                name: 'custitem_ecm_brand',
                join: 'item',
            }));
            columns.push(search.createColumn({
                name: 'custitem_ecm_origincountry',
                join: 'item',
            }));

            return columns
        }

        function getSalesOrderResult(result, columns, plId) {
            let data = {};
            let list1 = [];
            let weight_sum = 0;

            result.forEach((x, i) => {

                let invoice = record.load({
                    type: 'invoice',
                    id: plId
                });

                let so_id = x.getValue(columns[6]);
                let so = record.load({
                    type: 'salesorder',
                    id: so_id
                })
                let sc_id = so.getValue('custbody_sourceformtran')
                let sc = record.load({
                    type: 'salesorder',
                    id: sc_id
                })
                let currency = x.getText(columns[14]);

                if (i == 0) {
                    let inv_no = x.getValue(columns[0])
                    let salesrep = x.getText(columns[1])
                    let bank_info = x.getValue(columns[2])
                    let sp_no = x.getValue(columns[3])
                    let po_no = x.getValue(columns[4])
                    let customer_id = x.getValue(columns[5]);
                    let income_date = x.getValue(columns[7]);
                    let company_name = x.getValue(columns[8]);
                    let company_address = x.getValue(columns[9]);
                    let company_id = x.getValue(columns[12]);
                    let total_tax = invoice.getValue('taxtotal');
                    let total_amount_tax = invoice.getValue('total');

                    let company = record.load({
                        type: 'subsidiary',
                        id: company_id
                    })
                    let vat_no = company.getValue('federalidnumber')
                    let phone = company.getValue('custrecord37');
                    let fax = company.getValue('fax');


                    let trade_type = sc.getText('custbody_ecm_incoterm');
                    let department_port_v = sc.getValue('custbody_ecm_loadingport');
                    let destination_port_v = sc.getValue('custbody_ecm_destination_port');
                    let shipaddress = sc.getValue('shipaddress');
                    let delivery_address = sc.getValue('custbody_ecm_delivery_address');
                    let department_country = sc.getText('custbody_ecm_countryof_departure');
                    let destination_country = sc.getText('custbody_ecm_countryof_destination');

                    let department_port = '', destination_port = '';
                    if (department_port_v) {
                        let loading_list = record.load({
                            type: 'customrecord_ecm_loaddest_ports',
                            id: department_port_v
                        })
                        department_port = loading_list.getValue('custrecord_el_name_en')
                    }
                    if (destination_port_v) {
                        let loading_list = record.load({
                            type: 'customrecord_ecm_loaddest_ports',
                            id: destination_port_v
                        })
                        destination_port = loading_list.getValue('custrecord_el_name_en')
                    }

                    let customer = record.load({
                        type: 'customer',
                        id: customer_id
                    })
                    let customer_name = customer.getValue('altname')
                    let customer_address = sc.getValue('billaddress')
                    let customer_phone = customer.getValue('phone')
                    let customer_vat_no = customer.getValue('vatregnumber')


                    let trade_term;
                    if (['FAS', 'FOB'].includes(trade_type)) {
                        trade_term = trade_type + ' ' + department_port
                    } else if (['CFR', 'CIF', 'DES', 'DEQ'].includes(trade_type)) {
                        trade_term = trade_type + ' ' + destination_port
                    } else if (['CPT', 'CIP', 'DDU', 'DDP', 'DAF', 'DAT', 'DAP', 'DPU'].includes(trade_type)) {
                        trade_term = trade_type + ' ' + shipaddress
                    } else if (['EXW', 'FCA'].includes(trade_type)) {
                        trade_term = trade_type + ' ' + delivery_address
                    }

                    let from;
                    if (['EXW', 'FCA'].includes(trade_type)) {
                        from = delivery_address
                    } else {
                        from = department_port + ' ' + department_country
                    }

                    let to;
                    if (['EXW', 'FCA'].includes(trade_type)) {
                        to = shipaddress
                    } else {
                        to = destination_port + ' ' + destination_country
                    }

                    let subsidiarySearchObj = search.create({
                        type: "subsidiary",
                        filters:
                            [['internalid', 'is', company_id]],
                        columns:
                            [search.createColumn({ name: "custrecord_ecm_trade_electricseal", label: "Subsidiary Seal" }),]
                    });
                    let seal_id;
                    subsidiarySearchObj.run().each(function (result) {
                        // .run().each has a limit of 4,000 results
                        seal_id = result.getValue('custrecord_ecm_trade_electricseal')
                        return true;
                    });

                    let picFile, picData
                    let picObj = {
                        common: '------=_NextPart_01D95376.EE32E720\n'
                            + 'Content-Location: file:///C:/6E367788/file3304.files/seal\n'
                            + 'Content-Transfer-Encoding: base64\n'
                            + 'Content-Type: image/png\n\n',
                    }
                    if (seal_id) {
                        picFile = file.load({ id: seal_id });
                        picData = picObj.common + picFile.getContents();
                    }

                    let tax_rate = invoice.getSublistValue({
                        sublistId: 'item',
                        fieldId: 'taxrate1',
                        line: i
                    })

                    if (bank_info) {
                        bank_info = bank_info.replace(/\n/g, '<br>')
                    }

                    data.inv_no = isNull(inv_no)
                    data.salesrep = isNull(salesrep)
                    data.sc_no = isNull(sc.getValue('tranid'))
                    data.bank_info = isNull(bank_info)
                    data.customer_name = isNull(customer_name)
                    data.customer_address = isNull(customer_address)
                    data.customer_phone = isNull(customer_phone)
                    data.customer_vat_no = isNull(customer_vat_no)
                    data.sp_no = isNull(sp_no)
                    data.po_no = isNull(po_no)
                    data.trade_term = isNull(trade_term)
                    data.from = isNull(from)
                    data.to = isNull(to)
                    data.income_date = isNull(income_date)
                    data.payment_term = isNull(sc.getText('custbody_ecm_termsdisplay_en'))
                    data.company_name = isNull(company_name)
                    data.company_address = isNull(company_address)
                    data.phone = isNull(phone)
                    data.fax = isNull(fax)
                    data.vat_no = isNull(vat_no)
                    data.currency = isNull(currency)
                    data.total_tax = isNull(Number(total_tax))
                    data.picname = 'seal'
                    data.picdata = isNull(picData)
                    data.total_amount_tax = isNull(total_amount_tax)
                    data.total_amount_tax_en = commonUtil.translate(total_amount_tax)
                    data.tax_rate = isNull(tax_rate)
                }
                let goods_name = x.getValue(columns[13])
                let brand = x.getValue(columns[16])
                let origin = x.getText(columns[17])

                let sp_id = x.getValue(columns[15])
                let net_weight = 0
                if (sp_id) {
                    let sp = record.load({
                        type: 'customrecord_ecm_sp',
                        id: sp_id
                    })
                    net_weight = sp.getSublistValue({
                        sublistId: 'recmachcustrecord_scdline_sp',
                        fieldId: 'custrecord_scdline_net_weight',
                        line: i
                    })
                }
                let good_id = invoice.getSublistValue({
                    sublistId: 'item',
                    fieldId: 'item',
                    line: i
                })
                let good = record.load({
                    type: 'lotnumberedinventoryitem',
                    id: good_id
                })
                let unitstype = good.getValue('unitstype')
                let amount = invoice.getSublistValue({
                    sublistId: 'item',
                    fieldId: 'amount',
                    line: i
                })
                let rate = invoice.getSublistValue({
                    sublistId: 'item',
                    fieldId: 'rate',
                    line: i
                })
                let unit_price, unit
                if (unitstype == 7) {
                    let exrate = good.getValue('custitem_ecm_case_package_kg')
                    unit = good.getText('custitem_ecm_wgt_unit')
                    if (exrate) {
                        unit_price = (rate / exrate).toFixedNew(8)
                    }
                } else {
                    unit = invoice.getSublistValue({
                        sublistId: 'item',
                        fieldId: 'units_display',
                        line: i
                    })
                    unit_price = rate 
                }

                let hscode = invoice.getSublistValue({
                    sublistId: 'item',
                    fieldId: 'custcol_emc_hscode',
                    line: i
                })
                weight_sum += Number(net_weight)

                let line = {
                    goods_name,
                    amount,
                    unit_price: unit_price + currency + '/' + unit,
                    net_weight,
                    brand,
                    origin,
                    hscode
                }

                list1.push(line)
            })

            data.total_net_weight = weight_sum

            data.list = list1

            return data
        }

        // 如果取值为空则单元格为空
        function isNull(someValue) {
            if (someValue == '' || someValue == null) {
                return '';
            } else {
                if (isNaN(someValue) && someValue.indexOf("&") >= 0) {
                    someValue = someValue.replace(/&/g, "&amp;");
                }
                return someValue;
            }
        }

        return { onRequest }

    });
