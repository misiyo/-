/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 */
define(['N/encode', 'N/record', 'N/render', 'N/search', 'N/file', 'SuiteScripts/tools/common_api.js'],
    /**
 * @param{encode} encode
 * @param{record} record
 * @param{render} render
 * @param{search} search
 * @param{file} file
 */
    (encode, record, render, search, file, commonApi) => {
        /**
         * Defines the Suitelet script trigger point.
         * @param {Object} scriptContext
         * @param {ServerRequest} scriptContext.request - Incoming request
         * @param {ServerResponse} scriptContext.response - Suitelet response
         * @since 2015.2
         */
        const onRequest = (scriptContext) => {
            let request = scriptContext.request;
            let response = scriptContext.response;
            if (request.method == 'GET') {
                let plId = request.parameters.rec_id;
                let xmlStr = getXml(plId);
                //写文件
                response.writeFile(xmlStr);
            }
        }

        function getXml(plId) {
            let customerPrintFormat = {
                Order_Excel: 'SuiteScripts/SuiteScripts_MC/订单要求.xml',
            };

            let plObj = record.load({
                type: 'customrecord_ecm_sp',
                id: plId
            });

            let xlsName = plObj.getValue('name');
            // let template = plObj.getValue('custrecord_amg_pl_download'); //文件类型
            let printFormat = customerPrintFormat.Order_Excel;
            let tempFile = file.load({
                id: printFormat
            });

            let t_render = render.create();
            //模板的内容
            t_render.templateContent = tempFile.getContents();

            let allData = getData(plId);

            t_render.addCustomDataSource({
                alias: 'data',
                format: render.DataSource.OBJECT,
                data: allData
            });

            let excel_str = t_render.renderAsString();

            //将字符串转换为另一种类型的编码
            let fstr = encode.convert({
                string: excel_str,
                inputEncoding: encode.Encoding.UTF_8,
                outputEncoding: encode.Encoding.BASE_64
            });

            let name = xlsName + ' Shipping Plan.xls';

            let excel = file.create({
                name: name,
                fileType: file.Type.EXCEL,
                //folder : 369,
                contents: fstr
            });
            return excel;
        }

        function getData(plId) {
            let data = {};

            let filters = [];
            filters.push(['internalid', 'anyof', plId]);
            // filters.push('and');
            // filters.push(["mainline", "is", "F"],);
            // filters.push('and');
            // filters.push(["taxline", "is", "F"])

            let columns = [];

            columns = getShippingPlanColumns(columns)

            let mySearch = search.create({
                type: 'customrecord_ecm_sp',
                filters: filters,
                columns: columns
            });
            let result = commonApi.getAllData(mySearch);
            log.debug('res', result);
            if (result) {
                data = getShippingPlanResult(result, columns, plId);
            }
            log.debug('data', JSON.stringify(data));
            return data;
        }

        function getShippingPlanColumns(columns) {
            columns.push(search.createColumn({
                name: 'custrecord_scdline_purchaseorder',
                join: 'custrecord_scdline_sp'
            }));
            columns.push(search.createColumn({
                name: 'custrecord_scdline_sc',
                join: 'custrecord_scdline_sp'
            }));
            columns.push(search.createColumn({
                name: 'custrecord_scdline_item',
                join: 'custrecord_scdline_sp'
            }));
            columns.push(search.createColumn({
                name: 'custrecord_scdline_chname',
                join: 'custrecord_scdline_sp'
            }));
            columns.push(search.createColumn({
                name: 'custrecord_scdline_priceqty',
                join: 'custrecord_scdline_sp'
            }));
            columns.push(search.createColumn({
                name: 'custrecord_scdline_priceunit',
                join: 'custrecord_scdline_sp'
            }));
            columns.push(search.createColumn({
                name: 'custrecord_scdline_net_weight',
                join: 'custrecord_scdline_sp'
            }));
            columns.push(search.createColumn({
                name: 'custrecord_scdline_gross_weight',
                join: 'custrecord_scdline_sp'
            }));
            columns.push(search.createColumn({
                name: 'custrecord_scdline_punch',
                join: 'custrecord_scdline_sp'
            }));
            columns.push(search.createColumn({
                name: 'custrecord_scdline_hs_code',
                join: 'custrecord_scdline_sp'
            }));
            columns.push(search.createColumn({
                name: 'custrecord_ecm_subname_cn',
                join: 'custrecord_sp_scsubsidiary'
            }));
            columns.push(search.createColumn({
                name: 'companyname',
                join: 'custrecord_sp_freightfor'
            }));
            columns.push(search.createColumn({
                name: 'vatregnumber',
                join: 'custrecord_sp_customer'
            }));
            columns.push(search.createColumn({
                name: 'custrecord_scdline_enname',
                join: 'custrecord_scdline_sp'
            }));

            return columns
        }

        function getShippingPlanResult(result, columns, plId) {
            let data = {}, list = []

            let sp = record.load({
                type: 'customrecord_ecm_sp',
                id: plId
            })

            result.forEach((x, i) => {
                if (i == 0) {
                    data.spno = isNull(sp.getValue('tranid'))

                    let po_no = x.getValue(columns[0])
                    if (po_no) {
                        let po = record.load({
                            type: 'purchaseorder',
                            id: po_no
                        })
                        data.po_no = isNull(po.getValue('tranid'))
                    }

                    let sc_id = x.getValue(columns[1])
                    if (sc_id) {
                        let sc = record.load({
                            type: 'salesorder',
                            id: sc_id
                        })
                        data.reference_order = isNull(sc.getValue('tranid'))
                    }

                    data.seller_comopany = isNull(x.getValue(columns[10]))

                    let start_port_id = sp.getValue('custrecord_sp_loadingport')
                    if (start_port_id) {
                        if (start_port_id == "11728") {
                            data.start_port_text = '任何港口'
                        } else {
                            let start_port = record.load({
                                type: 'customrecord_ecm_loaddest_ports',
                                id: start_port_id
                            })
                            data.start_port_text = isNull(start_port.getValue('custrecord_el_name_cn'))
                        }
                    }

                    data.export_country_text = isNull(sp.getText('custrecord_sp_country_destination'))

                    data.trade_trem_text = isNull(sp.getText('custrecord_sp_incoterm'))

                    let discharging_port_id = sp.getValue('custrecord_sp_destinationport')
                    if (discharging_port_id) {
                        if (discharging_port_id == "11728") {
                            data.discharging_port_text = '任何港口'
                        } else {
                            let discharging_port = record.load({
                                type: 'customrecord_ecm_loaddest_ports',
                                id: discharging_port_id
                            })
                            data.discharging_port_text = isNull(discharging_port.getValue('custrecord_el_name_en'))
                        }
                    }

                    data.transport_text = isNull(sp.getText('custrecord_sp_shipping_method'))

                    let box_type1 = sp.getText('custrecord_sp_cubetype1')
                    let box_num1 = sp.getValue('custrecord_sp_cubetypeqty1')
                    let box_type2 = sp.getText('custrecord_sp_cubetype2')
                    let box_num2 = sp.getValue('custrecord_sp_cubetypeqty2')
                    let box_total1 = box_type1 && box_num1 ? box_num1 + 'X' + box_type1 : ''
                    let box_total2 = box_type2 && box_num2 ? box_num2 + 'X' + box_type2 : ''
                    data.total_cabinet = box_total1 + (box_total1 && box_total2 ? '+' : '') + box_total2

                    data.inspect_text = isNull(sp.getText('custrecord_sp_inspection_type'))

                    let photo_demand = sp.getValue('custrecord_sp_photo_request')
                    data.is_photograph_text = photo_demand == '8' || photo_demand == '' ? '否' : '是'
                    data.photograph_demand = isNull(sp.getText('custrecord_sp_photo_request'))

                    data.factory_name = x.getValue(columns[11])

                    data.remark = isNull(sp.getText('custrecord_sp_tag'))
                    data.not_neutral_remark = isNull(sp.getValue('custrecord_sp_tagcontent'))

                    data.supplier_text = isNull(sp.getValue('custrecord_sp_vendordocs'))
                    data.consignor_text = isNull(sp.getValue('custrecord_sp_otherdocs_addremark'))

                    data.notice_purchase_demand = isNull(sp.getValue('custrecord_sp_poreq_othemark'))

                    let sender_name = sp.getValue('custrecord_sp_ifbolcorp_name')
                    let sender_add = sp.getValue('custrecord_sp_ifbol_address')
                    let sender_tel = sp.getValue('custrecord_sp_ifbol_phone')
                    let sender_fax = sp.getValue('custrecord_sp_ifbol_fax')
                    data.sender = (sender_name ? sender_name + '&#xA;' : '')
                        + (sender_add ? sender_add + '&#xA;' : '')
                        + (sender_tel ? 'TEL:' + sender_tel + '&#xA;' : '')
                        + (sender_fax ? 'FAX:' + sender_fax : '')

                    let recevier_name = sp.getValue('custrecord_sp_irbol_name')
                    let recevier_add = sp.getValue('custrecord_sp_irbol_address')
                    let recevier_tel = sp.getValue('custrecord_sp_irbol_phone')
                    let recevier_fax = sp.getValue('custrecord_sp_irbol_fax')
                    data.recevier = (recevier_name ? recevier_name + '&#xA;' : '')
                        + (recevier_add ? recevier_add + '&#xA;' : '')
                        + (recevier_tel ? 'TEL:' + recevier_tel + '&#xA;' : '')
                        + (recevier_fax ? 'FAX:' + recevier_fax : '')

                    let noticer_name = sp.getValue('custrecord_sp_notibol_name')
                    let noticer_add = sp.getValue('custrecord_sp_notibol_address')
                    let noticer_tel = sp.getValue('custrecord_sp_notibol_phone')
                    let noticer_fax = sp.getValue('custrecord_sp_lading_notifier')
                    data.noticer = (noticer_name ? noticer_name + '&#xA;' : '')
                        + (noticer_add ? noticer_add + '&#xA;' : '')
                        + (noticer_tel ? 'TEL:' + noticer_tel + '&#xA;' : '')
                        + (noticer_fax ? 'FAX:' + noticer_fax : '')

                    data.mark = isNull(sp.getValue('custrecord_sp_mark'))

                    let bolrequest = sp.getText('custrecord_sp_bolrequest')
                    let signway = sp.getText('custrecord_sp_signway')
                    let boltype = sp.getText('custrecord_sp_boltype')
                    let otherrequeest = sp.getValue('custrecord_sp_otherrequeest')
                    let vesselcom_ootreq = sp.getValue('custrecord_sp_vesselcom_ootreq')
                    data.document_require = (bolrequest ? bolrequest + ';&#xA;' : '')
                        + (signway ? '签单方式:' + signway + ';&#xA;' : '')
                        + (boltype ? '提单:' + boltype + ';&#xA;' : '')
                        + (otherrequeest ? '其他提单显示要求:' + otherrequeest + ';&#xA;' : '')
                        + (vesselcom_ootreq ? '其他提单要求:' + vesselcom_ootreq + ';' : '')

                    data.ship_date = dateTypeChange(sp.getText('custrecord_sp_shipto'))

                    data.trans_shipment_text = isNull(sp.getText('custrecord_sp_vessel_route'))

                    data.terminal_requirement = isNull(sp.getValue('custrecord_sp_destport_req'))

                    data.ship_card_text = sp.getValue('custrecord_sp_shippapers') ? '是' : '否'

                    data.free_box = isNull(sp.getText('custrecord_sp_timeof_freeconta') + sp.getValue('custrecord_sp_freeconta_remark'))

                    data.appoint_forwarder = isNull(sp.getValue('custrecord_sp_forward'))

                    data.ship_company_demand = isNull(sp.getValue('custrecord_sp_otherreeq'))

                    let invoice_check = isNull(sp.getValue('custrecord_sp_invoice_check'))
                    let invoice_check1 = isNull(sp.getValue('custrecord_sp_invoice_original'))
                    let invoice_check2 = isNull(sp.getValue('custrecord_sp_invoice_copy'))
                    let invoice_check3 = isNull(sp.getValue('custrecord_sp_invoice_elect'))
                    let invoice_check4 = isNull(sp.getValue('custrecord_sp_invoice_otherreq'))
                    data.extra_text1 = invoice_check ? '正本：' + (invoice_check1 || 0) + '；副本：' + (invoice_check2 || 0) + '；电子：' + (invoice_check3 || 0) + '；' + invoice_check4 : ''

                    let coa_type = isNull(sp.getValue('custrecord_sp_coa_type'))
                    let coa_type1 = isNull(sp.getValue('custrecord_sp_coa_original'))
                    let coa_type2 = isNull(sp.getValue('custrecord_sp_coa_copy'))
                    let coa_type3 = isNull(sp.getValue('custrecord_sp_coa_elect'))
                    let coa_type4 = isNull(sp.getValue('custrecord_sp_coa_otherreq'))
                    data.extra_text2 = coa_type == 1 ? '正本：' + (coa_type1 || 0) + '；副本：' + (coa_type2 || 0) + '；电子：' + (coa_type3 || 0) + '；' + coa_type4 : ''
                    data.extra_text7 = coa_type == 2 ? '正本：' + (coa_type1 || 0) + '；副本：' + (coa_type2 || 0) + '；电子：' + (coa_type3 || 0) + '；' + coa_type4 : ''

                    let msds_check = isNull(sp.getValue('custrecord_sp_msds_check'))
                    let msds_check1 = isNull(sp.getValue('custrecord_sp_msds_original'))
                    let msds_check2 = isNull(sp.getValue('custrecord_sp_msds_copy'))
                    let msds_check3 = isNull(sp.getValue('custrecord_sp_msds_elect'))
                    let msds_check4 = isNull(sp.getValue('custrecord_sp_msds_otherreq'))
                    data.extra_text3 = msds_check ? '正本：' + (msds_check1 || 0) + '；副本：' + (msds_check2 || 0) + '；电子：' + (msds_check3 || 0) + '；' + msds_check4 : ''

                    let pack_check = isNull(sp.getValue('custrecord_sp_pack_check'))
                    let pack_check1 = isNull(sp.getValue('custrecord_sp_pack_original'))
                    let pack_check2 = isNull(sp.getValue('custrecord_sp_pack_copy'))
                    let pack_check3 = isNull(sp.getValue('custrecord_sp_pack_elect'))
                    let pack_check4 = isNull(sp.getValue('custrecord_sp_pack_otherreq'))
                    data.extra_text4 = pack_check ? '正本：' + (pack_check1 || 0) + '；副本：' + (pack_check2 || 0) + '；电子：' + (pack_check3 || 0) + '；' + pack_check4 : ''

                    let insu_check = isNull(sp.getValue('custrecord_sp_insu_check'))
                    let insu_check1 = isNull(sp.getValue('custrecord_sp_insu_original'))
                    let insu_check2 = isNull(sp.getValue('custrecord_sp_insu_copy'))
                    let insu_check3 = isNull(sp.getValue('custrecord_sp_insu_elect'))
                    let insu_check4 = isNull(sp.getValue('custrecord_sp_insu_otherreq'))
                    data.extra_text5 = insu_check ? '正本：' + (insu_check1 || 0) + '；副本：' + (insu_check2 || 0) + '；电子：' + (insu_check3 || 0) + '；' + insu_check4 : ''

                    let origin_check = isNull(sp.getValue('custrecord_sp_origin_check'))
                    let origin_check1 = isNull(sp.getValue('custrecord_sp_origin_original'))
                    let origin_check2 = isNull(sp.getValue('custrecord_sp_origin_copy'))
                    let origin_check3 = isNull(sp.getValue('custrecord_sp_origin_elect'))
                    let origin_check4 = isNull(sp.getText('custrecord_sp_origin_certificate'))
                    let origin_check5 = isNull(sp.getValue('custrecord_sp_origin_otherreq'))
                    data.extra_text6 = origin_check ? '正本：' + (origin_check1 || 0) + '；副本：' + (origin_check2 || 0) + '；电子：' + (origin_check3 || 0) + '；' + origin_check4 + '；' + origin_check5 : ''

                    let healthy_check = isNull(sp.getValue('custrecord_sp_healthy_check'))
                    let healthy_check1 = isNull(sp.getValue('custrecord_sp_healthy_original'))
                    let healthy_check2 = isNull(sp.getValue('custrecord_sp_healthy_copy'))
                    let healthy_check3 = isNull(sp.getValue('custrecord_sp_healthy_elect'))
                    let healthy_check4 = isNull(sp.getValue('custrecord_sp_healthy_otherreq'))
                    data.extra_text10 = healthy_check ? '正本：' + (healthy_check1 || 0) + '；副本：' + (healthy_check2 || 0) + '；电子：' + (healthy_check3 || 0) + '；' + healthy_check4 : ''

                    data.bill_demand = isNull(sp.getValue('custrecord_sp_orderreq'))

                    data.document_detail = '公司名称：' + isNull(sp.getValue('custrecord_sp_deli_comname')) +
                        '&#xA;国家：' + isNull(sp.getValue('custrecord_sp_deli_country')) +
                        '&#xA;城市：' + isNull(sp.getValue('custrecord_sp_deli_city')) +
                        '&#xA;邮编：' + isNull(sp.getValue('custrecord_sp_deli_zip')) +
                        '&#xA;邮箱：' + isNull(sp.getValue('custrecord_sp_deli_email')) +
                        '&#xA;详细地址：' + isNull(sp.getValue('custrecord_sp_deli_address')) +
                        '&#xA;联系人：' + isNull(sp.getValue('custrecord_sp_deli_contract')) +
                        '&#xA;电话：' + isNull(sp.getValue('custrecord_sp_deli_phone'))

                    data.lc_arrive_date = dateTypeChange(sp.getText('custrecord_sp_lcdate'))

                    data.lc_no = isNull(sp.getValue('custrecord_sp_lcno'))

                    data.buyer_no = isNull(x.getValue(columns[12]))

                    data.letter_credit_flag_text = isNull(sp.getText('custrecord_sp_surptype'))

                    data.credit_flag_text = sp.getValue('custrecord_sp_apply') ? '是' : '否'

                    data.note = isNull(sp.getValue('custrecord_sp_memo'))
                }

                let item_id = x.getValue(columns[2])
                let item = record.load({
                    type: 'lotnumberedinventoryitem',
                    id: item_id
                })

                let line = {
                    goods_name: isNull(x.getValue(columns[3])),
                    goods_account: isNull(x.getValue(columns[4]) + x.getText(columns[5])),
                    package_name: isNull(item.getValue('custitem_ecm_package_remk_cn')),
                    package_label: isNull(x.getValue(columns[7]) - x.getValue(columns[6])),
                    pallet_wrap: x.getValue(columns[8]) ? '是' : '否',
                    hscode: isNull(x.getValue(columns[9])),
                    goods_description: isNull(x.getValue(columns[13]))
                }

                list.push(line)

            })

            data.list = list

            return data
        }

        // 如果取值为空则单元格为空
        function isNull(someValue) {
            if (someValue == '' || someValue == null) {
                return '';
            } else {
                if (isNaN(someValue) && someValue.indexOf("&") >= 0) {
                    someValue = someValue.replace(/&/g, "&amp;");
                }
                return someValue;
            }
        }

        function dateTypeChange(date) {
            if (date) {
                let arr = date.split('/')
                if (arr.length == 3) {
                    return arr[2] + '-' + arr[0] + '-' + arr[1]
                } else {
                    return date
                }
            } else date
        }

        return { onRequest }

    });
