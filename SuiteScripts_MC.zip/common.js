/**
 * @NApiVersion 2.x
 * @NModuleScope Public
 */

define([],

    function () {

        function translate(number) {
            // number = 998.678;
            if (number < 0) {
                s = "error";
                return s;
            }

            let result = toEnglish(number)
            // 有小数的情况
            if ((number + '').indexOf('.') != -1) {
                result = result + ' POINT';
                let str = (number + '')
                // 截取小数部分字符串
                let small = str.substr(str.indexOf('.') + 1, str.length - str.indexOf('.'))
                for (i = 0; i < small.length; i++) {
                    result = result + ' ' + oneByOneTran(small.charAt(i))
                }
            }
            if (result) {
                result = result.toUpperCase() + ' ONLY'
            }
            return result
        }

        function oneByOneTran(n) {
            switch (parseInt(n)) {
                case 0:
                    s = "zero";
                    return s;
                case 1:
                    s = "one";
                    return s;
                case 2:
                    s = "two";
                    return s;
                case 3:
                    s = "three";
                    return s;
                case 4:
                    s = "four";
                    return s;
                case 5:
                    s = "five";
                    return s;
                case 6:
                    s = "six";
                    return s;
                case 7:
                    s = "seven";
                    return s;
                case 8:
                    s = "eight";
                    return s;
                case 9:
                    s = "nine";
                    return s;
            }
        }

        function toEnglish(number) {
            let s
            if (number < 20) {
                switch (parseInt(number)) {
                    case 0:
                        s = "zero";
                        return s;
                    case 1:
                        s = "one";
                        return s;
                    case 2:
                        s = "two";
                        return s;
                    case 3:
                        s = "three";
                        return s;
                    case 4:
                        s = "four";
                        return s;
                    case 5:
                        s = "five";
                        return s;
                    case 6:
                        s = "six";
                        return s;
                    case 7:
                        s = "seven";
                        return s;
                    case 8:
                        s = "eight";
                        return s;
                    case 9:
                        s = "nine";
                        return s;
                    case 10:
                        s = "ten";
                        return s;
                    case 11:
                        s = "eleven";
                        return s;
                    case 12:
                        s = "twelve";
                        return s;
                    case 13:
                        s = "thirteen";
                        return s;
                    case 14:
                        s = "fourteen";
                        return s;
                    case 15:
                        s = "fifteen";
                        return s;
                    case 16:
                        s = "sixteen";
                        return s;
                    case 17:
                        s = "seventeen";
                        return s;
                    case 18:
                        s = "eighteen";
                        return s;
                    case 19:
                        s = "nineteen";
                        return s;
                    default:
                        s = "error";
                        return s;
                }
            }

            if (number < 100) {
                if (number % 10 == 0) {
                    switch (number) {
                        case 20:
                            s = "twenty";
                            return s;
                        case 30:
                            s = "thirty";
                            return s;
                        case 40:
                            s = "forty";
                            return s;
                        case 50:
                            s = "fifty";
                            return s;
                        case 60:
                            s = "sixty";
                            return s;
                        case 70:
                            s = "seventy";
                            return s;
                        case 80:
                            s = "eighty";
                            return s;
                        case 90:
                            s = "ninety";
                            return s;
                        default:
                            s = "error";
                            return s;
                    }
                } else {
                    s = toEnglish(parseInt(number / 10) * 10) + ' ' +
                        toEnglish(parseInt((number % 10)));
                    return s;
                }
            }

            if (number < 1000) {
                if (number % 100 == 0) {
                    s = toEnglish(parseInt(number / 100)) + " hundred";
                    return s;
                } else {
                    s = toEnglish(parseInt(number / 100)) + " hundred and " +
                        toEnglish(parseInt(number % 100));
                    return s;
                }
            }

            if (number < 1000000) {
                if (number % 1000 == 0) {
                    s = toEnglish(parseInt(number / 1000)) + " thousand";
                    return s;
                } else {
                    s = toEnglish(parseInt(number / 1000)) + " thousand " +
                        toEnglish(parseInt(number % 1000));
                    return s;
                }
            }



            if (number < 1000000000) {
                if (number % 1000000 == 0) {
                    s = toEnglish(parseInt(number / 1000000)) + " million";
                    return s;
                } else {
                    s = toEnglish(parseInt(number / 1000000)) + " million " +
                        toEnglish(parseInt(number % 1000000));
                    return s;
                }
            }
            return s;
            // if (number < 999999999) {
            //     if (number % 1000000000 == 0) {
            //         s = toEnglish(number / 1000000000) + " billion";
            //         return s;
            //     } else {
            //         s = toEnglish(number / 1000000000) + " billion "
            //             + toEnglish(number % 1000000000);
            //         return s;
            //     }
            // }

        }

        return {
            translate: translate
        }
    })