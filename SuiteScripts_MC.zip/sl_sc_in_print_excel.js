/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 */
define(['N/encode', 'N/file', 'N/record', 'N/render', 'N/search', 'SuiteScripts/tools/common_api.js'],
    /**
 * @param{encode} encode
 * @param{file} file
 * @param{record} record
 * @param{render} render
 * @param{search} search
 */
    (encode, file, record, render, search, commonApi) => {
        /**
         * Defines the Suitelet script trigger point.
         * @param {Object} scriptContext
         * @param {ServerRequest} scriptContext.request - Incoming request
         * @param {ServerResponse} scriptContext.response - Suitelet response
         * @since 2015.2
         */
        const onRequest = (scriptContext) => {
            let request = scriptContext.request;
            let response = scriptContext.response;
            if (request.method == 'GET') {
                let plId = request.parameters.rec_id;
                let excel_type = request.parameters.excel_type
                let xmlStr = getXml(plId, excel_type);
                //写文件
                response.writeFile(xmlStr);
            }
        }

        function getXml(plId, excel_type) {
            let customerPrintFormat = {
                Sale_Contract_Excel: 'SuiteScripts/SuiteScripts_MC/中国内贸合同.txt',
                Sale_Contract_Vip: 'SuiteScripts/SuiteScripts_MC/网站会员服务合同（国内）.txt'
            };

            let plObj = record.load({
                type: 'salesorder',
                id: plId
            });
            let xlsName = plObj.getValue('tranid');
            // let template = plObj.getValue('custrecord_amg_pl_download'); //文件类型

            let printFormat
            if (excel_type == 5) {
                printFormat = customerPrintFormat.Sale_Contract_Excel;
            } else if (excel_type == 6) {
                printFormat = customerPrintFormat.Sale_Contract_Vip;
            }
            let tempFile = file.load({
                id: printFormat
            });

            let t_render = render.create();
            //模板的内容
            t_render.templateContent = tempFile.getContents();

            let allData = getData(plId, excel_type);

            t_render.addCustomDataSource({
                alias: 'data',
                format: render.DataSource.OBJECT,
                data: allData
            });

            let excel_str = t_render.renderAsString();

            //将字符串转换为另一种类型的编码
            let fstr = encode.convert({
                string: excel_str,
                inputEncoding: encode.Encoding.UTF_8,
                outputEncoding: encode.Encoding.BASE_64
            });

            let name = xlsName + ' Sales Order' + '.xls';

            let excel = file.create({
                name: name,
                fileType: file.Type.EXCEL,
                //folder : 369,
                contents: fstr
            });
            return excel;
        }

        function getData(plId, excel_type) {
            let data = {};

            let filters = [];
            filters.push(['type', 'anyof', "SalesOrd"]);
            filters.push('and');
            filters.push(['internalid', 'anyof', plId]);
            filters.push('and');
            filters.push(["mainline", "is", "F"],);
            filters.push('and');
            filters.push(["taxline", "is", "F"])
            filters.push('and');
            filters.push(['item', "noneof", "@NONE@"]);

            let columns = [];

            columns = getSalesOrderColumns(columns)

            let mySearch = search.create({
                type: 'salesorder',
                filters: filters,
                columns: columns
            });
            let result = commonApi.getAllData(mySearch);
            log.debug('res', result);
            if (result) {
                data = getSalesOrderResult(result, columns, plId, excel_type);
            }
            log.debug('data', JSON.stringify(data));
            return data;
        }

        function getSalesOrderColumns(columns) {
            columns.push(search.createColumn({
                name: 'custrecord_ecm_subname_cn',
                join: 'subsidiary'
            }));
            columns.push(search.createColumn({
                name: 'tranid'
            }));
            columns.push(search.createColumn({
                name: 'legalname',
                join: 'subsidiary'
            }));
            columns.push(search.createColumn({
                name: 'custbody_ecm_signaddress_cn',
            }));
            columns.push(search.createColumn({
                name: 'trandate',
            }));
            columns.push(search.createColumn({
                name: 'custcol_ecm_productname_cn',
            }));
            columns.push(search.createColumn({
                name: 'custitem_ecm_spec_combine_cn',
                join: 'item'
            }));
            columns.push(search.createColumn({
                name: 'custitem_ecm_brand',
                join: 'item'
            }));
            columns.push(search.createColumn({
                name: 'custcol_ecm_product_othermemo',
            }));
            columns.push(search.createColumn({
                name: 'custbody_ecm_skuspec_isdisplay',
            }));
            columns.push(search.createColumn({
                name: 'custbody_ecm_skubrand_isdisplay',
            }));
            columns.push(search.createColumn({
                name: 'unitstype',
                join: 'item'
            }));
            columns.push(search.createColumn({
                name: 'custcol_ecm_packageremark'
            }));
            columns.push(search.createColumn({
                name: 'custitem_ecm_case_package_kg',
                join: 'item'
            }));
            columns.push(search.createColumn({
                name: 'custitem_ecm_wgt_unit',
                join: 'item'
            }));
            columns.push(search.createColumn({
                name: 'custitem_ecm_package_remk_cn',
                join: 'item'
            }));
            columns.push(search.createColumn({
                name: 'rate',
            }));
            columns.push(search.createColumn({
                name: 'quantity',
            }));
            columns.push(search.createColumn({
                name: 'unit',
            }));
            columns.push(search.createColumn({
                name: 'custbody_ecm_leadtime',
            }));
            columns.push(search.createColumn({
                name: 'custbody_ecm_incoterm',
            }));
            columns.push(search.createColumn({
                name: 'custbody_ecm_delivery_address'
            }));
            columns.push(search.createColumn({
                name: 'shipaddress',
            }));
            columns.push(search.createColumn({
                name: 'custbody_ecm_termsdisplay_en',
            }));
            columns.push(search.createColumn({
                name: 'custrecord_ecm_subaddress_cn',
                join: 'subsidiary'
            }));
            columns.push(search.createColumn({
                name: 'entity'
            }));
            columns.push(search.createColumn({
                name: 'custrecord37',
                join: 'subsidiary'
            }));
            columns.push(search.createColumn({
                name: 'fax',
                join: 'subsidiary'
            }));
            columns.push(search.createColumn({
                name: 'vatregnumber',
                join: 'customer'
            }));
            columns.push(search.createColumn({
                name: 'custbody_ecm_bankaccount',
            }));
            columns.push(search.createColumn({
                name: 'phone',
                join: 'customer'
            }));
            columns.push(search.createColumn({
                name: 'fax',
                join: 'customer'
            }));
            columns.push(search.createColumn({
                name: 'companyname',
                join: 'customer'
            }));
            columns.push(search.createColumn({
                name: 'custbody_ecm_bankinfoma',
            }));
            columns.push(search.createColumn({
                name: 'custentity_ecm_nameen',
                join: 'customer'
            }));
            columns.push(search.createColumn({
                name: 'custitem_ecm_serviceperiod',
                join: 'item'
            }));
            columns.push(search.createColumn({
                name: 'custitem_ecm_servicedetail',
                join: 'item'
            }));
            columns.push(search.createColumn({
                name: 'custrecord_ecm_trade_electricseal',
                join: 'subsidiary'
            }));
            columns.push(search.createColumn({
                name: 'custentity_ecm_licenseno',
                join: 'customer'
            }));
            columns.push(search.createColumn({
                name: 'custitem_ecm_productname_cn',
                join: 'item'
            }));

            return columns
        }

        function getSalesOrderResult(result, columns, plId, excel_type) {
            let data = {};
            let list1 = [];

            result.forEach((x, i) => {
                let sales_order = record.load({
                    type: 'salesorder',
                    id: plId
                })

                if (i == 0) {
                    let name = x.getValue(columns[0])
                    let tranid = x.getValue(columns[1])
                    let legalname = x.getValue(columns[2])
                    let signaddress_cn = x.getValue(columns[3])
                    let trandate = x.getValue(columns[4])
                    let leadtime = x.getValue(columns[19])
                    let trade_type = x.getText(columns[20]);
                    let delivery_address = x.getValue(columns[21]);
                    let shipaddress = x.getValue(columns[22]);
                    let termsdisplay_en = x.getValue(columns[23]);
                    let address = x.getValue(columns[24]);
                    let customer_id = x.getValue(columns[25]);
                    let phone = x.getValue(columns[26]);
                    let fax = x.getValue(columns[27]);
                    let vatregnumber = x.getValue(columns[28]);
                    let bank_account = x.getValue(columns[29]);
                    let customer_phone = x.getValue(columns[30]);
                    let customer_fax = x.getValue(columns[31]);
                    let customer_cn = x.getValue(columns[32]);
                    let bank_id = x.getValue(columns[33]);
                    let customer_en = x.getValue(columns[34]);
                    let seal_id = x.getValue(columns[37]);
                    let license_no = x.getValue(columns[38])

                    let total_amount = sales_order.getValue('total');
                    let subtotal = sales_order.getValue('subtotal')

                    let transation_address, cost, is_total
                    if (trade_type == 'EXW') {
                        transation_address = delivery_address
                        cost = '需方承担运费'
                        is_total = ''
                    } else {
                        transation_address = shipaddress
                        cost = '供方承担运费'
                        is_total = '总金额包含运费。'
                    }

                    let customer_message, customer_address;
                    if (customer_id) {
                        customer_message = record.load({
                            type: 'customer',
                            id: customer_id
                        })
                        customer_address = customer_message.getValue('defaultaddress')
                    }

                    let seller_person = sales_order.getValue('salesrep')
                    let seller_message, employee, email;
                    if (seller_person) {
                        seller_message = record.load({
                            type: 'employee',
                            id: seller_person
                        })
                        employee = seller_message.getValue('custentity_ecm_cn_name')
                        email = seller_message.getValue('email')
                    }

                    let seller_id = sales_order.getValue('subsidiary')
                    let seller_company = record.load({
                        type: 'subsidiary',
                        id: seller_id
                    })
                    let federalidnumber = seller_company.getValue('federalidnumber')

                    let bank_info, bank
                    if (bank_id) {
                        bank_info = record.load({
                            type: 'customrecord_ecm_bankinfo',
                            id: bank_id
                        })
                        bank = bank_info.getValue('custrecord_ecm_beneficiarybankcn')
                    }

                    let picFile, picData
                    let picObj = {
                        vip: '------=_NextPart_01D96E30.C2C7CD60\n'
                            + 'Content-Location: file:///C:/35647555/file6085.files/seal\n'
                            + 'Content-Transfer-Encoding: base64\n'
                            + 'Content-Type: image/png\n\n',
                    }
                    if (excel_type == 6) {
                        if (seal_id) {
                            picFile = file.load({ id: seal_id });
                            picData = picObj.vip + picFile.getContents();
                        }
                    }

                    data.name = isNull(name)
                    data.tranid = isNull(tranid)
                    data.legalname = isNull(legalname)
                    data.signaddress_cn = isNull(signaddress_cn)
                    data.trandate = dateTypeChange(trandate)
                    data.leadtime = dateTypeChange(leadtime)
                    data.transation_address = isNull(transation_address)
                    data.cost = isNull(cost)
                    data.termsdisplay_en = isNull(termsdisplay_en)
                    data.is_total = isNull(is_total)
                    data.address = isNull(address)
                    data.customer_address = isNull(customer_address)
                    data.employee = isNull(employee)
                    data.phone = isNull(phone)
                    data.fax = isNull(fax)
                    data.bank_account = isNull(bank_account)
                    data.federalidnumber = isNull(federalidnumber)
                    data.vatregnumber = isNull(vatregnumber)
                    data.customer_phone = isNull(customer_phone)
                    data.customer_fax = isNull(customer_fax)
                    data.customer_cn = isNull(customer_cn)
                    data.bank = isNull(bank)
                    data.customer_employee = getCustomerName(plId)
                    data.customer_en = isNull(customer_en)
                    data.email = isNull(email)
                    data.picname = 'seal'
                    data.picdata = isNull(picData)
                    data.license_no = isNull(license_no)
                    data.total_amount = isNull(Number(total_amount).toFixed(2))
                    data.amount_cn = dealBigMoney(total_amount)
                    data.subtotal = isNull(subtotal)
                }

                let detail_name = x.getValue(columns[5])

                let arr1 = []
                arr1.push(x.getValue(columns[6]))
                arr1.push(x.getValue(columns[7]))
                arr1.push(x.getValue(columns[8]))
                let arr2 = []
                arr2.push(x.getValue(columns[9]))
                arr2.push(x.getValue(columns[10]))
                let detail_specification = ''
                for (let y = 0; y < arr1.length; y++) {
                    if (y < arr2.length) {
                        if (arr1[y] != '' && arr2[y]) {
                            detail_specification += arr1[y] + '<br>'
                        }
                    } else {
                        if (arr1[y] != '') {
                            detail_specification += arr1[y] + '<br>'
                        }
                    }
                }

                let unittype = x.getValue(columns[11]);
                let detail_packing;
                if (unittype == 7) {
                    detail_packing = x.getValue(columns[13]) + x.getText(columns[14]) + '/' + x.getValue(columns[15]) + ';<br>'
                        + x.getValue(columns[12]);
                } else {
                    detail_packing = x.getValue(columns[12]);
                }

                let tax_rate = sales_order.getSublistValue({
                    sublistId: 'item',
                    fieldId: 'taxrate1',
                    line: i
                })
                let rate = sales_order.getSublistValue({
                    sublistId: 'item',
                    fieldId: 'custcol_ecm_price_packunit',
                    line: i
                })
                let detail_unit_price = (Number(rate) * (100 + Number(tax_rate ? tax_rate : 0))) / 100

                let detail_quantity = sales_order.getSublistValue({
                    sublistId: 'item',
                    fieldId: 'custcol_ecm_qty_packunit',
                    line: i
                });
                let detail_unit = sales_order.getSublistText({
                    sublistId: 'item',
                    fieldId: 'custcol_ecm_wgt_unit',
                    line: i
                });
                let detail_amount = sales_order.getSublistValue({
                    sublistId: 'item',
                    fieldId: 'grossamt',
                    line: i
                })
                let sub_amount = sales_order.getSublistValue({
                    sublistId: 'item',
                    fieldId: 'amount',
                    line: i
                });

                let good_name = x.getValue(columns[39])
                let server_date = x.getValue(columns[35])
                let remark = x.getValue(columns[36])

                let line = {
                    good_name,
                    'commodity_name': detail_name,
                    'specification': detail_specification,
                    'packing': detail_packing != '/;<br>' ? detail_packing : '',
                    'unit_price': detail_unit_price ? detail_unit_price.toFixed(2) : 0,
                    unit_price_1: rate ? Number(rate).toFixed(2) : 0,
                    'quantity': detail_quantity,
                    'unit': detail_unit,
                    'amount': detail_amount ? Number(detail_amount).toFixed(2) : 0,
                    sub_amount,
                    server_date,
                    remark
                }

                list1.push(line)
            })

            data.list = list1


            return data
        }

        function getCustomerName(scId) {
            let salesorderSearchObj = search.create({
                type: "salesorder",
                filters: [
                    ["type", "anyof", "SalesOrd"],
                    "AND",
                    ["mainline", "is", "F"],
                    "AND",
                    ["taxline", "is", "F"],
                    "AND",
                    ["internalid", "anyof", scId]],
                columns: [
                    search.createColumn({
                        name: "entityid",
                        join: "contactPrimary",
                        label: "名称"
                    }),
                ]
            });
            let columns = salesorderSearchObj.columns;
            let result = salesorderSearchObj.run().getRange({ start: 0, end: 1000 })
            if (result && result.length > 0) {
                return result[0].getValue(columns[0])
            }
        }

        // 如果取值为空则单元格为空
        function isNull(someValue) {
            if (someValue == '' || someValue == null) {
                return '';
            } else {
                if (isNaN(someValue) && someValue.indexOf("&") >= 0) {
                    someValue = someValue.replace(/&/g, "&amp;");
                }
                return someValue;
            }
        }


        /** 数字金额大写转换(可以处理整数,小数,负数) */
        function dealBigMoney(n) {
            var fraction = ['角', '分'];
            var digit = ['零', '壹', '贰', '叁', '肆', '伍', '陆', '柒', '捌', '玖'];
            var unit = [['元', '万', '亿'], ['', '拾', '佰', '仟']];
            var head = n < 0 ? '欠' : '';
            n = Math.abs(n);

            var s = '';

            for (var i = 0; i < fraction.length; i++) {
                s += (digit[Math.floor(n * 10 * Math.pow(10, i)) % 10] + fraction[i]).replace(/零./, '');
            }
            s = s || '整';
            n = Math.floor(n);

            for (var i = 0; i < unit[0].length && n > 0; i++) {
                var p = '';
                for (var j = 0; j < unit[1].length && n > 0; j++) {
                    p = digit[n % 10] + unit[1][j] + p;
                    n = Math.floor(n / 10);
                }
                s = p.replace(/(零.)*零$/, '').replace(/^$/, '零') + unit[0][i] + s;
            }
            return head + s.replace(/(零.)*零元/, '元').replace(/(零.)+/g, '零').replace(/^整$/, '零元整');
        }

        // yyyy/MM/dd -> yyyy年MM月dd日
        function dateTypeChange(date) {
            let arr = date.split('/')

            if (arr.length == 3) {
                return arr[2] + '年' + arr[0] + '月' + arr[1] + '日'
            } else {
                return date
            }
        }

        return { onRequest }

    });
