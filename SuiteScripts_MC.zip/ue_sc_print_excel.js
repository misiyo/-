/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 */
define(['N/record', 'N/url', 'N/runtime'],
    /**
 * @param{url} url
 * @param{record} record
 * @param{runtime} runtime
 */
    (record, url, runtime) => {
        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {
            let typeObj = scriptContext.type;
            let newRec = scriptContext.newRecord;
            let curForm = scriptContext.form;
            if (typeObj == 'view') {
                let business_type = newRec.getValue('custbody_ecm_contract_type')
                log.debug('业务类型', newRec.getText('custbody_ecm_contract_type'))
                log.debug('business_type', business_type)

                let iscrossborder = newRec.getValue('custbody_ecm_iscrossborder');
                log.debug('是否跨境', iscrossborder)
                log.debug('iscrossborder', iscrossborder)

                let destination_country = newRec.getValue('custbody_ecm_countryof_destination')
                log.debug('目的国', newRec.getText('custbody_ecm_countryof_destination'))
                log.debug('destination_country', destination_country)

                let subsidiary = newRec.getValue('subsidiary')
                log.debug('子公司', newRec.getText('subsidiary'))
                log.debug('subsidiary', subsidiary)

                let entity = newRec.getValue('entity')
                let customer = record.load({
                    type: 'customer',
                    id: entity
                })
                let country = customer.getSublistValue({
                    sublistId: 'addressbook',
                    fieldId: 'country_initialvalue',
                    line: 0
                })
                let urlObj = {
                    outUrl: url.resolveScript({
                        scriptId: 'customscript_sl_sc_print_excel',
                        deploymentId: 'customdeploy_sl_sc_print_excel',
                    }),
                    inUrl: url.resolveScript({
                        scriptId: 'customscript_sl_sc_in_print_excel',
                        deploymentId: 'customdeploy_sl_sc_in_print_excel',
                    }),
                }
                // 1 common 2 荷兰 3 德国 4 美国 5 内贸 6 国内会员 7 海外会员
                let urlObjType, excel_type
                if (business_type == 4 || business_type == 6) {
                    urlObjType = urlObj.outUrl
                    excel_type = 1
                } else if (business_type == 5) {
                    if (iscrossborder) {
                        urlObjType = urlObj.outUrl
                        excel_type = 1
                    } else {
                        if (destination_country == 47) {
                            urlObjType = urlObj.inUrl
                            excel_type = 5
                        } else {
                            if (subsidiary == 29) {
                                urlObjType = urlObj.outUrl
                                excel_type = 2
                            } else if (subsidiary == 31) {
                                urlObjType = urlObj.outUrl
                                excel_type = 4
                            } else if (subsidiary == 28) {
                                urlObjType = urlObj.outUrl
                                excel_type = 3
                            } else {
                                urlObjType = urlObj.outUrl
                                excel_type = 1
                            }
                        }
                    }
                } else if (business_type == 7) {
                    if (country == 'CN') {
                        urlObjType = urlObj.inUrl
                        excel_type = 6
                    } else {
                        urlObjType = urlObj.outUrl
                        excel_type = 7
                    }
                }

                let printExcel = "window.open('" + urlObjType + "&rec_id=" + newRec.id + "&type=excel&excel_type=" + excel_type + "','_self')";
                curForm.addButton({
                    id: 'custpage_dl_1',
                    label: 'Print SC-Execl',
                    functionName: printExcel
                })
                if (business_type != 7) {
                    let printPI = "window.open('" + urlObj.outUrl + "&rec_id=" + newRec.id + "&type=pi&excel_type=0','_self')";
                    curForm.addButton({
                        id: 'custpage_dl_2',
                        label: 'Print PI-Execl',
                        functionName: printPI
                    })
                }
            }
        }

        /**
         * Defines the function definition that is executed before record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const beforeSubmit = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {

        }

        return {
            beforeLoad,
            // beforeSubmit, 
            // afterSubmit
        }

    });
