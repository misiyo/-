/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 */
define(['N/url', 'N/record'],
    /**
 * @param{url} url
 * @param{record} record
 */
    (url, record) => {
        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {
            let typeObj = scriptContext.type;
            let newRec = scriptContext.newRecord;
            let curForm = scriptContext.form;
            if (typeObj == 'view') {
                let plObj = record.load({
                    type: 'invoice',
                    id: newRec.id
                });
                let sc_id = plObj.getValue('createdfrom')
                let sc_type
                if (sc_id) {
                    let sc = record.load({
                        type: 'salesorder',
                        id: sc_id
                    })
                    sc_type = sc.getValue('custbody_ecm_contract_type')
                }
                if (sc_type == 4 || sc_type == 5) {
                    let urlObjType = url.resolveScript({
                        scriptId: 'customscript_sl_ci_print_excel',
                        deploymentId: 'customdeploy_sl_ci_print_excel',
                    })
                    let printExcel = "window.open('" + urlObjType + "&rec_id=" + newRec.id + "','_self')";
                    curForm.addButton({
                        id: 'custpage_dl_1',
                        label: 'Finance Inv',
                        functionName: printExcel
                    })
                } else if (sc_type == 7) {
                    let invUrl = url.resolveScript({
                        scriptId: 'customscript_ecm_inv_print_excel_sl',
                        deploymentId: 'customdeploy_ecm_inv_print_excel_sl',
                        // returnExternalUrl: true
                    });
                    let printInv = "window.open('" + invUrl + "&rec_id=" + newRec.id + "&rec_type=" + newRec.type + "','_self')";
                    curForm.addButton({
                        id: "custpage_ecm_invoice_print_btn",
                        label: "Finance Inv",
                        functionName: printInv
                    });
                }
            }
        }

        /**
         * Defines the function definition that is executed before record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const beforeSubmit = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {

        }

        return {
            beforeLoad,
            // beforeSubmit,
            // afterSubmit
        }

    });
