/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 * Version        Date(M-D-Y)            Author              Remark
 * 1.0            2/28/2023              Kori                TAPD【1018680】根据PO创建IR单后，将采购收货单的数量反写SP子记录的【实际出运数量】。
 * 2.0            3/01/2023              Kori                记录type、sublistId、fieldId变更及测试支持
 * 已作废            已作废                已作废                已作废
 */
define(['N/currentRecord', 'N/search', 'N/record'],
/**
 * @param{currentRecord} currentRecord
 * @param{search} search
 */
function(currentRecord, search, record) {
    
    /**
     * Function to be executed after page is initialized.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.mode - The mode in which the record is being accessed (create, copy, or edit)
     *
     * @since 2015.2
     */
    function pageInit(scriptContext) {

    }

    /**
     * Function to be executed when field is changed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
     * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
     *
     * @since 2015.2
     */
    function fieldChanged(scriptContext) {

    }

    /**
     * Function to be executed when field is slaved.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     *
     * @since 2015.2
     */
    function postSourcing(scriptContext) {

    }

    /**
     * Function to be executed after sublist is inserted, removed, or edited.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @since 2015.2
     */
    function sublistChanged(scriptContext) {

    }

    /**
     * Function to be executed after line is selected.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @since 2015.2
     */
    function lineInit(scriptContext) {

    }

    /**
     * Validation function to be executed when field is changed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
     * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
     *
     * @returns {boolean} Return true if field is valid
     *
     * @since 2015.2
     */
    function validateField(scriptContext) {

    }

    /**
     * Validation function to be executed when sublist line is committed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateLine(scriptContext) {

    }

    /**
     * Validation function to be executed when sublist line is inserted.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateInsert(scriptContext) {

    }

    /**
     * Validation function to be executed when record is deleted.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateDelete(scriptContext) {

    }

    /**
     * Validation function to be executed when record is saved.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @returns {boolean} Return true if record is valid
     *
     * @since 2015.2
     */
    function saveRecord(scriptContext) {
        var newRec = scriptContext.currentRecord;
        var isPoRec = true;
        var createFromTypeInfo = search.lookupFields({type:'itemreceipt',id:newRec.id,columns:['createdfrom.type']});
        var createFromType = createFromTypeInfo['createdfrom.type'][0].value;
        console.log('createFromTypeInfo',createFromTypeInfo);
        console.log('createFromType',createFromType);
        if(createFromType != 'PurchOrd'){
            isPoRec = false;
        }
        if(isPoRec){
            var lineCount = newRec.getLineCount('item');
            if(lineCount > 0){
                var spId = newRec.getValue('custbody_ecm_sp');
                if(spId){
                    var spRec = record.load({type:'customrecord_ecm_sp', id:spId});
                    var spStatus = spRec.getValue('custrecord_sp_status');
                    if(spStatus != '5' && spStatus != 5){//未完结
                        var irData = getIrData(newRec);
                        if(irData.length > 0){//sp回写数量
                            var spCount = spRec.getLineCount({sublistId:'recmachcustrecord_scdline_sp'});
                            for(var i = 0; i < spCount; i++){
                                for(var j =0; j < irData.length; j++){
                                    var spItem = spRec.getSublistValue({sublistId:'recmachcustrecord_scdline_sp', fieldId:'custrecord_scdline_item', line: i});
                                    var spLine = spRec.getSublistValue({sublistId:'recmachcustrecord_scdline_sp', fieldId:'custrecord_scdline_scdlineid', line: i});
                                    if(spItem == irData[j].irItem && spLine == irData[j].irLine){
                                        spRec.setSublistValue({sublistId:'recmachcustrecord_scdline_sp',fieldId:'custrecord_scdline_spqty',value:irData[j].irQty,line:i})
                                    }
                                }
                            }
                            spRec.save({enableSourcing:true,ignoreMandatoryFields:true});
                        }
                    }
                }
            }
        }
        return true;
    }

    /**
     * 获取IR单明细行的数据
     * @param newRec
     * @returns {*[]}
     */
    function getIrData(newRec) {
        var irData = [];
        var irCount = newRec.getLineCount({sublistId:'item'});
        if(irCount > 0){
            for(var index = 0; index < irCount; index ++){
                var irItem = newRec.getSublistValue({sublistId:'item', fieldId:'item', line:index});
                var irLine = newRec.getSublistValue({sublistId:'item', fieldId:'custcol_ecm_uniquekey', line:index});
                var irQty = newRec.getSublistValue({sublistId:'item', fieldId:'quantity', line:index}) || 0;
                var irJson = {
                    irItem:irItem,
                    irLine:irLine,
                    irQty:irQty,
                }
                var createIr = true;
                for(var i = 0; i < irData.length; i++){
                    // if(irData[i].irItem == irItem && irLine == irData[i].irLine){
                    if(irData[i].irItem == irItem && irLine == irData[i].irLine){
                        createIr = false;
                        irData[i].irQty = Number(irData[i].irQty).add(Number(irQty));
                        break;
                    }
                }
                if(createIr && irLine){//首行
                    irData.push(irJson)
                }
            }
        }
        return irData;
    }

    /**
     * 自定义加法运算
     * @param arg1
     * @param arg2
     * @return {number}
     */
    function accAdd(arg1, arg2) {
        var r1, r2, m, c;
        try {
            r1 = arg1.toString().split(".")[1].length;
        } catch (e) {
            r1 = 0;
        }
        try {
            r2 = arg2.toString().split(".")[1].length;
        } catch (e) {
            r2 = 0;
        }
        c = Math.abs(r1 - r2);
        m = Math.pow(10, Math.max(r1, r2));
        if (c > 0) {
            var cm = Math.pow(10, c);
            if (r1 > r2) {
                arg1 = Number(arg1.toString().replace(".", ""));
                arg2 = Number(arg2.toString().replace(".", "")) * cm;
            } else {
                arg1 = Number(arg1.toString().replace(".", "")) * cm;
                arg2 = Number(arg2.toString().replace(".", ""));
            }
        } else {
            arg1 = Number(arg1.toString().replace(".", ""));
            arg2 = Number(arg2.toString().replace(".", ""));
        }
        return (arg1 + arg2) / m;
    }
    Number.prototype.add = function (arg) {
        return accAdd(arg, this);
    }

    /**
     * 获取全部数据
     * @param searchObj
     * @return {Result[]}
     */
    function getAllData(searchObj) {
        var searchRun = searchObj.run();
        var datas = searchRun.getRange({ start: 0, end: 1000 });
        var length = 1000;
        while (datas) {
            if (datas.length == length) {
                var tResults = searchRun.getRange({ start: length, end: length + 1000 });
                if (tResults.length > 0) {
                    datas = datas.concat(tResults);
                }
                length = length + 1000;
            }
            else {
                break;
            }
        }
        return datas;
    }

    return {
        pageInit: pageInit,
        // fieldChanged: fieldChanged,
        // postSourcing: postSourcing,
        // sublistChanged: sublistChanged,
        // lineInit: lineInit,
        // validateField: validateField,
        // validateLine: validateLine,
        // validateInsert: validateInsert,
        // validateDelete: validateDelete,
        saveRecord: saveRecord
    };
    
});
