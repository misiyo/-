/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * Version          Date(m-d-y)          Author        Remark
 * 1.0              2023/3/2             Kori          TAPD【1018618】基于SP公司间自动生成发票
 * 1.1              2023/3/7             Kori          TAPD【1018618】账单class字段、memo字段取值变更，ordertype条件
 * 1.2              2023/3/7             Kori          TAPD【1018618】新增：库存详细信息带值
 * 1.3              2023/3/13            Kori          增加取值字段
 * 1.4              2023/3/15            Kori          【记】:转发票，库存详细信息序号为列表类型，无须重新塞值
 * 1.5              2023/3/21            Kori          优化rate数值异常问题
 */
define(['N/record', 'N/search', 'N/url','N/runtime', 'N/https'],
    /**
 * @param{record} record
 * @param{search} search
 * @param{url} url
 */
    (record, search, url, runtime,https) => {
        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed before record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const beforeSubmit = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {
            ifRecordCreateInvoice(scriptContext);//IF单自动生成创建发票、日记账

        }

        /**
         * IF单创建发票
         * @param scriptContext
         */
        const ifRecordCreateInvoice = (scriptContext) => {
            let newRec = scriptContext.newRecord;
            let recType = scriptContext.type;
            if(recType == 'delete'){
                return;
            }
            let invoiceRec;
            let ifRec = record.load({type:'itemfulfillment',id:newRec.id})
            let orderType = ifRec.getValue('custbody_ecm_ordertype');
            let createFromTypeInfo = search.lookupFields({
                type:'itemfulfillment',
                id:newRec.id,
                columns:['createdfrom.type']
            });
            let createFromType = createFromTypeInfo['createdfrom.type'][0].value;
            if((orderType == 3 || orderType == '3') && createFromType == 'SalesOrd'){//Intercompany Order
                try {
                    if(recType == 'create'){
                        log.debug('create','create!')
                        let soId = ifRec.getValue('createdfrom');
                        invoiceRec = record.transform({
                            fromType: record.Type.SALES_ORDER,
                            fromId: soId,
                            toType: record.Type.INVOICE,
                            isDynamic: false,
                        });
                    }else if(recType == 'edit'){
                        let invoiceId = newRec.getValue('custbody_ecm_je_invoice');
                        if(invoiceId){
                            invoiceRec = record.load({type:'invoice', id:invoiceId});
                        }else{
                            let soId = newRec.getValue('createdfrom');
                            invoiceRec = record.transform({
                                fromType: record.Type.SALES_ORDER,
                                fromId: soId,
                                toType: record.Type.INVOICE,
                                isDynamic: false,
                            });
                        }
                    }
                    let {bodyData, itemData, keyArr} = getIfData(newRec);
                    //account Body塞值
                    for (key in bodyData) {
                        if (bodyData[key] && key != 'class1' && key != 'trandate') {
                            invoiceRec.setValue({fieldId: key, value: bodyData[key]})
                        }else if (bodyData[key] && key == 'class1' && key != 'trandate') {
                            invoiceRec.setValue({fieldId: 'class', value: bodyData[key]})
                        }else{//trandate
                            invoiceRec.setText({fieldId: key, text: bodyData[key]})
                        }
                    }
                    //account 明细行 塞值
                    if (itemData.length > 0) {
                        let itemCount = invoiceRec.getLineCount({sublistId: 'item'});
                        if (itemCount > 0) {//移除已存在行
                            for (let i = itemCount - 1; i >= 0; i--) {
                                if (keyArr.length <= i) {
                                    log.debug('deleteLine','----------deleteLine----------')
                                    invoiceRec.removeLine({sublistId: 'item', line: i});
                                }
                            }
                        }
                        let itemCount1 = invoiceRec.getLineCount({sublistId: 'item'});
                        for (let index = 0; index < itemData.length; index++) {
                            invoiceRec.setSublistValue({
                                sublistId: 'item',
                                fieldId: 'quantity',
                                value: itemData[index].lineQty,
                                line: index
                            });
                            invoiceRec.setSublistValue({
                                sublistId: 'item',
                                fieldId: 'rate',
                                value: String(itemData[index].lineRate),
                                line:index
                            });
                            let invRec = invoiceRec.getSublistSubrecord({
                                sublistId: 'item',
                                fieldId: 'inventorydetail',
                                line: index
                            });
                            let invNum = invRec.getLineCount({sublistId:'inventoryassignment'});
                            invRec.setSublistText({
                                sublistId: 'inventoryassignment',
                                fieldId: 'inventorynumber',
                                text: itemData[index].receiptNumber,
                                line:0
                            });
                            invRec.setSublistValue({
                                sublistId: 'inventoryassignment',
                                fieldId: 'quantity',
                                value: itemData[index].lineQty,
                                line:0
                            });
                        }
                    }
                    let invoiceId = invoiceRec.save({enableSourcing: true, ignoreMandatoryFields: true});
                    if (invoiceId) {//反写
                        let ifRec = record.load({type:'itemfulfillment', id:newRec.id});
                        ifRec.setValue({fieldId: 'custbody_ecm_je_invoice', value: invoiceId});
                        ifRec.save({enableSourcing: true, ignoreMandatoryFields: true});
                    }
                    createRiJiZhang(recType, invoiceId);//will 自动生成日记账
                }catch (e) {
                    log.error('e',e.message);
                }
            }
        }

        /**
         * will自动生成日记账
         */
        const createRiJiZhang = (recType, invoiceId) => {
            if(recType == 'create' && invoiceId) {
                //新增：will生成日记账
                let obj = {id : invoiceId, type : 'invoice'};
                let slUrl = url.resolveScript({
                    scriptId: 'customscript_ecm_sl_create_je',
                    deploymentId: 'customdeploy_ecm_sl_create_je',
                    returnExternalUrl: true
                });
                slUrl += '&rid=' + encodeURIComponent(invoiceId);
                if (runtime.executionContext !== runtime.ContextType.SUITELET) {
                    log.debug('runtime.executionContext',runtime.executionContext);
                    let response = https.post({
                        url: slUrl,
                        body: obj,
                    });
                }
            }
        }

        /**
         * 获取IF单数据
         * @param newRec
         * @returns {{itemData: *[], bodyData: {}}}
         */
        const getIfData = (newRec) => {
            let bodyData = getIfBodyData(newRec);
            let {itemData, keyArr} = getIfItemData(newRec);
            log.debug('itemData',itemData);
            return {bodyData,itemData,keyArr};
        }

        /**
         * 获取IF单body字段数据
         * @param newRec
         * @returns {{}}
         */
        const getIfBodyData = (newRec) => {
            let ifRec = record.load({type:'itemfulfillment',id:newRec.id});
            let bodyData = {};
            let custbody_ecm_ordertype = ifRec.getValue('custbody_ecm_ordertype');//待确定
            let trandate = ifRec.getValue('trandate');
            let entity = ifRec.getValue('entity');
            let currency = '';
            let subsidiary = ifRec.getValue('subsidiary');
            let class1 = ifRec.getValue('class');
            let department = ifRec.getValue('department');
            let exchangerate = '';
            let custbody_ecm_sp = ifRec.getValue('custbody_ecm_sp');
            let soId = ifRec.getValue('createdfrom');
            let custbody_ecm_icposo_transaction = '';
            if(soId){
                let companyOrder = search.lookupFields({
                    type:'salesorder',
                    id:soId,
                    columns:['custbody_ecm_icposo_transaction','exchangerate','currency']
                });
                custbody_ecm_icposo_transaction = companyOrder['custbody_ecm_icposo_transaction'][0].value;
                exchangerate = companyOrder['exchangerate'];
                currency = companyOrder['currency'][0].value;
            }
            let location = '';
            let itemCount = ifRec.getLineCount({sublistId:'item'})
            if(itemCount > 0){
                location = ifRec.getSublistValue({sublistId:'item',fieldId:'location',line:0});
            }

            bodyData.location = location;
            bodyData.trandate = trandate;
            bodyData.custbody_ecm_ordertype = custbody_ecm_ordertype;
            bodyData.class1 = class1;
            bodyData.department = department;
            bodyData.custbody_ecm_sp = custbody_ecm_sp;
            bodyData.custbody_ecm_icposo_transaction = custbody_ecm_icposo_transaction;
            return bodyData;
        }

        /**
         * 获取IF单明细行数据
         * @param newRec
         * @returns {*[]}
         */
        const getIfItemData = (newRec) => {
            let ifRec = record.load({type:'itemfulfillment',id:newRec.id});
            let itemData = [];
            let keyArr = [];
            let lineCount = ifRec.getLineCount({sublistId:'item'});
            if(lineCount > 0){
                for(let index  = 0; index < lineCount; index++){
                    let lineItem = ifRec.getSublistValue({sublistId:'item',fieldId:'item',line:index});//货品
                    let lineQty = ifRec.getSublistValue({sublistId:'item',fieldId:'quantity',line:index,}) || 0;//数量
                    let lineSpLine = ifRec.getValue('custcol_ecm_spline');//sp Line
                    let lineSpLine1 = ifRec.getSublistValue({sublistId:'item',fieldId:'custcol_emc_line_no',line:index});//修改：取值不匹配
                    //明细行货品对应的采购订单
                    let soId = ifRec.getValue('createdfrom');
                    let soRec = record.load({type:'salesorder',id:soId});
                    let soLine = soRec.findSublistLineWithValue({sublistId:'item',fieldId:'custcol_emc_line_no',value:lineSpLine1});//对应行
                    let lineTaxcode = '';
                    let lineRate = '';
                    if(soLine != '-1' && soLine != -1){
                        lineRate = soRec.getSublistValue({sublistId:'item',fieldId:'rate',line:soLine});//单价
                        lineTaxcode = soRec.getSublistValue({sublistId:'item', fieldId:'taxcode', line:soLine});//税码
                    }
                    let lineUnit = ifRec.getSublistValue({sublistId:'item',fieldId:'units',line:index});//计量单位
                    //获取库存详细信息序列号
                    let invRec = ifRec.getSublistSubrecord({sublistId:'item',fieldId:'inventorydetail',line:index});
                    let invCount = invRec.getLineCount({sublistId:'inventoryassignment'});
                    let receiptNumber = '';
                    if(invCount > 0){
                        receiptNumber = invRec.getSublistText({sublistId:'inventoryassignment',fieldId:'inventorynumber',line:0});
                    }


                    let irJson = {
                        'lineItem':lineItem,
                        'lineQty':lineQty,
                        'lineRate':lineRate,
                        'lineSpLine':lineSpLine,
                        'lineTaxcode':lineTaxcode,
                        'lineUnit':lineUnit,
                        'receiptNumber':receiptNumber
                    }
                    itemData.push(irJson);
                    if(lineSpLine1){
                        keyArr.push(lineSpLine1);
                    }
                }
            }
            return {itemData,keyArr};
        }

        return {/**beforeLoad, beforeSubmit, **/afterSubmit}

    });
