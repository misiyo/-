/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * Version           Date              Author               Remark
 * 1.0               2/24/2023         Kori                 TAPD【1018574】IR单 批次重复校验
 */
define(['N/record', 'N/search', '../tools/common_api.js'],
    /**
 * @param{record} record
 * @param{search} search
 */
    (record, search, commonApi) => {
        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed before record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const beforeSubmit = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {
            var recType = scriptContext.type;
            var newRec = scriptContext.newRecord;
            if(recType == 'delete'){
                return;
            }else if(recType == 'create' || recType == 'edit'){
                var curRec = record.load({type:newRec.type, id:newRec.id})
            }
            var lineCount = curRec.getLineCount({sublistId:'item'});
            var existPcArr = searchExistPc();
            for(var index = 0; index < lineCount; index++){
                var lineitem = curRec.getSublistValue({sublistId:'item', fieldId:'item', line:index});
                var linelocation = curRec.getSublistValue({sublistId:'item', fieldId:'location', line:index});
                var invRec = curRec.getSublistSubrecord({sublistId:'item', fieldId:'inventorydetail', line:index});
                var invLine = invRec.getLineCount({sublistId:'inventoryassignment'});
                for(var k = 0; k < invLine.length; k++) {
                    var linePc = invRec.getSublistValue({
                        sublistId: 'inventoryassignment',
                        fieldId: 'issueinventorynumber',
                        line: k
                    });
                    for (var j = 0; j < existPcArr.length; j++) {
                        if (existPcArr[j].item == lineitem && existPcArr[j].location == linelocation && existPcArr[j].invNum == linePc) {
                            alert('The batch number you entered has existed in the system, please check and enter the correct batch number. （您输入的批号在系统中已存在,请检查并输入正确的批号。）')
                            return false;
                        }
                    }
                }
            }
        }

        function searchExistPc(){
            var invData = [];
            var invdSearch = search.create({
                type: "inventorydetail",
                filters:
                    [
                    ],
                columns:
                    [
                        search.createColumn({name: "item", label: "货品"}),
                        search.createColumn({name: "location", label: "地点"}),
                        search.createColumn({
                            name: "inventorynumber",
                            sort: search.Sort.ASC,
                            label: " 编号"
                        }),
                        search.createColumn({name: "status", label: "状态"})
                    ]
            });
            // var invRes = common.getAllData(invdSearch);
            var invRes = commonApi.getAllData(invdSearch);
            var invCol = invdSearch.columns;
            if(invRes.length > 0){
                for(var i = 0; i < invRes.length; i++){
                    var item = invRes[i].getValue(invCol[0]);
                    var location = invRes[i].getValue(invCol[1]);
                    var invNum = invRes[i].getValue(invCol[2]);
                    var invJson = {
                        item:item,
                        location:location,
                        invNum:invNum,
                    }
                    invData.push(invJson);
                }
            }
            return invData;
        }

        return {/**beforeLoad, beforeSubmit, **/afterSubmit}

    });
