/**
 * @NApiVersion 2.1
 * @NScriptType ScheduledScript
 * Version         Date           Author             Remark
 * 1.0             2023/2/20      Kori               TAPD【1018453】自动生成合同配货——海外仓直发
 * 1.1             2023/2/23      Kori               TAPD【1018453】新增：预付款比例、SCD明细字段
 * 1.2             2023/3/8       Kori               TAPD【1018453】新增：字段回写，taxrate百分比类型报错查找
 * 1.3             2023/3/8       Kori               TAPD【1018453】sc-ss（一对多）逻辑优化
 * 2.0             2023/3/8       Kori               运输方式不匹配、search写在for循环需要优化
 * 3.0             2023/3/9       Kori               ss合同配货数量回写
 * 4.0             2023/4/7       Kori               sc明细行新增字段
 * 5.0             2023/4/10      Kori               新增字段：SCD明细行的Cargo Premium{custrecord_scdline_perscost}
 *                                                   =Unit Price of Primary Sale Unit{custrecord_scdline_amt}/Item
 *                                                   的Unit Capacity{custitem_ecm_case_package_kg}*0.00028*1.1
 * 6.0             2023/4/18      Kori               sc明细行字段取值变更、逻辑变更
 * 待补充           待补充          待补充               etc...
 */
define(['N/record', 'N/search', 'N/runtime', '../tools/common_api.js'],
    /**
 * @param{record} record
 * @param{search} search
 */
    (record, search, runtime, commonApi) => {

        /**
         * Defines the Scheduled script trigger point.
         * @param {Object} scriptContext
         * @param {string} scriptContext.type - Script execution context. Use values from the scriptContext.InvocationType enum.
         * @since 2015.2
         */
        const execute = (scriptContext) => {
            let scId = runtime.getCurrentScript().getParameter('custscript_sc_id');
            if(scId){
                try{
                    createScdRecord(scId);
                }catch (e) {
                    log.error('errorMsg',e.message)
                }
            }
        }

        /**
         * 获取数据、创建csd记录
         * @param scId
         */
        const createScdRecord = (scId) => {
            let ssArr = searchSsBySc(scId);
            let subsidiaryArr = searchSubsidiayCurrency();
            if(ssArr.length > 0){
                for(let i = 0; i < ssArr.length; i++){
                    let ssData = searchSsInfo(ssArr[i],scId,subsidiaryArr);
                    if(ssData.ssArr.length > 0){
                        createScdByShippingSchedule(ssData);//创建SCD单据
                    }
                }
            }
        }


        /**
         * 获取一张ss数据
         * @param scId
         * @returns {{}}      {body:'',ssArr:[{},{}...]}
         */
        const searchSsInfo = (ssId,scId,subsidiaryArr) => {
            let ssData = {};
            let ssArr = [];
            let itemArr = [];

            let scRec = record.load({type:'salesorder', id: scId});
            let custrecord_scd_dateofsigning = scRec.getValue('saleseffectivedate');//签约日期?
            let custrecord_scd_exchangerate = scRec.getValue('exchangerate');//Exchangerate
            let custrecord_scd_currency = scRec.getValue('currency');//Currency
            let custrecord_scd_terms = scRec.getValue('terms');//Terms
            let entity = scRec.getValue('entity');//entity
            let custrecord_scd_salesservice = scRec.getValue('custbody_ecm_cusservice');//客服
            let custrecord_scd_demander = scRec.getValue('subsidiary');//附属公司
            let custrecord_scd_packinginstruction = scRec.getValue('custrecord_scd_packinginstruction');//包装说明

            ssData.custrecord_scd_dateofsigning = custrecord_scd_dateofsigning;
            ssData.custrecord_scd_exchangerate = custrecord_scd_exchangerate;
            ssData.custrecord_scd_currency = custrecord_scd_currency;
            ssData.custrecord_scd_terms = custrecord_scd_terms;
            ssData.custrecord_scd_salesservice = custrecord_scd_salesservice;
            ssData.custrecord_scd_demander = custrecord_scd_demander;
            ssData.custrecord_scd_packinginstruction = custrecord_scd_packinginstruction;

            let custrecord_scd_preproportion = scRec.getValue('custbody_ecm_prepayment_ratio');//预付款比例
            let custrecord_scd_pretype = scRec.getValue('custbody_ecm_prepay_method');//预付款支付方式
            let custrecord_scd_prenode = scRec.getValue('custbody_ecm_prepay_node');//预付款支付支点
            let custrecord_scd_preday = scRec.getValue('custbody_ecm_advance_prepaydays');//预款支付期
            let custrecord_scd_surpproportion = scRec.getValue('custbody_ecm_prepayment_ratio');//余款比例
            let custrecord_scd_surpnode = scRec.getValue('custbody_ecm_balance_prepay_node');//余款支付节点
            let custrecord_scd_surpday = scRec.getValue('custbody_ecm_balance_termsdays');//余款账期
            let custrecord_scd_surptype = scRec.getValue('custbody_ecm_balance_prepay_method');//余款支付方式
            let custrecord_scdline_japdelivery = scRec.getValue('custbody_ecm_deliverydate_type');//交割日文言
            let custrecord_scd_warehousestock = scRec.getValue('custbody_ecm_iswarehousestock');
            let custrecord_scd_paytermscn = scRec.getValue('custbody_ecm_termsdisplay_cn');//PaymentTermsCN
            let custrecord_scd_paytermsen = scRec.getValue('custbody_ecm_termsdisplay_en');//PaymentTermsEN
            let qiyunguo = scRec.getValue('custbody_ecm_countryof_departure');//起运国

            ssData.custrecord_scd_preproportion = custrecord_scd_preproportion;
            ssData.custrecord_scd_surpproportion = custrecord_scd_surpproportion;
            ssData.custrecord_scd_pretype = custrecord_scd_pretype;
            ssData.custrecord_scd_prenode = custrecord_scd_prenode;
            ssData.custrecord_scd_preday = custrecord_scd_preday;
            ssData.custrecord_scd_surpnode = custrecord_scd_surpnode;
            ssData.custrecord_scd_surpday = custrecord_scd_surpday;
            ssData.custrecord_scd_surptype = custrecord_scd_surptype;
            ssData.custrecord_scdline_japdelivery = custrecord_scdline_japdelivery;
            ssData.custrecord_scd_warehousestock = custrecord_scd_warehousestock;
            ssData.custrecord_scd_paytermscn = custrecord_scd_paytermscn;
            ssData.custrecord_scd_paytermsen = custrecord_scd_paytermsen;
            ssData.qiyunguo = qiyunguo;

            let ssSearch = search.create({
                type:"customrecord_shipping_schedule",
                filters:[
                    ["internalid", "anyof", ssId]
                ],
                columns:[
                    search.createColumn({name : 'internalid'}),
                    search.createColumn({name : 'custrecord_ssc_location'}),
                    search.createColumn({name : 'custrecord_ssc_exshipdate'}),
                    search.createColumn({name : 'custrecord_ssc_loadingport'}),
                    search.createColumn({name : 'custrecord_ssc_order_type'}),//单据类型
                    search.createColumn({name : 'custrecord_ssc_iscross_border'}),//boolean
                    search.createColumn({name : 'custrecord_ssc_incoterm'}),//贸易方式
                    search.createColumn({name : 'custrecord_ssc_shipping_method'}),//运输方式
                    search.createColumn({name : 'custrecord_ssc_destinationport'}),//目的港
                    search.createColumn({name : 'custrecord_ssc_country_destination'}),//目的国
                    search.createColumn({name : 'custrecord_ssc_scnumber'}),//销售合同

                    search.createColumn({
                        name:'custrecord_sscd_scsku',//货品
                        join:'CUSTRECORD_SSCD_PARENT'
                    }),
                    search.createColumn({//数量
                        name:'custrecord_sscd_scqty',
                        join:'CUSTRECORD_SSCD_PARENT'
                    }),
                    search.createColumn({//计量单位
                        name:'custrecord_sscd_unit',
                        join:'CUSTRECORD_SSCD_PARENT'
                    }),
                    search.createColumn({//计价单位
                        name:'custrecord_sscd_priceunits',
                        join:'CUSTRECORD_SSCD_PARENT'
                    }),
                    search.createColumn({
                        name:'custrecord_sscd_number',//合同行id
                        join:'CUSTRECORD_SSCD_PARENT',
                        sort: search.Sort.ASC
                    }),
                    search.createColumn({
                        name:'name',//序号
                        join:'CUSTRECORD_SSCD_PARENT'
                    }),
                    search.createColumn({name : 'custrecord_ssc_country_destination'}),//起运国
                    search.createColumn({name : 'custrecord_ssc_poreq_othemark'}),//其他要求
                    search.createColumn({name : 'custrecord_ssc_memo'}),//备注

                    search.createColumn({
                        name:'custrecord_sscd_sourcing',//采购员
                        join:'CUSTRECORD_SSCD_PARENT'
                    }),
                    search.createColumn({
                        name:'custrecord_sscd_ispalletstretch',//打托缠膜
                        join:'CUSTRECORD_SSCD_PARENT'
                    }),
                    search.createColumn({
                        name:'custrecord_sscd_csdty_created',//已配货数量
                        join:'CUSTRECORD_SSCD_PARENT'
                    }),
                    search.createColumn({
                        name:'custrecord_sscd_scno',//销售合同
                        join:'CUSTRECORD_SSCD_PARENT'
                    }),

                    search.createColumn({
                        name:'custrecord_sscd_rate',//单价
                        join:'CUSTRECORD_SSCD_PARENT'
                    }),
                    search.createColumn({
                        name:'custrecord_sscd_taxcode',//税码
                        join:'CUSTRECORD_SSCD_PARENT'
                    }),
                    search.createColumn({
                        name:'custrecord_sscd_taxreate',//税率
                        join:'CUSTRECORD_SSCD_PARENT'
                    }),

                    search.createColumn({
                        name:'custrecord_sscd_landfreight',//陆运费
                        join:'CUSTRECORD_SSCD_PARENT'
                    }),
                    search.createColumn({
                        name:'custrecord_sscd_tariff',//关税
                        join:'CUSTRECORD_SSCD_PARENT'
                    }),
                    search.createColumn({
                        name:'custrecord_sscd_oceanfreight',//海运费
                        join:'CUSTRECORD_SSCD_PARENT'
                    }),
                    search.createColumn({
                        name:'custrecord_sscd_insurancefee',//人保费
                        join:'CUSTRECORD_SSCD_PARENT'
                    }),
                    search.createColumn({
                        name:'custrecord_sscd_customs_clearancefee',//清关费
                        join:'CUSTRECORD_SSCD_PARENT'
                    }),
                    search.createColumn({
                        name:'custrecord_sscd_storagefee',//仓储费
                        join:'CUSTRECORD_SSCD_PARENT'
                    }),
                    search.createColumn({
                        name:'custrecord_sscd_inspe_certifi_fee',//检验认证费
                        join:'CUSTRECORD_SSCD_PARENT'
                    }),
                    //custrecord_ssc_salerep
                    search.createColumn({name : 'custrecord_ssc_salerep'}),//备注
                    search.createColumn({
                        name:'custrecord_sscd_sclineid',//合同行id
                        join:'CUSTRECORD_SSCD_PARENT'
                    }),
                    //custrecord_sscd_ssqty
                    search.createColumn({
                        name:'custrecord_sscd_ssqty',//ss数量
                        join:'CUSTRECORD_SSCD_PARENT'
                    }),
                    //custrecord_ssc_vessel_deadline
                    search.createColumn({
                        name:'custrecord_ssc_vessel_deadline',//船期截止日
                    }),
                ]
            });
            let ssRes = commonApi.getAllData(ssSearch);
            let ssCol = ssSearch.columns;
            if(ssRes.length > 0){
                for(let index = 0; index < ssRes.length; index ++){
                    let custrecord_scdline_purchasetaxcode = '';
                    if(index == 0){
                        let custrecord_scd_ss = ssRes[index].getValue(ssCol[0]);
                        let custrecord_scd_location = ssRes[index].getValue(ssCol[1]);
                        let custrecord_scd_shipdate = ssRes[index].getValue(ssCol[2]);
                        let custrecord_scd_portofdeparture = ssRes[index].getValue(ssCol[3]);
                        let custrecord_scd_sctype = ssRes[index].getValue(ssCol[4]);
                        let custrecord_scd_crossborder = ssRes[index].getValue(ssCol[5]);
                        let custrecord_scd_tradeterms = ssRes[index].getValue(ssCol[6]);
                        let custrecord_scd_transportmode = ssRes[index].getValue(ssCol[7]);
                        let custrecord_scd_portofdestination = ssRes[index].getValue(ssCol[8]);
                        let custrecord_scd_countryofdestination = ssRes[index].getValue(ssCol[9]);
                        let custrecord_scd_sc = ssRes[index].getValue(ssCol[10]);
                        let custrecord_scd_countryofdeparture = ssRes[index].getValue(ssCol[17]);
                        let custrecord_scd_otherrequirement = ssRes[index].getValue(ssCol[18]);
                        let custrecord_scd_memo = ssRes[index].getValue(ssCol[19]);
                        let custrecord_scd_salesrep = ssRes[index].getValue(ssCol[34]);
                        let custrecord_scd_disttype = 2;
                        let custrecord_scd_supplier = '';
                        let custrecord_scd_purccurrency = '';
                        if(custrecord_scd_location){
                            let locRec = record.load({type:'location', id:custrecord_scd_location});
                            custrecord_scd_supplier = locRec.getValue('subsidiary');
                            if(custrecord_scd_supplier){
                                for(let index = 0; index < subsidiaryArr.length; index++){
                                    if(subsidiaryArr[index].subsidiaryName == custrecord_scd_supplier){
                                        custrecord_scd_purccurrency = subsidiaryArr[index].currency;
                                        custrecord_scdline_purchasetaxcode = subsidiaryArr[index].taxcode;
                                        break;
                                    }
                                }
                            }
                        }

                        ssData.custrecord_scd_ss  = custrecord_scd_ss;
                        ssData.custrecord_scd_location  = custrecord_scd_location;
                        ssData.custrecord_scd_disttype = custrecord_scd_disttype;
                        ssData.custrecord_scd_supplier = custrecord_scd_supplier;
                        ssData.custrecord_scd_purccurrency = custrecord_scd_purccurrency;
                        ssData.custrecord_scd_shipdate  = custrecord_scd_shipdate;
                        ssData.custrecord_scd_portofdeparture  = custrecord_scd_portofdeparture;
                        ssData.custrecord_scd_sctype  = custrecord_scd_sctype;
                        ssData.custrecord_scd_salesrep  = custrecord_scd_salesrep;
                        ssData.custrecord_scd_crossborder  = custrecord_scd_crossborder;
                        ssData.custrecord_scd_tradeterms  = custrecord_scd_tradeterms;
                        ssData.custrecord_scd_transportmode  = custrecord_scd_transportmode;
                        ssData.custrecord_scd_portofdestination  = custrecord_scd_portofdestination;
                        ssData.custrecord_scd_countryofdestination  = custrecord_scd_countryofdestination;
                        ssData.custrecord_scd_sc  = custrecord_scd_sc;
                        ssData.custrecord_scd_countryofdeparture  = custrecord_scd_countryofdeparture;
                        ssData.custrecord_scd_otherrequirement  = custrecord_scd_otherrequirement;
                        ssData.custrecord_scd_memo  = custrecord_scd_memo;
                    }
                    let lineContactItem = ssRes[index].getValue(ssCol[11]);
                    let lineQty = ssRes[index].getValue(ssCol[12]);
                    let custrecord_scdline_uniquekey = ssRes[index].getValue(ssCol[35]);
                    let lineCnName, lineEgName, lineCas, capacity;
                    let custrecord_scdline_gross_weight = '';
                    let custrecord_scdline_net_weight = '';
                    let custrecord_scdline_volume = '';
                    let custrecord_scdline_msds = '';
                    let custrecord_scdline_certifforsea = '';
                    let custrecord_scdline_certifforair = '';
                    let custrecord_scdline_technrailway = '';
                    let custrecord_scdline_dangpackinginstruction = '';
                    let custrecord_scdline_dangsyndrome = '';
                    let custrecord_scdline_resuttsheet = '';
                    let custrecord_scdline_commissionunitprice = '';
                    let custrecord_scdline_totalcommission = '';
                    let remkCn = '';
                    let dateofsigning = '';
                    if(lineContactItem){
                        let itemInfo = search.lookupFields({
                            type:'item',
                            id:lineContactItem,
                            columns:['custitem_ecm_spu_cnname',
                                'custitem_ecm_spu_enname',
                                'custitem_ecm_cas',
                                'custitem_ecm_case_package_kg',
                                //321新增
                                'custitem_ecm_gross_weight',
                                'custitem_ecm_net_weight',
                                'custitem_ecm_case_volume',//乘数量
                                'custitem_ecm_msds',
                                'custitem_ecm_certificatebysea',
                                'custitem_ecm_certificatebyair',
                                'custitem_ecm_technicaldescripbyrailway',
                                'custitem_ecm_packaginginstruction',
                                'custitem_ecm_dangerouspackagesyndrome',
                                'custitem_ecm_packingperformanceresutt',
                                'custitem_ecm_package_remk_cn',
                            ]
                        });
                        lineCnName = itemInfo['custitem_ecm_spu_cnname'];
                        lineEgName = itemInfo['custitem_ecm_spu_enname'];
                        lineCas = itemInfo['custitem_ecm_cas'];
                        capacity = itemInfo['custitem_ecm_case_package_kg'];
                        //418新增
                        remkCn = itemInfo['custitem_ecm_package_remk_cn'];
                        //321新增
                        custrecord_scdline_gross_weight = itemInfo['custitem_ecm_gross_weight'] || '';
                        custrecord_scdline_gross_weight = Number(custrecord_scdline_gross_weight).mul(Number(lineQty));
                        custrecord_scdline_net_weight = itemInfo['custitem_ecm_net_weight'] || '';
                        custrecord_scdline_net_weight = Number(custrecord_scdline_net_weight).mul(Number(lineQty));
                        custrecord_scdline_volume = itemInfo['custitem_ecm_case_volume'] || '';
                        custrecord_scdline_volume = Number(custrecord_scdline_volume).mul(Number(lineQty));
                        if(Object.keys(itemInfo['custitem_ecm_msds']).length > 0){
                            custrecord_scdline_msds = itemInfo['custitem_ecm_msds'][0].value;
                        }else{
                            custrecord_scdline_msds = '';
                        }
                        if(Object.keys(itemInfo['custitem_ecm_certificatebysea']).length > 0){
                            custrecord_scdline_certifforsea = itemInfo['custitem_ecm_certificatebysea'][0].value;
                        }else{
                            custrecord_scdline_certifforsea = '';
                        }
                        if(Object.keys(itemInfo['custitem_ecm_certificatebyair']).length > 0){
                            custrecord_scdline_certifforair = itemInfo['custitem_ecm_certificatebyair'][0].value;
                        }else{
                            custrecord_scdline_certifforair = '';
                        }
                        if(Object.keys(itemInfo['custitem_ecm_technicaldescripbyrailway']).length > 0){
                            custrecord_scdline_technrailway = itemInfo['custitem_ecm_technicaldescripbyrailway'][0].value;
                        }else{
                            custrecord_scdline_technrailway = '';
                        }
                        if(Object.keys(itemInfo['custitem_ecm_packaginginstruction']).length > 0){
                            custrecord_scdline_dangpackinginstruction = itemInfo['custitem_ecm_packaginginstruction'][0].value;
                        }else{
                            custrecord_scdline_dangpackinginstruction = '';
                        }
                        if(Object.keys(itemInfo['custitem_ecm_dangerouspackagesyndrome']).length > 0){
                            custrecord_scdline_dangsyndrome = itemInfo['custitem_ecm_dangerouspackagesyndrome'][0].value;
                        }else{
                            custrecord_scdline_dangsyndrome = '';
                        }
                        if(Object.keys(itemInfo['custitem_ecm_packingperformanceresutt']).length > 0){
                            custrecord_scdline_resuttsheet = itemInfo['custitem_ecm_packingperformanceresutt'][0].value;
                        }else{
                            custrecord_scdline_resuttsheet = '';
                        }
                        if(ssData.custrecord_scd_sc && custrecord_scdline_uniquekey){
                            let scRecord = record.load({type:'salesorder',id:ssData.custrecord_scd_sc});
                            let lineIndex = scRecord.findSublistLineWithValue({sublistId:'item',fieldId:'custcol_ecm_uniquekey',value:custrecord_scdline_uniquekey});
                            if(lineIndex != -1){
                                let lineUnitPrice = scRecord.getSublistValue({sublistId:'item',fieldId:'custcol_ecm_commissionunitprice',line:lineIndex})
                                custrecord_scdline_commissionunitprice = lineUnitPrice;
                                custrecord_scdline_totalcommission = Number(lineUnitPrice).mul(Number(lineQty));
                            }
                        }
                    }
                    //搜索Item Declaration Information
                    let idiData = {};
                    if(lineContactItem && qiyunguo){
                        idiData = searchIDIRec(lineContactItem, qiyunguo,remkCn,ssData.custrecord_scd_dateofsigning);
                    }
                    let lineUnit = ssRes[index].getValue(ssCol[13]);
                    let linePriceUnit = ssRes[index].getValue(ssCol[14]);
                    let lineId = ssRes[index].getValue(ssCol[15]);
                    let lineIndex = ssRes[index].getValue(ssCol[16]);
                    let lineSourcer = ssRes[index].getValue(ssCol[20]);
                    let linePallet = ssRes[index].getValue(ssCol[21]);
                    let lineCalQty = ssRes[index].getValue(ssCol[22]);
                    let linescno = ssRes[index].getValue(ssCol[23]);
                    let lineamt = ssRes[index].getValue(ssCol[24]) || 0;
                    let linecode = ssRes[index].getValue(ssCol[25]);
                    let linerate = ssRes[index].getValue(ssCol[26]);
                    let cost1 = ssRes[index].getValue(ssCol[27]);
                    let cost2 = ssRes[index].getValue(ssCol[28]);
                    let cost3 = ssRes[index].getValue(ssCol[29]);
                    let cost4 = ssRes[index].getValue(ssCol[30]);
                    let cost5 = ssRes[index].getValue(ssCol[31]);
                    let cost6 = ssRes[index].getValue(ssCol[32]);
                    let cost7 = ssRes[index].getValue(ssCol[33]);
                    let ssQty = ssRes[index].getValue(ssCol[36]);
                    let perscost = Number(Number(lineamt) / Number(capacity)).mul(0.000128).mul(1.1)
                    //改为取SS=>custrecord_ssc_vessel_deadline
                    let lineExpshipDate = ssRes[index].getValue(ssCol[37]);
                    // let lineExpshipDate = scRec.getSublistValue({sublistId:'item', fieldId:'expectedshipdate', line:index});

                    itemArr.push(lineContactItem)
                    let scJson = {
                        lineContactItem : lineContactItem,
                        lineQty : lineQty,
                        lineUnit : lineUnit,
                        linePriceUnit : linePriceUnit,
                        lineId : lineId,
                        lineIndex : lineIndex,
                        lineCnName : lineCnName,
                        lineEgName : lineEgName,
                        lineCas : lineCas,
                        capacity : capacity,
                        lineSourcer : lineSourcer,
                        linePallet : linePallet,
                        lineCalQty : lineCalQty,
                        linescno : linescno,
                        lineamt : lineamt,
                        linecode : linecode,
                        linerate : linerate,
                        lineExpshipDate : lineExpshipDate,
                        cost1 : cost1,
                        cost2 : cost2,
                        cost3 : cost3,
                        cost4 : cost4,
                        cost5 : cost5,
                        cost6 : cost6,
                        cost7 : cost7,
                        custrecord_scdline_uniquekey : custrecord_scdline_uniquekey || '',
                        custrecord_scdline_purchasetaxcode : custrecord_scdline_purchasetaxcode || '',
                        custrecord_scdline_gross_weight : custrecord_scdline_gross_weight || '',
                        custrecord_scdline_net_weight : custrecord_scdline_net_weight || '',
                        custrecord_scdline_volume : custrecord_scdline_volume || '',
                        custrecord_scdline_msds : custrecord_scdline_msds || '',
                        custrecord_scdline_certifforsea : custrecord_scdline_certifforsea || '',
                        custrecord_scdline_certifforair : custrecord_scdline_certifforair || '',
                        custrecord_scdline_technrailway : custrecord_scdline_technrailway || '',
                        custrecord_scdline_dangpackinginstruction : custrecord_scdline_dangpackinginstruction || '',
                        custrecord_scdline_dangsyndrome : custrecord_scdline_dangsyndrome || '',
                        custrecord_scdline_resuttsheet : custrecord_scdline_resuttsheet || '',
                        //idi data
                        custrecord_scdline_declarationinfo : idiData.custrecord_scdline_declarationinfo,
                        custrecord_scdline_custom_basicinfo : idiData.custrecord_scdline_custom_basicinfo,
                        custrecord_scdline_cusdel_name : idiData.custrecord_scdline_cusdel_name,
                        custrecord_scdline_elements_declarati : idiData.custrecord_scdline_elements_declarati,
                        custrecord_scdline_area : idiData.custrecord_scdline_area,
                        custrecord_scdline_hs_code : idiData.custrecord_scdline_hs_code,
                        custrecord_scdline_conditions_customs : idiData.custrecord_scdline_conditions_customs,
                        custrecord_scdline_taxrefund_rate : idiData.custrecord_scdline_taxrefund_rate,
                        custrecord_scdline_codition : idiData.custrecord_scdline_codition,
                        custrecord_scdline_category : idiData.custrecord_scdline_category,
                        custrecord_scdline_extax_reftype : idiData.custrecord_scdline_extax_reftype,
                        custrecord_scdline_extax_refund : idiData.custrecord_scdline_extax_refund,
                        custrecord_scdline_import_tariff_type : idiData.custrecord_scdline_import_tariff_type,
                        custrecord_scdline_import_tariffs : idiData.custrecord_scdline_import_tariffs,
                        custrecord_scdline_vat_type : idiData.custrecord_scdline_vat_type,
                        custrecord_scdline_vat : idiData.custrecord_scdline_vat,
                        custrecord_scdline_specialcode : idiData.custrecord_scdline_specialcode,
                        custrecord_scdline_commissionunitprice : custrecord_scdline_commissionunitprice,
                        custrecord_scdline_totalcommission : custrecord_scdline_totalcommission,
                        ssQty : ssQty,
                        perscost : perscost
                    }
                    ssArr.push(scJson);
                }
            }
            itemArr = uniqueArr(itemArr);
            ssData.ssArr = ssArr;
            ssData.itemLen = itemArr.length;
            return ssData;

        }

        /**
         * 通过货品和起运国获取idi记录数据
         * @param lineContactItem
         * @param qiyunguo
         * @param remkCn
         * @param dateofsigning
         * @returns {{}}
         */
        const searchIDIRec = (lineContactItem, qiyunguo,remkCn,dateofsigning) => {
            let idiData = {};
            let idiSearch = search.create({
                type: "customrecord_ecm_customs_declarationinfo",
                filters:
                    [
                        ["custrecord_ecm_ecd_parent_cust_decl","anyof",lineContactItem],
                        "AND",
                        ["custrecord_ecm_ecd_area","anyof",qiyunguo]
                    ],
                columns:
                    [
                        search.createColumn({name: "internalid", label: "内部 ID"}),
                        search.createColumn({name: "custrecord_ecm_ecd_custom_basicinfo", label: "海关基础信息"}),
                        search.createColumn({name: "custrecord_ecm_ecd_cusdel_name", label: "报关品名"}),
                        search.createColumn({name: "custrecord_ecm_ecd_elements_declarati", label: "申报要素"}),
                        search.createColumn({name: "custrecord_ecm_ecd_area", label: "海关地区"}),
                        search.createColumn({name: "custrecord_ecm_ecd_hs_code", label: "海关编码"}),
                        search.createColumn({name: "custrecord_ecm_ecd_conditions_customs", label: "关税税率"}),
                        search.createColumn({name: "custrecord_ecm_ecd_taxrefund_rate", label: "退税率"}),
                        search.createColumn({name: "custrecord_ecm_ecd_codition", label: "海关监管条件"}),
                        search.createColumn({name: "custrecord_ecm_ecd_category", label: "检疫类别"}),
                        search.createColumn({name: "custrecord_ecm_ecd_extax_reftype", label: "出口退税类型"}),
                        search.createColumn({name: "custrecord_ecm_ecd_extax_refund", label: "出口退税"}),
                        search.createColumn({name: "custrecord_ecm_ecd_import_tariff_type", label: "进口关税类型"}),
                        search.createColumn({name: "custrecord_ecm_ecd_import_tariffs", label: "进口关税"}),
                        search.createColumn({name: "custrecord_ecm_ecd_vat_type", label: "增值税类型"}),
                        search.createColumn({name: "custrecord_ecm_ecd_vat", label: "增值税"}),
                        search.createColumn({name: "custrecord_ecm_idi_specialcode", label: "特殊商品标识"})
                    ]
            });
            let idiRes = idiSearch.run().getRange({start:0,end:1});
            let columns = idiSearch.columns;
            if(idiRes.length > 0){
                let idiId = idiRes[0].getValue(columns[0]);
                let custrecord_ecm_ecd_custom_basicinfo = idiRes[0].getValue(columns[1]);
                let custrecord_ecm_ecd_cusdel_name = idiRes[0].getValue(columns[2]);
                let custrecord_ecm_ecd_elements_declarati = idiRes[0].getValue(columns[3]);
                let custrecord_ecm_ecd_area = idiRes[0].getValue(columns[4]);
                let custrecord_ecm_ecd_hs_code = idiRes[0].getValue(columns[5]);
                let custrecord_ecm_ecd_conditions_customs = idiRes[0].getValue(columns[6]);
                let custrecord_ecm_ecd_taxrefund_rate = idiRes[0].getValue(columns[7]);
                let custrecord_ecm_ecd_codition = idiRes[0].getValue(columns[8]);
                let custrecord_ecm_ecd_category = idiRes[0].getValue(columns[9]);
                let custrecord_ecm_ecd_extax_reftype = idiRes[0].getValue(columns[10]);
                let custrecord_ecm_ecd_extax_refund = idiRes[0].getValue(columns[11]);
                let custrecord_ecm_ecd_import_tariff_type = idiRes[0].getValue(columns[12]);
                let custrecord_ecm_ecd_import_tariffs = idiRes[0].getValue(columns[13]);
                let custrecord_ecm_ecd_vat_type = idiRes[0].getValue(columns[14]);
                let custrecord_ecm_ecd_vat = idiRes[0].getValue(columns[15]);
                let custrecord_ecm_idi_specialcode = idiRes[0].getValue(columns[16]);

                idiData.custrecord_scdline_declarationinfo = idiId;
                idiData.custrecord_scdline_custom_basicinfo = custrecord_ecm_ecd_custom_basicinfo;
                idiData.custrecord_scdline_cusdel_name = custrecord_ecm_ecd_cusdel_name;
                //有"${package}"替换成Item的Package(CN){custitem_ecm_package_remk_cn},
                //若有"${orderDate}"替换成SCD的Signing Date{custrecord_scd_dateofsigning}
                custrecord_ecm_ecd_elements_declarati = custrecord_ecm_ecd_elements_declarati.replace(/\$\{package\}/g,remkCn);
                custrecord_ecm_ecd_elements_declarati = custrecord_ecm_ecd_elements_declarati.replace(/\$\{orderDate}\'/g,dateofsigning);
                idiData.custrecord_scdline_elements_declarati = custrecord_ecm_ecd_elements_declarati;
                idiData.custrecord_scdline_area = custrecord_ecm_ecd_area;
                idiData.custrecord_scdline_hs_code = custrecord_ecm_ecd_hs_code;
                idiData.custrecord_scdline_conditions_customs = custrecord_ecm_ecd_conditions_customs;
                idiData.custrecord_scdline_taxrefund_rate = custrecord_ecm_ecd_taxrefund_rate;
                idiData.custrecord_scdline_codition = custrecord_ecm_ecd_codition;
                idiData.custrecord_scdline_category = custrecord_ecm_ecd_category;
                idiData.custrecord_scdline_extax_reftype = custrecord_ecm_ecd_extax_reftype;
                idiData.custrecord_scdline_extax_refund = custrecord_ecm_ecd_extax_refund;
                idiData.custrecord_scdline_import_tariff_type = custrecord_ecm_ecd_import_tariff_type;
                idiData.custrecord_scdline_import_tariffs = custrecord_ecm_ecd_import_tariffs;
                idiData.custrecord_scdline_vat_type = custrecord_ecm_ecd_vat_type;
                idiData.custrecord_scdline_vat = custrecord_ecm_ecd_vat;
                idiData.custrecord_scdline_specialcode = custrecord_ecm_idi_specialcode;
            }
            return idiData;
        }

        //数组去重
        function uniqueArr(arr){
            let newArr = [];
            for (let i = 0; i < arr.length; i++) {
                if (newArr.indexOf(arr[i]) === -1 && arr[i]) {
                    newArr.push(arr[i]);
                }
            }
            return newArr;
        }

        /**
         * 获取子公司和币种
         * @returns {*[]}
         */
        const searchSubsidiayCurrency = () => {
            let subsidiaryArr = [];
            let searchObj = search.create({
                type:'subsidiary',
                filters:[],
                columns:[
                    search.createColumn({name : 'internalid'}),
                    search.createColumn({name : 'name'}),
                    search.createColumn({name : 'currency'}),
                    search.createColumn({name : 'custrecord_ecm_taxcode'}),
                ]
            });
            let searchRes = commonApi.getAllData(searchObj);
            let columns = searchObj.columns;
            if(searchRes.length > 0){
                for(let index = 0; index < searchRes.length; index++){
                    let subsidiaryName = searchRes[index].getValue(columns[0]);
                    let currency = searchRes[index].getValue(columns[2]);
                    let taxcode = searchRes[index].getValue(columns[3]);
                    let subsidiaryJson = {
                        'subsidiaryName' : subsidiaryName,
                        'currency' : currency,
                        'taxcode' : taxcode,
                    }
                    subsidiaryArr.push(subsidiaryJson);
                }
            }
            return subsidiaryArr;
        }

        /**
         * 获取sc单据对应的ss(一对多关系)
         * @param scId
         * @returns {*[]}
         */
        const searchSsBySc = (scId) => {
            let ssArr = [];

            let ssSearch = search.create({
                type:"customrecord_shipping_schedule",
                filters:[
                    ["custrecord_ssc_scnumber", "anyof", scId],
                    "AND",
                    ["custrecord_ssc_completescd","is","F"]
                ],
                columns:[
                    search.createColumn({name : 'internalid'})
                ]
            });
            let ssRes = commonApi.getAllData(ssSearch);
            let ssCol = ssSearch.columns;
            if(ssRes.length > 0){
                for(let index = 0; index < ssRes.length; index ++){
                    let scId = ssRes[index].getValue(ssCol[0]);
                    ssArr.push(scId);
                }
            }
            return ssArr;
        }


        /**
         * sc、ss等数据创建scd
         * @param ssData
         */
        const createScdByShippingSchedule = (ssData) => {
            let scdRec = record.create({type:'customrecord_ecm_scd'});
            //body
            for(let key in ssData){
                if(ssData[key] && key != 'ssArr' && key != 'custrecord_scd_shipdate'){
                    scdRec.setValue({fieldId:key, value:ssData[key]})
                }else if(key == 'custrecord_scd_shipdate'){
                    scdRec.setText({fieldId:key, text:ssData[key]})
                }
            }
            if(ssData.ssArr.length > 0){
                for(let i = 0; i < ssData.ssArr.length; i++){
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_item', value:ssData.ssArr[i].lineContactItem, line:i});
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_scitem', value:ssData.ssArr[i].lineContactItem, line:i});
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_uniquekey', value:ssData.ssArr[i].custrecord_scdline_uniquekey, line:i});
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_qty', value:ssData.ssArr[i].ssQty, line:i});
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_ssscdqty', value:ssData.ssArr[i].lineQty, line:i});
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_ssqty', value:ssData.ssArr[i].lineQty, line:i});
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_unit', value:ssData.ssArr[i].lineUnit, line:i});
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_amt', value:ssData.ssArr[i].lineamt, line:i});
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_taxcode', value:ssData.ssArr[i].linecode, line:i});
                    scdRec.setSublistText({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_taxrate', text:ssData.ssArr[i].linerate, line:i});
                    let percentRate = commonApi.percentToNumber(ssData.ssArr[i].linerate);
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_taxgross', value:Number(Number(ssData.ssArr[i].ssQty).mul(Number(percentRate))).mul(Number(ssData.ssArr[i].lineamt)), line:i});
                    let newRate = Number(percentRate) + 1;
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_grossamt', value:Number(Number(ssData.ssArr[i].ssQty).mul(Number(ssData.ssArr[i].lineamt))).mul(Number(newRate)), line:i});
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_purchasetaxcode', value:ssData.ssArr[i].custrecord_scdline_purchasetaxcode, line:i});

                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_landfreightcost', value:ssData.ssArr[i].cost1, line:i});//陆运费
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_tariffcost', value:ssData.ssArr[i].cost2, line:i});
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_seafreightcost', value:ssData.ssArr[i].cost3, line:i});
                    // scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_perscost', value:ssData.ssArr[i].cost4, line:i});
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_clearancecost', value:ssData.ssArr[i].cost5, line:i});
                    // scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_storagecost', value:ssData.ssArr[i].cost6, line:i});
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_inspectioncost', value:ssData.ssArr[i].cost7, line:i});
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_gross_weight', value:ssData.ssArr[i].custrecord_scdline_gross_weight, line:i});
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_net_weight', value:ssData.ssArr[i].custrecord_scdline_net_weight, line:i});
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_volume', value:ssData.ssArr[i].custrecord_scdline_volume, line:i});
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_msds', value:ssData.ssArr[i].custrecord_scdline_msds, line:i});
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_certifforsea', value:ssData.ssArr[i].custrecord_scdline_certifforsea, line:i});
                    if(ssData.ssArr[i].custrecord_scdline_certifforair){
                        scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_certifforair', value:ssData.ssArr[i].custrecord_scdline_certifforair, line:i});
                    }
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_technrailway', value:ssData.ssArr[i].custrecord_scdline_technrailway, line:i});
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_dangpackinginstruction', value:ssData.ssArr[i].custrecord_scdline_dangpackinginstruction, line:i});
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_dangsyndrome', value:ssData.ssArr[i].custrecord_scdline_dangsyndrome, line:i});
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_resuttsheet', value:ssData.ssArr[i].custrecord_scdline_resuttsheet, line:i});
                    //idi record
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_declarationinfo', value:ssData.ssArr[i].custrecord_scdline_declarationinfo, line:i});
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_custom_basicinfo', value:ssData.ssArr[i].custrecord_scdline_custom_basicinfo, line:i});
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_cusdel_name', value:ssData.ssArr[i].custrecord_scdline_cusdel_name, line:i});
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_elements_declarati', value:ssData.ssArr[i].custrecord_scdline_elements_declarati, line:i});
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_area', value:ssData.ssArr[i].custrecord_scdline_area, line:i});
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_hs_code', value:ssData.ssArr[i].custrecord_scdline_hs_code, line:i});
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_conditions_customs', value:ssData.ssArr[i].custrecord_scdline_conditions_customs, line:i});
                    scdRec.setSublistText({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_taxrefund_rate', text:ssData.ssArr[i].custrecord_scdline_taxrefund_rate, line:i});
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_codition', value:ssData.ssArr[i].custrecord_scdline_codition, line:i});
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_category', value:ssData.ssArr[i].custrecord_scdline_category, line:i});
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_extax_reftype', value:ssData.ssArr[i].custrecord_scdline_extax_reftype, line:i});
                    scdRec.setSublistText({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_extax_refund', text:ssData.ssArr[i].custrecord_scdline_extax_refund, line:i});
                    // scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_import_tariff_type', value:ssData.ssArr[i].custrecord_scdline_import_tariff_type, line:i});
                    // scdRec.setSublistText({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_import_tariffs', text:ssData.ssArr[i].custrecord_scdline_import_tariffs, line:i});
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_vat_type', value:ssData.ssArr[i].custrecord_scdline_vat_type, line:i});
                    scdRec.setSublistText({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_vat', text:ssData.ssArr[i].custrecord_scdline_vat, line:i});
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_specialcode', value:ssData.ssArr[i].custrecord_scdline_specialcode, line:i});
                    //取表头信息
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_distributiontype', value:2, line:i});//默认为 合同发货
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_sc', value:ssData.custrecord_scd_sc, line:i});
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_ss', value:ssData.custrecord_scd_ss, line:i});
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_perscost', value:ssData.ssArr[i].perscost, line:i});
                    let packQty = Number(ssData.ssArr[i].ssQty) / Number(ssData.ssArr[i].custrecord_scdline_net_weight);

                    if(ssData.ssArr[i].lineContactItem){
                        let primaryUnit = search.lookupFields({
                            type:'item',
                            id:ssData.ssArr[i].lineContactItem,
                            columns:['unitstype']
                        });
                        let mainUnit = '';
                        if(Object.keys(primaryUnit['unitstype']).length > 0){
                            mainUnit = primaryUnit['unitstype'][0].value;
                            if(mainUnit == 7 || mainUnit == '7'){//item主单位为package时，取SCD QUANTITY{custrecord_scdline_qty}，否则为空
                                // scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_packing_qty', value:packQty, line:i});
                                scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_packing_qty', value:ssData.ssArr[i].ssQty, line:i});
                            }else{
                                scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_packing_qty', value:'', line:i});
                            }
                        }
                    }

                    //待计算
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_priceunit', value:ssData.ssArr[i].linePriceUnit, line:i});
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_scdlineid', value:ssData.ssArr[i].lineId, line:i});
                    scdRec.setSublistText({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_sslineid', text:ssData.ssArr[i].lineIndex, line:i});
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_chname', value:ssData.ssArr[i].lineCnName, line:i});
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_enname', value:ssData.ssArr[i].lineEgName, line:i});
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_casno', value:ssData.ssArr[i].lineCas, line:i});
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_sourcing', value:ssData.ssArr[i].lineSourcer, line:i});
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_punch', value:ssData.ssArr[i].linePallet, line:i});
                    scdRec.setSublistText({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_pushipdate', text:ssData.ssArr[i].lineExpshipDate, line:i});
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_poqty', value:ssData.ssArr.length, line:i});
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_demander', value:ssData.custrecord_scd_demander, line:i});//销售子公司
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_commissionunitprice', value:ssData.ssArr[i].custrecord_scdline_commissionunitprice, line:i});//销售子公司
                    scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_totalcommission', value:ssData.ssArr[i].custrecord_scdline_totalcommission, line:i});//销售子公司
                    if(ssData.ssArr[i].linePriceUnit == ssData.ssArr[i].lineUnit){//已配货数量
                        scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_priceqty', value:ssData.ssArr[i].lineCalQty, line:i});
                    }else{
                        let newQty = Number(ssData.ssArr[i].lineCalQty).mul(Number(ssData.ssArr[i].capacity));
                        scdRec.setSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd', fieldId:'custrecord_scdline_priceqty', value:newQty, line:i});
                    }
                }
            }
            let scdId = scdRec.save({enableSourcing:true, ignoreMandatoryFields:true});
            // log.debug('scdId',scdId);
            if(scdId){//回写
                let ssRec = record.load({type:'customrecord_shipping_schedule', id:ssData.custrecord_scd_ss});
                ssRec.setValue({fieldId:'custrecord_ssc_completescd', value:true});
                let ssNum = ssRec.getLineCount('recmachcustrecord_sscd_parent');
                if(ssNum > 0){
                    for(let index = 0; index < ssNum; index++){
                        let hasScdNum = ssRec.getSublistValue({sublistId:'recmachcustrecord_sscd_parent',fieldId:'custrecord_sscd_ssqty',line:index}) || 0;
                        ssRec.setSublistValue({sublistId:'recmachcustrecord_sscd_parent',fieldId:'custrecord_sscd_csdty_created',value:hasScdNum,line:index})
                    }
                }
                ssRec.save({enableSourcing:true, ignoreMandatoryFields:true});
            }

        }

        return {execute}

    });
