/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 * Version          Date(m-d-y)            Author            Remark
 * 1.0              2022/2/23         Kori            TAPD【1018572】PO Create ICSO (公司间SO)
 * 2.0              2023/1/3          Kori            增加currency自动带值
 * 3.0              2023/3/17         Kori            sl下拉列表选项调整增加taxcode,subsidiary自动取值
 * 4.0              2023/3/29         Kori            增加uniquekey字段赋值
 * 5.0              2023/4/13         Kori            新增字段
 * 6.0              2023/4/17         Kori            新增批量字段
 * 7.0              2023/4/19         Kori            新增：当前员工字段赋值so
 */
define(['N/record', 'N/search', 'N/ui/serverWidget', 'N/https', 'N/runtime', '../tools/common_api.js'],
    /**
     * @param{record} record
     * @param{search} search
     * @param{serverWidget} serverWidget
     */
    (record, search, serverWidget, https, runtime, commonApi) => {
        /**
         * Defines the Suitelet script trigger point.
         * @param {Object} scriptContext
         * @param {ServerRequest} scriptContext.request - Incoming request
         * @param {ServerResponse} scriptContext.response - Suitelet response
         * @since 2015.2
         */
        const onRequest = (scriptContext) => {
            let request = scriptContext.request;
            let response = scriptContext.response;
            let param = request.parameters;
            let poId = param.poId;
            let poSub = param.poSub;
            let posubsidiary = param.poSub;
            let poNum = param.poNum;
            let country = param.country;
            let method = request.method;
            if('GET' == method){
                let curForm = createIcpoSlForm(poId,poSub,posubsidiary,poNum,country);
                response.writePage(curForm);
            }else{
                let recid = param.custpage_recordid;
                let customer = param.custpage_customer;
                let currency = param.custpage_currency;
                let taxcode = param.custpage_taxrate;
                let subsidiary = param.custpage_subsidiary;
                let ponum = param.custpage_ponum;
                // log.debug('recid',recid);
                let poJson = {
                    recid:recid,
                    customer:customer,
                    currency:currency,
                    taxcode:taxcode,
                    subsidiary:subsidiary,
                    ponum:ponum
                }
                let icsoId = createIcsoRecord(poJson);
                if(icsoId){
                    //回写字段
                    let poRec = record.load({type:'purchaseorder', id:recid});
                    poRec.setValue({fieldId:'custbody_ecm_icposo_transaction', value:icsoId});
                    poRec.save({enableSourcing:true,ignoreMandatoryFields:true});
                    //页面跳转
                    let soStr = 'SANDBOX' == runtime.envType ? 'https://7284938-sb1.app.netsuite.com/app/accounting/transactions/salesord.nl?id='+ icsoId +'&whence=' :'https://7284938-sb1.app.netsuite.com/app/accounting/transactions/salesord.nl?id='+ icsoId +'&whence=';
                    let soUrl = soStr;
                    //刷新父页面后关闭窗口
                    response.write('<script>window.opener.location.reload();window.opener.open("'+soUrl+'", "_blank");window.close();</script>')
                }

            }

        }

        /**
         * 创建sl页面
         * @param poId
         * @param poSub
         * @param posubsidiary
         * @param poNum
         * @param country
         * @returns {*}
         */
        const createIcpoSlForm = (poId,poSub,posubsidiary,poNum,country) =>{
            let curForm = serverWidget.createForm({title:'Create ICSO', hideNavBar:false});
            curForm.clientScriptModulePath = './cs_create_icso.js';
            curForm.addSubmitButton('Submit');
            curForm.addButton({id:'custpage_btn_cspo_close', label:'Close', functionName:`closePage()`});

            curForm.addFieldGroup({id:'custpage_shuruzhi', label:'输入值'});
            let customer = curForm.addField({id:'custpage_customer', type:'SELECT', label:'Customer', source:'customer', container:'custpage_shuruzhi'});
            let currency = curForm.addField({id:'custpage_currency', type:'SELECT', label:'Currency', container:'custpage_shuruzhi'});
            currency.addSelectOption({value:'', text:''});
            let subsidiary = curForm.addField({id:'custpage_subsidiary', type:'SELECT', label:'Subsidiary',container:'custpage_shuruzhi'});
            subsidiary.addSelectOption({value:'', text:''});
            let taxrate = curForm.addField({id:'custpage_taxrate', type:'SELECT', label:'Tax Code',container:'custpage_shuruzhi'});
            taxrate.addSelectOption({value:'', text:''});
            customer.isMandatory = true;
            currency.isMandatory = true;
            taxrate.isMandatory = true;

            curForm.addFieldGroup({id:'custpage_sourse', label:'来源'});
            let ponum = curForm.addField({id:'custpage_ponum', type:'TEXT', label:'ICPO',container:'custpage_sourse'});
            let recordId = curForm.addField({id:'custpage_recordid', type:'TEXT', label:'poId'});
            recordId.updateDisplayType({
                displayType : serverWidget.FieldDisplayType.HIDDEN
            });
            recordId.defaultValue = poId;

            ponum.updateDisplayType({
                displayType : serverWidget.FieldDisplayType.DISABLED
            });
            ponum.updateDisplaySize({
                height : 25,
                width : 30
            });
            ponum.defaultValue = poNum;

            return curForm;
        }

        const createIcsoRecord = (poJson) => {
            let {bodyData,itemData} = getIcpoData(poJson.recid);
            //create ICSO
            let soRec = record.create({type:'salesorder', isDynamic:true, defaultValue:{customform:'SANDBOX'== runtime.envType ? 101:101}});
            soRec.setValue({fieldId:'entity', value:poJson.customer});
            soRec.setValue({fieldId:'subsidiary', value:poJson.subsidiary});
            soRec.setValue({fieldId:'custbody_ecm_icposo_transaction', value:poJson.recid});
            soRec.setText({fieldId:'currency', text:poJson.currency});
            soRec.setValue({fieldId:'custbody_ecm_ordertype', value:'SANDBOX'== runtime.envType ? 3:3});
            soRec.setValue({fieldId:'custbody_ecm_incoterm', value:bodyData.incoterm});
            soRec.setValue({fieldId:'custbody_ecm_contract_type', value:6});
            soRec.setValue({fieldId:'custbody_ecm_iswarehousestock', value:true});
            soRec.setValue({fieldId:'terms', value:bodyData.terms});
            //20230417新增字段：
            soRec.setValue({fieldId:'custbody_ecm_shipping_method', value:bodyData.custbody_ecm_shipping_method});
            soRec.setValue({fieldId:'custbody_ecm_loadingport', value:bodyData.custbody_ecm_loadingport});
            soRec.setValue({fieldId:'custbody_ecm_incoterm', value:bodyData.custbody_ecm_incoterm});
            soRec.setValue({fieldId:'custbody_ecm_countryof_departure', value:bodyData.custbody_ecm_countryof_departure});
            soRec.setValue({fieldId:'custbody_ecm_destination_port', value:bodyData.custbody_ecm_destination_port});
            soRec.setValue({fieldId:'custbody_ecm_countryof_destination', value:bodyData.custbody_ecm_countryof_destination});
            soRec.setValue({fieldId:'custbody_ecm_prepayment_ratio', value:String(bodyData.custbody_ecm_prepayment_ratio)});
            soRec.setValue({fieldId:'custbody_ecm_prepay_method', value:bodyData.custbody_ecm_prepay_method});
            soRec.setValue({fieldId:'custbody_ecm_prepay_node', value:bodyData.custbody_ecm_prepay_node});
            soRec.setValue({fieldId:'custbody_ecm_advance_prepaydays', value:bodyData.custbody_ecm_advance_prepaydays});
            soRec.setValue({fieldId:'custbody_ecm_balance_prepay_method', value:bodyData.custbody_ecm_balance_prepay_method});
            soRec.setValue({fieldId:'custbody_ecm_balance_prepay_node', value:bodyData.custbody_ecm_balance_prepay_node});
            soRec.setValue({fieldId:'custbody_ecm_balance_termsdays', value:bodyData.custbody_ecm_balance_termsdays});
            soRec.setValue({fieldId:'custbody_ecm_deliverydate_type', value:bodyData.custbody_ecm_deliverydate_type});
            //419新增字段
            soRec.setValue({fieldId:'custbody_ecm_cusservice', value:runtime.getCurrentUser().id});

            if(itemData.length > 0){
                for(let index = 0; index < itemData.length; index++){
                    soRec.selectNewLine({sublistId:'item'});
                    soRec.setCurrentSublistValue({sublistId:'item',fieldId:'item',value:itemData[index].lineItem});
                    soRec.setCurrentSublistValue({sublistId:'item',fieldId:'units',value:itemData[index].lineUnit});
                    soRec.setCurrentSublistValue({sublistId:'item',fieldId:'quantity',value:itemData[index].lineQty});
                    soRec.setCurrentSublistValue({sublistId:'item',fieldId:'taxcode',value:Number(poJson.taxcode)});
                    soRec.setCurrentSublistValue({sublistId:'item',fieldId:'rate',value:itemData[index].linerate});
                    soRec.setCurrentSublistValue({sublistId:'item',fieldId:'amount',value:itemData[index].lineamount});
                    soRec.setCurrentSublistValue({sublistId:'item',fieldId:'custcol_ecm_uniquekey',value:itemData[index].uniquekey});
                    soRec.commitLine({sublistId:'item'});
                }
            }
            let ratei = soRec.getSublistValue({sublistId:'item',fieldId:'rate',line:0});
            let icsoId = soRec.save({enableSourcing:true, ignoreMandatoryFields:true});
            return icsoId;
        }

        const getIcpoData = (recid) =>{
            let poRec = record.load({type:'purchaseorder', id:recid});
            let bodyData = getIcpoBodyInfo(poRec);
            let itemData = getIcpoItemInfp(poRec);
            return{bodyData,itemData};
        }

        const getIcpoBodyInfo = (poRec) => {
            let bodyData = {};
            let incoterm = poRec.getValue('incoterm');
            let terms = poRec.getValue('terms');
            //2023/4/17新增字段
            let custbody_ecm_shipping_method = poRec.getValue('custbody_ecm_shipping_method');
            let custbody_ecm_incoterm = poRec.getValue('custbody_ecm_incoterm');
            let custbody_ecm_loadingport = poRec.getValue('custbody_ecm_loadingport');
            let custbody_ecm_countryof_departure = poRec.getValue('custbody_ecm_countryof_departure');
            let custbody_ecm_destination_port = poRec.getValue('custbody_ecm_destination_port');
            let custbody_ecm_countryof_destination = poRec.getValue('custbody_ecm_countryof_destination');
            let custbody_ecm_prepayment_ratio = poRec.getValue('custbody_ecm_prepayment_ratio');
            let custbody_ecm_prepay_method = poRec.getValue('custbody_ecm_prepay_method');
            let custbody_ecm_prepay_node = poRec.getValue('custbody_ecm_prepay_node');
            let custbody_ecm_advance_prepaydays = poRec.getValue('custbody_ecm_advance_prepaydays');
            let custbody_ecm_balance_prepay_method = poRec.getValue('custbody_ecm_balance_prepay_method');
            let custbody_ecm_balance_prepay_node = poRec.getValue('custbody_ecm_balance_prepay_node');
            let custbody_ecm_balance_termsdays = poRec.getValue('custbody_ecm_balance_termsdays');
            let custbody_ecm_deliverydate_type = poRec.getValue('custbody_ecm_deliverydate_type');


            bodyData.terms = terms;
            bodyData.incoterm = incoterm;
            bodyData.custbody_ecm_shipping_method = custbody_ecm_shipping_method;
            bodyData.custbody_ecm_incoterm = custbody_ecm_incoterm;
            bodyData.custbody_ecm_loadingport = custbody_ecm_loadingport;
            bodyData.custbody_ecm_countryof_departure = custbody_ecm_countryof_departure;
            bodyData.custbody_ecm_destination_port = custbody_ecm_destination_port;
            bodyData.custbody_ecm_countryof_destination = custbody_ecm_countryof_destination;
            bodyData.custbody_ecm_prepayment_ratio = custbody_ecm_prepayment_ratio;
            bodyData.custbody_ecm_prepay_method = custbody_ecm_prepay_method;
            bodyData.custbody_ecm_prepay_node = custbody_ecm_prepay_node;
            bodyData.custbody_ecm_advance_prepaydays = custbody_ecm_advance_prepaydays;
            bodyData.custbody_ecm_balance_prepay_method = custbody_ecm_balance_prepay_method;
            bodyData.custbody_ecm_balance_prepay_node = custbody_ecm_balance_prepay_node;
            bodyData.custbody_ecm_balance_termsdays = custbody_ecm_balance_termsdays;
            bodyData.custbody_ecm_deliverydate_type = custbody_ecm_deliverydate_type;
            return bodyData;
        }

        const getIcpoItemInfp = (poRec) => {
            let itemData = [];
            let lineCount = poRec.getLineCount({sublistId:'item'});
            for(let index = 0; index < lineCount; index++){
                let lineNo = poRec.getSublistValue({sublistId:'item',fieldId:'line',line:index});
                let lineItem = poRec.getSublistValue({sublistId:'item',fieldId:'item',line:index});
                let lineUnit = poRec.getSublistValue({sublistId:'item',fieldId:'units',line:index});
                let lineQty = poRec.getSublistValue({sublistId:'item',fieldId:'quantity',line:index}) || 0;
                let lineCode = poRec.getSublistValue({sublistId:'item',fieldId:'taxcode',line:index});
                let linerate = poRec.getSublistValue({sublistId:'item',fieldId:'rate',line:index});
                let lineamount = poRec.getSublistValue({sublistId:'item',fieldId:'amount',line:index});
                let uniquekey = poRec.getSublistValue({sublistId:'item',fieldId:'custcol_ecm_uniquekey',line:index});
                let lineJson = {
                    lineNo:lineNo,
                    lineItem:lineItem,
                    lineUnit:lineUnit,
                    lineQty:lineQty,
                    lineCode:lineCode,
                    linerate:linerate,
                    lineamount:lineamount,
                    uniquekey:uniquekey
                }
                itemData.push(lineJson);
            }
            return itemData;
        }

        const searchTaxcode = (country1, subsidiary1) =>{
            let taxArr = [];
            let taxcodeSearch = search.create({
                type: "salestaxitem",
                filters:
                    [
                        ["country","anyof",country1],
                        "AND",
                        ["subsidiary","anyof",subsidiary1]
                    ],
                columns:
                    [
                        search.createColumn({name: "name", label: "名称"}),
                        search.createColumn({
                            name: "rate",
                            sort: search.Sort.ASC,
                            label: "税率"
                        })
                    ]
            });
            let taxRes = commonApi.getAllData(taxcodeSearch);
            let taxCol = taxcodeSearch.columns;
            if(taxRes.length > 0){
                for(let index = 0; index < taxRes.length; index++){
                    let taxname = taxRes[index].getValue(taxCol[0]);
                    let taxcode = taxRes[index].getValue(taxCol[1]);
                    let taxJson = {
                        'taxname':taxname,
                        'taxcode':taxcode,
                    }
                    taxArr.push(taxJson);
                }
            }
            return taxArr;
        }

        return {onRequest}

    });
