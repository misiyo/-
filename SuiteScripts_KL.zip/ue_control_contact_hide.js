/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * Version          Date            Author           Remark
 * 1.0              2/28/2023       Kori             TAPD【1018455】合同配货页面控制
 */
define(['N/record', 'N/runtime'],
    /**
 * @param{record} record
 */
    (record, runtime) => {
        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {
            let newRec= scriptContext.newRecord;
            let recType = scriptContext.type;
            let curForm = scriptContext.form;
            let role = runtime.getCurrentUser().role;
            if(recType == 'view' && role != '3' && role != 3){
            // if(recType == 'view'){
                //隐藏预览页面编辑、删除
                hiddenSublistLink(curForm, 'recmachcustrecord_ecm_scdline_scd');

                // jQuery('#recmachcustrecord_ecm_scdline_scd__tab').find('tbody').children('tr').each(function() {jQuery(this).children('td')[47].remove()});
                // jQuery('#recmachcustrecord_ecm_scdline_scd__tab').find('tbody').children('tr').each(function() {jQuery(this).children('td')[0].remove()});
                // jQuery('#div__lab48').remove();
                // jQuery('#div__lab1').remove();
            }
        }

        /**
         * Defines the function definition that is executed before record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const beforeSubmit = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {

        }

        /**
         * 隐藏子记录编辑/删除链接
         *
         * @param sublistId        子记录tableid，去除__tab
         *
         *
         */
        function hiddenSublistLink(form,sublistId) {

            var fnBody='setTimeout(function(){ var sublistId="'+sublistId+'";';
            fnBody +='var handleHidden=function(){var cols=[];var tableId=sublistId+"__tab";var mytable=document.getElementById(tableId);var colsCount=mytable.rows[0].cells.length;var len=mytable.rows.length;for(var i=0;i<colsCount;i++){var label=mytable.rows[0].cells[i].innerText;if(label=="编辑"||label=="edit" || label=="EDIT" ||label=="删除"||label=="delete"||label=="REMOVE"){cols.push(i)}}if(cols.length<1){throw""}cols.sort();for(var i=0;i<len;i++){for(var x=0;x<cols.length;x++){mytable.rows[i].deleteCell(cols[x]-x)}}};function startHidden(){window.hiddenTimes=0;clearInterval(window.hiddenProcessTimer);window.hiddenProcessTimer=setInterval(function(){if(!window.oldSortFun){var sortFunName=sublistId+"doServerSort";window.oldSortFun=window[sortFunName];window[sortFunName]=function(col){window.oldSortFun(col);startHidden()}}try{console.log("window.hiddenTimes:"+window.hiddenTimes);handleHidden();clearInterval(window.hiddenProcessTimer)}catch(e){console.log(JSON.stringify(e))};window.hiddenTimes++;if(window.hiddenTimes>10){clearInterval(window.hiddenProcessTimer)}},500)}startHidden();';
            fnBody+=' },0);'
            var field = form.addField({
                id : 'custpage_innerhtml_for_hidden_link'+ String((new Date()).getTime())+Math.floor(Math.random()*100000),
                label : ' ',
                type : "INLINEHTML"
            });
            field.defaultValue = '<script>' + fnBody + '</script>';

        }

        return {beforeLoad/**, beforeSubmit, afterSubmit**/}

    });
