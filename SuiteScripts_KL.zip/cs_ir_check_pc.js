/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 * Version           Date              Author               Remark
 * 1.0               2/24/2023         Kori                 TAPD【1018574】IR单 批次重复校验
 * 2.0               3/3/2023          Kori                 批次重复校验测试支持
 * 3.0               3/20/2023         Kori                 新增货品、地点存在时，获取批次校验
 */
define(['N/currentRecord', 'N/search', '../tools/common_api.js'],
/**
 * @param{currentRecord} currentRecord
 * @param{search} search
 */
function(currentRecord, search, commonApi) {
    
    /**
     * Function to be executed after page is initialized.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.mode - The mode in which the record is being accessed (create, copy, or edit)
     *
     * @since 2015.2
     */
    function pageInit(scriptContext) {

    }

    /**
     * Function to be executed when field is changed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
     * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
     *
     * @since 2015.2
     */
    function fieldChanged(scriptContext) {

    }

    /**
     * Function to be executed when field is slaved.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     *
     * @since 2015.2
     */
    function postSourcing(scriptContext) {

    }

    /**
     * Function to be executed after sublist is inserted, removed, or edited.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @since 2015.2
     */
    function sublistChanged(scriptContext) {

    }

    /**
     * Function to be executed after line is selected.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @since 2015.2
     */
    function lineInit(scriptContext) {

    }

    /**
     * Validation function to be executed when field is changed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
     * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
     *
     * @returns {boolean} Return true if field is valid
     *
     * @since 2015.2
     */
    function validateField(scriptContext) {

    }

    /**
     * Validation function to be executed when sublist line is committed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateLine(scriptContext) {

    }

    /**
     * Validation function to be executed when sublist line is inserted.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateInsert(scriptContext) {

    }

    /**
     * Validation function to be executed when record is deleted.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateDelete(scriptContext) {

    }

    /**
     * Validation function to be executed when record is saved.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @returns {boolean} Return true if record is valid
     *
     * @since 2015.2
     */
    function saveRecord(scriptContext) {
        try{
            var isNotSameInventoryPc = irInventoryPcCheck(scriptContext);
            if(!isNotSameInventoryPc){
                return false;
            }
        }catch (e) {
            log.error('e=>',e.message)
        }
        return true;
    }

    /**
     * IR单库存详细信息批次重复校验
     * @param scriptContext
     * @returns {boolean}
     */
    function irInventoryPcCheck(scriptContext){
        var isNotSameInventoryPc = true;
        var curRec = scriptContext.currentRecord;
        if(!curRec.id){//新建时触发
            // console.log('批次校验','批次校验');
            var lineCount = curRec.getLineCount({sublistId:'item'});
            var existPcArr = searchExistPc();
            if(lineCount > 0){
                for(var index = 0; index < lineCount; index++){
                    var lineitem = curRec.getSublistValue({sublistId:'item', fieldId:'item', line:index});
                    var linelocation = curRec.getSublistValue({sublistId:'item', fieldId:'location', line:index});
                    var lineQty = curRec.getSublistValue({sublistId:'item', fieldId:'quantity', line:index}) || 0;
                    if(lineitem && linelocation && (lineQty > 0)){
                        curRec.selectLine({sublistId:'item', line:index});
                        var invRec = curRec.getCurrentSublistSubrecord({sublistId:'item', fieldId:'inventorydetail'});
                        var invLine = invRec.getLineCount({sublistId:'inventoryassignment'});
                        if(invLine > 0){
                            for(var k = 0; k < invLine; k++) {
                                invRec.selectLine({sublistId:'inventoryassignment', line:k})
                                var linePc = invRec.getCurrentSublistValue({
                                    sublistId: 'inventoryassignment',
                                    fieldId: 'receiptinventorynumber'
                                });
                                for (var j = 0; j < existPcArr.length; j++) {
                                    if (existPcArr[j].item == lineitem && existPcArr[j].location == linelocation && String(existPcArr[j].invNum) == String(linePc)) {
                                        alert('The batch number you entered has existed in the system, please check and enter the correct batch number. （您输入的批号在系统中已存在,请检查并输入正确的批号。）')
                                        // return false;
                                        isNotSameInventoryPc = false;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return isNotSameInventoryPc;
    }

    /**
     * 获取库存详细信息的item、location、批次号
     * @returns {*[]}
     */
    function searchExistPc(){
        var invData = [];
        var invdSearch = search.create({
            type: "inventorydetail",
            filters:
                [
                    ["transaction.type","noneof","PurchOrd","SalesOrd"]
                ],
            columns:
                [
                    search.createColumn({name: "item", label: "货品"}),
                    search.createColumn({name: "location", label: "地点"}),
                    search.createColumn({
                        name: "inventorynumber",
                        sort: search.Sort.ASC,
                        label: " 编号"
                    }),
                    search.createColumn({name: "status", label: "状态"})
                ]
        });
        var invRes = commonApi.getAllData(invdSearch);
        var invCol = invdSearch.columns;
        if(invRes.length > 0){
            for(var i = 0; i < invRes.length; i++){
                var item = invRes[i].getValue(invCol[0]);
                var location = invRes[i].getValue(invCol[1]);
                var invNum = invRes[i].getText(invCol[2]);
                var invJson = {
                    item:item,
                    location:location,
                    invNum:invNum,
                }
                invData.push(invJson);
            }
        }
        return invData;
    }

    return {
        // pageInit: pageInit,
        // fieldChanged: fieldChanged,
        // postSourcing: postSourcing,
        // sublistChanged: sublistChanged,
        // lineInit: lineInit,
        // validateField: validateField,
        // validateLine: validateLine,
        // validateInsert: validateInsert,
        // validateDelete: validateDelete,
        saveRecord: saveRecord
    };
    
});
