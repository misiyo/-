/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * Version          Date            Author          Remark
 * 1.0              2023/2/20       Kori            TAPD【1018453】自动生成合同配货——海外仓直发
 * 1.1              2023/4/3        Kori            权限更改为 管理员、Overseas Logistics Specialist角色
 * 1.2              2023/4/10       Kori            新增字段：SCD明细行的Cargo Premium{custrecord_scdline_perscost}
 *                                                  =Unit Price of Primary Sale Unit{custrecord_scdline_amt}/Item
 *                                                  的Unit Capacity{custitem_ecm_case_package_kg}*0.00028*1.1
 */
define(['N/record', 'N/search', 'N/task', 'N/runtime'],
    /**
 * @param{record} record
 * @param{search} search
 * @param{task} task
 */
    (record, search, task, runtime) => {
        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed before record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const beforeSubmit = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {
            scAndSsCreateScdRecord(scriptContext);//仓库直发生成scd
        }

        /**
         * ss仓库直发生成scd记录
         * @param scriptContext
         */
        const scAndSsCreateScdRecord = (scriptContext) => {
            let fucStatus = 'SANDBOX' == runtime.envType ? 2 : 2;//"生效"
            let cType = 'SANDBOX' == runtime.envType ? 5 : 5;//海外仓、仓库直发
            let recRole = runtime.getCurrentUser().role;

            let recType = scriptContext.type;
            let newRec = scriptContext.newRecord;
            let oldRec = scriptContext.oldRecord;
            let contactType = newRec.getValue('custbody_ecm_contract_type');
            if (recType == 'edit' && (recRole == 3 || recRole == '3' || recRole == '1125' || recRole == 1125)){
                let newStatus = newRec.getValue('custbody_ecm_document_status');//生效状态
                let oldStatus = oldRec.getValue('custbody_ecm_document_status');
                if (oldStatus != fucStatus && newStatus == fucStatus && contactType == cType) {
                    task.create({
                        taskType: task.TaskType.SCHEDULED_SCRIPT,
                        scriptId: 'customscript_hc_sc_create_scd_sch',
                        deploymentId: 'customdeploy_hc_sc_create_scd_sch_dep',
                        params: {
                            'custscript_sc_id': newRec.id
                        }
                    }).submit();

                }
            }
        }

        return {/**beforeLoad, beforeSubmit, **/afterSubmit}

    });
