/**
 * @NApiVersion 2.1
 * @NScriptType ScheduledScript
 *
 * Version		Date			Author			Memo
 * 1.0			2023/02/14		John Wang		中信保：限额余额接口＄1�718290＄1�7
 */
define(['N/https', 'N/record', 'N/task', '/SuiteScripts/tools/common_api.js', '/SuiteScripts/tools/hc_edi_interface_tool.js', '/SuiteScripts/tools/moment.js', '/SuiteScripts/tools/ramda.min.js'],
    /**
     * @param{https} https
     * @param{task} task
     */
    (https, record, task, commonApi, interfaceTool, moment, ramda) => {
        const QUOTA_BALANCE_TYPE = 'customrecord_ecm_sinosure_limitbalance';//限额余额记录id
        const LOG_TYPE = 'customrecord_hc_edi_interface_log';//日志类型
        const IMETHOD = 'getQuotaBalanceInfoByPolicyNo';//接口method
        const ITYPE = 1;//接口类型：限额余预1�7
        const FIELD_MAPPING = {
            'policyNo' : 'custrecord_esl_policyno',
            'quotaNo' : 'custrecord_esl_quotano',//主键
            'quotaBalance' : 'custrecord_esl_quotabalance',
            'refuseRate' : 'custrecord_esl_refuserate',
            'otherRate' : 'custrecord_esl_otherrate',
            'calculateTime' : 'custrecord_esl_calculatetime',
            'bankNo' : 'custrecord_esl_bankno',
            'payMode' : 'custrecord_esl_paymode',
            'errorCode': 'custrecord_esl_errorcode',
            'errorMsg': 'custrecord_esl_errormsg'
        };
        /**
         * Defines the Scheduled script trigger point.
         * @param {Object} scriptContext
         * @param {string} scriptContext.type - Script execution context. Use values from the scriptContext.InvocationType enum.
         * @since 2015.2
         */
        const execute = (scriptContext) => {
            let reqData = {
                "imethod": IMETHOD,
            };
            let rtnData = interfaceTool.requestEdiServer(reqData, ITYPE);
            log.debug('接口返回数据', rtnData)
            if(true == rtnData.valid) {
                let infoData = rtnData.data.datas;
                if(infoData && infoData.length > 0) {
                    infoData = JSON.parse(infoData);
                    //获取扄1�7有quotaNo，匹配已有数捄1�7
                    let quotaNos = ramda.groupBy(ramda.path(['quotaNo']))(infoData);
                    let existQuotaData = formatExistQuotaNo(Object.keys(quotaNos));
                    let buyerNos = ramda.groupBy(ramda.path(['buyerNo']))(infoData);
                    let customerData = formatCustomData(Object.keys(buyerNos));

                    let methodData = formatPayMethod();
                    log.debug('data===', infoData);
                    let createdDataIdArray = [],
                        logUpdVal = {
                            custrecord_hc_inf_process_msg: '',
                            custrecord_hc_inf_errorflag: false
                        };
                    try {
                        for(let i = 0; i < infoData.length; i++) {
                            let obj;
                            if('undefined' == typeof existQuotaData[infoData[i].quotaNo]) {
                                obj = record.create({type: QUOTA_BALANCE_TYPE});
                            } else {
                                obj = record.load({type: QUOTA_BALANCE_TYPE, id: existQuotaData[infoData[i].quotaNo]});
                            }
                            if(infoData[i].buyerNo && customerData[infoData[i].buyerNo]) {
                                obj.setValue({fieldId: 'custrecord_esl_buyerno', value: customerData[infoData[i].buyerNo]});
                            }
                            if(infoData[i].payMode) {
                                obj.setValue({fieldId: 'custrecord_esl_paymode', value: methodData[infoData[i].payMode] || ''});
                            }
                            for(key in infoData[i]) {
                                if('calculateTime' == key) {
                                    let tmpDate = moment(infoData[i].calculateTime);
                                    if (!isNaN(tmpDate)) {
                                        let tmpDateStr = tmpDate.format('MM/DD/YYYY');
                                        obj.setText({fieldId: FIELD_MAPPING[key], text: tmpDateStr});
                                    }
                                } else if('buyerNo' != key && 'payMode' != key){
                                    obj.setValue({fieldId: FIELD_MAPPING[key], value: infoData[i][key]});
                                }
                            }
                            let qid = obj.save();
                            createdDataIdArray.push(qid);
                        }
                        logUpdVal.custrecord_hc_inf_process_msg = createdDataIdArray.join('&');
                    } catch (e) {
                        log.error('生成限额余额error===>' + rtnData.logId, e);
                        if(createdDataIdArray && createdDataIdArray.length > 0) {
                            createdDataIdArray.forEach(function (cid) {
                                record.delete({type: QUOTA_BALANCE_TYPE, id: cid});
                            });
                        }
                        logUpdVal.custrecord_hc_inf_process_msg = e.message;
                        logUpdVal.custrecord_hc_inf_errorflag = true;
                    }
                    record.submitFields({
                        type: LOG_TYPE,
                        id: rtnData.logId,
                        values: logUpdVal
                    });
                }
            }
        }

        /**
         * 搜索已存在quotaNo记录
         * @param quotaNoArray              本次返回quotaNo
         * @return {{}}                     {quotaNo：id}
         */
        const formatExistQuotaNo = quotaNoArray => {
            let existData = {};//{quotaNo：id}
            if(!quotaNoArray || 0 == quotaNoArray.length) {
                return existData;
            }
            let filters = [],
                columns = ['custrecord_esl_quotano'];
            quotaNoArray.forEach(function (qno) {
                filters.push(['custrecord_esl_quotano', 'is', qno]);
                filters.push('or');
            });
            filters.pop();
            let results = commonApi.searchAllData(QUOTA_BALANCE_TYPE, filters, columns);
            if(results && results.length > 0) {
                results.forEach(function (res) {
                    existData[res.getValue(columns[0])] = res.id;
                });
            }
            log.debug('已存在quotaNo数据', existData);
            return existData;
        }

        /**
         * 搜索客户
         * @param quotaNoArray              本次返回buyerNo
         * @return {{}}                     {buyerNo：id}
         */
        const formatCustomData = buyerNoArray => {
            let existData = {};//{quotaNo：id}
            if(!buyerNoArray || 0 == buyerNoArray.length) {
                return existData;
            }
            let filters = [],
                columns = ['custentity_ecm_sinosurebuyerno'];
            buyerNoArray.forEach(function (bno) {
                filters.push(['custentity_ecm_sinosurebuyerno', 'is', bno]);
                filters.push('or');
            });
            filters.pop();
            let results = commonApi.searchAllData('customer', filters, columns);
            if(results && results.length > 0) {
                results.forEach(function (res) {
                    existData[res.getValue(columns[0])] = res.id;
                });
            }
            log.debug('匹配customer', existData);
            return existData;
        }

        /**
         * 搜索【中信保-支付方式〄1�7
         * @return {{}}                     {code：id}
         */
        const formatPayMethod = () => {
            let existData = {};//{quotaNo：id}
            let filters = [],
                columns = ['custrecord_esp_code'];
            let results = commonApi.searchAllData('customrecord_ecm_sinosure_paymethod', filters, columns);
            if(results && results.length > 0) {
                results.forEach(function (res) {
                    existData[res.getValue(columns[0])] = res.id;
                });
            }
            log.debug('匹配支付方式', existData);
            return existData;
        }

        return {execute}

    });
