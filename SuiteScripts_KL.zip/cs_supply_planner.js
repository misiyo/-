/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 * Version          Date            Author          Remark
 * 1.0              2023/2/21       Kori            TAPD【1018453】SCD 保存后custrecord_scdline_supplyplanner、custrecord_scdline_supplier自动带值
 * 2.0              2023/2/28       Kori            TAPD【1018455】合同配货页面控制，字段不可被编辑
 */
define(['N/currentRecord', 'N/runtime', 'N/search'],
/**
 * @param{currentRecord} currentRecord
 */
function(currentRecord, runtime, search) {
    var scdBodyField = {
        'custrecord_scd_sc' : 'custrecord_scd_sc',
        'custrecord_scd_disttype' : 'custrecord_scd_disttype',
        'custrecord_scd_supplier' : 'custrecord_scd_supplier',
        'custrecord_scd_vendor' : 'custrecord_scd_vendor',
        'custrecord_scd_purccurrency' : 'custrecord_scd_purccurrency',
        'custrecord_scd_location' : 'custrecord_scd_location',
        'custrecord_scd_shipdate' : 'custrecord_scd_shipdate',
        'custrecord_scd_pc' : 'custrecord_scd_pc',
        'custrecord_scd_ss' : 'custrecord_scd_ss',
        'custrecord_scd_sctype' : 'custrecord_scd_sctype',
        'custrecord_scd_currency' : 'custrecord_scd_currency',
        'custrecord_scd_preproportion' : 'custrecord_scd_preproportion',
        'custrecord_scd_pretype' : 'custrecord_scd_pretype',
        'custrecord_scd_prenode' : 'custrecord_scd_prenode',
        'custrecord_scd_preday' : 'custrecord_scd_preday',
        'custrecord_scd_surpproportion' : 'custrecord_scd_surpproportion',
        'custrecord_scd_surpnode' : 'custrecord_scd_surpnode',
        'custrecord_scd_surpday' : 'custrecord_scd_surpday',
        'custrecord_scd_surptype' : 'custrecord_scd_surptype',
        // 'custrecord_scd_paytermscn' : 'custrecord_scd_paytermscn',
        // 'custrecord_scd_paytermsen' : 'custrecord_scd_paytermsen',
        // 'custrecord_scd_japdelivery' : 'custrecord_scd_japdelivery',
    }

    var scdLineField = {
        'custrecord_scdline_item' :'custrecord_scdline_item',
        'custrecord_scdline_qty' :'custrecord_scdline_qty',
        'custrecord_scdline_unit' :'custrecord_scdline_unit',
        'custrecord_scdline_amt' :'custrecord_scdline_amt',
        'custrecord_scdline_taxcode' :'custrecord_scdline_taxcode',
        'custrecord_scdline_taxrate' :'custrecord_scdline_taxrate',
        'custrecord_scdline_taxgross' :'custrecord_scdline_taxgross',
        'custrecord_scdline_grossamt' :'custrecord_scdline_grossamt',
        'custrecord_scdline_scitem' :'custrecord_scdline_scitem',
        'custrecord_scdline_ssqty' :'custrecord_scdline_ssqty',
        'custrecord_scdline_ssscdqty' :'custrecord_scdline_ssscdqty',
        'custrecord_scdline_pclineid' :'custrecord_scdline_pclineid',
        'custrecord_scdline_scdlineid' :'custrecord_scdline_scdlineid',
        'custrecord_scdline_sslineid' :'custrecord_scdline_sslineid',
        'custrecord_scdline_purchaseamt' :'custrecord_scdline_purchaseamt',
        'custrecord_scdline_purchasetaxcode' :'custrecord_scdline_purchasetaxcode',
        'custrecord_scdline_polineid' :'custrecord_scdline_polineid',
        'custrecord_scdline_poqty' :'custrecord_scdline_poqty',
        'custrecord_scdline_sp' :'custrecord_scdline_sp',
        'custrecord_scdline_realsp' :'custrecord_scdline_realsp',
        'custrecord_scdline_spqty' :'custrecord_scdline_spqty',
        'custrecord_scdline_solineid' :'custrecord_scdline_solineid',
        'custrecord_scdline_itline' :'custrecord_scdline_itline',
        'custrecord_scdline_supplier' :'custrecord_scdline_supplier',
        'custrecord_scdline_demander' :'custrecord_scdline_demander',
        'custrecord_scdline_icso' :'custrecord_scdline_icso',
        'custrecord_scdline_icsoline' :'custrecord_scdline_icsoline',
        'custrecord_scdline_icpo' :'custrecord_scdline_icpo',
        'custrecord_scdline_icpoline' :'custrecord_scdline_icpoline',
    }
    /**
     * Function to be executed after page is initialized.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.mode - The mode in which the record is being accessed (create, copy, or edit)
     *
     * @since 2015.2
     */
    function pageInit(scriptContext) {
            stopNotAdministratorsChangeLine(scriptContext);
    }

    /**
     * 阻止其他角色修改字段、新增删除行
     * @param scriptContext
     */
    function stopNotAdministratorsChangeLine(scriptContext){
        var curRec = scriptContext.currentRecord;
        var role = runtime.getCurrentUser().role;
        if(scriptContext.mode == 'edit' &&  role != '3' && role != 3){
            //不允许管理员以外的角色删除行、插入行
            jQuery('.uir-listheader-button-row').hide();
            jQuery('#tbl_recmachcustrecord_ecm_scdline_scd_remove').parent().hide();
            jQuery('#tbl_recmachcustrecord_ecm_scdline_scd_insert').parent().hide();


            //body字段不可修改
            for (var key in scdBodyField) {
                curRec.getField({fieldId: scdBodyField[key]}).isDisabled = true;
            }

            //item字段不可修改
            var lineNum = curRec.getCurrentSublistIndex({sublistId:'recmachcustrecord_ecm_scdline_scd'});
            for(var key2 in scdLineField){
                console.log('subKey==',key2);
                curRec.getSublistField({sublistId:'recmachcustrecord_ecm_scdline_scd',fieldId:key2,line:(lineNum - 1)}).isDisabled = true;
            }
        }
    }

    /**
     * Function to be executed when field is changed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
     * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
     *
     * @since 2015.2
     */
    function fieldChanged(scriptContext) {
        var curRec = scriptContext.currentRecord;
        var curField = scriptContext.fieldId;
        if(curField == 'custrecord_scd_location'){
            var location = curRec.getValue('custrecord_scd_location');
            if(location){
                var locationInfo = search.lookupFields({
                    type:'location',
                    id:location,
                    columns:['subsidiary']
                })
                var supplyer = locationInfo['subsidiary'];
                // console.log('supplyer',supplyer);
                if(supplyer){
                    var lineCount = curRec.getLineCount({sublistId:'recmachcustrecord_ecm_scdline_scd'});
                    if(lineCount > 0){
                        for(var index = 0; index < lineCount; index++){
                            curRec.selectLine({sublistId:'recmachcustrecord_ecm_scdline_scd', line:index});
                            curRec.setCurrentSublistText({sublistId:'recmachcustrecord_ecm_scdline_scd',fieldId:'custrecord_scdline_demander',text:supplyer});
                            curRec.setCurrentSublistText({sublistId:'recmachcustrecord_ecm_scdline_scd',fieldId:'custrecord_scdline_supplier',text:supplyer});
                            curRec.commitLine({sublistId:'recmachcustrecord_ecm_scdline_scd'});
                        }
                    }
                }

            }

        }
    }

    /**
     * Function to be executed when field is slaved.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     *
     * @since 2015.2
     */
    function postSourcing(scriptContext) {

    }

    /**
     * Function to be executed after sublist is inserted, removed, or edited.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @since 2015.2
     */
    function sublistChanged(scriptContext) {

    }

    /**
     * Function to be executed after line is selected.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @since 2015.2
     */
    function lineInit(scriptContext) {

    }

    /**
     * Validation function to be executed when field is changed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
     * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
     *
     * @returns {boolean} Return true if field is valid
     *
     * @since 2015.2
     */
    function validateField(scriptContext) {

    }

    /**
     * Validation function to be executed when sublist line is committed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateLine(scriptContext) {
        var role = runtime.getCurrentUser().role;
        var curRec = scriptContext.currentRecord;
        var curSub = scriptContext.sublistId;
        var location = curRec.getValue('custrecord_scd_location');
        if(role != '3' && role != 3){
            alert('您没有权限新增行、请联系管理员！(You do not have permission to add rows, Please contact administrator.)')
            return false;
        }
        if(location && curSub == 'recmachcustrecord_ecm_scdline_scd'){
            curRec.setCurrentSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd',fieldId:'custrecord_scdline_supplyplanner',value:location});
            curRec.setCurrentSublistValue({sublistId:'recmachcustrecord_ecm_scdline_scd',fieldId:'custrecord_scdline_supplier',value:location});
        }
        return true;
    }

    /**
     * Validation function to be executed when sublist line is inserted.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateInsert(scriptContext) {

    }

    /**
     * Validation function to be executed when record is deleted.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateDelete(scriptContext) {

    }

    /**
     * Validation function to be executed when record is saved.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @returns {boolean} Return true if record is valid
     *
     * @since 2015.2
     */
    function saveRecord(scriptContext) {

    }

    return {
        pageInit: pageInit,
        fieldChanged: fieldChanged,
        // postSourcing: postSourcing,
        // sublistChanged: sublistChanged,
        // lineInit: lineInit,
        // validateField: validateField,
        validateLine: validateLine,
        // validateInsert: validateInsert,
        // validateDelete: validateDelete,
        // saveRecord: saveRecord
    };
    
});
