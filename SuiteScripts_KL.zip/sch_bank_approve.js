/**
 * @NApiVersion 2.1
 * @NScriptType ScheduledScript
 * Version         Date               Author            Remarks
 * 1.0             2023/02/16         Kori              TAPD【1018423】宜开美接口04 银行代码申请批复
 * 1.1             2023/02/17         Kori              TAPD【1018423】宜开美接口04测试&优化
 */
define(['N/record', 'N/runtime', 'N/search', '../tools/common_api.js', '../tools/ramda.min.js', '/SuiteScripts/tools/moment.js',  '/SuiteScripts/tools/hc_edi_interface_tool.js'],
    /**
     * @param{record} record
     * @param{runtime} runtime
     * @param{search} search
     */
    (record, runtime, search, commonApi, ramda, moment, interfaceTool) => {

        const BUYER_BALANCE_TYPE = 'customrecord_ecm_sinosure_bankcodeapprov';//银行代码批复通知记录id
        const BUYERAPPLY_BALANCE_TYPE = 'customrecord_ecm_sinosure_bankcodeapply';//银行代码申请记录id
        const LOG_TYPE = 'customrecord_hc_edi_interface_log';//日志类型
        const IMETHOD = 'doEdiBankCodeApprove';//接口method
        const ITYPE = 6;//接口类型：限额余额
        const BUYER_FIELD_MAPPING = {
            //银行批复信息
            'noticeSerialNo' : 'custrecord_esbap_noticeserialno',//主键
            'corpSerialNo' : 'custrecord_esbap_corpserialno',
            'approveFlag' : 'custrecord_esbap_approveflag',
            'unAcceptCode' : 'custrecord_esbap_unacceptcode',
            'unAcceptReason' : 'custrecord_esbap_unacceptreason',
            'notifyTime' : 'custrecord_esbap_notifytime',
            //银行详细信息
            'corpSerialNo' : 'custrecord_esbap_corpserialno',
            'clientNo' : 'custrecord_esbap_clientno',
            'bankSwift': 'custrecord_esbap_bankswift',
            'chnName': 'custrecord_esbap_chnname',
            'engName': 'custrecord_esbap_engname',
            'countryCode': 'custrecord_esbap_countrycode',
            'address': 'custrecord_esbap_address',
            'zip': 'custrecord_esbap_zip',
            'tel': 'custrecord_esbap_tel',
            'fax': 'custrecord_esbap_fax',
            'webAddress': 'custrecord_esbap_webaddress',
            'setupDate': 'custrecord_esbap_setupdate',
            'corporation': 'custrecord_esbap_corporation',
            'turnover': 'custrecord_esbap_turnover',
            'profit': 'custrecord_esbap_profit',
            'totalAsset': 'custrecord_esbap_totalasset',
            'selfAssetRate': 'custrecord_esbap_selfassetrate',
            'selfCapital': 'custrecord_esbap_selfcapital',
            'nodeSum': 'custrecord_esbap_nodesum',
            'employeeSum': 'custrecord_esbap_employeesum',
            'belongBankName': 'custrecord_esbap_belongbankName',
            'belongBankSwift': 'custrecord_esbap_belongbankswift',
            'interOrder': 'custrecord_esbap_interorder',
            'nationOrder': 'custrecord_esbap_nationorder',
            'stockHolder': 'custrecord_esbap_stockholder',
            'remark': 'custrecord_esbap_remark',
            'modifyTime': 'custrecord_esbap_modifytime',

            'errorCode': 'custrecord_esbap_errorcode',
            'errorMsg': 'custrecord_esbap_errormsg',
        };
        const BANKAPY_FIELD_MAPPING = {
            'corpSerialNo' : 'name',
            'clientNo' : 'custrecord_esba_clientno',
            'bankSwift': 'custrecord_esba_bankswift',
            'chnName': 'custrecord_esba_chnname',
            'engName': 'custrecord_esba_engname',
            'countryCode': 'custrecord_esba_countrycode',
            'address': 'custrecord_esba_address',
            'zip': 'custrecord_esba_zip',
            'tel': 'custrecord_esba_tel',
            'fax': 'custrecord_esba_fax',
            'webAddress': 'custrecord_esba_webaddress',
            'setupDate': 'custrecord_esba_setupdate',
            'corporation': 'custrecord_esba_corporation',
            'turnover': 'custrecord_esba_turnover',
            'profit': 'custrecord_esba_profit',
            'totalAsset': 'custrecord_esba_totalasset',
            'selfAssetRate': 'custrecord_esba_selfassetRate',
            'selfCapital': 'custrecord_esba_selfcapital',
            'nodeSum': 'custrecord_esba_nodesum',
            'employeeSum': 'custrecord_esba_employeesum',
            'belongBankName': 'custrecord_esba_belongbankname',
            'belongBankSwift': 'custrecord_esba_belongbankswift',
            'interOrder': 'custrecord_esba_interorder',
            'nationOrder': 'custrecord_esba_nationorder',
            'stockHolder': 'custrecord_esba_stockholder',
            'remark': 'custrecord_esba_remark'
        };

        /**
         * Defines the Scheduled script trigger point.
         * @param {Object} scriptContext
         * @param {string} scriptContext.type - Script execution context. Use values from the scriptContext.InvocationType enum.
         * @since 2015.2
         */
        const execute = (scriptContext) => {
            echemiBankApproveInterface(scriptContext);//宜开美银行批复接口
        }

        /**
         * 宜开美银行批复接口
         * @param scriptContext
         */
        const echemiBankApproveInterface = (scriptContext) => {
            let reqData = {
                "datas": {
                    "startDate": "1580486400000",
                    "endDate": (new Date()).getTime() + ''
                },
                "imethod": IMETHOD,
            };
            let rtnData = interfaceTool.requestEdiServer(reqData, ITYPE);//获取中信保“银行代码批复结果”

            let countryInfo = searchNSCountry();
            if(rtnData.valid == true){
                let infoData = rtnData.data.datas;
                if(infoData && infoData.length > 0) {
                    infoData = JSON.parse(infoData);
                    //获取所有quotaNo，匹配已有数据
                    let quotaNos = ramda.groupBy(ramda.path(['noticeSerialNo']))(infoData);//ramda将数据分组为{'':[]}
                    let existQuotaData = formatExistQuotaNo(Object.keys(quotaNos));
                    let corpSerialNo = ramda.groupBy(ramda.path(['corpSerialNo']))(infoData);
                    let existCorpSerialNo = formatCorpSerialNo(Object.keys(corpSerialNo));

                    let createdDataIdArray = [],
                        logUpdVal = {
                            custrecord_hc_inf_process_msg: '',
                            custrecord_hc_inf_errorflag: false
                        };
                    let bankApyId = '';//银行申请记录内部id

                    try {
                        for(let i = 0; i < infoData.length; i++) {
                            let obj;
                            if('undefined' == typeof existQuotaData[infoData[i].noticeSerialNo]) {
                                obj = record.create({type: BUYER_BALANCE_TYPE});
                            } else {
                                obj = record.load({type: BUYER_BALANCE_TYPE, id: existQuotaData[infoData[i].noticeSerialNo]});
                            }
                            for(key in infoData[i]) {
                                if('notifyTime' == key) {
                                    let tmpDate = moment(infoData[i].key);
                                    if (!isNaN(tmpDate)) {
                                        let tmpDateStr = tmpDate.format('MM/DD/YYYY');
                                        obj.setText({fieldId: BUYER_FIELD_MAPPING[key], text: tmpDateStr});
                                    }
                                } else if('approveFlag' == key){//0-申请退回/不通过；1-通过/代码发布
                                    if(infoData[i].approveFlag == 0 || infoData[i].approveFlag == '0'){
                                        obj.setValue({fieldId: BUYER_FIELD_MAPPING[key], value: '申请退回/不通过'})
                                    }else{
                                        obj.setValue({fieldId: BUYER_FIELD_MAPPING[key], value: '通过/代码发布'})
                                    }
                                }else if('approveFlag' != key && 'notifyTime' != key && 'bankInfo' != key){
                                    obj.setValue({fieldId: BUYER_FIELD_MAPPING[key], value: infoData[i][key]});
                                } else{//'bankInfo' == key
                                    let buyerInfo = infoData[i].bankInfo;
                                    for (key1 in buyerInfo) {
                                        if ('setupDate' == key1 || 'modifyTime' == key1) {
                                            let tmpDate = moment(buyerInfo.key1);
                                            if (!isNaN(tmpDate)) {
                                                let tmpDateStr = tmpDate.format('MM/DD/YYYY');
                                                obj.setText({
                                                    fieldId: BUYER_FIELD_MAPPING[key1],
                                                    text: tmpDateStr
                                                });
                                            }
                                        } else if ('countryCode' == key1) {
                                            for (let index = 0; index < countryInfo.length; index++) {
                                                if (countryInfo[index].ecCode == buyerInfo[key1]) {
                                                    obj.setValue({
                                                        fieldId: BUYER_FIELD_MAPPING[key1],
                                                        value: countryInfo[index].NSCtyId
                                                    });
                                                    break;
                                                }
                                            }
                                        } else {
                                            obj.setValue({
                                                fieldId: BUYER_FIELD_MAPPING[key1],
                                                value: buyerInfo[key1]
                                            });
                                        }
                                    }
                                }
                            }
                            let qid = obj.save({enableSourcing:true,ignoreMandatoryFields:true});
                            createdDataIdArray.push(qid);

                            if(qid){//将更新信息同步至买方代码申请
                                let buyerApyRec;
                                if('undefined' != typeof existCorpSerialNo[infoData[i].corpSerialNo]){
                                    buyerApyRec = record.load({type:BUYERAPPLY_BALANCE_TYPE,id:existCorpSerialNo[infoData[i].corpSerialNo]});
                                    let buyerApyInfo = infoData[i].bankInfo;
                                    bankApyId = existCorpSerialNo[infoData[i].corpSerialNo];

                                    for(key in buyerApyInfo) {
                                        if('setupDate' == key){
                                            let tmpDate = moment(buyerApyInfo.key);
                                            if (!isNaN(tmpDate)) {
                                                let tmpDateStr = tmpDate.format('MM/DD/YYYY');
                                                buyerApyRec.setText({fieldId: BANKAPY_FIELD_MAPPING[key], text: tmpDateStr});
                                            }
                                        } else if('countryCode' == key){
                                            for(let index = 0; index < countryInfo.length; index ++){
                                                if(countryInfo[index].ecCode == buyerApyInfo[key]){
                                                    buyerApyRec.setValue({fieldId: BANKAPY_FIELD_MAPPING[key], value: countryInfo[index].NSCtyId});
                                                    break;
                                                }
                                            }
                                        } else if('modifyTime' != key){
                                            buyerApyRec.setValue({fieldId: BANKAPY_FIELD_MAPPING[key], value: buyerApyInfo[key]});
                                        }
                                    }
                                    //更新成功
                                    buyerApyRec.setValue({fieldId: 'custrecord_esba_status', value: 5});//信保成功
                                    let bankRec = buyerApyRec.save({ignoreMandatoryFields:true,enableSourcing:true});
                                }
                            }
                        }
                        logUpdVal.custrecord_hc_inf_process_msg = createdDataIdArray.join('&');
                    } catch (e) {
                        log.error('生成买方代码申请反馈error===>' + rtnData.logId, e);
                        if(createdDataIdArray && createdDataIdArray.length > 0) {
                            createdDataIdArray.forEach(function (cid) {
                                record.delete({type: BUYER_BALANCE_TYPE, id: cid});
                            });
                        }
                        logUpdVal.custrecord_esbp_errormsg = e.message;
                        logUpdVal.custrecord_hc_inf_errorflag = true;
                        //银行申请错误检测
                        record.submitFields({
                            type: BUYERAPPLY_BALANCE_TYPE,
                            id: bankApyId,
                            values: {'custrecord_esba_status':6}
                        });
                    }
                    record.submitFields({
                        type: LOG_TYPE,
                        id: rtnData.logId,
                        values: logUpdVal
                    });
                }
            }
        }

        /**
         * 搜索已存在银行申请批复noticeSerialNo记录
         * @param quotaNoArray              本次返回quotaNo
         * @return {{}}                     {quotaNo：id}
         */
        const formatExistQuotaNo = quotaNoArray => {
            let existData = {};//{quotaNo：id}
            if(!quotaNoArray || 0 == quotaNoArray.length) {
                return existData;
            }
            let filters = [],
                columns = ['custrecord_esbap_noticeSerialNo'];
            quotaNoArray.forEach(function (qno) {//数组search forEach + or
                filters.push(['custrecord_esbap_noticeSerialNo', 'is', qno]);
                filters.push('or');
            });
            filters.pop();
            let results = commonApi.searchAllData(BUYER_BALANCE_TYPE, filters, columns);
            if(results && results.length > 0) {
                results.forEach(function (res) {
                    existData[res.getValue(columns[0])] = res.id;
                });
            }
            // log.debug('已存在quotaNo数据', existData);
            return existData;
        }

        /**
         * 获取已存在银行申请记录
         * @param quotaNoArray
         * @returns {{}}
         */
        const formatCorpSerialNo = quotaNoArray => {
            let existData = {};//{quotaNo：id}
            if(!quotaNoArray || 0 == quotaNoArray.length) {
                return existData;
            }
            let filters = [],
                columns = ['name'];
            quotaNoArray.forEach(function (qno) {
                filters.push(['idtext', 'is', qno]);
                filters.push('or');
            });
            filters.pop();
            let results = commonApi.searchAllData(BUYERAPPLY_BALANCE_TYPE, filters, columns);
            if(results && results.length > 0) {
                results.forEach(function (res) {
                    existData[res.getValue(columns[0])] = res.id;
                });
            }
            // log.debug('已存在CorpSerial数据', existData);
            return existData;
        }


        /**
         * 搜索客户
         * @param quotaNoArray              本次返回buyerNo
         * @return {{}}                     {buyerNo：id}
         */
        const formatCustomData = buyerNoArray => {
            let existData = {};//{quotaNo：id}
            if(!buyerNoArray || 0 == buyerNoArray.length) {
                return existData;
            }
            let filters = [],
                columns = ['custrecord_esbp_buyerNo'];
            buyerNoArray.forEach(function (bno) {
                filters.push(['custrecord_esbp_buyerNo', 'is', bno]);
                filters.push('or');
            });
            filters.pop();
            let results = commonApi.searchAllData('customer', filters, columns);
            if(results && results.length > 0) {
                results.forEach(function (res) {
                    existData[res.getValue(columns[0])] = res.id;
                });
            }
            // log.debug('匹配customer', existData);
            return existData;
        }

        /**
         * 获取NS与接口匹配的国家
         * @returns {*[]}
         */
        const searchNSCountry = () => {
            let countryInfo = [];
            let countrycodeSearchObj = search.create({
                type: "customrecord_ecm_countrycode",
                filters: [],
                columns: [
                    search.createColumn({name: "custrecord_ec_code", label: "代码"}),
                    search.createColumn({name: "internalid", label: "内部 ID"})
                ]
            });
            let countryRes = commonApi.getAllData(countrycodeSearchObj);
            let countryCol = countrycodeSearchObj.columns;
            if(countryRes.length > 0){
                for(let index = 0; index < countryRes.length; index++){
                    let ecCode = countryRes[index].getValue(countryCol[0]);
                    let NSCtyId = countryRes[index].getValue(countryCol[1]);
                    let ctyJson = {
                        ecCode:ecCode,
                        NSCtyId:NSCtyId
                    }
                    countryInfo.push(ctyJson);
                }
            }
            return countryInfo;
        }

        return {execute}

    });
