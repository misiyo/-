/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * Version        Date(M-D-Y)            Author              Remark
 * 1.0            2/28/2023              Kori                TAPD【1018680】根据PO创建IR单后，将采购收货单的数量反写SP子记录的【实际出运数量】。
 * 2.0            3/01/2023              Kori                记录type、sublistId、fieldId变更及测试支持
 */
define(['N/record', 'N/runtime', 'N/search'],
    /**
 * @param{record} record
 * @param{runtime} runtime
 * @param{search} search
 */
    (record, runtime, search) => {
        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed before record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const beforeSubmit = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {
            var newRec = scriptContext.newRecord;
            var recType = scriptContext.type;
            if(recType == 'delete'){
                return;
            }
            var isPoRec = true;
            var poId = newRec.getValue('createdfrom');
            log.debug('poId',poId);
            log.debug('newRec.id',newRec.id);
            if(poId){
                var createFromTypeInfo = search.lookupFields({type:'itemreceipt',id:newRec.id,columns:['createdfrom.type']});
                var createFromType = createFromTypeInfo['createdfrom.type'][0].value;
                if(createFromType != 'PurchOrd'){
                    isPoRec = false;
                }
            }

            if(isPoRec && ((recType == 'edit' && 'USERINTERFACE' == runtime.executionContext) || recType == 'create')){
                log.debug('recType',recType);
                var lineCount = newRec.getLineCount('item');
                if(lineCount > 0){
                    log.debug('lineCount',lineCount);
                    var spId = newRec.getValue('custbody_ecm_sp');
                    if(spId){
                        var spRec = record.load({type:'customrecord_ecm_sp', id:spId});
                        var spStatus = spRec.getValue('custrecord_sp_status');
                        if(spStatus != '5' && spStatus != 5){//未完结
                            var irData = getIrData(newRec);
                            if(irData.length > 0){//sp回写数量
                                var spCount = spRec.getLineCount({sublistId:'recmachcustrecord_scdline_sp'});
                                for(var i = 0; i < spCount; i++){
                                    for(var j =0; j < irData.length; j++){
                                        var spItem = spRec.getSublistValue({sublistId:'recmachcustrecord_scdline_sp', fieldId:'custrecord_scdline_item', line: i});
                                        var spLine = spRec.getSublistValue({sublistId:'recmachcustrecord_scdline_sp', fieldId:'custrecord_scdline_scdlineid', line: i});
                                        var spQty = spRec.getSublistValue({sublistId:'recmachcustrecord_scdline_sp', fieldId:'custrecord_scdline_spqty', line: i}) || 0;
                                        if(spItem == irData[j].irItem && spLine == irData[j].irLine){
                                            var spNewQty = Number(spQty).add(Number(irData[j].irQty));
                                            spRec.setSublistValue({sublistId:'recmachcustrecord_scdline_sp',fieldId:'custrecord_scdline_spqty',value:spNewQty,line:i})
                                        }
                                    }
                                }
                                spRec.save({enableSourcing:true,ignoreMandatoryFields:true});
                            }
                        }
                    }
                }
            }
        }


        /**
         * 获取IR单明细行的数据
         * @param newRec
         * @returns {*[]}
         */
        function getIrData(newRec) {
            var irData = [];
            var irCount = newRec.getLineCount({sublistId:'item'});
            if(irCount > 0){
                for(var index = 0; index < irCount; index ++){
                    var irItem = newRec.getSublistValue({sublistId:'item', fieldId:'item', line:index});
                    var irLine = newRec.getSublistValue({sublistId:'item', fieldId:'custcol_ecm_uniquekey', line:index});
                    var irQty = newRec.getSublistValue({sublistId:'item', fieldId:'quantity', line:index}) || 0;
                    var irJson = {
                        irItem:irItem,
                        irLine:irLine,
                        irQty:irQty,
                    }
                    var createIr = true;
                    for(var i = 0; i < irData.length; i++){
                        // if(irData[i].irItem == irItem && irLine == irData[i].irLine){
                        if(irData[i].irItem == irItem && irLine == irData[i].irLine){
                            createIr = false;
                            irData[i].irQty = Number(irData[i].irQty).add(Number(irQty));
                            break;
                        }
                    }
                    if(createIr && irLine){//首行
                        irData.push(irJson)
                    }
                }
            }
            return irData;
        }

        /**
         * 自定义加法运算
         * @param arg1
         * @param arg2
         * @return {number}
         */
        function accAdd(arg1, arg2) {
            var r1, r2, m, c;
            try {
                r1 = arg1.toString().split(".")[1].length;
            } catch (e) {
                r1 = 0;
            }
            try {
                r2 = arg2.toString().split(".")[1].length;
            } catch (e) {
                r2 = 0;
            }
            c = Math.abs(r1 - r2);
            m = Math.pow(10, Math.max(r1, r2));
            if (c > 0) {
                var cm = Math.pow(10, c);
                if (r1 > r2) {
                    arg1 = Number(arg1.toString().replace(".", ""));
                    arg2 = Number(arg2.toString().replace(".", "")) * cm;
                } else {
                    arg1 = Number(arg1.toString().replace(".", "")) * cm;
                    arg2 = Number(arg2.toString().replace(".", ""));
                }
            } else {
                arg1 = Number(arg1.toString().replace(".", ""));
                arg2 = Number(arg2.toString().replace(".", ""));
            }
            return (arg1 + arg2) / m;
        }
        Number.prototype.add = function (arg) {
            return accAdd(arg, this);
        }

        return {/**beforeLoad, beforeSubmit, **/afterSubmit}

    });
