/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 *
 * Version      Date             Author          Memo
 *  1.0         2023.03.01       Neil Tang      【ID1018895】外贸通用PI模板
 *  2.0         2023.03.03       Neil Tang      【ID1018895】外贸通用PI模板-新增字段取值
 */
define(['N/search', 'N/file', 'N/render', 'N/xml', 'N/record', 'N/ui/serverWidget', 'N/runtime'],
    (search, file, render, xml, record, serverWidget, runtime) => {
        /**
         * Defines the Suiteconst script trigger point.
         * @param {Object} scriptContext
         * @param {ServerRequest} scriptContext.request - Incoming request
         * @param {ServerResponse} scriptContext.response - Suiteconst response
         * @since 2015.2
         */
        const onRequest = (scriptContext) => {
            const {request, response} = scriptContext;
            const {parameters, method} = request;

            const {rType, rId} = parameters;

            const bodyDataFields = [];

            if ('GET' == method) {
                try {
                    let renderer = render.create();
                    let templateId = 104;
                    if(runtime.accountId == '7284938') templateId = 104; //TODO 上线后要做环境校验
                    renderer.setTemplateById(templateId);
                    
                    renderer.addRecord('record',record.load({type: rType, id: rId}));
                    let invoicePdf = renderer.renderAsPdf();

                    invoicePdf.name = new Date().getTime() + '.pdf';

                    response.writeFile({
                        file: invoicePdf,
                         isInline: true
                    });

                } catch (e) {
                    log.error(`Type:${rType} Id:${rId}`, e);

                    const form = serverWidget.createForm({
                        title : '处理失败，错误提示:'+e.message,
                        hideNavBar : true
                    });
                    const buttonfunc = "window.history.go(-1)";
                    form.addButton({id: 'custpage_goback', label: '返回', functionName: buttonfunc})
                    response.writePage(form);

                }
            }
        }

        return {onRequest}

    });
