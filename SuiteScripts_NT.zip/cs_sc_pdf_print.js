/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 *
 * Version      Date             Author          Memo
 *  1.0         2023.03.01       Neil Tang      【ID1018895】外贸通用PI模板
 */
define(['N/currentRecord', 'N/search', 'N/url', 'N/record', 'N/format'],
    function (currentRecord, search, url, record, format) {

        function pageInit(scriptContext) {}

        function printPdf(handleFlag) {
            var curtRec = currentRecord.get();

            var myUrl = url.resolveScript({
                scriptId: 'customscript_sl_ecm_sc_pdf_print',
                deploymentId: 'customdeploy_sl_ecm_sc_pdf_print',
                returnExternalUrl: false,
                params: {
                    'rType': curtRec.type,
                    'rId':  curtRec.id,
                }
            });

            window.open(myUrl, '_blank');

        }


        return {
            pageInit: pageInit,
            printPdf:printPdf
        };

    });
