/**
 * @NApiVersion 2.1
 * @NScriptType MapReduceScript
 *
 * Version		Date			Author			Remark
 * 1.0          2023/04/10      Mark Z          SP自动生成IR【1019607】 & SP更新公司间价格【1018807】
 * 2.0          2023/04/11      Mark Z          IR单汇总到岸成本【1018607】
 * 3.0          2023/04/14      Mark Z          更新到岸成本计算公式【1018607】
 * 4.0          2023/04/18      Mark Z          更新公司间价格所需汇率日期取值
 */
define(['N/query', 'N/record', 'N/runtime', 'N/search', '../tools/common_api.js', '../tools/ramda.min.js', 'N/currency'],
    /**
 * @param{query} query
 * @param{record} record
 * @param{runtime} runtime
 * @param{search} search
 */
    (query, record, runtime, search, commonApi, R, currency) => {
        const searchId = 'customsearch_ecm_sp_updateprice_newirdev';
        /**
         * Defines the function that is executed at the beginning of the map/reduce process and generates the input data.
         * @param {Object} inputContext
         * @param {boolean} inputContext.isRestarted - Indicates whether the current invocation of this function is the first
         *     invocation (if true, the current invocation is not the first invocation and this function has been restarted)
         * @param {Object} inputContext.ObjectRef - Object that references the input data
         * @typedef {Object} ObjectRef
         * @property {string|number} ObjectRef.id - Internal ID of the record instance that contains the input data
         * @property {string} ObjectRef.type - Type of the record instance that contains the input data
         * @returns {Array|Object|Search|ObjectRef|File|Query} The input data to use in the map/reduce process
         * @since 2015.2
         */

        const getInputData = (inputContext) => {
            try {
                return pendingData();
            } catch (e) {
                log.error('getInputData error', e);
            }
        }

        /**
         * 获取待处理的SP
         * @return {[]}
         */
        const pendingData = () => {
            let spIds = [];
            let spSearchObj = search.load({id: searchId});
            let results = commonApi.getAllData(spSearchObj);
            results.forEach(res => {
                spIds.push(res.id);
            });
            return spIds;
        }

        /**
         * Defines the function that is executed when the map entry point is triggered. This entry point is triggered automatically
         * when the associated getInputData stage is complete. This function is applied to each key-value pair in the provided
         * context.
         * @param {Object} mapContext - Data collection containing the key-value pairs to process in the map stage. This parameter
         *     is provided automatically based on the results of the getInputData stage.
         * @param {Iterator} mapContext.errors - Serialized errors that were thrown during previous attempts to execute the map
         *     function on the current key-value pair
         * @param {number} mapContext.executionNo - Number of times the map function has been executed on the current key-value
         *     pair
         * @param {boolean} mapContext.isRestarted - Indicates whether the current invocation of this function is the first
         *     invocation (if true, the current invocation is not the first invocation and this function has been restarted)
         * @param {string} mapContext.key - Key to be processed during the map stage
         * @param {string} mapContext.value - Value to be processed during the map stage
         * @since 2015.2
         */

        const map = (mapContext) => {

        }

        /**
         * Defines the function that is executed when the reduce entry point is triggered. This entry point is triggered
         * automatically when the associated map stage is complete. This function is applied to each group in the provided context.
         * @param {Object} reduceContext - Data collection containing the groups to process in the reduce stage. This parameter is
         *     provided automatically based on the results of the map stage.
         * @param {Iterator} reduceContext.errors - Serialized errors that were thrown during previous attempts to execute the
         *     reduce function on the current group
         * @param {number} reduceContext.executionNo - Number of times the reduce function has been executed on the current group
         * @param {boolean} reduceContext.isRestarted - Indicates whether the current invocation of this function is the first
         *     invocation (if true, the current invocation is not the first invocation and this function has been restarted)
         * @param {string} reduceContext.key - Key to be processed during the reduce stage
         * @param {List<String>} reduceContext.values - All values associated with a unique key that was passed to the reduce stage
         *     for processing
         * @since 2015.2
         */
        const reduce = (reduceContext) => {
            let spId = reduceContext.values[0];
            log.debug('spId', spId);
            try {
                let currencyRate = {};// 币种转换汇率
                let itemInfos = getAllItem();// 货品 unit capacity
                let {spLines, isWarehouseStock, irIds, invoiceDate, scIds} = searchSPLines(spId);
                if (spLines.length > 0) {
                    // 搜索汇率日期
                    let exchangeRateDateArr = [];
                    if (scIds && scIds.length > 0) {
                        exchangeRateDateArr = searchExchangeRateDate(scIds);
                        if (exchangeRateDateArr.length > 0) {
                            // 根据日期排序
                            exchangeRateDateArr.sort((a, b) => {
                                let date1 = new Date(a).getTime();
                                let date2 = new Date(b).getTime();
                                return date1 - date2;
                            });
                        }
                    }
                    let exchangeRateDate = exchangeRateDateArr[0] || '';
                    log.debug('exchangeRateDate', exchangeRateDate);
                    if (!exchangeRateDate) {
                        throw `${spId}-未取到SP生成公司间单据所需汇率日期`;
                    }
                    if (exchangeRateDate) {
                        spLines = formatData(spLines, currencyRate, exchangeRateDate);
                        log.debug('spLines', spLines);
                        // 根据SO汇总，更新公司间价格
                        let groupBySoData = R.groupBy(R.path(['soId']))(spLines);
                        log.debug('groupBySoData', groupBySoData);
                        let updateFlag = {};
                        updateFlag.status = 0;// 0-成功，1-失败
                        updateFlag.errorMsg = '';
                        for (let soId in groupBySoData) {
                            updateFlag = updateICPrice(soId, groupBySoData[soId], isWarehouseStock, updateFlag, spId, itemInfos);
                        }
                        if (0 == updateFlag.status) {
                            let createFlag = {};
                            createFlag.status = 0;// 0-成功 1-失败
                            createFlag.errorMsg = '';
                            // 获取IR批次
                            let irLots = getIRLots(irIds);
                            if (Object.keys(irLots).length > 0) {
                                // 更新成功，生成IR
                                let groupByPoData = R.groupBy(R.path(['poId']))(spLines);
                                for (let poId in groupByPoData) {
                                    createFlag = createIR(groupByPoData[poId], poId, irLots, createFlag, invoiceDate, itemInfos);
                                }
                            }
                            else {
                                createFlag.status = 1;
                                createFlag.errorMsg = '未搜到对应行批次信息';
                            }

                            log.debug('createFlag', createFlag);
                            if (createFlag.status == 0) {
                                record.submitFields({
                                    type: 'customrecord_ecm_sp',
                                    id: spId,
                                    values: {
                                        custrecord_sp_isupdated_icposoprice: true,
                                        custrecord_sp_finaldemanderpore: true
                                    },
                                    options: {
                                        enablesourcing: true,
                                        ignoreMandatoryFields: true
                                    }
                                });
                            }
                        }
                    }
                }
            } catch (e) {
                log.error('reduce error', e);
            }
        }

        /**
         * 搜索货品的unit capacity
         * @return {{}}
         */
        const getAllItem = () => {
            let itemInfos = {};
            let itemSearchObj = search.create({
                type: 'item',
                filters: [
                    ['isinactive', 'is', 'F']
                ],
                columns: [
                    search.createColumn({name: 'custitem_ecm_case_package_kg'})
                ]
            });
            let columns = itemSearchObj.columns;
            let results = commonApi.getAllData(itemSearchObj);
            results.forEach(res => {
                itemInfos[res.id] = res.getValue(columns[0]) || 0;
            });
            return itemInfos;
        }

        /**
         * 搜索对应SP明细汇率日期
         * @param scIds
         * @return {[]}
         */
        const searchExchangeRateDate = scIds => {
            let exchangeRateDateArr = [];
            let scSearchObj = search.create({
                type: 'salesorder',
                filters: [
                    ['mainline', 'is', 'T'],
                    'and',
                    ['taxline', 'is', 'F'],
                    'and',
                    ['internalid', 'anyof', scIds]
                ],
                columns: [
                    search.createColumn({name: 'trandate', label: 'Date'}),
                    search.createColumn({name: 'createdfrom', label: 'Created From'}),
                    search.createColumn({
                        name: 'trandate',
                        join: 'createdFrom',
                        label: 'Date'
                    }),
                    search.createColumn({
                        name: 'type',
                        join: 'createdFrom',
                        label: 'Type'
                    })
                ]
            });
            let columns = scSearchObj.columns;
            let results = commonApi.getAllData(scSearchObj);
            results.forEach(res => {
                let date = res.getValue(columns[0]);
                let createdFrom = res.getValue(columns[1]) || '';
                if (createdFrom) {
                    let createdFromType = res.getValue(columns[3]) || '';
                    if ('Estimate' == createdFromType) {
                        date = res.getValue(columns[2])
                    }
                }
                exchangeRateDateArr.push(date);
            });
            return exchangeRateDateArr;
        }

        /**
         * 搜索需要更新价格的明细
         * @param spId
         * @return {{isWarehouseStock: string, spLines: [], irIds: [], invoiceDate: string, scIds: []}}
         */
        const searchSPLines = (spId) => {
            let spLines = [], irIds = [], scIds = [];
            let isWarehouseStock = '', invoiceDate = '';
            let spSearchObj = search.create({
                type: 'customrecord_ecm_scd_line',
                filters: [
                    ['custrecord_scdline_sp', 'anyof', spId],
                    'and',
                    ['custrecord_ecm_scdline_scd.custrecord_scd_sc', 'noneof', '@NONE@'],
                    'and',
                    ['custrecord_scdline_supplier', 'noneof', '@NONE@'],
                    'and',
                    ['custrecord_scdline_demander', 'noneof', '@NONE@'],
                    'and',
                    ['custrecord_scdline_finaldemander', 'noneof', '@NONE@']
                ],
                columns: [
                    search.createColumn({name: 'internalid', sort: 'ASC'}),
                    search.createColumn({name: 'custrecord_scd_sc', join: 'custrecord_ecm_scdline_scd'}),// SO
                    search.createColumn({name: 'custrecord_scdline_uniquekey'}),// SO行唯一键
                    search.createColumn({name: 'custrecord_sp_warehousestock', join: 'custrecord_scdline_sp'}),// 是否备货
                    search.createColumn({name: 'custrecord_scdline_tariffcost'}),
                    search.createColumn({name: 'custrecord_scdline_clearancecost'}),
                    search.createColumn({name: 'custrecord_scdline_seafreightcost'}),
                    search.createColumn({name: 'custrecord_scdline_perscost'}),
                    search.createColumn({name: 'custrecord_scdline_purchaseamt'}),// 源单价
                    search.createColumn({name: 'custrecord_scd_purccurrency', join: 'custrecord_ecm_scdline_scd'}),
                    search.createColumn({name: 'custrecord_sp_sccurrency', join: 'custrecord_scdline_sp'}),
                    search.createColumn({name: 'custrecord_scdline_icir'}),
                    search.createColumn({name: 'custrecord_scdline_finaldemanderpo'}),
                    search.createColumn({name: 'custrecord_sp_deliverydate', join: 'custrecord_scdline_sp'}),
                    search.createColumn({name: 'custrecord_scdline_sc'})
                ]
            });
            let columns = spSearchObj.columns;
            let results = spSearchObj.run().getRange({start: 0, end: 1000});
            results.forEach((res, i) => {
                let spLineId = res.id;
                let soId = res.getValue(columns[1]);
                let soLineNo = res.getValue(columns[2]);
                let warehouseStock = res.getValue(columns[3]);
                let tariffCost = res.getValue(columns[4]);
                let clearanceCost = res.getValue(columns[5]);
                let seaFreight = res.getValue(columns[6]);
                let personCost = res.getValue(columns[7]);
                let oriRate = res.getValue(columns[8]);
                let scdCurrency = res.getValue(columns[9]);
                let spCurrency = res.getValue(columns[10]);
                let icIR = res.getValue(columns[11]);
                let finalPO = res.getValue(columns[12]);
                let deliveryDate = res.getValue(columns[13]);
                let scId = res.getValue(columns[14]);
                if (i == 0) {
                    isWarehouseStock = warehouseStock;
                    invoiceDate = deliveryDate;
                }
                let json = {
                    spLineId: spLineId,
                    soId: soId,
                    soLineNo: soLineNo,
                    tariffCost: tariffCost,
                    clearanceCost: clearanceCost,
                    seaFreight: seaFreight,
                    personCost: personCost,
                    rate: oriRate,
                    scdCurrency: scdCurrency,
                    spCurrency: spCurrency,
                    irId: icIR,
                    poId: finalPO,
                    scId: scId
                };
                spLines.push(json);
                if (icIR && irIds.indexOf(icIR) === -1) {
                    irIds.push(icIR);
                }
                if (scId && scIds.indexOf(scId) === -1) {
                    scIds.push(scId);
                }
            });
            return {spLines, isWarehouseStock, irIds, invoiceDate, scIds};
        }

        /**
         * 将ICPO单价填入spLines
         * @param spLines
         * @param currencyRate
         * @param exchangeRateDate
         * @return {*}
         */
        const formatData = (spLines, currencyRate, exchangeRateDate) => {
            spLines.forEach(line => {
                let fromCurrency = line.scdCurrency;
                let toCurrency = line.spCurrency;
                let rate = line.rate;
                let exchangeRate = 1;// 转换汇率
                if (fromCurrency != toCurrency) {
                    let rateKey = `${fromCurrency}&${toCurrency}`;
                    if (!currencyRate[rateKey]) {
                        exchangeRate = currency.exchangeRate({
                            source: fromCurrency,
                            target: toCurrency,
                            date: new Date(exchangeRateDate)
                        });
                        currencyRate[rateKey] = exchangeRate;
                    }
                    else {
                        exchangeRate = currencyRate[rateKey];
                    }
                }
                line.rate = Number(rate).mul(Number(exchangeRate));
            });
            return spLines;
        }

        /**
         * 更新公司间价格
         * @param soId
         * @param lines
         * @param isWarehouseStock
         * @param updateFlag
         * @param spId
         * @param itemInfos
         * @return {*}
         */
        const updateICPrice = (soId, lines, isWarehouseStock, updateFlag, spId, itemInfos) => {
            let newPrice = {};// 新单价
            let interCPO = '';
            let rateInfo = {};
            try {
                let soObj = record.load({type: 'salesorder', id: soId});
                interCPO = soObj.getValue({fieldId: 'custbody_ecm_icposo_transaction'}) || '';
                if (!interCPO) {
                    updateFlag.status = 1;
                    updateFlag.errorMsg += `soid(${soId})未找到ICPO;`;
                }
                if (0 == updateFlag.status) {
                    let supplier = soObj.getValue({fieldId: 'subsidiary'});
                    let icPOFields = search.lookupFields({
                        type: 'purchaseorder',
                        id: interCPO,
                        columns: ['subsidiary']
                    });
                    let demander = icPOFields['subsidiary'][0].value;
                    rateInfo = searchInterCompanyRate(supplier, demander, isWarehouseStock);
                    if (Object.keys(rateInfo).length > 0) {
                        let ratio = toPoint(rateInfo.ratio);
                        // 更新货品单价
                        let lineCount = soObj.getLineCount({sublistId: 'item'});
                        for (let i = 0; i < lineCount; i++) {
                            let itemId = soObj.getSublistValue({sublistId: 'item', fieldId: 'item', line: i});
                            let uniqueKey = soObj.getSublistValue({sublistId: 'item', fieldId: 'custcol_ecm_uniquekey', line: i});
                            for (let j = 0; j < lines.length; j++) {
                                if (uniqueKey == lines[j].soLineNo) {
                                    let newRate = lines[j].rate;
                                    if ('T' == isWarehouseStock || true == isWarehouseStock) {
                                        newRate = Number(newRate).mul(1 + Number(ratio));
                                    }
                                    else {
                                        let cost = Number(lines[j].tariffCost).add(Number(lines[j].clearanceCost)).add(Number(lines[j].seaFreight)).add(Number(lines[j].personCost));
                                        cost = Number(itemInfos[itemId]) === 0 ? 0 : Number(cost).div(Number(itemInfos[itemId]));
                                        newRate = Number(newRate).add(Number(cost));
                                        newRate = Number(newRate).mul(1 + Number(ratio));
                                    }
                                    soObj.setSublistValue({sublistId: 'item', fieldId: 'rate', value: newRate, line: i});
                                    newPrice[uniqueKey] = {
                                        rate: newRate,
                                        spLineId: lines[j].spLineId
                                    };
                                    break;
                                }
                            }
                        }
                        soObj.setValue({fieldId: 'custbody_ecm_intercompany', value: rateInfo.id});
                        soObj.setValue({fieldId: 'custbody_ecm_sp', value: spId});
                        soObj.setValue({fieldId: 'custbody_echemi_unitpriceicpo', value: true});
                        soObj.save({enableSourcing: true, ignoreMandatoryFields: true});
                    }
                    else {
                        updateFlag.status = 1;
                        updateFlag.errorMsg += `soid(${soId})未匹配到公司间加价比例;`;
                    }
                }
            } catch (e) {
                log.error('update so price error', e);
                updateFlag.status = 1;
                updateFlag.errorMsg += `soid(${soId})${e.message}`;
            }
            // 更新ICPO
            if (0 == updateFlag.status) {
                log.debug(`${soId} newPrice`, newPrice);
                try {
                    updateICPO(interCPO, newPrice, rateInfo.id, spId);
                } catch (e) {
                    log.error('update icpo price error');
                    updateFlag.status = 1;
                    updateFlag.errorMsg += `soid(${soId})=>icpo(${interCPO})${e.message}`;
                }
            }
            log.debug('update price updateFlag', updateFlag);
            return updateFlag;
        }

        /**
         * 搜索公司间加价比例
         * @param supplier
         * @param demander
         * @param isWarehouseStock
         * @return {{}}
         */
        const searchInterCompanyRate = (supplier, demander, isWarehouseStock) => {
            let rateInfo = {};
            let filters = [];
            filters.push(['isinactive', 'is', 'F']);
            filters.push('and');
            filters.push(['custrecord_ecm_interco_supplier', 'anyof', supplier]);
            filters.push('and');
            filters.push(['custrecord_ecm_interco_demand', 'anyof', demander]);
            if ('T' == isWarehouseStock || true == isWarehouseStock) {
                filters.push('and');
                filters.push(['custrecord_ecm_stock', 'is', 'T']);
            }
            else {
                filters.push('and');
                filters.push(['custrecord_ecm_stock', 'is', 'F']);
            }
            let icSearchObj = search.create({
                type: 'customrecord_ecm_intercompany',
                filters: filters,
                columns: [
                    search.createColumn({name: 'custrecord_ecm_interco_ratio'})
                ]
            });
            let columns = icSearchObj.columns;
            let results = icSearchObj.run().getRange({start: 0, end: 1});
            if (results && results.length > 0) {
                rateInfo.id = results[0].id;
                rateInfo.ratio = results[0].getValue(columns[0]) || '0.0%';
            }
            log.debug('rateInfo', rateInfo);
            return rateInfo;
        }

        // 百分比转小数
        const toPoint = (percent) => {
            let strVal = percent.replace("%", "");
            let numberVal = Number(strVal).div(Number(100));
            return numberVal;
        }

        /**
         * 更新ICPO
         * @param poId
         * @param newPrice
         * @param rateInfoId
         * @param spId
         */
        const updateICPO = (poId, newPrice, rateInfoId, spId) => {
            let poObj = record.load({type: 'purchaseorder', id: poId});
            let lineCount = poObj.getLineCount({sublistId: 'item'});
            for (let i = 0; i < lineCount; i++) {
                let lineNo = poObj.getSublistValue({sublistId: 'item', fieldId: 'custcol_ecm_uniquekey', line: i});
                if (newPrice[lineNo]) {
                    poObj.setSublistValue({sublistId: 'item', fieldId: 'rate', value: newPrice[lineNo].rate, line: i});
                    poObj.setSublistValue({sublistId: 'item', fieldId: 'custcol_ecm_spline', value: newPrice[lineNo].spLineId, line: i});
                }
            }
            poObj.setValue({fieldId: 'custbody_ecm_intercompany', value: rateInfoId});
            poObj.setValue({fieldId: 'custbody_ecm_sp', value: spId});
            poObj.setValue({fieldId: 'custbody_echemi_unitpriceicpo', value: true});
            poObj.save({enableSourcing: true, ignoreMandatoryFields: true});
        }

        /**
         * 获取IR批次
         * @param irIds
         * @return {{}}
         */
        const getIRLots = irIds => {
            let lots = {};
            if (irIds.length > 0) {
                let irSearchObj = search.create({
                    type: 'itemreceipt',
                    filters: [
                        ['type', 'anyof', 'ItemRcpt'],
                        'and',
                        ['mainline', 'is', 'F'],
                        'and',
                        ['taxline', 'is', 'F'],
                        'and',
                        ['internalid', 'anyof', irIds]
                    ],
                    columns: [
                        search.createColumn({name: "item", label: "Item"}),
                        search.createColumn({name: "custcol_ecm_uniquekey", label: "Ecm行唯一键"}),
                        search.createColumn({name: "custcol_ecm_spline", label: "SP Line"}),
                        search.createColumn({
                            name: "inventorynumber",
                            join: "inventoryDetail",
                            label: " Number"
                        }),
                        search.createColumn({
                            name: "quantity",
                            join: "inventoryDetail",
                            label: "Quantity"
                        })
                    ]
                });
                let columns = irSearchObj.columns;
                let results = commonApi.getAllData(irSearchObj);
                results.forEach(res => {
                    let lineNo = res.getValue(columns[1]);
                    let json = {
                        lotNo: res.getText(columns[3]),
                        qty: res.getValue(columns[4])
                    }
                    if (!lots[lineNo]) {
                        lots[lineNo] = [];
                    }
                    lots[lineNo].push(json);
                });
            }
            return lots;
        }

        /**
         * 创建IR
         * @param lines
         * @param poId
         * @param irLots
         * @param createFlag
         * @param invoiceDate
         * @param itemInfos
         * @return {*}
         */
        const createIR = (lines, poId, irLots, createFlag, invoiceDate, itemInfos) => {
            try {
                let irObj = record.transform({
                    fromType: 'purchaseorder',
                    fromId: poId,
                    toType: 'itemreceipt'
                });
                irObj.setValue({fieldId: 'landedcostmethod', value: 'VALUE'});
                irObj.setText({fieldId: 'trandate', text: invoiceDate});
                let poFields = search.lookupFields({
                    type: 'purchaseorder',
                    id: poId,
                    columns: ['subsidiary.custrecord_ecm_location']
                });
                log.debug('poFields', poFields);
                let location = '';
                if (poFields['subsidiary.custrecord_ecm_location'].length > 0) {
                    location = poFields['subsidiary.custrecord_ecm_location'][0].value;
                }
                if (location) {
                    let lineCount = irObj.getLineCount({sublistId: 'item'});
                    for (let i = 0; i < lineCount; i++) {
                        let lineFlag = false;
                        let lineNo = irObj.getSublistValue({sublistId: 'item', fieldId: 'custcol_ecm_uniquekey', line: i});
                        let lots = irLots[lineNo];
                        for (let j = 0; j < lines.length; j++) {
                            if (lineNo == lines[j].soLineNo) {
                                lineFlag = true;
                                break;
                            }
                        }
                        if (lots.length > 0 && lineFlag) {
                            irObj.setSublistValue({sublistId: 'item', fieldId: 'location', value: location, line: i});
                            let inventoryDetailObj = irObj.getSublistSubrecord({sublistId: 'item', fieldId: 'inventorydetail', line: i});
                            lots.forEach((lotObj, index) => {
                                inventoryDetailObj.setSublistValue({sublistId: 'inventoryassignment', fieldId: 'receiptinventorynumber', value: lotObj.lotNo, line: index});
                                inventoryDetailObj.setSublistValue({sublistId: 'inventoryassignment', fieldId: 'quantity', value: lotObj.qty, line: index});
                            });
                        }
                        else {
                            irObj.setSublistValue({sublistId: 'item', fieldId: 'itemreceive', value: false, line: i});
                        }
                    }
                    // 计算到岸成本
                    sumLandedCost(irObj, itemInfos);
                    irObj.save({enableSourcing: true, ignoreMandatoryFields: true});
                }
                else {
                    throw 'PO子公司的关联在途虚拟仓为空';
                }
            } catch (e) {
                log.error('create ir error', e);
                createFlag.status = 1;
                createFlag.errorMsg = `poId:${poId} create ir error:${e.message}`;
            }
            return createFlag;
        }

        /**
         * 汇总到岸成本
         * @param irObj
         * @param itemInfos
         */
        const sumLandedCost = (irObj, itemInfos) => {
            let lineCount = irObj.getLineCount({sublistId: 'item'});
            let lineData = {};// {scdLine:qty}
            for (let i = 0; i < lineCount; i++) {
                let check = irObj.getSublistValue({sublistId: 'item', fieldId: 'itemreceive', line: i});
                if(true == check) {
                    let itemId = irObj.getSublistValue({sublistId: 'item', fieldId: 'item', line: i}),
                        qty = irObj.getSublistValue({sublistId: 'item', fieldId: 'quantity', line: i}),
                        scdLine = irObj.getSublistValue({sublistId: 'item', fieldId: 'custcol_ecm_spline', line: i});
                    if ('' != scdLine) {
                        lineData[scdLine] = {
                            itemId: itemId,
                            qty: qty
                        };
                    }
                }
            }
            let costData = formatTotalCost(Object.keys(lineData));//scd明细行到岸成本汇总（单个）
            let totalArray = [0,0,0,0,0,0];
            for(let key in lineData) {
                let thisCost = costData[key];
                for(let j = 0; j < 6; j++) {
                    let costVal = Number(lineData[key].qty).mul(Number(thisCost[j])).mul(Number(itemInfos[lineData[key].itemId]));
                    totalArray[j] = Number(totalArray[j]).add(Number(costVal));
                }
            }
            ['landedcostamount5', 'landedcostamount6', 'landedcostamount1' , 'landedcostamount3', 'landedcostamount2', 'landedcostamount4'].forEach(function (fid, index) {
                irObj.setValue({fieldId: fid, value: totalArray[index]});
            });
        }

        /**
         * SCDLine费用数据
         * @param scdLineArray
         * @return {{}}             {scdLineId：[1,2,3,4,5,6]}按顺序为storage-insp-tarif-seaft-clearf-perc
         */
        const formatTotalCost = (scdLineArray) => {
            let scdCostTotal = {};//{scdLine:total}
            if(!scdLineArray || 0 == scdLineArray.length) {
                return scdCostTotal;
            }
            let filters = [], columns = [];
            filters.push(['internalid', 'anyof', scdLineArray]);
            columns.push('custrecord_scdline_storagecost');
            columns.push('custrecord_scdline_inspectioncost');
            columns.push('custrecord_scdline_tariffcost');
            columns.push('custrecord_scdline_seafreightcost');
            columns.push('custrecord_scdline_clearancecost');
            columns.push('custrecord_scdline_perscost');
            columns.push('custrecord_scdline_storagecost');
            let results = search.create({type: 'customrecord_ecm_scd_line', filters: filters, columns: columns}).run().getRange({start: 0, end: 1000});
            if(results && results.length > 0) {
                results.forEach(function (data) {
                    let thisCost = [];
                    thisCost.push(data.getValue(columns[0]) || 0);
                    thisCost.push(data.getValue(columns[1]) || 0);
                    thisCost.push(data.getValue(columns[2]) || 0);
                    thisCost.push(data.getValue(columns[3]) || 0);
                    thisCost.push(data.getValue(columns[4]) || 0);
                    thisCost.push(data.getValue(columns[5]) || 0);
                    scdCostTotal[data.id] = thisCost;
                });
            }
            log.debug('scdLine费用明细', scdCostTotal);
            return scdCostTotal;
        }

        /**
         * Defines the function that is executed when the summarize entry point is triggered. This entry point is triggered
         * automatically when the associated reduce stage is complete. This function is applied to the entire result set.
         * @param {Object} summaryContext - Statistics about the execution of a map/reduce script
         * @param {number} summaryContext.concurrency - Maximum concurrency number when executing parallel tasks for the map/reduce
         *     script
         * @param {Date} summaryContext.dateCreated - The date and time when the map/reduce script began running
         * @param {boolean} summaryContext.isRestarted - Indicates whether the current invocation of this function is the first
         *     invocation (if true, the current invocation is not the first invocation and this function has been restarted)
         * @param {Iterator} summaryContext.output - Serialized keys and values that were saved as output during the reduce stage
         * @param {number} summaryContext.seconds - Total seconds elapsed when running the map/reduce script
         * @param {number} summaryContext.usage - Total number of governance usage units consumed when running the map/reduce
         *     script
         * @param {number} summaryContext.yields - Total number of yields when running the map/reduce script
         * @param {Object} summaryContext.inputSummary - Statistics about the input stage
         * @param {Object} summaryContext.mapSummary - Statistics about the map stage
         * @param {Object} summaryContext.reduceSummary - Statistics about the reduce stage
         * @since 2015.2
         */
        const summarize = (summaryContext) => {

        }

        return {
            getInputData,
            // map,
            reduce,
            // summarize
        }

    });
