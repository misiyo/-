/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 *
 * Version		Date			Author			Remarks
 * 1.0          2023/02/21      mark zhang      sl_ss_create_scd.js引用cs
 * 2.0          2023/03/09      mark zhang      新增字段显示控制，报错信息改为英文
 * 3.0          2023/03/27      mark zhang      取消Port Of Departure,Location字段在配货类型=仓库发货时添加SC下子公司可选地点
 */
define(['N/currentRecord', 'N/record', 'N/search'],
/**
 * @param{currentRecord} currentRecord
 * @param{record} record
 * @param{search} search
 */
function(currentRecord, record, search) {
    
    /**
     * Function to be executed after page is initialized.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.mode - The mode in which the record is being accessed (create, copy, or edit)
     *
     * @since 2015.2
     */
    function pageInit(scriptContext) {
        jQuery('#inpt_custpage_distribution_type2').css({width: 300});
        jQuery('#inpt_custpage_location3').css({width: 300});
        jQuery('#inpt_custpage_pur_contract4').css({width: 300});
        jQuery('#custpage_supply_planner_display').css({width: 300});
        jQuery('#inpt_custpage_supplier5').css({width: 300});
        jQuery('#custpage_vendor_display').css({width: 300});
        jQuery('#inpt_custpage_pur_currency6').css({width: 300});
        jQuery('#custpage_shipping_date').css({width: 300});
    }

    /**
     * Function to be executed when field is changed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
     * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
     *
     * @since 2015.2
     */
    var pcInfos = {};// 采购合同明细数据
    function fieldChanged(scriptContext) {
        var curRec = scriptContext.currentRecord;
        var fieldId = scriptContext.fieldId;
        var sublistId = scriptContext.sublistId;

        if ('custpage_distribution_type' == fieldId) {
            var distributionType = curRec.getValue('custpage_distribution_type');// 配货类型
            if (3 === Number(distributionType)) {
                nlapiDisableField('custpage_supplier', true);
                nlapiDisableField('custpage_vendor', true);
                nlapiDisableField('custpage_pur_currency', true);
                var lineCount = curRec.getLineCount('custpage_line');
                if (lineCount > 0) {
                    for (var l = 0; l < lineCount; l++) {
                        var purPriceFieldObj = curRec.getSublistField({sublistId: 'custpage_line', fieldId: 'custpage_line_purprice', line: l});
                        purPriceFieldObj.isDisabled = true;
                        var purTaxCodeFieldObj = curRec.getSublistField({sublistId: 'custpage_line', fieldId: 'custpage_line_taxcode', line: l});
                        purTaxCodeFieldObj.isDisabled = true;
                    }
                }
            }
            else {
                nlapiDisableField('custpage_supplier', false);
                nlapiDisableField('custpage_vendor', false);
                nlapiDisableField('custpage_pur_currency', false);
                var lineCount = curRec.getLineCount('custpage_line');
                if (lineCount > 0) {
                    for (var m = 0; m < lineCount; m++) {
                        var purPriceFieldObj = curRec.getSublistField({sublistId: 'custpage_line', fieldId: 'custpage_line_purprice', line: m});
                        purPriceFieldObj.isDisabled = false;
                        var purTaxCodeFieldObj = curRec.getSublistField({sublistId: 'custpage_line', fieldId: 'custpage_line_taxcode', line: m});
                        purTaxCodeFieldObj.isDisabled = false;
                    }
                }
            }

            // 配货类型=仓库发货，Location字段填值
            var locFieldObj = curRec.getField('custpage_location');
            if (2 === Number(distributionType)) {
                var ssId = curRec.getValue('custpage_ss_no');
                if (ssId) {
                    var ssFieldObj = search.lookupFields({
                        type: 'customrecord_shipping_schedule',
                        id: ssId,
                        columns: ['custrecord_ssc_ifbolcorp_subsi']
                    });
                    console.log('custrecord_ssc_ifbolcorp_subsi ==> ' + JSON.stringify(ssFieldObj));
                    if (ssFieldObj['custrecord_ssc_ifbolcorp_subsi'].length > 0) {
                        var scSubId = ssFieldObj['custrecord_ssc_ifbolcorp_subsi'][0].value;
                    }
                    if (scSubId) {
                        var locationArr = searchLoc(scSubId);
                        if (locationArr && locationArr.length > 0) {
                            locFieldObj.removeSelectOption({value: null});
                            locFieldObj.insertSelectOption({value: '', text: ''});
                            for (var n = 0; n < locationArr.length; n++) {
                                locFieldObj.insertSelectOption({value: locationArr[n].value, text: locationArr[n].text});
                            }
                        }
                    }
                }
            }
            else {
                locFieldObj.removeSelectOption({value: null});
                locFieldObj.insertSelectOption({value: '', text: ''});
            }
        }

        if ('custpage_pur_contract' == fieldId) {
            var distributionType = curRec.getValue('custpage_distribution_type');// 配货类型
            var pcId = curRec.getValue('custpage_pur_contract');
            if (pcId && !pcInfos[pcId]) {
                pcInfos[pcId] = getPCLines(pcId);
            }
            if (pcId && 3 === Number(distributionType)) {
                curRec.setValue('custpage_supplier', pcInfos[pcId].subsidiary);
                curRec.setValue('custpage_vendor', pcInfos[pcId].vendor);
                curRec.setValue('custpage_pur_currency', pcInfos[pcId].currency);
            }
            var lineCount = curRec.getLineCount('custpage_line');
            if (lineCount > 0) {
                // 清空pc line id
                for (var i = 0; i < lineCount; i++) {
                    var sublistFieldObj = curRec.getSublistField('custpage_line', 'custpage_line_pclineid', i);
                    sublistFieldObj.removeSelectOption({value: null});
                    sublistFieldObj.insertSelectOption({value: '', text: ''});
                    if (pcId) {
                        var pcLines = pcInfos[pcId].lines;
                        for (var j = 0; j < pcLines.length; j++) {
                            sublistFieldObj.insertSelectOption({
                                value: pcLines[j].lineNo,
                                text: 'pcLineId:' + pcLines[j].lineNo + ',SKU:' + pcLines[j].itemName
                            });
                        }
                    }
                }
            }
        }

        if ('custpage_line' == sublistId && 'custpage_line_pclineid' == fieldId) {
            var pcLineId = curRec.getCurrentSublistValue('custpage_line', 'custpage_line_pclineid') || '';
            if (!pcLineId) {
                curRec.setCurrentSublistValue('custpage_line', 'custpage_line_pcqty', '');
            } else {
                var pcId = curRec.getValue('custpage_pur_contract');
                if (pcId) {
                    var pcLines = pcInfos[pcId].lines;
                    if (pcLines && pcLines.length > 0) {
                        for (var k = 0; k < pcLines.length; k++) {
                            if (pcLineId == pcLines[k].lineNo) {
                                curRec.setCurrentSublistValue('custpage_line', 'custpage_line_pcqty', pcLines[k].reQty);
                                curRec.setCurrentSublistValue('custpage_line', 'custpage_line_purprice', pcLines[k].rate);
                                curRec.setCurrentSublistValue('custpage_line', 'custpage_line_taxcode', pcLines[k].taxCode);
                                break;
                            }
                        }
                    }
                }
            }
        }

        if ('custpage_line' == sublistId && 'custpage_line_scditem' == fieldId) {
            var itemId = curRec.getCurrentSublistValue('custpage_line', 'custpage_line_scditem');
            if (itemId) {
                var itemFields = search.lookupFields({
                    type: 'item',
                    id: itemId,
                    columns: ['saleunit']
                });
                if (itemFields['saleunit'].length > 0) {
                    curRec.setCurrentSublistValue('custpage_line', 'custpage_line_unit', itemFields['saleunit'][0].text);
                }
            }
        }
    }

    /**
     * 搜索该子公司下的Location
     * @param subId
     * @return {[]}
     */
    function searchLoc(subId) {
        var locArr = [];
        var locSearchObj = search.create({
            type: 'location',
            filters: [
                ['isinactive', 'is', 'F'],
                'and',
                ['subsidiary', 'anyof', subId]
            ],
            columns: [
                search.createColumn({name: 'name'})
            ]
        });
        var columns = locSearchObj.columns;
        var results = locSearchObj.run().getRange({start: 0, end: 1000});
        if (results && results.length > 0) {
            for (var i = 0; i < results.length; i++) {
                locArr.push({
                    value: results[i].id,
                    text: results[i].getValue(columns[0])
                });
            }
        }
        return locArr;
    }

    /**
     * 获取采购合同货品行
     * @param pcId
     * @return {{}}
     */
    function getPCLines(pcId) {
        var pcInfos = {};
        var pcLines = [];
        var pcObj = record.load({type: 'purchaseorder', id: pcId});
        pcInfos.subsidiary = pcObj.getValue('subsidiary');
        pcInfos.vendor = pcObj.getValue('entity');
        pcInfos.currency = pcObj.getValue('currency');
        var lineCount = pcObj.getLineCount({sublistId: 'item'});
        for (var i = 0; i < lineCount; i++) {
            var itemName = pcObj.getSublistValue({sublistId: 'item', fieldId: 'item_display', line: i});
            var lineNo = pcObj.getSublistValue({sublistId: 'item', fieldId: 'custcol_emc_line_no', line: i});
            var qty = pcObj.getSublistValue({sublistId: 'item', fieldId: 'quantity', line: i});
            var createdQty = pcObj.getSublistValue({sublistId: 'item', fieldId: 'custcol_ecm_creatpoqty', line: i}) || 0;
            var reQty = Number(qty) - Number(createdQty);// 剩余数量
            var rate = pcObj.getSublistValue({sublistId: 'item', fieldId: 'rate', line: i});
            var taxCode = pcObj.getSublistValue({sublistId: 'item', fieldId: 'taxcode', line: i});
            var json = {
                lineNo: lineNo,
                itemName: itemName,
                reQty: reQty,
                rate: rate,
                taxCode: taxCode
            }
            pcLines.push(json);
        }
        pcInfos.lines = pcLines;
        return pcInfos;
    }

    /**
     * Function to be executed when field is slaved.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     *
     * @since 2015.2
     */
    function postSourcing(scriptContext) {

    }

    /**
     * Function to be executed after sublist is inserted, removed, or edited.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @since 2015.2
     */
    function sublistChanged(scriptContext) {

    }

    /**
     * Function to be executed after line is selected.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @since 2015.2
     */
    function lineInit(scriptContext) {

    }

    /**
     * Validation function to be executed when field is changed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
     * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
     *
     * @returns {boolean} Return true if field is valid
     *
     * @since 2015.2
     */
    function validateField(scriptContext) {

    }

    /**
     * Validation function to be executed when sublist line is committed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateLine(scriptContext) {

    }

    /**
     * Validation function to be executed when sublist line is inserted.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateInsert(scriptContext) {

    }

    /**
     * Validation function to be executed when record is deleted.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateDelete(scriptContext) {

    }

    /**
     * Validation function to be executed when record is saved.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @returns {boolean} Return true if record is valid
     *
     * @since 2015.2
     */
    function saveRecord(scriptContext) {
        var isSuccess = false;
        var curRec = scriptContext.currentRecord;
        var ssId = curRec.getValue('custpage_ss_no');// SS NO
        var distributionType = curRec.getValue('custpage_distribution_type');// 配货类型
        var shipDate = curRec.getText('custpage_shipping_date');
        var supplyPlanner = curRec.getValue('custpage_supply_planner');
        if (distributionType && shipDate && supplyPlanner) {
            isSuccess = true;
        }
        var lineCount = curRec.getLineCount('custpage_line');
        // Main字段校验
        // if (ssId) {
        //     var ssFields = search.lookupFields({
        //         type: 'customrecord_shipping_schedule',
        //         id: ssId,
        //         columns: ['custrecord_ssc_iscross_border']// 是否跨境
        //     });
        //     var isCross = ssFields['custrecord_ssc_iscross_border'];
        //     if ('T' == isCross || true == isCross) {
        //         // 销售合同勾选跨境，启运港必填
        //         var portOfDeparture = curRec.getValue('custpage_port');
        //         if (!portOfDeparture) {
        //             alert('Please enter value(s) for: Port of Departure');
        //             return false;
        //         }
        //     }
        // }
        // 当配货类型为以销定采时，表头的供方、供应商、采购币种为必填；
        if (1 === Number(distributionType)) {
            var supplier = curRec.getValue('custpage_supplier');
            var vendor = curRec.getValue('custpage_vendor');
            var currency = curRec.getValue('custpage_pur_currency');
            if (!supplier || !vendor || !currency) {
                var msg1 = 'Please enter value(s) for: ';
                if (!supplier) {
                    msg1 += 'Supplier;';
                }
                if (!vendor) {
                    msg1 += 'Vendor;';
                }
                if (!currency) {
                    msg1 += 'Purchase Currency'
                }
                alert(msg1);
                return false;
            }
        }
        // 当配货类型为仓库发货时，表头的仓库为必填；
        if (2 === Number(distributionType)) {
            var location = curRec.getValue('custpage_location');
            if (!location) {
                alert('Please enter value(s) for: Location');
                return false;
            }
        }
        // 当配货类型为采购合同时，表头的采购合同为必填；
        if (3 === Number(distributionType)) {
            var pcId = curRec.getValue('custpage_pur_contract');
            if (!pcId) {
                alert('Please enter value(s) for: Purchase Contract');
                return false;
            }
        }

        // 校验明细
        if (lineCount > 0) {
            var isSelect = false;// 是否勾选明细
            var lineErrorMsg = '';
            for (var i = 0; i < lineCount; i++) {
                var isCheck = curRec.getSublistValue('custpage_line', 'custpage_line_check', i);
                if ('T' == isCheck || true == isCheck) {
                    isSelect = true;
                    // 校验明细行的合同配货数量<发运计划数量-已配货数量；
                    var scdQty = curRec.getSublistValue('custpage_line', 'custpage_line_scdqty', i) || 0;// 合同配货数量
                    var ssQty = curRec.getSublistValue('custpage_line', 'custpage_line_qty', i) || 0;// 发运计划数量
                    var ssdQty = curRec.getSublistValue('custpage_line', 'custpage_line_dqty', i) || 0;// 已配货数量
                    var reQty = Number(ssQty) - Number(ssdQty);
                    if (Number(scdQty) > Number(reQty)) {
                        lineErrorMsg += 'Line ' + (i + 1) + ': sales contract distribution quantity is not greater than shipping schedule distribution quantity;';
                    }
                    // 当配货类型为以销定采时，明细行的采购单价、采购税码为必填；
                    if (1 === Number(distributionType)) {
                        var rate = curRec.getSublistValue('custpage_line', 'custpage_line_purprice', i) || 0;// 采购单价
                        var taxCode = curRec.getSublistValue('custpage_line', 'custpage_line_taxcode', i);// 采购税码
                        if (Number(rate) == 0) {
                            lineErrorMsg += 'Line ' + (i + 1) + ': purchase rate cannot be empty;';
                        }
                        if (!taxCode) {
                            lineErrorMsg += 'Line ' + (i + 1) + ': purchase taxcode cannot be empty;';
                        }
                    }
                    // 当配货类型为采购合同时，明细行的采购合同行ID为必填；判断每行的合同配货数量是否小于等于该采购合同行的数量-已生成订单数量，不满足时提示；
                    if (3 === Number(distributionType)) {
                        var pcLineId = curRec.getSublistValue('custpage_line', 'custpage_line_pclineid', i);
                        var pcQty = curRec.getSublistValue('custpage_line', 'custpage_line_pcqty', i);
                        if (!pcLineId) {
                            lineErrorMsg += 'Line' + (i + 1) + ': purchase contract line id cannot be empty;';
                        }
                        if (Number(scdQty) > Number(pcQty)) {
                            lineErrorMsg += 'Line' + (i + 1) + ': sales contract distribution quantity is not greater than purchase contract line can generate the order quantity;';
                        }
                    }
                    if (i < lineCount - 1 && lineErrorMsg) {
                        lineErrorMsg += '\r';
                    }
                }
            }
            if (lineErrorMsg) {
                alert(lineErrorMsg);
                return false;
            }
            // 未勾选明细
            if (!isSelect) {
                alert('Please check at least one line of details.');
                return false;
            }
        }
        else {
            alert('Line cannot be empty.');
            return false;
        }
        console.log('isSuccess ==> ' + isSuccess);
        if (true == isSuccess) {
            addScreenDisabled();
        }
        return true;
    }

    function addScreenDisabled() {
        var $ = jQuery;
        var docHeight = $(document).height(); //获取窗口高度

        $('body').append('<div id="overlay"></div>');
        $('#overlay').append('<span style="width:100%;height:100%;line-height:100px;text-align:center;display:block;font-weight: bold; color: red;font-size: 20pt;"><br/><br/><br/>Data is being generated.Please wait.</span>');
        $('#overlay')
            .height(docHeight)
            .css({
                'opacity': .6, //透明度
                'position': 'absolute',
                'top': 0,
                'left': 0,
                'background-color': '#939090',
                'width': '100%',
                'z-index': 10000, //保证这个悬浮层位于其它内容之上
            });

        setTimeout(function () {
            $('#overlay').fadeOut('slow')
        }, 10000000);
    }

    function searchData() {
        var curRec = currentRecord.get();
        var ssNo = curRec.getValue('custpage_ss_no') || '';
        if (!ssNo) {
            alert('Please enter value(s) for: SS NO');
            return;
        }

        var url = window.location.href;
        var urlArr = url.split('&');
        var newUrl = '&iss=T';

        if (ssNo) {
            newUrl += '&ssno=' + ssNo;
        }

        setWindowChanged(window, false);
        window.location.href = urlArr[0] + "&" + urlArr[1] + newUrl;
    }

    return {
        pageInit: pageInit,
        fieldChanged: fieldChanged,
        // postSourcing: postSourcing,
        // sublistChanged: sublistChanged,
        // lineInit: lineInit,
        // validateField: validateField,
        // validateLine: validateLine,
        // validateInsert: validateInsert,
        // validateDelete: validateDelete,
        saveRecord: saveRecord,
        searchData: searchData
    };
    
});
