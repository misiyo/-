/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 *
 * Version		Date			Author			Remarks
 * 1.0          2023/02/24      Mark Z          SCD新建后回写SS/PC数量
 * 2.0          2023/03/13      Mark Z          回写合同配货数量后遍历SS明细合同配货数量是否大于等于SS数量，勾选COMPLETED SCD
 */
define(['N/record', 'N/runtime', '../tools/common_api.js'],
    /**
 * @param{record} record
 */
    (record, runtime, commonApi) => {
        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed before record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const beforeSubmit = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {
            let newObj = scriptContext.newRecord;
            let type = scriptContext.type;
            if ('delete' == type) {
                return;
            }

            if ('create' == type) {
                writeBackQty(newObj);
            }
        }

        /**
         * 回写数量
         * @param newObj
         */
        const writeBackQty = newObj => {
            let obj = record.load({type: newObj.type, id: newObj.id});
            let ssId = obj.getValue({fieldId: 'custrecord_scd_ss'}) || '';
            let pcId = obj.getValue({fieldId: 'custrecord_scd_pc'}) || '';
            const subId = 'recmachcustrecord_ecm_scdline_scd';
            let lineCount = obj.getLineCount({sublistId: subId});
            let ssLines = {}, pcLines = {};
            for (let i = 0; i < lineCount; i++) {
                let qty = obj.getSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_qty', line: i});
                let scLineNo = obj.getSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_uniquekey', line: i});
                let pcLineNo = obj.getSublistValue({sublistId: subId, fieldId: 'custrecord_scdline_pclineid', line: i});
                if (qty) {
                    if (scLineNo) {
                        ssLines[scLineNo] = qty;
                    }
                    if (pcLineNo) {
                        pcLines[pcLineNo] = qty;
                    }
                }
            }
            log.debug('ssLines', ssLines);
            log.debug('pcLines', pcLines);
            // 回写
            if (ssId && Object.keys(ssLines).length > 0) {
                let ssObj = record.load({type: 'customrecord_shipping_schedule', id: ssId});
                let ssLineCount = ssObj.getLineCount({sublistId: 'recmachcustrecord_sscd_parent'});
                // 回写合同配货数量
                for (let j = 0; j < ssLineCount; j++) {
                    let scLineNo = ssObj.getSublistValue({sublistId: 'recmachcustrecord_sscd_parent', fieldId: 'custrecord_sscd_sclineid', line: j});
                    let ssdQty = ssObj.getSublistValue({sublistId: 'recmachcustrecord_sscd_parent', fieldId: 'custrecord_sscd_csdty_created', line: j}) || 0;
                    if (ssLines[scLineNo]) {
                        ssObj.setSublistValue({sublistId: 'recmachcustrecord_sscd_parent', fieldId: 'custrecord_sscd_csdty_created', line: j, value: Number(ssdQty).add(Number(ssLines[scLineNo]))});
                    }
                }
                // 遍历所有明细，判断合同配货数量是否大于等于数量，勾选COMPLETED SCD
                let totalSSQty = 0, totalSCDQty = 0;
                for (let l = 0; l < ssLineCount; l++) {
                    let qty = ssObj.getSublistValue({sublistId: 'recmachcustrecord_sscd_parent', fieldId: 'custrecord_sscd_ssqty', line: l}) || 0;
                    let scdQty = ssObj.getSublistValue({sublistId: 'recmachcustrecord_sscd_parent', fieldId: 'custrecord_sscd_csdty_created', line: l}) || 0;
                    totalSSQty = Number(totalSSQty).add(Number(qty));
                    totalSCDQty = Number(totalSCDQty).add(Number(scdQty));
                }
                if (Number(totalSCDQty) >= Number(totalSSQty)) {
                    ssObj.setValue({fieldId: 'custrecord_ssc_completescd', value: true});
                }
                ssObj.save({enableSourcing: true, ignoreMandatoryFields: true});
            }

            if (pcId && Object.keys(pcLines).length > 0) {
                let pcObj = record.load({type: 'purchaseorder', id: pcId});
                let pcLineCount = pcObj.getLineCount({sublistId: 'item'});
                for (let k = 0; k < pcLineCount; k++) {
                    let pcLineNo = pcObj.getSublistValue({sublistId: 'item', fieldId: 'custcol_emc_line_no', line: k});
                    let pcdQty = pcObj.getSublistValue({sublistId: 'item', fieldId: 'custcol_ecm_creatpoqty', line: k}) || 0;
                    if (pcLines[pcLineNo]) {
                        pcObj.setSublistValue({sublistId: 'item', fieldId: 'custcol_ecm_creatpoqty', line: k, value: Number(pcdQty).add(Number(pcLines[pcLineNo]))});
                    }
                }
                pcObj.save({enableSourcing: true, ignoreMandatoryFields: true});
            }
        }

        return {/*beforeLoad, beforeSubmit, */afterSubmit}

    });
