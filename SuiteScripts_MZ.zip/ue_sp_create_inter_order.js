/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 *
 * Version		Date			Author			Remarks
 * 1.0          2023/02/28      Mark Z          SP Create PO/SO/IR/IF
 * 2.0          2023/03/16      Mark Z          排除Scheduled脚本触发
 * 3.0          2023/03/27      Mark Z          公司间交易生成成功或不需要生成公司间交易，勾选生成公司间交易成功
 * 4.0          2023/04/10      Mark Z          新增字段取值
 */
define(['N/record', 'N/runtime', 'N/search', 'N/task'],
    /**
     * @param{record} record
     * @param{runtime} runtime
     * @param{search} search
     * @param{task} task
     */
    (record, runtime, search, task) => {
        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed before record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const beforeSubmit = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {
            let newRec = scriptContext.newRecord, type = scriptContext.type;
            if ('delete' == type) {
                return;
            }
            log.debug('runtime.executionContext', runtime.executionContext);
            // log.debug('runtime.getCurrentScript().id', runtime.getCurrentScript().id);
            // 排除scheduled脚本触发
            if (runtime.executionContext == 'SCHEDULED') {
                return;
            }
            if (runtime.executionContext != 'SCHEDULED') {
                createIC(newRec, type);
            }
        }

        /**
         * 创建公司间单据
         * @param newRec
         * @param type
         */
        const createIC = (newRec, type) => {
            let obj = record.load({type: newRec.type, id: newRec.id});
            let tradeTerms = obj.getText({fieldId: 'custrecord_sp_incoterm'}) || '';// 贸易术语
            let spStatus = obj.getValue({fieldId: 'custrecord_sp_status'});// Shipping Plan Status
            // log.debug('tradeTerms', tradeTerms);
            // log.debug('spStatus', spStatus);
            let isCreated = obj.getValue({fieldId: 'custrecord_sp_ictransaction'});// 生成公司间交易成功
            if (('F' == isCreated || false == isCreated)) {
                // 判断明细是否需要生成公司间交易
                let isCheck = false;// 是否勾选生成公司间交易成功
                let lineCount = obj.getLineCount({sublistId: 'recmachcustrecord_scdline_sp'});
                let needCreateICOrderLine = 0;// 需要生成公司间交易的行数
                if (lineCount > 0) {
                    for (let i = 0; i < lineCount; i++) {
                        let supplier = obj.getSublistValue({sublistId: 'recmachcustrecord_scdline_sp', fieldId: 'custrecord_scdline_supplier', line: i}) || '';
                        let demander = obj.getSublistValue({sublistId: 'recmachcustrecord_scdline_sp', fieldId: 'custrecord_scdline_demander', line: i}) || '';
                        if (supplier && demander && supplier != demander) {
                            let icPO = obj.getSublistValue({sublistId: 'recmachcustrecord_scdline_sp', fieldId: 'custrecord_scdline_icpo', line: i}) || '';
                            let icSO = obj.getSublistValue({sublistId: 'recmachcustrecord_scdline_sp', fieldId: 'custrecord_scdline_icso', line: i}) || '';
                            let icIR = obj.getSublistValue({sublistId: 'recmachcustrecord_scdline_sp', fieldId: 'custrecord_scdline_icir', line: i}) || '';
                            let icIF = obj.getSublistValue({sublistId: 'recmachcustrecord_scdline_sp', fieldId: 'custrecord_scdline_icif', line: i}) || '';
                            // po/so/ir/if为空
                            if (!icPO || !icSO || !icIR || !icIF) {
                                needCreateICOrderLine++;
                            }
                        }
                    }
                    if (needCreateICOrderLine == 0) {
                        isCheck = true;
                    }
                }
                // 非创建时保存，明细为空，勾选生成公司间交易成功
                if (lineCount == 0 && 'create' != type) {
                    isCheck = true;
                }

                let date = '';
                // 1.EXW,FCA,CPT,CIP在提货状态生成，且未勾选生成公司间交易成功
                if (('EXW' == tradeTerms || 'FCA' == tradeTerms || 'CPT' == tradeTerms || 'CIP' == tradeTerms) && 2 === Number(spStatus) && !isCheck) {
                    date = obj.getText({fieldId: 'custrecord_sp_deliverycomdate'}) || '';
                    taskAsyncScripts(obj.id, date);
                }
                // 2.FAS,FOB,CFR,CIF在离港状态生成，且未勾选生成公司间交易成功
                if (('FAS' == tradeTerms || 'FOB' == tradeTerms || 'CFR' == tradeTerms || 'CIF' == tradeTerms) && 3 === Number(spStatus) && !isCheck) {
                    date = obj.getText({fieldId: 'custrecord_sp_departuredate'}) || '';
                    taskAsyncScripts(obj.id, date);
                }
                // 3.DES,DEQ,DDU,DDP,DAF在到达状态生成，且未勾选生成公司间交易成功
                if (('DES' == tradeTerms || 'DEQ' == tradeTerms || 'DDU' == tradeTerms || 'DDP' == tradeTerms || 'DAF' == tradeTerms || 'DAT' == tradeTerms || 'DAP' == tradeTerms || 'DPU' == tradeTerms) && 4 === Number(spStatus) && !isCheck) {
                    date = obj.getText({fieldId: 'custrecord_sp_arrivaldate'}) || '';
                    taskAsyncScripts(obj.id, date);
                }

                let updVals = {};
                updVals.custrecord_sp_ictransaction = isCheck;
                if (date) {
                    updVals.custrecord_sp_deliverydate = date;
                }

                record.submitFields({
                    type: newRec.type,
                    id: newRec.id,
                    values: updVals,
                    options: {
                        enablesourcing: true,
                        ignoreMandatoryFields: true
                    }
                });
            }
        }

        // 调用异步脚本
        const taskAsyncScripts = (id, date) => {
            let ssTask = task.create({
                taskType: task.TaskType.SCHEDULED_SCRIPT,
                scriptId: 'customscript_ecm_create_interc_orders_ss',
                params: {
                    'custscript_hc_spid': id,
                    'custscript_hc_spdate': date
                }
            });
            ssTask.submit();
        }

        return {
            // beforeLoad,
            // beforeSubmit,
            afterSubmit
        }

    });
