/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 */
define(['N/query', 'N/record', 'N/search'],
    /**
 * @param{query} query
 * @param{record} record
 * @param{search} search
 */
    (query, record, search) => {
        /**
         * Defines the Suitelet script trigger point.
         * @param {Object} scriptContext
         * @param {ServerRequest} scriptContext.request - Incoming request
         * @param {ServerResponse} scriptContext.response - Suitelet response
         * @since 2015.2
         */
        const onRequest = (scriptContext) => {
            // record.submitFields({
            //     type: 'salesorder',
            //     id: 8520,
            //     values: {
            //         custbody_ecm_balance_termsdays: 10
            //     },
            //     options: {
            //         ignoreMandatoryFields: true
            //     }
            // });
            // let spLineIds = ['1'];
            // let sql = `
            //             SELECT BUILTIN_RESULT.TYPE_INTEGER("TRANSACTION"."ID") AS "ID" /*{id#RAW}*/,
            //                     BUILTIN_RESULT.TYPE_INTEGER(transactionLine.custcol_ecm_spline) AS splineid /*{transactionlines.custcol_ecm_spline#RAW}*/,
            //                     BUILTIN_RESULT.TYPE_INTEGER(inventoryAssignment_SUB.inventorynumber) AS lotid /*{transactionlines.inventoryassignment.inventorynumber#RAW}*/,
            //                     BUILTIN_RESULT.TYPE_STRING(inventoryAssignment_SUB.inventorynumber_0) AS lotno /*{transactionlines.inventoryassignment.inventorynumber.inventorynumber#RAW}*/,
            //                     BUILTIN_RESULT.TYPE_FLOAT(inventoryAssignment_SUB.quantity) AS lotqty /*{transactionlines.inventoryassignment.quantity#RAW}*/
            //             FROM
            //                 "TRANSACTION",
            //                 (SELECT inventoryAssignment."TRANSACTION" AS transaction_join, inventoryAssignment.transactionline AS transactionline_join, inventoryAssignment.inventorynumber AS inventorynumber, inventoryNumber.inventorynumber AS inventorynumber_0, inventoryAssignment.quantity AS quantity, inventoryAssignment.quantity AS quantity_crit, inventoryAssignment.inventorynumber AS inventorynumber_crit FROM inventoryAssignment, inventoryNumber WHERE inventoryAssignment.inventorynumber = inventoryNumber."ID"(+) ) inventoryAssignment_SUB,
            //                 transactionLine
            //             WHERE
            //                 (
            //                     (
            //                         (
            //                             transactionLine."TRANSACTION" = inventoryAssignment_SUB.transaction_join(+)
            //                             AND
            //                             transactionLine."ID" = inventoryAssignment_SUB.transactionline_join(+)
            //                         )
            //                         AND
            //                         "TRANSACTION"."ID" = transactionLine."TRANSACTION"
            //                     )
            //                 )
            //                 AND
            //                 (
            //                     (
            //                         "TRANSACTION"."TYPE" IN ('InvTrnfr', 'ItemRcpt')
            //                         AND
            //                         NVL(transactionLine.mainline, 'F') = ?
            //                         AND
            //                         NVL(transactionLine.taxline, 'F') = ?
            //                         AND
            //                         inventoryAssignment_SUB.quantity_crit > ?
            //                         AND
            //                         NOT( inventoryAssignment_SUB.inventorynumber_crit IS NULL )
            //                         AND
            //                         transactionLine.custcol_ecm_spline IN (${spLineIds.toString()})
            //                     )
            //                 )
            //             ORDER BY "TRANSACTION"."ID" ASC NULLS LAST`;
            // let results = query.runSuiteQL({
            //     query: sql,
            //     params:[false,false,0]
            // }).asMappedResults();

            // let myQuery = query.load({id: 'custworkbook15'});
            // let mySuiteQL = myQuery.toSuiteQL();
            // log.debug('mySuiteQL', mySuiteQL);
            // let mySuiteQLQuery = mySuiteQL.query;
            // log.debug('mySuiteQLQuery', mySuiteQLQuery);
            // let results = mySuiteQL.run().asMappedResults();
            // log.debug('results', results);

            // let sql = `
            //             SELECT BUILTIN_RESULT.TYPE_INTEGER("TRANSACTION"."ID") AS "ID" /*{id#RAW}*/,
            //                     BUILTIN_RESULT.TYPE_INTEGER(transactionLine.custcol_ecm_spline) AS splineid /*{transactionlines.custcol_ecm_spline#RAW}*/,
            //                     BUILTIN_RESULT.TYPE_INTEGER(inventoryAssignment_SUB.inventorynumber) AS lotid /*{transactionlines.inventoryassignment.inventorynumber#RAW}*/,
            //                     BUILTIN_RESULT.TYPE_STRING(inventoryAssignment_SUB.inventorynumber_0) AS lotno /*{transactionlines.inventoryassignment.inventorynumber.inventorynumber#RAW}*/,
            //                     BUILTIN_RESULT.TYPE_FLOAT(inventoryAssignment_SUB.quantity) AS lotqty /*{transactionlines.inventoryassignment.quantity#RAW}*/
            //             FROM
            //                 "TRANSACTION",
            //                 (SELECT inventoryAssignment."TRANSACTION" AS transaction_join, inventoryAssignment.transactionline AS transactionline_join, inventoryAssignment.inventorynumber AS inventorynumber, inventoryNumber.inventorynumber AS inventorynumber_0, inventoryAssignment.quantity AS quantity, inventoryAssignment.quantity AS quantity_crit, inventoryAssignment.inventorynumber AS inventorynumber_crit FROM inventoryAssignment, inventoryNumber WHERE inventoryAssignment.inventorynumber = inventoryNumber."ID"(+) ) inventoryAssignment_SUB,
            //                 transactionLine
            //             WHERE
            //                 (
            //                     (
            //                         (
            //                             transactionLine."TRANSACTION" = inventoryAssignment_SUB.transaction_join(+)
            //                             AND
            //                             transactionLine."ID" = inventoryAssignment_SUB.transactionline_join(+)
            //                         )
            //                         AND
            //                         "TRANSACTION"."ID" = transactionLine."TRANSACTION"
            //                     )
            //                 )
            //                 AND
            //                 (
            //                     (
            //                         "TRANSACTION"."TYPE" IN ('InvTrnfr', 'ItemRcpt')
            //                         AND
            //                         NVL(transactionLine.mainline, 'F') = ?
            //                         AND
            //                         NVL(transactionLine.taxline, 'F') = ?
            //                         AND
            //                         inventoryAssignment_SUB.quantity_crit > ?
            //                         AND
            //                         NOT( inventoryAssignment_SUB.inventorynumber_crit IS NULL )
            //                         AND
            //                         "TRANSACTION"."ID" = ?
            //                     )
            //                 )
            //             ORDER BY "TRANSACTION"."ID" ASC NULLS LAST`;
            // let results = query.runSuiteQL({
            //     query: sql,
            //     params:[false,false,0,3161]
            // }).asMappedResults();
            // log.debug('results', results);

            // let lotArr = [];
            // let irObj = record.load({type: 'itemfulfillment', id: 3176});
            // let lineCount = irObj.getLineCount({sublistId: 'item'});
            // for (let i = 0; i < lineCount; i++) {
            //     // let spLineId = irObj.getSublistValue({sublistId: 'item', fieldId: 'custcol_ecm_spline', line: i});
            //     // if (spLineId) {
            //         let inventoryDetailObj = irObj.getSublistSubrecord({sublistId: 'item', fieldId: 'inventorydetail', line: i});
            //         let idLines = inventoryDetailObj.getLineCount({sublistId: 'inventoryassignment'});
            //
            //         for (let j = 0; j < idLines; j++) {
            //             let lotId = inventoryDetailObj.getSublistValue({sublistId: 'inventoryassignment', fieldId: 'issueinventorynumber', line: j});
            //             let lotQty = inventoryDetailObj.getSublistValue({sublistId: 'inventoryassignment', fieldId: 'quantity', line: j});
            //             let json = {
            //                 lotId: lotId,
            //                 lotQty: lotQty
            //             };
            //             lotArr.push(json);
            //         }
            //         // irLots[spLineId] = lotArr;
            //     // }
            // }
            // log.debug('lotArr', lotArr);

            // let spObj = record.load({type: 'customrecord_ecm_sp', id: 56});
            // let locId = spObj.getValue({fieldId: 'custrecord_sp_location'});
            // let locObj = record.load({type: 'location', id: locId});
            // let subsidiary = locObj.getValue({fieldId: 'subsidiary'});
            // log.debug('subsidiary',subsidiary);

            let currencyRate = getCuyRate();// 获取币种转换汇率
        }

        /**
         * 获取货币历史汇率
         * @return {{}}
         */
        const getCuyRate = () => {
            let rateInfo = {};
            let exchangeSearch = search.create({
                type: 'currencyrate',
                columns: [
                    'basecurrency',
                    'transactioncurrency',
                    'exchangerate',
                    search.createColumn({
                        name: 'effectivedate',
                        sort: search.Sort.DESC,
                        label: "生效日期"
                    })
                ]
            });
            let columns = exchangeSearch.columns;
            let res = exchangeSearch.run().getRange({start: 0, end: 1000});
            for (let i = 0; i < res.length; i++) {
                let baseCurrency = res[i].getValue(columns[0]);
                let transactionCurrency = res[i].getValue(columns[1]);
                let key = baseCurrency + '&' + transactionCurrency;
                let json = {
                    exchangeRate: res[i].getValue(columns[2]),
                    date: res[i].getValue(columns[3])
                }
                if (!rateInfo[key]) {
                    rateInfo[key] = [];
                    rateInfo[key].push(json);
                } else {
                    rateInfo[key].push(json);
                }
            }
            log.debug('rateInfo', rateInfo);
            return rateInfo;
        }

        return {onRequest}

    });
