/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 *
 * Version		Date			Author			Remark
 * 1.0          2023/03/27      Mark Z          计算非公司间销售订单开票DueDate
 */
define(['N/record', 'N/search', 'N/config'],
    /**
 * @param{record} record
 * @param{search} search
 */
    (record, search, config) => {
        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed before record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const beforeSubmit = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {
            let newObj = scriptContext.newRecord,
                type = scriptContext.type;

            if ('delete' == type) {
                return;
            }

            calculateDueDate(newObj, type);

        }

        /**
         * 计算DueDate
         * @param newObj
         * @param type
         */
        const calculateDueDate = (newObj, type) => {
            let createdFromType = '';// 创建自单据类型
            let createdFromId = newObj.getValue('createdfrom');
            if (createdFromId) {
                let invFieldObj = search.lookupFields({
                    type: 'invoice',
                    id: newObj.id,
                    columns: ['createdfrom.type']
                });
                if (invFieldObj['createdfrom.type'].length > 0) {
                    createdFromType = invFieldObj['createdfrom.type'][0].value;
                }
                if ('SalesOrd' == createdFromType) {
                    let soFieldObj = search.lookupFields({
                        type: 'salesorder',
                        id: createdFromId,
                        columns: ['custbody_ecm_ordertype', 'custbody_ecm_balance_termsdays', 'custbody_ecm_sp']
                    });
                    let orderType = '', spId = '';
                    if (soFieldObj['custbody_ecm_ordertype'].length > 0) {
                        orderType = soFieldObj['custbody_ecm_ordertype'][0].value;
                    }
                    if (soFieldObj['custbody_ecm_sp'].length > 0) {
                        spId = soFieldObj['custbody_ecm_sp'][0].value;
                    }
                    let termsDays = soFieldObj['custbody_ecm_balance_termsdays'] || 0;
                    // 订单类型 != intercompany order & sp的Delivery Date有值
                    if (3 !== Number(orderType) && spId) {
                        let spFieldObj = search.lookupFields({
                            type: 'customrecord_ecm_sp',
                            id: spId,
                            columns: ['custrecord_sp_deliverydate']
                        });
                        let deliveryDate = '';
                        if (spFieldObj['custrecord_sp_deliverydate']) {
                            deliveryDate = spFieldObj['custrecord_sp_deliverydate'];
                        }
                        log.debug('deliveryDate', deliveryDate);
                        log.debug('termsDays', termsDays);
                        if (deliveryDate) {
                            let dueDate = dateAddDays(deliveryDate, termsDays);
                            log.debug('dueDate', dueDate);
                            if (dueDate) {
                                record.submitFields({
                                    type: newObj.type,
                                    id: newObj.id,
                                    values: {
                                        duedate: dueDate
                                    },
                                    options: {
                                        enablesourcing: true,
                                        ignoreMandatoryFields: true
                                    }
                                });
                            }
                        }
                    }
                }
            }
        }

        /**
         * 日期加减
         * @param date
         * @param days
         * @return {string|boolean}
         */
        const dateAddDays = (date, days) => {
            date += ' 00:00:00';
            let date1 = new Date(date);
            let mOffset = date1.getTimezoneOffset();
            let now = new Date(date1.getTime() + (8 * 60 + mOffset) * 60 * 1000);
            let newDate = new Date(now.getTime() + (86400) * Number(days) * 1000);
            let year = newDate.getFullYear();
            let month = newDate.getMonth() + 1;
            let day = newDate.getDate();
            month = month < 10 ? '0' + month : month;
            day = day < 10 ? '0' + day : day;

            let configObj = config.load({type: config.Type.USER_PREFERENCES});
            let dateformat = configObj.getValue('DATEFORMAT');

            if ('' == year || '' == month || '' == day || '' == dateformat) {
                return false;
            }
            if ('YYYY年M月D日' == dateformat) {
                return year + '年' + Number(month) + '月' + Number(day) + '日 ';
            } else if ('YYYY年MM月DD日' == dateformat) {
                return year + '年' + month + '月' + day + '日 ';
            } else if ('YYYY-M-D' == dateformat) {
                return year + '-' + Number(month) + '-' + Number(day);
            } else if('YYYY-MM-DD' == dateformat) {
                return year + '-' + month + '-' + day;
            } else if ('YYYY M D' == dateformat) {
                return year + ' ' + Number(month) + ' ' + Number(day);
            } else if ('YYYY MM DD' == dateformat) {
                return year + ' ' + month + ' ' + day;
            } else if ('YYYY/M/D' == dateformat) {
                return year + '/' + Number(month) + '/' + Number(day);
            } else if ('YYYY/MM/DD' == dateformat) {
                return year + '/' + month + '/' + day;
            } else if ('M/D/YYYY' == dateformat) {
                return Number(month) + '/' + Number(day) + '/' + year;
            } else if ('MM/DD/YYYY' == dateformat) {
                return month + '/' + day + '/' + year;
            } else if ('D/M/YYYY' == dateformat) {
                return Number(day) + '/' + Number(month) + '/' + year;
            } else if ('DD/MM/YYYY' == dateformat) {
                return day + '/' + month + '/' + year;
            } else if ('D-Mon-YYYY' == dateformat) {
                let months = ["1", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                let tempMonth = months[month - 1];
                return Number(day) + '-' + tempMonth + '月-' + year;
            } else if ('DD-Mon-YYYY' == dateformat) {
                let months = ["1", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                let tempMonth = months[month - 1];
                return day + '-' + tempMonth + '月-' + year;
            } else if ('D.M.YYYY' == dateformat) {
                return Number(day) + '.' + Number(month) + '.' + year;
            } else if('DD.MM.YYYY' == dateformat) {
                return day + '.' + month + '.' + year;
            }
        }

        return {/*beforeLoad, beforeSubmit, */afterSubmit}

    });
