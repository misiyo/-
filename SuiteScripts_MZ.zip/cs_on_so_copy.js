/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 *
 * Version		Date			Author			Remarks
 * 1.0          2020/11/06      mark            点击mark copy时清空字段，保存时判断字段是否重复
 * 2.0          2021/06/24      John Wang       PO重复校验搜索优化
 * 3.0          2021/08/20      John Wang       v2优化，新加同客户校验
 */
define(['N/record','N/search','N/runtime'],

    function(record,search,runtime) {

        /**
         * Function to be executed after page is initialized.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.mode - The mode in which the record is being accessed (create, copy, or edit)
         *
         * @since 2015.2
         */
        function pageInit(scriptContext) {
            var rec = scriptContext.currentRecord;
            var mode = scriptContext.mode;

            var env = runtime.envType;
            var sid = env == 'SANDBOX' ? 1 : 3;//TODO 子公司

            //copy时触发
            if (mode == 'copy') {
                //子公司为美国 ETI
                var subsidiary = rec.getValue({
                    fieldId: 'subsidiary'
                });
                if (subsidiary == sid) {
                    //清空PO#字段
                    rec.setValue({
                        fieldId: 'otherrefnum',
                        value: ''
                    });
                }
            }
        }

        /**
         * Function to be executed when field is changed.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         * @param {string} scriptContext.fieldId - Field name
         * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
         * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
         *
         * @since 2015.2
         */
        function fieldChanged(scriptContext) {

        }

        /**
         * Function to be executed when field is slaved.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         * @param {string} scriptContext.fieldId - Field name
         *
         * @since 2015.2
         */
        function postSourcing(scriptContext) {

        }

        /**
         * Function to be executed after sublist is inserted, removed, or edited.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         *
         * @since 2015.2
         */
        function sublistChanged(scriptContext) {

        }

        /**
         * Function to be executed after line is selected.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         *
         * @since 2015.2
         */
        function lineInit(scriptContext) {

        }

        /**
         * Validation function to be executed when field is changed.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         * @param {string} scriptContext.fieldId - Field name
         * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
         * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
         *
         * @returns {boolean} Return true if field is valid
         *
         * @since 2015.2
         */
        function validateField(scriptContext) {

        }

        /**
         * Validation function to be executed when sublist line is committed.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         *
         * @returns {boolean} Return true if sublist line is valid
         *
         * @since 2015.2
         */
        function validateLine(scriptContext) {

        }

        /**
         * Validation function to be executed when sublist line is inserted.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         *
         * @returns {boolean} Return true if sublist line is valid
         *
         * @since 2015.2
         */
        function validateInsert(scriptContext) {

        }

        /**
         * Validation function to be executed when record is deleted.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         *
         * @returns {boolean} Return true if sublist line is valid
         *
         * @since 2015.2
         */
        function validateDelete(scriptContext) {

        }

        /**
         * Validation function to be executed when record is saved.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @returns {boolean} Return true if record is valid
         *
         * @since 2015.2
         */
        function saveRecord(scriptContext) {
            var rec = scriptContext.currentRecord;

            var env = runtime.envType;
            var sid = env == 'SANDBOX' ? 1 : 3;//TODO 子公司

            //子公司为美国ETI
            var subsidiary = rec.getValue({
                fieldId: 'subsidiary'
            });
            if (subsidiary == sid) {
                var customer_po = rec.getValue({
                    fieldId: 'otherrefnum'
                });
                var entity = rec.getValue('entity');
                if('' != customer_po) {
                	var recordId = rec.id;
                	//判断record.id是否存在
                	//创建时不存在
                	//编辑时，当前记录id存在
                	var filters = [];
                	filters.push(['type','anyof','SalesOrd']);
                	filters.push('and');
                	filters.push(['mainline','is', true]);
                	filters.push('and');
                	filters.push(['subsidiary','anyof',sid]);
                	filters.push('and');
                	filters.push(['status','noneof','SalesOrd:C','SalesOrd:H']);
                	filters.push('and');
                	filters.push(['formulatext: {otherrefnum}','is',customer_po]);
                	filters.push('and');
                	filters.push(['entity','anyof',entity]);
                	if (recordId) {
                		filters.push('and');
                		filters.push(['internalid','noneof',recordId]);
                	}
                	var mySearch_create = search.create({
                		type: "salesorder",
                		filters: filters,
                		columns:
                			[
                			 search.createColumn({name: "internalid"})
                			 ]
                	});
                	var results = mySearch_create.run().getRange({start: 0, end: 1});
                	var po_arrayNum = [];
                	if(results && results.length > 0) {
                		//alert('This customer PO already exists.');
                        //return false;
                        if (window.confirm('This customer PO already exists.')==false){
                            return false;
                        }
                	} else {
                		return true;
                	}
                }
            }
            return true;
        }

        //获取全部数据
        function getAllSearchData(mySearch) {
            var run_search = mySearch.run();
            var all_datas = run_search.getRange({ start: 0, end: 1000 });
            var data_i = 1000;

            while (all_datas) {
                if (all_datas.length == data_i) {
                    var to_data_ex = run_search.getRange({ start: data_i, end: data_i + 1000 });
                    if (to_data_ex.length > 0) {
                        all_datas = all_datas.concat(to_data_ex);
                    }
                    data_i = data_i + 1000;
                } else {
                    break;
                }
            }
            return all_datas;
        }

        return {
            pageInit: pageInit,
            //fieldChanged: fieldChanged,
            //postSourcing: postSourcing,
            //sublistChanged: sublistChanged,
            //lineInit: lineInit,
            //validateField: validateField,
            //validateLine: validateLine,
            //validateInsert: validateInsert,
            //validateDelete: validateDelete,
            saveRecord: saveRecord
        };

    });