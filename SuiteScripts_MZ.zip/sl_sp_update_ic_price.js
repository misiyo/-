/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 *
 * Version		Date			Author			Remark
 * 1.0          2023/03/10      Mark Z          更新公司间价格
 * 2.0          2023/03/29      Mark Z          明细对应字段改为EcmUniqueKey
 * 3.0          2023/03/31      Mark Z          新增字段回写&加价比例匹配规则&单价计算逻辑
 * 4.0          2023/04/06      Mark Z          修改单价取值逻辑
 */
define(['N/query', 'N/record', 'N/redirect', 'N/runtime', 'N/search', '../tools/common_api.js', '../tools/ramda.min.js', 'N/currency'],
    /**
 * @param{query} query
 * @param{record} record
 * @param{redirect} redirect
 * @param{runtime} runtime
 * @param{search} search
 */
    (query, record, redirect, runtime, search, commonApi, R, currency) => {
        /**
         * Defines the Suitelet script trigger point.
         * @param {Object} scriptContext
         * @param {ServerRequest} scriptContext.request - Incoming request
         * @param {ServerResponse} scriptContext.response - Suitelet response
         * @since 2015.2
         */
        const onRequest = (scriptContext) => {
            let request = scriptContext.request;
            let params = request.parameters;
            let spType = params.sptype, spId = params.spid;

            if ('GET' == request.method) {
                try {
                    let currencyRate = {};// 币种转换汇率
                    let itemInfos = getAllItem();// 货品 unit capacity
                    let {/*icpos, */spLines/*, spLineIds*/, isWarehouseStock} = searchSPLines(spId);
                    // let poItemRates = searchICPO(icpos, spLineIds);
                    spLines = formatData(spLines, currencyRate);
                    log.debug('currencyRate', currencyRate);
                    log.debug('new spLines', spLines);
                    // 根据SO汇总
                    let groupBySoData = R.groupBy(R.path(['soId']))(spLines);
                    log.debug('groupBySoData', groupBySoData);
                    let updateFlag = {};
                    updateFlag.status = 0;// 0-成功，1-失败
                    updateFlag.errorMsg = '';
                    for (let soId in groupBySoData) {
                        updateFlag = updateICPrice(soId, groupBySoData[soId], isWarehouseStock, updateFlag, spId, itemInfos);
                    }
                    if (0 == updateFlag.status) {
                        record.submitFields({
                            type: spType,
                            id: spId,
                            values: {
                                custrecord_sp_isupdated_icposoprice: true
                            },
                            options: {
                                enablesourcing: true,
                                ignoreMandatoryFields: true
                            }
                        });
                    }
                } catch (e) {
                    log.error('update price error', e);
                }
                redirect.toRecord({type: spType, id: spId});
            }
        }

        /**
         * 更新公司间价格
         * @param soId
         * @param lines
         * @param isWarehouseStock
         * @param updateFlag
         * @param spId
         * @param itemInfos
         * @return {*}
         */
        const updateICPrice = (soId, lines, isWarehouseStock, updateFlag, spId, itemInfos) => {
            let newPrice = {};// 新单价
            let interCPO = '';
            let rateInfo = {};
            try {
                let soObj = record.load({type: 'salesorder', id: soId});
                interCPO = soObj.getValue({fieldId: 'custbody_ecm_icposo_transaction'}) || '';
                if (!interCPO) {
                    updateFlag.status = 1;
                    updateFlag.errorMsg += `soid(${soId})未找到ICPO;`;
                }
                if (0 == updateFlag.status) {
                    let supplier = soObj.getValue({fieldId: 'subsidiary'});
                    let icPOFields = search.lookupFields({
                        type: 'purchaseorder',
                        id: interCPO,
                        columns: ['subsidiary']
                    });
                    let demander = icPOFields['subsidiary'][0].value;
                    rateInfo = searchInterCompanyRate(supplier, demander, isWarehouseStock);
                    if (Object.keys(rateInfo).length > 0) {
                        let ratio = toPoint(rateInfo.ratio);
                        // 更新货品单价
                        let lineCount = soObj.getLineCount({sublistId: 'item'});
                        for (let i = 0; i < lineCount; i++) {
                            let itemId = soObj.getSublistValue({sublistId: 'item', fieldId: 'item', line: i});
                            let uniqueKey = soObj.getSublistValue({sublistId: 'item', fieldId: 'custcol_ecm_uniquekey', line: i});
                            for (let j = 0; j < lines.length; j++) {
                                if (uniqueKey == lines[j].soLineNo) {
                                    let newRate = lines[j].rate;
                                    if ('T' == isWarehouseStock || true == isWarehouseStock) {
                                        newRate = Number(newRate).mul(1 + Number(ratio));
                                    }
                                    else {
                                        let cost = Number(lines[j].tariffCost).add(Number(lines[j].clearanceCost)).add(Number(lines[j].seaFreight)).add(Number(lines[j].personCost));
                                        cost = Number(itemInfos[itemId]) === 0 ? 0 : Number(cost).div(Number(itemInfos[itemId]));
                                        newRate = Number(newRate).add(Number(cost));
                                        newRate = Number(newRate).mul(1 + Number(ratio));
                                    }
                                    soObj.setSublistValue({sublistId: 'item', fieldId: 'rate', value: newRate, line: i});
                                    newPrice[uniqueKey] = {
                                        rate: newRate,
                                        spLineId: lines[j].spLineId
                                    };
                                    break;
                                }
                            }
                        }
                        soObj.setValue({fieldId: 'custbody_ecm_intercompany', value: rateInfo.id});
                        soObj.setValue({fieldId: 'custbody_ecm_sp', value: spId});
                        soObj.setValue({fieldId: 'custbody_echemi_unitpriceicpo', value: true});
                        soObj.save({enableSourcing: true, ignoreMandatoryFields: true});
                    }
                    else {
                        updateFlag.status = 1;
                        updateFlag.errorMsg += `soid(${soId})未匹配到公司间加价比例;`;
                    }
                }
            } catch (e) {
                log.error('update so price error', e);
                updateFlag.status = 1;
                updateFlag.errorMsg += `soid(${soId})${e.message}`;
            }
            // 更新ICPO
            if (0 == updateFlag.status) {
                log.debug(`${soId} newPrice`, newPrice);
                try {
                    updateICPO(interCPO, newPrice, rateInfo.id, spId);
                } catch (e) {
                    log.error('update icpo price error');
                    updateFlag.status = 1;
                    updateFlag.errorMsg += `soid(${soId})=>icpo(${interCPO})${e.message}`;
                }
            }
            // 更新IR
            // if (0 == updateFlag.status) {
            //     let irIds = searchIR(interCPO);
            //     irIds.forEach(irId => {
            //         updateIR(irId, newPrice, updateFlag);
            //     });
            // }

            return updateFlag;
        }

        /**
         * 更新IR
         * @param irId
         * @param newPrice
         * @param updateFlag
         */
        const updateIR = (irId, newPrice, updateFlag) => {
            try {
                let irObj = record.load({type: 'itemreceipt', id: irId});
                let lineCount = irObj.getLineCount({sublistId: 'item'});
                for (let i = 0; i < lineCount; i++) {
                    let lineNo = irObj.getSublistValue({sublistId: 'item', fieldId: 'custcol_ecm_uniquekey', line: i});
                    if (newPrice[lineNo]) {
                        irObj.setSublistValue({sublistId: 'item', fieldId: 'rate', value: newPrice[lineNo].rate, line: i});
                    }
                }
                irObj.save({enableSourcing: true, ignoreMandatoryFields: true});
            } catch (e) {
                log.error('update ir price error', e);
                updateFlag.status = 1;
                updateFlag.errorMsg += `irid(${irId})${e.message}`;
            }
        }

        /**
         * 搜索关联的IR
         * @param poId
         * @return {[]}
         */
        const searchIR = poId => {
            let irIds = [];
            let irSearchObj = search.create({
                type: 'itemreceipt',
                filters: [
                    ['mainline', 'is', 'T'],
                    'and',
                    ['taxline', 'is', 'F'],
                    'and',
                    ['createdfrom', 'anyof', poId]
                ],
                columns: [
                    search.createColumn({name: 'internalid'})
                ]
            });
            let results = irSearchObj.run().getRange({start: 0, end: 1000});
            results.forEach(res => {
                irIds.push(res.id);
            });
            log.debug('irIds', irIds);
            return irIds;
        }

        /**
         * 更新ICPO
         * @param poId
         * @param newPrice
         * @param rateInfoId
         * @param spId
         */
        const updateICPO = (poId, newPrice, rateInfoId, spId) => {
            let poObj = record.load({type: 'purchaseorder', id: poId});
            let lineCount = poObj.getLineCount({sublistId: 'item'});
            for (let i = 0; i < lineCount; i++) {
                let lineNo = poObj.getSublistValue({sublistId: 'item', fieldId: 'custcol_ecm_uniquekey', line: i});
                if (newPrice[lineNo]) {
                    poObj.setSublistValue({sublistId: 'item', fieldId: 'rate', value: newPrice[lineNo].rate, line: i});
                    poObj.setSublistValue({sublistId: 'item', fieldId: 'custcol_ecm_spline', value: newPrice[lineNo].spLineId, line: i});
                }
            }
            poObj.setValue({fieldId: 'custbody_ecm_intercompany', value: rateInfoId});
            poObj.setValue({fieldId: 'custbody_ecm_sp', value: spId});
            poObj.setValue({fieldId: 'custbody_echemi_unitpriceicpo', value: true});
            poObj.save({enableSourcing: true, ignoreMandatoryFields: true});
        }

        /**
         * 搜索公司间加价比例
         * @param supplier
         * @param demander
         * @param isWarehouseStock
         * @return {{}}
         */
        const searchInterCompanyRate = (supplier, demander, isWarehouseStock) => {
            let rateInfo = {};
            let filters = [];
            filters.push(['isinactive', 'is', 'F']);
            filters.push('and');
            filters.push(['custrecord_ecm_interco_supplier', 'anyof', supplier]);
            filters.push('and');
            filters.push(['custrecord_ecm_interco_demand', 'anyof', demander]);
            if ('T' == isWarehouseStock || true == isWarehouseStock) {
                filters.push('and');
                filters.push(['custrecord_ecm_stock', 'is', 'T']);
            }
            else {
                filters.push('and');
                filters.push(['custrecord_ecm_stock', 'is', 'F']);
            }
            let icSearchObj = search.create({
                type: 'customrecord_ecm_intercompany',
                filters: filters,
                columns: [
                    search.createColumn({name: 'custrecord_ecm_interco_ratio'})
                ]
            });
            let columns = icSearchObj.columns;
            let results = icSearchObj.run().getRange({start: 0, end: 1});
            if (results && results.length > 0) {
                rateInfo.id = results[0].id;
                rateInfo.ratio = results[0].getValue(columns[0]) || '0.0%';
            }
            log.debug('rateInfo', rateInfo);
            return rateInfo;
        }

        /**
         * 将ICPO单价填入spLines
         * @param spLines
         * @param currencyRate
         * @return {*}
         */
        const formatData = (spLines, currencyRate) => {
            spLines.forEach(line => {
                let fromCurrency = line.scdCurrency;
                let toCurrency = line.spCurrency;
                let rate = line.rate;
                let exchangeRate = 1;// 转换汇率
                if (fromCurrency != toCurrency) {
                    let rateKey = `${fromCurrency}&${toCurrency}`;
                    if (!currencyRate[rateKey]) {
                        exchangeRate = currency.exchangeRate({
                            source: fromCurrency,
                            target: toCurrency
                        });
                        currencyRate[rateKey] = exchangeRate;
                    }
                    else {
                        exchangeRate = currencyRate[rateKey];
                    }
                }
                line.rate = Number(rate).mul(Number(exchangeRate));
            });
            return spLines;
        }

        /**
         * 搜索ICPO货品单价
         * @param icPos
         * @param spLineIds
         * @return {{}}
         */
        const searchICPO = (icPos, spLineIds) => {
            let poItemRates = {};
            let poSearchObj = search.create({
                type: 'purchaseorder',
                filters: [
                    ['mainline', 'is', 'F'],
                    'and',
                    ['taxline', 'is', 'F'],
                    'and',
                    ['internalid', 'anyof', icPos],
                    'and',
                    ['custcol_ecm_spline', 'anyof', spLineIds]
                ],
                columns: [
                    search.createColumn({name: 'custcol_ecm_spline', label: 'SP Line'}),
                    search.createColumn({name: 'custcol_ecm_uniquekey', label: 'Ecm行唯一键'}),
                    search.createColumn({name: 'fxrate', label: 'Item Rate'}),
                    search.createColumn({name: 'currency'})
                ]
            });
            let columns = poSearchObj.columns;
            let results = poSearchObj.run().getRange({start: 0, end: 1000});
            results.forEach(res => {
                let spLineId = res.getValue(columns[0]),
                    lineUniqueKey = res.getValue(columns[1]),
                    rate = res.getValue(columns[2]),
                    currency = res.getValue(columns[3]);
                poItemRates[lineUniqueKey] = {
                    rate: rate,
                    currency: currency,
                    spLineId: spLineId
                };
            });
            log.debug('poItemRates', poItemRates);
            return poItemRates;
        }

        /**
         * 搜索需要更新价格的明细
         * @param spId
         * @return {{isWarehouseStock: string, spLines: []}}
         */
        const searchSPLines = (spId) => {
            let spLines = [];
            let isWarehouseStock = '';
            let spSearchObj = search.create({
                type: 'customrecord_ecm_scd_line',
                filters: [
                    ['custrecord_scdline_sp', 'anyof', spId],
                    'and',
                    ['custrecord_ecm_scdline_scd.custrecord_scd_sc', 'noneof', '@NONE@'],
                    'and',
                    ['custrecord_scdline_supplier', 'noneof', '@NONE@'],
                    'and',
                    ['custrecord_scdline_demander', 'noneof', '@NONE@'],
                    'and',
                    ['custrecord_scdline_finaldemander', 'noneof', '@NONE@'],
                    // 'and',
                    // ['custrecord_scdline_icpo', 'noneof', '@NONE@'],
                    // 'and',
                    // ['custrecord_scdline_purchaseorder', 'noneof', '@NONE@'],
                    // 'and',
                    // ['custrecord_scdline_icpo.mainline', 'is', 'T'],
                    // 'and',
                    // ['custrecord_scdline_icpo.taxline', 'is', 'F']
                ],
                columns: [
                    search.createColumn({name: 'internalid', sort: 'ASC'}),
                    search.createColumn({name: 'custrecord_scd_sc', join: 'custrecord_ecm_scdline_scd'}),// SO
                    search.createColumn({name: 'custrecord_scdline_uniquekey'}),// SO行唯一键
                    search.createColumn({name: 'custrecord_sp_warehousestock', join: 'custrecord_scdline_sp'}),// 是否备货
                    // search.createColumn({name: 'currency', join: 'custrecord_scdline_icpo'}),// ICPO-currency
                    search.createColumn({name: 'custrecord_scdline_tariffcost'}),
                    search.createColumn({name: 'custrecord_scdline_clearancecost'}),
                    search.createColumn({name: 'custrecord_scdline_seafreightcost'}),
                    search.createColumn({name: 'custrecord_scdline_perscost'}),
                    // search.createColumn({name: 'custrecord_scdline_purchaseorder'}),
                    search.createColumn({name: 'custrecord_scdline_purchaseamt'}),// 源单价
                    search.createColumn({name: 'custrecord_scd_purccurrency', join: 'custrecord_ecm_scdline_scd'}),
                    search.createColumn({name: 'custrecord_sp_sccurrency', join: 'custrecord_scdline_sp'})
                ]
            });
            let columns = spSearchObj.columns;
            let results = spSearchObj.run().getRange({start: 0, end: 1000});
            results.forEach((res, i) => {
                let spLineId = res.id;
                let soId = res.getValue(columns[1]);
                let soLineNo = res.getValue(columns[2]);
                let warehouseStock = res.getValue(columns[3]);
                let tariffCost = res.getValue(columns[4]);
                let clearanceCost = res.getValue(columns[5]);
                let seaFreight = res.getValue(columns[6]);
                let personCost = res.getValue(columns[7]);
                let oriRate = res.getValue(columns[8]);
                let scdCurrency = res.getValue(columns[9]);
                let spCurrency = res.getValue(columns[10])
                if (i == 0) {
                    isWarehouseStock = warehouseStock;
                }
                let json = {
                    spLineId: spLineId,
                    soId: soId,
                    soLineNo: soLineNo,
                    // isWarehouseStock: isWarehouseStock,
                    // poId: poId,
                    tariffCost: tariffCost,
                    clearanceCost: clearanceCost,
                    seaFreight: seaFreight,
                    personCost: personCost,
                    // icPoCurrency: icPoCurrency
                    rate: oriRate,
                    scdCurrency: scdCurrency,
                    spCurrency: spCurrency
                };
                spLines.push(json);
                // if (poId && icpos.indexOf(poId) === -1) {
                //     icpos.push(poId);
                // }
                // spLineIds.push(spLineId);
            });
            // log.debug('icpos', icpos);
            log.debug('spLines', spLines);
            // log.debug('spLineIds', spLineIds);
            log.debug('isWarehouseStock', isWarehouseStock);
            return {/*icpos, */spLines/*, spLineIds*/, isWarehouseStock};
        }

        /**
         * 搜索货品的unit capacity
         * @return {{}}
         */
        const getAllItem = () => {
            let itemInfos = {};
            let itemSearchObj = search.create({
                type: 'item',
                filters: [
                    ['isinactive', 'is', 'F']
                ],
                columns: [
                    search.createColumn({name: 'custitem_ecm_case_package_kg'})
                ]
            });
            let columns = itemSearchObj.columns;
            let results = commonApi.getAllData(itemSearchObj);
            results.forEach(res => {
                itemInfos[res.id] = res.getValue(columns[0]) || 0;
            });
            return itemInfos;
        }

        // 百分比转小数
        const toPoint = (percent) => {
            let strVal = percent.replace("%", "");
            let numberVal = Number(strVal).div(Number(100));
            return numberVal;
        }

        return {onRequest}

    });
