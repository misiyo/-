/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 * version      date            author              remark
 * 1.0          2023/04/12      Gino Lu             CSV转XML
 */
define(['N/encode', 'N/file', 'N/ui/serverWidget', 'N/url', 'N/xml', '/SuiteScripts/tools/common_api.js'],
    /**
     * @param{encode} encode
     * @param{file} file
     * @param{serverWidget} serverWidget
     * @param{url} url
     * @param{xml} xml
     * @param commonApi
     */
    (encode, file, serverWidget, url, xml, commonApi) => {
        /**
         * Defines the Suitelet script trigger point.
         * @param {Object} scriptContext
         * @param {ServerRequest} scriptContext.request - Incoming request
         * @param {ServerResponse} scriptContext.response - Suitelet response
         * @since 2015.2
         */
        const onRequest = (scriptContext) => {
            let request = scriptContext.request;
            let response = scriptContext.response;
            let params = request.parameters;
            // log.debug('params', params);

            if ('GET' == request.method) {
                let form = createForm(params);
                response.writePage(form);
            }
        }

        // 创建页面
        function createForm(params) {
            let form = serverWidget.createForm({title: 'CSV TO XML', hideNavBar: true});
            let csv = file.load({
                id: 'SuiteScripts/SuiteScripts_GL/customrecord_ecm_custom_basic_info.csv'
            });
            let csvArr = commonApi.cSVToArray(csv.getContents(), ',');
            let csvJson = {};
            for(let i = 1;i < csvArr.length;i++){
                if(typeof csvJson[csvArr[i][0]] != 'object' && csvArr[i][0]){
                    csvJson[csvArr[i][0]] = [];
                }
                let json = {};
                json.scriptId = csvArr[i][1];
                json.label = csvArr[i][2];
                json.translation = csvArr[i][3];
                if(JSON.stringify(json) != '{}'){
                    csvJson[csvArr[i][0]].push(json);
                }
            }
            log.debug('csvJson', csvJson);

            let xmlFile = xml.Parser.fromString(file.load('SuiteScripts/SuiteScripts_GL/custcollection_ecm_custom_basic_info.xml').getContents());

            let root = xmlFile.documentElement;
            root.setAttribute({ name : 'scriptid', value : 'custcollection_'+csvArr[1][0]});
            log.debug('root', root.attributes);

            return form;
        }

        return {onRequest}

    });
