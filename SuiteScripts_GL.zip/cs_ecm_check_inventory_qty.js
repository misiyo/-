/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 * version      date            author              remark
 * 1.0          2023/03/06      Gino Lu             校验库存可用量【ID1018531】
 * 2.0          2023/03/07      Gino Lu             完善逻辑
 * 3.0          2023/03/13      Gino Lu             逻辑变更
 * 4.0          2023/03/15      Gino Lu             逻辑变更
 * 5.0          2023/03/16      Gino Lu             逻辑变更
 * 6.0          2023/03/16      Gino Lu             完善逻辑
 * 7.0          2023/03/21      Gino Lu             变更逻辑
 * 8.0          2023/03/24      Gino Lu             变更逻辑
 * 9.0          2023/04/04      Gino Lu             日期格式设置
 */
define(['N/currentRecord', 'N/record', 'N/runtime', 'N/search', 'SuiteScripts/tools/common_api.js'],
    /**
     * @param{currentRecord} currentRecord
     * @param record
     * @param runtime
     * @param search
     * @param commonApi
     */
    function (currentRecord, record, runtime, search, commonApi) {

        /**
         * Function to be executed after page is initialized.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.mode - The mode in which the record is being accessed (create, copy, or edit)
         *
         * @since 2015.2
         */
        function pageInit(scriptContext) {

        }

        /**
         * Function to be executed when field is changed.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.sublistId - Sublist name
         * @param {string} scriptContext.fieldId - Field name
         * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
         * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
         *
         * @since 2015.2
         */
        function fieldChanged(scriptContext) {
            var curRec = scriptContext.currentRecord;
            var curIndex = curRec.getCurrentSublistIndex({sublistId: 'inventory_list'});
            if(scriptContext.fieldId == 'custpage_inventory_number'){
                var scdItemId = curRec.getValue('custpage_inventory_itemid');
                var location = curRec.getValue('custpage_inventory_location');
                var inventoryNumber = curRec.getCurrentSublistValue({sublistId: 'inventory_list', fieldId: 'custpage_inventory_number'});
                for(var i = 0; i < curRec.getLineCount('inventory_list'); i++){
                    if(curRec.getSublistValue({sublistId: 'inventory_list', fieldId: 'custpage_inventory_number', line: i}) == inventoryNumber){
                        alert('You have added this batch of item!');
                        curRec.cancelLine({sublistId: 'inventory_list'});
                        return ;
                    }
                }

                var inventoryQty = 0,
                    averageCost = 0,
                    productDate = '',
                    unit = '';
                if(inventoryNumber != '' && inventoryNumber){
                    var inventoryInfo = getInventoryInfo(inventoryNumber, location);
                    inventoryQty = inventoryInfo.inventoryQty;
                    productDate = inventoryInfo.productDate || '';
                    unit = inventoryInfo.unit || '';
                    averageCost = inventoryInfo.averageCost;
                    try {
                        var mySearchObj = search.create({
                            type: 'customrecord_ecm_scd_line',
                            filters: [
                                ['custrecord_id_spline.custrecord_id_item','anyof',scdItemId],
                                'AND',
                                ['custrecord_id_spline.custrecord_id_seriallot','anyof',inventoryNumber],
                                'AND',
                                ['custrecord_id_spline.custrecord_id_location','anyof',location],
                                'AND',
                                ['custrecord_scdline_sp.custrecord_sp_status','anyof','1','6','7'] //未出运,订舱成功,预估费用已提交
                            ],
                            columns:[
                                search.createColumn({name: 'custrecord_id_quantity', join: 'CUSTRECORD_ID_SPLINE', summary: 'SUM', sort: search.Sort.ASC, label: 'Quantity'})
                            ]
                        });
                        var res = commonApi.getAllData(mySearchObj);
                        var columns = mySearchObj.columns;
                        if(res && res.length > 0){
                            inventoryQty = Number(inventoryQty).sub(Number(res[0].getValue(columns[0])));
                        }
                    }catch (e){
                        console.log('searchECMInventoryDetail Error===>'+e);
                    }
                }

                curRec.selectLine({sublistId: 'inventory_list', line: curIndex});
                curRec.setCurrentSublistValue({sublistId: 'inventory_list', fieldId: 'custpage_max_qty', value: inventoryQty});
                curRec.setCurrentSublistValue({sublistId: 'inventory_list', fieldId: 'custpage_inventory_cost', value: averageCost});
                curRec.setCurrentSublistValue({sublistId: 'inventory_list', fieldId: 'custpage_inventory_unit', value: unit});
                curRec.setCurrentSublistValue({sublistId: 'inventory_list', fieldId: 'custpage_inventory_date_production', value: productDate});
                curRec.setCurrentSublistValue({sublistId: 'inventory_list', fieldId: 'custpage_inventory_qty', value: inventoryQty, ignoreFieldChange: true});
            }
            else if(scriptContext.fieldId == 'custpage_inventory_qty'){
                var maxQty = curRec.getCurrentSublistValue({sublistId: 'inventory_list', fieldId: 'custpage_max_qty'});
                var curQty = curRec.getCurrentSublistValue({sublistId: 'inventory_list', fieldId: 'custpage_inventory_qty'});

                if(Number(curQty) > Number(maxQty)){
                    alert('The max quantity is '+maxQty);
                    curRec.selectLine({sublistId: 'inventory_list', line: curIndex});
                    curRec.setCurrentSublistValue({sublistId: 'inventory_list', fieldId: 'custpage_inventory_qty', value: maxQty, ignoreFieldChange: true});
                }
                else if (Number(curQty) <= 0){
                    alert('The min quantity is greater than 0');
                    curRec.selectLine({sublistId: 'inventory_list', line: curIndex});
                    curRec.setCurrentSublistValue({sublistId: 'inventory_list', fieldId: 'custpage_inventory_qty', value: maxQty, ignoreFieldChange: true});
                }
            }
        }

        //获取系统标准批次相关信息
        function getInventoryInfo(inventoryNumber, location) {
            var json = {};
            var mySearchObj = search.create({
                type: 'inventorynumber',
                filters: [
                    ['location', 'anyof', location],
                    'AND',
                    ['internalid', 'anyof', inventoryNumber],
                    'AND',
                    ['formulanumeric: case when {item.inventorylocation.id}={location.id} then 1 else 0 end','equalto','1'],
                ],
                columns: ['quantityonhand', 'expirationdate', 'item.custitem_ecm_protectqualityperiod_days', 'item.saleunit', 'item.locationaveragecost']
            });
            var res = commonApi.getAllData(mySearchObj);
            var columns = mySearchObj.columns;
            console.log('inventoryRes===>'+JSON.stringify(res));
            if(res && res.length > 0){
                json.inventoryQty = res[0].getValue(columns[0]);
                var expirationDate = res[0].getValue(columns[1]);
                var period = res[0].getValue(columns[2]);
                json.productDate = setDateBySubDay(expirationDate, period);
                json.unit = res[0].getValue(columns[3]);
                json.averageCost = res[0].getValue(columns[4]);
            }
            return json;
        }

        //获取系统标准货品成本
        // function getInventoryRate(inventoryNumber, itemId, location) {
        //     var inventoryRate = 0;
        //     var mySearchObj = search.create({
        //         type: 'transaction',
        //         filters: [
        //             ['posting','is','T'],
        //             'AND',
        //             ['mainline','is','F'],
        //             'AND',
        //             ['taxline','is','F'],
        //             'AND',
        //             ['quantity','isnotempty',''],
        //             'AND',
        //             ['formulanumeric: case when {quantity}>0 then 1 else 0 end','equalto','1'],
        //             'AND',
        //             ['formulanumeric: case when {item.inventorylocation.id}={location.id} then 1 else 0 end','equalto','1'],
        //             'AND',
        //             ['formulanumeric: case when {item.assetaccount.id}={account.id} then 1 else 0 end','equalto','1'],
        //             'AND',
        //             ['inventorydetail.inventorynumber','anyof', inventoryNumber],
        //             'AND',
        //             ['inventorydetail.item','anyof', itemId],
        //             'AND',
        //             ['inventorydetail.location','anyof', location]
        //         ],
        //         columns: [
        //             search.createColumn({name: 'quantity', label: 'Quantity'}),
        //             search.createColumn({name: 'fxamount', label: 'Amount'})
        //         ]
        //     });
        //     var res = commonApi.getAllData(mySearchObj);
        //     console.log('transactionRes===>'+JSON.stringify(res));
        //     var columns = mySearchObj.columns;
        //     if(res && res.length > 0){
        //         inventoryRate = Number(res[0].getValue(columns[1])).div(Number(res[0].getValue(columns[0])));
        //     }
        //
        //     return inventoryRate;
        // }

        //在给定日期的基础上减少天
        function setDateBySubDay(dateOri, num){
            if(dateOri == '' || num == ''){
                return ;
            }
            var date = new Date(dateOri);
            date = date.setDate(Number(date.getDate()).sub(Number(num)));
            date = new Date(date);
            var newDate = date.getFullYear() + '/' + Number(date.getMonth()).add(1) + '/' + date.getDate();

            return date;
        }

        function doSubmit() {
            var obj = currentRecord.get();
            var scdQty = obj.getValue('custpage_inventory_scdqty');
            var scdLineId = obj.getValue('custpage_inventory_lineid');
            var length = obj.getLineCount('inventory_list');
            var totalQty = 0, totalAmt = 0;
            var ecmInventoryDetailArr = [];
            for (var i = 0; i < length; i++) {
                totalQty = Number(totalQty).add(Number(obj.getSublistValue('inventory_list', 'custpage_inventory_qty', i)));
                totalAmt = Number(totalAmt).add(Number(obj.getSublistValue('inventory_list', 'custpage_inventory_qty', i)).mul(Number(obj.getSublistValue('inventory_list', 'custpage_inventory_cost', i))));
                var json = {};
                json.inventory_number = obj.getSublistValue('inventory_list', 'custpage_inventory_number', i);
                json.inventory_qty = obj.getSublistValue('inventory_list', 'custpage_inventory_qty', i);
                json.pallet_number = obj.getSublistValue('inventory_list', 'custpage_inventory_pallet_number', i);
                json.per_pallet = obj.getSublistValue('inventory_list', 'custpage_inventory_per_pallet', i);
                json.pallet_size = obj.getSublistValue('inventory_list', 'custpage_inventory_pallet_size', i);
                json.package_number = obj.getSublistValue('inventory_list', 'custpage_inventory_package_number', i);
                json.gross_weight = obj.getSublistValue('inventory_list', 'custpage_inventory_gross_weight', i);
                json.net_weight = obj.getSublistValue('inventory_list', 'custpage_inventory_net_weight', i);
                json.volume = obj.getSublistValue('inventory_list', 'custpage_inventory_volume', i);
                json.date_production = obj.getSublistText('inventory_list', 'custpage_inventory_date_production', i);
                ecmInventoryDetailArr.push(json);
            }
            var cost = Number(Number(totalAmt).div(Number(totalQty))).toFixedNew(2);
            if (length < 1) {
                alert('Please input one line at least!');
                return;
            }
            if(scdQty != totalQty){
                alert('Input Quantity is not equal to SCD Quantity!');
                return;
            }
            setWindowChanged(window, false);
            window.opener.writeBackInventoryDetail(scdLineId, totalQty, ecmInventoryDetailArr, cost);
            window.close();
        }

        function doCancel() {
            setWindowChanged(window, false);
            window.close();
        }

        return {
            pageInit: pageInit,
            fieldChanged: fieldChanged,
            doCancel: doCancel,
            doSubmit: doSubmit
        };


    });
