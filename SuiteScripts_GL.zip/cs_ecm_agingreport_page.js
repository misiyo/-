/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 * version      date            author              remark
 * 1.0          2023/03/29      Gino Lu             库龄表【ID1019425】
 * 2.0          2023/04/12      Gino Lu             增加报表字段
 */
define(['N/currentRecord', 'N/record', 'N/runtime', 'N/search',  '/SuiteScripts/tools/common_api.js'],
/**
 * @param{currentRecord} currentRecord
 * @param{record} record
 * @param{runtime} runtime
 * @param{search} search
 */
function(currentRecord, record, runtime, search, commonApi) {
    
    /**
     * Function to be executed after page is initialized.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.mode - The mode in which the record is being accessed (create, copy, or edit)
     *
     * @since 2015.2
     */
    function pageInit(scriptContext) {

    }

    /**
     * Function to be executed when field is changed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
     * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
     *
     * @since 2015.2
     */
    function fieldChanged(scriptContext) {
        var curRec = scriptContext.currentRecord;
        if(scriptContext.fieldId == 'custpage_subsidiary'){
            var subsidiary = curRec.getValue('custpage_subsidiary');
            if(subsidiary){
                var lcArr = getAllLocation(subsidiary);
                var location = curRec.getField('custpage_location');
                location.removeSelectOption({value: null});
                location.insertSelectOption({value: '', text: ''});
                for(var i = 0; i < lcArr.length; i++){
                    location.insertSelectOption({value: lcArr[i].value, text: lcArr[i].text});
                }
            }
        }
    }

    // 获取所有与subsidiary相关的getAllLocation
    function getAllLocation(subsidiary) {
        var lcArr = [];
        var mySearchObj = search.create({
            type: 'location',
            filters: [
                ['subsidiary', 'anyof', subsidiary]
            ],
            columns: [
                search.createColumn({name: 'name', sort: search.Sort.ASC, label: 'Name'}),
            ]
        });
        var columns = mySearchObj.columns;
        var res = commonApi.getAllData(mySearchObj);
        if(res && res.length > 0){
            for(var i = 0;i < res.length;i++){
                var json = {};
                json.value = res[i].id;
                json.text = res[i].getValue(columns[0]);
                lcArr.push(json);
            }
        }
        console.log('lcArr===>'+JSON.stringify(lcArr));
        return lcArr;
    }

    /**
     * Function to be executed when field is slaved.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     *
     * @since 2015.2
     */
    function postSourcing(scriptContext) {

    }

    /**
     * Function to be executed after sublist is inserted, removed, or edited.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @since 2015.2
     */
    function sublistChanged(scriptContext) {

    }

    /**
     * Function to be executed after line is selected.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @since 2015.2
     */
    function lineInit(scriptContext) {

    }

    /**
     * Validation function to be executed when field is changed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
     * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
     *
     * @returns {boolean} Return true if field is valid
     *
     * @since 2015.2
     */
    function validateField(scriptContext) {

    }

    /**
     * Validation function to be executed when sublist line is committed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateLine(scriptContext) {

    }

    /**
     * Validation function to be executed when sublist line is inserted.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateInsert(scriptContext) {

    }

    /**
     * Validation function to be executed when record is deleted.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateDelete(scriptContext) {

    }

    /**
     * Validation function to be executed when record is saved.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @returns {boolean} Return true if record is valid
     *
     * @since 2015.2
     */
    function saveRecord(scriptContext) {
    }

    function searchData() {
        var curRec = currentRecord.get();
        var subsidiary = curRec.getValue('custpage_subsidiary');
        var location = curRec.getValue('custpage_location');
        var date = curRec.getText('custpage_date');

        var url = window.location.href;
        var urlArr = url.split('&');
        var newUrl = '';

        if (subsidiary){
            newUrl += '&subsidiary=' + subsidiary;
        }
        if (location){
            newUrl += '&location=' + location;
        }
        if (date) {
            newUrl += '&date=' + encodeURIComponent(date);
        }
        setWindowChanged(window, false);
        window.location.href = urlArr[0] + "&" + urlArr[1] + newUrl;
    }

    return {
        // pageInit: pageInit,
        fieldChanged: fieldChanged,
        // postSourcing: postSourcing,
        // sublistChanged: sublistChanged,
        // lineInit: lineInit,
        // validateField: validateField,
        // validateLine: validateLine,
        // validateInsert: validateInsert,
        // validateDelete: validateDelete,
        // saveRecord: saveRecord,
        searchData: searchData
    };
    
});
