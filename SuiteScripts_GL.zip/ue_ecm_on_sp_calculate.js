/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * version      date            author              remark
 * 1.0          2023/03/07      Gino Lu             下推生成Shipping Plan页面后计算逻辑【ID1018531】
 * 2.0          2023/03/08      Gino Lu             Shipping Plan页面字段控制【ID1018539】
 * 3.0          2023/03/21      Gino Lu             添加计算字段
 * 4.0          2023/03/23      Gino Lu             变更取值字段逻辑
 * 5.0          2023/04/17      Gino Lu             SP离港后邮件通知【ID1019768】
 * 6.0          2023/04/17      Gino Lu             SP订舱后邮件通知【ID1019766】
 */
define(['N/email', 'N/record', 'N/runtime', 'N/search', 'N/url', '/SuiteScripts/tools/common_api.js'],
    /**
     * @param{email} email
     * @param{record} record
     * @param{runtime} runtime
     * @param{search} search
     * @param{url} url
     * @param commonApi
     */
    (email, record, runtime, search, url, commonApi) => {
        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {
            disableSublistTab(scriptContext);
        }

        //禁用明细行字段
        const disableSublistTab = (scriptContext) =>{
            let form = scriptContext.form;
            let newRec = scriptContext.newRecord;
            let applyStatus = newRec.getValue('custrecord_sp_applystatus');
            let user = runtime.getCurrentUser();

            if(user.role != 3) { //角色非管理员
                let disableField = form.addField({
                    type: 'inlinehtml',
                    label: 'user_role',
                    id: `custpage_disable_user_role`
                });
                disableField.defaultValue = `
                <style>
                    #tbl_newrecrecmachcustrecord_scdline_sp {display: none;}
                    #tbl_attach {display: none;}
                    #tbl_newrec840 {display: none;}
                    
                    #recmachcustrecord_scdline_sp__tab td:first-child {display: none;}
                    #recmachcustrecord_scdline_sp__tab td[data-label="Remove"] {display: none;}
                    #recmachcustrecord_scdline_sp__tab td:last-child {display: none;}
                    
                    tr[class="uir-machine-row uir-machine-row-odd listtextnonedit uir-machine-row-focused"] {display: none;}
                    tr[class="uir-machine-row uir-machine-row-even listtextnonedit uir-machine-row-focused"] {display: none;}
                    .uir-machine-button-row {display: none;}
                    
                    #recmachcustrecord_scdline_sp_splits td[data-ns-tooltip="ITEM"] {pointer-events: none; cursor: auto; opacity: 0.4;}
                    #recmachcustrecord_scdline_sp_splits td[data-ns-tooltip="QUANTITY"] {pointer-events: none; cursor: auto; opacity: 0.4;}
                    #recmachcustrecord_scdline_sp_splits td[data-ns-tooltip="UNIT"] {pointer-events: none; cursor: auto; opacity: 0.4;}
                    #recmachcustrecord_scdline_sp_splits td[data-ns-tooltip="SELLING PRICE"] {pointer-events: none; cursor: auto; opacity: 0.4;}
                    #recmachcustrecord_scdline_sp_splits td[data-ns-tooltip="TAX CODE"] {pointer-events: none; cursor: auto; opacity: 0.4;}
                    #recmachcustrecord_scdline_sp_splits td[data-ns-tooltip="TAX RATE"] {pointer-events: none; cursor: auto; opacity: 0.4;}
                    #recmachcustrecord_scdline_sp_splits td[data-ns-tooltip="TAX AMT"] {pointer-events: none; cursor: auto; opacity: 0.4;}
                    #recmachcustrecord_scdline_sp_splits td[data-ns-tooltip="GROSS AMT"] {pointer-events: none; cursor: auto; opacity: 0.4;}
                    #recmachcustrecord_scdline_sp_splits td[data-ns-tooltip="SS ITEM"] {pointer-events: none; cursor: auto; opacity: 0.4;}
                    #recmachcustrecord_scdline_sp_splits td[data-ns-tooltip="SS QUANTITY"] {pointer-events: none; cursor: auto; opacity: 0.4;}
                    #recmachcustrecord_scdline_sp_splits td[data-ns-tooltip="DISTRIBUTED QUANTITY"] {pointer-events: none; cursor: auto; opacity: 0.4;}
                    #recmachcustrecord_scdline_sp_splits td[data-ns-tooltip="PURCHASE CONTRACT LINEID"] {pointer-events: none; cursor: auto; opacity: 0.4;}
                    #recmachcustrecord_scdline_sp_splits td[data-ns-tooltip="SC LINEID"] {pointer-events: none; cursor: auto; opacity: 0.4;}
                    #recmachcustrecord_scdline_sp_splits td[data-ns-tooltip="SS LINE"] {pointer-events: none; cursor: auto; opacity: 0.4;}
                    #recmachcustrecord_scdline_sp_splits td[data-ns-tooltip="PURCHASE RATE"] {pointer-events: none; cursor: auto; opacity: 0.4;}
                    #recmachcustrecord_scdline_sp_splits td[data-ns-tooltip="PURCHASE TAX CODE"] {pointer-events: none; cursor: auto; opacity: 0.4;}
                    #recmachcustrecord_scdline_sp_splits td[data-ns-tooltip="PO LINEID"] {pointer-events: none; cursor: auto; opacity: 0.4;}
                    #recmachcustrecord_scdline_sp_splits td[data-ns-tooltip="PO QUANTITY"] {pointer-events: none; cursor: auto; opacity: 0.4;}
                    #recmachcustrecord_scdline_sp_splits td[data-ns-tooltip="ACTUAL SHIPMENT"] {pointer-events: none; cursor: auto; opacity: 0.4;}
                    #recmachcustrecord_scdline_sp_splits td[data-ns-tooltip="ACTUAL SHIPMENT QTY"] {pointer-events: none; cursor: auto; opacity: 0.4;}
                    #recmachcustrecord_scdline_sp_splits td[data-ns-tooltip="SO LINEID"] {pointer-events: none; cursor: auto; opacity: 0.4;}
                    #recmachcustrecord_scdline_sp_splits td[data-ns-tooltip="IT LINEID"] {pointer-events: none; cursor: auto; opacity: 0.4;}
                    #recmachcustrecord_scdline_sp_splits td[data-ns-tooltip="SUPPLIER"] {pointer-events: none; cursor: auto; opacity: 0.4;}
                    #recmachcustrecord_scdline_sp_splits td[data-ns-tooltip="DEMANDER"] {pointer-events: none; cursor: auto; opacity: 0.4;}
                    #recmachcustrecord_scdline_sp_splits td[data-ns-tooltip="ICSO"] {pointer-events: none; cursor: auto; opacity: 0.4;}
                    #recmachcustrecord_scdline_sp_splits td[data-ns-tooltip="ICSO LINE"] {pointer-events: none; cursor: auto; opacity: 0.4;}
                    #recmachcustrecord_scdline_sp_splits td[data-ns-tooltip="ICPO"] {pointer-events: none; cursor: auto; opacity: 0.4;}
                    #recmachcustrecord_scdline_sp_splits td[data-ns-tooltip="ICPO LINE"] {pointer-events: none; cursor: auto; opacity: 0.4;}
                    
                </style>
                <script>
                     jQuery().ready(function hideFieldFunc(){
                        console.log(jQuery('#tbl_newrecrecmachcustrecord_scdline_sp').parent().hide());
                        console.log(jQuery('#tbl_attach').parent().hide());
                        console.log(jQuery('#tbl_newrec840').parent().hide());
                    });
                </script>`;
            }
            if(applyStatus == 3){ //审批通过
                let disableField = form.addField({
                    type: 'inlinehtml',
                    label: 'apply_status',
                    id: `custpage_disable_apply_status`
                });
                disableField.defaultValue = `
                <style>
                    #recmachcustrecord_scdline_sp_splits td[data-ns-tooltip="LAND FREIGHT COST"] {pointer-events: none; cursor: auto; opacity: 0.4;}
                    #recmachcustrecord_scdline_sp_splits td[data-ns-tooltip="TARIFF COST"] {pointer-events: none; cursor: auto; opacity: 0.4;}
                    #recmachcustrecord_scdline_sp_splits td[data-ns-tooltip="SEA FREIGHT COST"] {pointer-events: none; cursor: auto; opacity: 0.4;}
                    #recmachcustrecord_scdline_sp_splits td[data-ns-tooltip="PERSONAL PREMIUM COST"] {pointer-events: none; cursor: auto; opacity: 0.4;}
                    #recmachcustrecord_scdline_sp_splits td[data-ns-tooltip="INSPECTION AND CERTIFICATION COST"] {pointer-events: none; cursor: auto; opacity: 0.4;}
                    #recmachcustrecord_scdline_sp_splits td[data-ns-tooltip="STORAGE COST"] {pointer-events: none; cursor: auto; opacity: 0.4;}
                    #recmachcustrecord_scdline_sp_splits td[data-ns-tooltip="CUSTOMS CLEARANCE COST"] {pointer-events: none; cursor: auto; opacity: 0.4;}
                  
                </style>
                <script>
                </script>`;
            }
        }

        /**
         * Defines the function definition that is executed before record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const beforeSubmit = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {
            if(scriptContext.type == 'delete'){
                return ;
            }
            calculateAllLine(scriptContext);
            sendEmailByStatus(scriptContext);
        }

        //计算明细行的值
        const calculateAllLine = (scriptContext) => {
            try{
                let spObj = record.load({
                    type: scriptContext.newRecord.type,
                    id: scriptContext.newRecord.id
                });
                let advanceRatio = commonApi.percentToNumber(String(spObj.getValue('custrecord_sp_preparent'))) || 0; //预付款比例
                let contactRatio = Number(1).sub(Number(advanceRatio)); //余款比例

                let grossAmt = 0,
                    grossNetWeight = 0,
                    grossWeight = 0;
                for(let i = 0; i < spObj.getLineCount('recmachcustrecord_scdline_sp'); i++){
                    let singleGrossAmt = spObj.getSublistValue({sublistId: 'recmachcustrecord_scdline_sp', fieldId: 'custrecord_scdline_grossamt', line: i}) || 0;
                    let singleGrossNetWeight = spObj.getSublistValue({sublistId: 'recmachcustrecord_scdline_sp', fieldId: 'custrecord_scdline_net_weight', line: i}) || 0;
                    let singleGrossWeight = spObj.getSublistValue({sublistId: 'recmachcustrecord_scdline_sp', fieldId: 'custrecord_scdline_gross_weight', line: i}) || 0;

                    grossAmt = Number(grossAmt).add(Number(singleGrossAmt));
                    grossNetWeight = Number(grossNetWeight).add(Number(singleGrossNetWeight));
                    grossWeight = Number(grossWeight).add(Number(singleGrossWeight));
                }
                let preAmt = Number(grossAmt).mul(Number(advanceRatio));
                let payAmt = Number(grossAmt).mul(Number(contactRatio));

                spObj.setValue({fieldId: 'custrecord_sp_deli_contract', value: Number(contactRatio).mul(100)});
                spObj.setValue({fieldId: 'custrecord_sp_preamount', value: preAmt});
                spObj.setValue({fieldId: 'custrecord_sp_payamount', value: payAmt});
                spObj.setValue({fieldId: 'custrecord_sp_shippingamount', value: grossAmt});
                spObj.setValue({fieldId: 'custrecord_sp_gross_net_weight', value: grossNetWeight});
                spObj.setValue({fieldId: 'custrecord_sp_gross_weight', value: grossWeight});

                spObj.save({enableSourcing: true, ignoreMandatoryFields: true});
            }catch (e){
                log.error('calculateAllLine Error', e);
            }

        }

        //根据的单据状态发送邮件
        const sendEmailByStatus = (scriptContext) => {
            let newRec = record.load({
                type: scriptContext.newRecord.type,
                id: scriptContext.newRecord.id
            });
            let status = newRec.getValue('custrecord_sp_status');
            let isSendSuccess = true;
            let sender = '';
            let receiverArr = [];
            if(status == 6){ //status == booking successful
                let hasSentEmail = newRec.getValue('custrecord_sp_email_booking')
                if(hasSentEmail){ //如果已经发送过邮件
                    return ;
                }
                sender = newRec.getValue('custrecord_sp_logistician2');

                receiverArr.push(newRec.getValue('custrecord_sp_cusservice'));
                receiverArr.push(newRec.getValue('custrecord_sp_supplyplanner'));
                receiverArr.push(newRec.getValue('custrecord_sp_docofficer2'));

                let emailJson = getUserEmail(receiverArr);

                let receiverEmailArr = [];
                for(let i = 0;i < receiverArr.length;i++){
                    if(receiverEmailArr.indexOf(emailJson[receiverArr[i]]) == -1 && emailJson[receiverArr[i]]){
                        receiverEmailArr.push(emailJson[receiverArr[i]]);
                    }
                }
                let bookingAdd = newRec.getValue('custrecord_sp_bookingadd').split(';');
                for(let i = 0;i < bookingAdd.length;i++){
                    if(receiverEmailArr.indexOf(bookingAdd[i]) == -1 && bookingAdd[i]){
                        receiverEmailArr.push(bookingAdd[i]);
                    }
                }
                log.debug('receiverEmailArr', receiverEmailArr);
                let recUrl = url.resolveRecord({
                    recordType: scriptContext.newRecord.type,
                    recordId: scriptContext.newRecord.id,
                    isEditMode: false
                }).split('&');
                let exUrl = 'https://' + recUrl[2].split('=')[1].replace('_', '-') + '.app.netsuite.com' + recUrl[0] + '&' + recUrl[1];

                let emailBody = [
                    "The Shipping Plan has been booked successfully.",
                    "<br>",
                    "<a href='",
                    exUrl,
                    "'>",
                    "View Record",
                    "</a>"
                ].join("");

                let newReEmailArr = convert2DArr(receiverEmailArr, 10);
                log.debug('newReEmailArr', newReEmailArr);
                for (let i = 0; i < newReEmailArr.length;i++){
                    try {
                        email.send({
                            author: sender,
                            recipients: newReEmailArr[i],
                            subject: 'The Shipping Plan has been booked successfully.',
                            body: emailBody,
                        });
                    }catch (e) {
                        log.error('Booking SendEmail Error', e);
                        isSendSuccess = false;
                    }
                }
                if(isSendSuccess){
                    newRec.setValue({fieldId: 'custrecord_sp_email_booking', value: true});
                    newRec.save({ignoreMandatoryFields: true, enableSourcing: true});
                }
            }
            else if(status == 3){ //status == shipped
                let hasSentEmail = newRec.getValue('custrecord_sp_email_shipped')
                if(hasSentEmail){ //如果已经发送过邮件
                    return ;
                }
                sender = newRec.getValue('custrecord_sp_logistician2');

                receiverArr.push(newRec.getValue('custrecord_sp_cusservice'));
                receiverArr.push(newRec.getValue('custrecord_sp_supplyplanner'));
                receiverArr.push(newRec.getValue('custrecord_sp_docofficer2'));
                receiverArr.push(newRec.getValue('custrecord_sp_warehouseclerk'));

                let emailJson = getUserEmail(receiverArr);

                let receiverEmailArr = [];
                for(let i = 0;i < receiverArr.length;i++){
                    if(receiverEmailArr.indexOf(emailJson[receiverArr[i]]) == -1 && emailJson[receiverArr[i]]){
                        receiverEmailArr.push(emailJson[receiverArr[i]]);
                    }
                }
                let shippingAdd = newRec.getValue('custrecord_sp_sippingadd').split(';');
                for(let i = 0;i < shippingAdd.length;i++){
                    if(receiverEmailArr.indexOf(shippingAdd[i]) == -1 && shippingAdd[i]){
                        receiverEmailArr.push(shippingAdd[i]);
                    }
                }
                log.debug('receiverEmailArr', receiverEmailArr);
                let recUrl = url.resolveRecord({
                    recordType: scriptContext.newRecord.type,
                    recordId: scriptContext.newRecord.id,
                    isEditMode: false
                }).split('&');
                let exUrl = 'https://' + recUrl[2].split('=')[1].replace('_', '-') + '.app.netsuite.com' + recUrl[0] + '&' + recUrl[1];

                let emailBody = [
                    "The Shipping Plan has been Shipped.",
                    "<br>",
                    "<a href='",
                    exUrl,
                    "'>",
                    "View Record",
                    "</a>"
                ].join("");

                let newReEmailArr = convert2DArr(receiverEmailArr, 10);
                log.debug('newReEmailArr', newReEmailArr);
                for (let i = 0; i < newReEmailArr.length;i++){
                    try {
                        email.send({
                            author: sender,
                            recipients: newReEmailArr[i],
                            subject: 'The Shipping Plan has been Shipped.',
                            body: emailBody,
                        });
                    }catch (e) {
                        log.error('Shipped SendEmail Error', e);
                        isSendSuccess = false;
                    }
                }
                if(isSendSuccess){
                    newRec.setValue({fieldId: 'custrecord_sp_email_shipped', value: true});
                    newRec.save({ignoreMandatoryFields: true, enableSourcing: true});
                }
            }
        }

        //获取发件人和收件人邮箱地址
        const getUserEmail = (receiverArr) => {
            let userArr = [],
                emailJson = {};
            for(let i = 0;i < receiverArr.length;i++){
                if(userArr.indexOf(receiverArr[i]) == -1){
                    userArr.push(receiverArr[i]);
                }
            }
            let mySearchObj = search.create({
                type: 'employee',
                filters: [
                    ['internalid', 'anyof', userArr]
                ],
                columns: ['email']
            });
            let res = commonApi.getAllData(mySearchObj);
            if(res && res.length > 0){
                for(let i = 0;i < res.length;i++){
                    emailJson[res[i].id] = res[i].getValue('email');
                }
            }

            return emailJson;
        }

        //一维数组转二维数组
        function convert2DArr(arr, num) {
            let newArr = [];
            arr.forEach((it,idx) => {
                const total = Math.floor(idx / num); //判断当前在第几个数组内
                if(!(newArr[total])){ //判断当前是否有数组
                    newArr[total] = [];  //如果没有赋值一个空
                }
                newArr[total].push(it); // 并且把当前对应的索引里面进行添加
            });
            return newArr;
        }

        return {
            beforeLoad,
            // beforeSubmit,
            afterSubmit
        }

    });
