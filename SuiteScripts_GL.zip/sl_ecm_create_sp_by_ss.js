/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 * version      date            author              remark
 * 1.0          2023/02/21      Gino Lu             下推生成Shipping Plan页面【ID1018531】
 * 2.0          2023/03/01      Gino Lu             完善页面逻辑【ID1018531】
 * 3.0          2023/03/07      Gino Lu             完善逻辑
 * 4.0          2023/03/13      Gino Lu             逻辑变更
 * 5.0          2023/03/16      Gino Lu             完善逻辑
 * 6.0          2023/03/21      Gino Lu             变更逻辑
 * 7.0          2023/03/24      Gino Lu             变更逻辑
 * 8.0          2023/03/27      Gino Lu             在SP生成之后回写到PO的Shipping Plan字段【ID1019370】
 * 9.0          2023/03/28      Gino Lu             生成SP时增加赋值字段
 * 10.0         2023/03/29      Gino Lu             修改body部分label
 * 11.0         2023/03/30      Gino Lu             添加校验字段过滤SS
 * 12.0         2023/04/04      Gino Lu             添加映射字段
 * 13.0         2023/04/10      Gino Lu             修复多选字段塞值bug
 * 14.0         2023/04/12      Gino Lu             修改字段取值校验
 */
define(['N/config', 'N/encode', 'N/file', 'N/format', 'N/http', 'N/https', 'N/record', 'N/url', 'N/runtime', 'N/search', 'N/ui/serverWidget', '/SuiteScripts/tools/common_api.js'],
    /**
     * @param{config} config
     * @param{encode} encode
     * @param{file} file
     * @param{format} format
     * @param{http} http
     * @param{https} https
     * @param{record} record
     * @param{url} url
     * @param{runtime} runtime
     * @param{search} search
     * @param{serverWidget} serverWidget
     * @param commonApi
     */
    (config, encode, file, format, http, https, record, url, runtime, search, serverWidget, commonApi) => {
        /**
         * Defines the Suitelet script trigger point.
         * @param {Object} scriptContext
         * @param {ServerRequest} scriptContext.request - Incoming request
         * @param {ServerResponse} scriptContext.response - Suitelet response
         * @since 2015.2
         */
        // 明细字段
        const sublistField = [
                {id: 'custpage_line_ss', type: 'select', source: 'customrecord_shipping_schedule', label: 'SS', displayType: serverWidget.FieldDisplayType.INLINE},
                {id: 'custpage_line_ssitem', type: 'select', source: 'lotnumberedinventoryitem', label: 'SS Item', displayType: serverWidget.FieldDisplayType.INLINE},
                {id: 'custpage_line_scd', type: 'select', source: 'customrecord_ecm_scd', label: 'SCD', displayType: serverWidget.FieldDisplayType.INLINE},
                {id: 'custpage_line_scdline', type: 'select', source: 'customrecord_ecm_scd_line', label: 'SCD Line', displayType: serverWidget.FieldDisplayType.HIDDEN},
                {id: 'custpage_line_scditem', type: 'select', source: 'lotnumberedinventoryitem', label: 'SCD Item', displayType: serverWidget.FieldDisplayType.INLINE},
                {id: 'custpage_line_scdqty', type: 'text', label: 'SCD Quantity'},
                {id: 'custpage_line_unit', type: 'select', source: '-221', label: 'Unit', displayType: serverWidget.FieldDisplayType.INLINE},
                {id: 'custpage_line_inventory_type', type: 'text', label: 'Inventory Type', displayType: serverWidget.FieldDisplayType.HIDDEN},
                {id: 'custpage_line_location', type: 'select', source: 'location', label: 'Location', displayType: serverWidget.FieldDisplayType.INLINE},
                {id: 'custpage_line_inventory', type: 'text', label: 'Inventory Detail', displayType: serverWidget.FieldDisplayType.ENTRY},
                {id: 'custpage_line_inventory_btn', type: 'text', label: 'Detail Button'},
                {id: 'custpage_line_ecm_json', type: 'text', label: 'ECM Inventory Info', displayType: serverWidget.FieldDisplayType.HIDDEN},
                {id: 'custpage_line_average_cost', type: 'text', label: 'Average Cost', displayType: serverWidget.FieldDisplayType.HIDDEN},
            ];

        //脚本赋值字段映射
        const fieldMap = {
            entity: 'custrecord_sp_customer', subsidiary: 'custrecord_sp_scsubsidiary', currency: 'custrecord_sp_sccurrency',
            custrecord_ssc_incoterm: 'custrecord_sp_incoterm',
            custrecord_ssc_shipping_method: 'custrecord_sp_shipping_method', custrecord_ss_country_loading: 'custrecord_sp_country_loading', custrecord_ss_destilocation: 'custrecord_sp_destilocation',
            custbody_ecm_prepayment_ratio: 'custrecord_sp_preparent', custbody_ecm_prepay_method: 'custrecord_sp_pretype', custbody_ecm_prepay_node: 'custrecord_sp_prenode',
            custbody_ecm_advance_prepaydays: 'custrecord_sp_preday', custbody_ecm_balance_prepay_node: 'custrecord_sp_surpnode',
            custbody_ecm_balance_termsdays: 'custrecord_sp_surpday', custbody_ecm_balance_prepay_method: 'custrecord_sp_surptype', custbody_ecm_deliverydate_type: 'custrecord_sp_japdelivery',
            custrecord_scd_warehousestock: 'custrecord_sp_warehousestock', custrecord_scdline_supplyplanner: 'custrecord_sp_supplyplanner', custrecord_ssc_bookingemail: 'custrecord_sp_bookingadd',
            custrecord_ssc_shippingemail: 'custrecord_sp_sippingadd', custrecord_ssc_sendemail: 'custrecord_sp_sendaddress', custrecord_ssc_memo: 'custrecord_sp_memo',
            custrecord_ssc_fcl_lcl: 'custrecord_sp_lcl', custrecord_ssc_cubetype1: 'custrecord_sp_cubetype1', custrecord_ssc_cubetypeqty1: 'custrecord_sp_cubetypeqty1',
            custrecord_ssc_cubetype2: 'custrecord_sp_cubetype2', custrecord_ssc_cubetypeqty2: 'custrecord_sp_cubetypeqty2', custrecord_ssc_inspection_type: 'custrecord_sp_inspection_type',
            custrecord_ssc_third_inctype_remark: 'custrecord_sp_third_inctype_remark', custrecord_ssc_photo_request: 'custrecord_sp_photo_request', custrecord_ssc_photoreq_addremark: 'custrecord_sp_photoreq_addremark',
            custrecord_ssc_tagtype: 'custrecord_sp_tag', custrecord_ssc_tagcontent: 'custrecord_sp_tagcontent', custrecord_ssc_vendordocs: 'custrecord_sp_vendordocs',
            custrecord_ssc_otherdocs_addre: 'custrecord_sp_otherdocs_addremark', custrecord_ssc_poreq_othemark: 'custrecord_sp_poreq_othemark', custrecord_ssc_ifbolcorp_name: 'custrecord_sp_ifbolcorp_name',
            custrecord_ssc_ifbol_vatreg: 'custrecord_sp_ifbol_vatreg', custrecord_ssc_ifbol_address: 'custrecord_sp_ifbol_address', custrecord_ssc_ifbol_contact: 'custrecord_sp_ifbol_contact',
            custrecord_ssc_ifbol_phone: 'custrecord_sp_ifbol_phone', custrecord_ssc_ifbol_fax: 'custrecord_sp_ifbol_fax', custrecord_ssc_irbol_name: 'custrecord_sp_irbol_name',
            custrecord_ssc_irbol_vatreg: 'custrecord_sp_irbol_vatreg', custrecord_ssc_irbol_address: 'custrecord_sp_irbol_address', custrecord_ssc_irbol_country: 'custrecord_sp_irbol_country',
            custrecord_ssc_irbol_contact: 'custrecord_sp_irbol_contact', custrecord_ssc_irbol_phone: 'custrecord_sp_irbol_phone', custrecord_ssc_irbol_fax: 'custrecord_sp_irbol_fax',
            custrecord_ssc_isconsignee_phone: 'custrecord_sp_isconsignee_phone', custrecord_ssc_isconsignee_fax: 'custrecord_sp_isconsignee_fax',
            custrecord_ssc_notibol_name: 'custrecord_sp_notibol_name', custrecord_ssc_notibol_vatreg: 'custrecord_sp_notibol_vatreg', custrecord_ssc_notibol_address: 'custrecord_sp_notibol_address',
            custrecord_ssc_notibol_country: 'custrecord_sp_notibol_country', custrecord_ssc_notibol_contract: 'custrecord_sp_notibol_contract', custrecord_ssc_notibol_phone: 'custrecord_sp_notibol_phone',
            custrecord_ssc_isconsignee_vat: 'custrecord_sp_notibol_fax', custrecord_ssc_isshpper_vatreg: 'custrecord_sp_isshpper_vatreg', custrecord_ssc_isshpper_phone: 'custrecord_sp_isshpper_phone',
            custrecord_ssc_isshpper_fax: 'custrecord_sp_isshpper_fax', custrecord_ssc_mark: 'custrecord_sp_mark', custrecord_ssc_bolrequest: 'custrecord_sp_bolrequest',
            custrecord_ssc_signway: 'custrecord_sp_signway', custrecord_ssc_boltype: 'custrecord_sp_boltype', custrecord_ssc_otherrequeest: 'custrecord_sp_otherrequeest',
            custrecord_ssc_vessel_route: 'custrecord_sp_vessel_route',
            custrecord_ssc_destport_req: 'custrecord_sp_destport_req', custrecord_ssc_shippapers: 'custrecord_sp_shippapers', custrecord_ssc_timeof_freeconta: 'custrecord_sp_timeof_freeconta',
            custrecord_ssc_freeconta_remark: 'custrecord_sp_freeconta_remark', custrecord_ssc_forward: 'custrecord_sp_forward', custrecord_ssc_vesselcom_ootreq: 'custrecord_sp_vesselcom_ootreq',
            custrecord_ssc_orderreq: 'custrecord_sp_orderreq', custrecord_ssc_deli_comname: 'custrecord_sp_deli_comname', custrecord_ssc_deli_country: 'custrecord_sp_deli_country',
            custrecord_ssc_deli_city: 'custrecord_sp_deli_city', custrecord_ssc_deli_zip: 'custrecord_sp_deli_zip', custrecord_ssc_deli_email: 'custrecord_sp_deli_email',
            custrecord_ssc_deli_address: 'custrecord_sp_deli_address', custrecord_ssc_deli_phone: 'custrecord_sp_deli_phone',
            custrecord_ssc_order_type: 'custrecord_sp_contracttype', custrecord_ss_deliveryadd: 'custrecord_sp_deliveryadd', custrecord_ss_shippingadd: 'custrecord_sp_shippingadd',
            custrecord_ssc_vessel_deadline: 'custrecord_sp_shipto', custrecord_ss_invoice_check: 'custrecord_sp_invoice_check', custrecord_ss_invoice_original: 'custrecord_sp_invoice_original',
            custrecord_ss_invoice_copy: 'custrecord_sp_invoice_copy', custrecord_ss_invoice_elect: 'custrecord_sp_invoice_elect', custrecord_ss_invoice_otherreq: 'custrecord_sp_invoice_otherreq',
            custrecord_ss_coa_type: 'custrecord_sp_coa_type', custrecord_ss_coa_original: 'custrecord_sp_coa_original', custrecord_ss_coa_copy: 'custrecord_sp_coa_copy',
            custrecord_ss_coa_elect: 'custrecord_sp_coa_elect', custrecord_ss_coa_otherreq: 'custrecord_sp_coa_otherreq', custrecord_ss_msds_check: 'custrecord_sp_msds_check',
            custrecord_ss_msds_original: 'custrecord_sp_msds_original', custrecord_ss_msds_copy: 'custrecord_sp_msds_copy', custrecord_ss_msds_elect: 'custrecord_sp_msds_elect',
            custrecord_ss_msds_otherreq: 'custrecord_sp_msds_otherreq', custrecord_ss_pack_check: 'custrecord_sp_pack_check', custrecord_ss_pack_original: 'custrecord_sp_pack_original',
            custrecord_ss_pack_copy: 'custrecord_sp_pack_copy', custrecord_ss_pack_elect: 'custrecord_sp_pack_elect', custrecord_ss_pack_otherreq: 'custrecord_sp_pack_otherreq',
            custrecord_ss_insu_check: 'custrecord_sp_insu_check', custrecord_ss_insu_original: 'custrecord_sp_insu_original', custrecord_ss_insu_copy: 'custrecord_sp_insu_copy',
            custrecord_ss_insu_elect: 'custrecord_sp_insu_elect', custrecord_ss_insu_otherreq: 'custrecord_sp_insu_otherreq', custrecord_ss_origin_check: 'custrecord_sp_origin_check',
            custrecord_ss_origin_original: 'custrecord_sp_origin_original', custrecord_ss_origin_copy: 'custrecord_sp_origin_copy', custrecord_ss_origin_elect: 'custrecord_sp_origin_elect',
            custrecord_ss_origin_certificate: 'custrecord_sp_origin_certificate', custrecord_ss_preferential_certificate: 'custrecord_sp_preferential_certificate', custrecord_ss_origin_otherreq: 'custrecord_sp_origin_otherreq',
            custrecord_ss_healthy_check: 'custrecord_sp_healthy_check', custrecord_ss_healthy_original: 'custrecord_sp_healthy_original', custrecord_ss_healthy_copy: 'custrecord_sp_healthy_copy',
            custrecord_ss_healthy_elect: 'custrecord_sp_healthy_elect', custrecord_ss_healthy_otherreq: 'custrecord_sp_healthy_otherreq',
            custbody_ecm_commissioncurrency: 'custrecord_sp_commissioncurrency', custrecord_ss_labelmodel: 'custrecord_sp_labelmodel'
        }

        const onRequest = (scriptContext) => {
            let request = scriptContext.request;
            let response = scriptContext.response;
            let params = request.parameters;
            // log.debug('params', params);

            if ('GET' == request.method) {
                let user = runtime.getCurrentUser();
                let ssList = getAllSearchJson(user);
                let form = createForm(params, ssList, user);
                response.writePage(form);
            }
            else {
                let ssNoArr = params.custpage_ssno.match(/\d+/g);

                let shippingMethod = params.custpage_transport;
                let shippingDate = params.custpage_shipping_date;
                let isCrossBorder = params.custpage_cross_border;
                let portOrigin = params.custpage_departure_port;
                let portDestination = params.custpage_destination_port;
                let countryDestination = params.custpage_destination_country;
                let bookingClerk = params.custpage_logistics_operator;
                let officer = params.custpage_document_officer;
                let cusService = params.custpage_ss;

                let lineCount = request.getLineCount({group: 'custpage_sublist_line'});
                let lineArr = [];
                for (let i = 0 ; i < lineCount; i++) {
                    // let isSelect = request.getSublistValue({group: 'custpage_sublist_line', name: 'custpage_line_select', line: i});
                    // if ('T' == isSelect || true == isSelect) {
                    let scdLineId = request.getSublistValue({group: 'custpage_sublist_line', name: 'custpage_line_scdline', line: i});
                    let scdItemId = request.getSublistValue({group: 'custpage_sublist_line', name: 'custpage_line_scditem', line: i});
                    let location = request.getSublistValue({group: 'custpage_sublist_line', name: 'custpage_line_location', line: i});
                    let ecmJson = request.getSublistValue({group: 'custpage_sublist_line', name: 'custpage_line_ecm_json', line: i});
                    let averageRate = request.getSublistValue({group: 'custpage_sublist_line', name: 'custpage_line_average_cost', line: i});
                    if(scdLineId && scdLineId != ''){
                        let json = {};
                        json.scdLineId = scdLineId;
                        json.scdItemId = scdItemId;
                        json.location = location;
                        json.ecmInfo = JSON.parse(ecmJson);
                        json.averageRate = averageRate;
                        lineArr.push(json);
                    }
                    // }
                }
                let scdData = getSCDData(ssNoArr[0]);
                let scData = getSCData(scdData.scIdArr[0]);
                let data = {};
                for(let key in scdData){
                    if(key != 'scIdArr'){
                        data = Object.assign({}, scdData[key], scData[key]);
                    }
                }

                let reqData = {
                    custrecord_sp_shipping_method: shippingMethod,
                    custrecord_sp_estshippingdate: shippingDate,
                    custrecord_sp_iscross_border: isCrossBorder,
                    custrecord_sp_loadingport: portOrigin,
                    custrecord_sp_destinationport: portDestination,
                    custrecord_sp_country_destination: countryDestination,
                    custrecord_sp_logistician: bookingClerk,
                    custrecord_sp_docofficer: officer,
                    custrecord_sp_cusservice: cusService,
                    scriptData: data
                }
                log.debug('reqData', reqData);

                let newSpId = createShippingPlan(reqData);
                log.debug('newSpId', newSpId);
                let scdLineArr = linkSCDLineToShipping(lineArr, newSpId);
                log.debug('scdLineArr', scdLineArr);
                if(newSpId){
                    let spObj = record.load({type: 'customrecord_ecm_sp', id: newSpId});
                    spObj.save({enableSourcing: true, ignoreMandatoryFields: true}); //重载触发ue脚本
                    response.sendRedirect({
                        type: 'RECORD',
                        identifier: 'customrecord_ecm_sp',
                        id: newSpId
                    });
                }
                else {
                    response.write('生成shipping plan失败！');
                }
            }
        }

        //创建sp
        function createShippingPlan(reqData) {
            let spObj = record.create({
                type: 'customrecord_ecm_sp',
                isDynamic: true
            });
            for(let fieldId in reqData){
                let fieldType = '';
                if(fieldId != 'scriptData'){
                    if(fieldId == 'custrecord_sp_iscross_border'){
                        spObj.setValue({fieldId: fieldId, value: reqData[fieldId] == 'T' ? true : false});
                    }
                    else if(fieldId == 'custrecord_sp_estshippingdate'){
                        spObj.setText({fieldId: fieldId, text: reqData[fieldId]});
                    }
                    else {
                        spObj.setValue({fieldId: fieldId, value: reqData[fieldId]});
                    }
                }
                else {
                    for(let key in reqData[fieldId]){
                        try {
                            if(!fieldMap[key]){
                                log.error('Missing Corresponding Field In SP', key);
                                continue;
                            }
                            if(reqData[fieldId][key] && reqData[fieldId][key] != null){
                                fieldType = spObj.getField(fieldMap[key]).type;
                                reqData[fieldId][key] = format.parse({value: reqData[fieldId][key], type: fieldType});
                                if(fieldType == 'multiselect'){
                                    reqData[fieldId][key] = reqData[fieldId][key].split(',');
                                }
                                spObj.setValue({fieldId: fieldMap[key], value: reqData[fieldId][key]});
                            }
                        }catch (e){
                            log.error('setFieldValue Error', e);
                        }
                    }
                }
            }
            try {
                return spObj.save({enableSourcing: true, ignoreMandatoryFields: true});
            }catch (e){
                log.error('createShippingPlan Error', e);
            }
        }

        //关联sp明细行
        function linkSCDLineToShipping(lineArr, spId) {
            let scdLineIdArr = [];
            for(let i = 0; i < lineArr.length; i++){
                let ecmInventoryIdArr = createEcmInventoryDetail(lineArr[i]);
                try{
                    if(!lineArr[i].scdLineId){
                        continue;
                    }
                    let scdLineObj = record.load({
                        type: 'customrecord_ecm_scd_line',
                        id: lineArr[i].scdLineId
                    });
                    let poId = scdLineObj.getValue('custrecord_scdline_purchaseorder');
                    if(poId){
                        record.submitFields({
                            type: 'purchaseorder',
                            id: poId,
                            values: {
                                custbody_ecm_sp: spId
                            },
                            options: {
                                ignoreMandatoryFields: true
                            }
                        });
                    }

                    scdLineObj.setValue({fieldId: 'custrecord_scdline_realsp', value: true});
                    scdLineObj.setValue({fieldId: 'custrecord_scdline_inventorydetail', value: ecmInventoryIdArr});
                    scdLineObj.setValue({fieldId: 'custrecord_scdline_location', value: lineArr[i].location});
                    if(lineArr[i].averageRate){
                        scdLineObj.setValue({fieldId: 'custrecord_scdline_purchaseamt', value: lineArr[i].averageRate});
                    }
                    scdLineObj.setValue({fieldId: 'custrecord_scdline_sp', value: spId});

                    scdLineIdArr.push(scdLineObj.save({enableSourcing: true, ignoreMandatoryFields: true}));
                }catch (e){
                    log.error('linkSCDLineToShipping Error', e);
                }
            }
            return scdLineIdArr;
        }

        //创建ecm Inventory Detail记录
        function createEcmInventoryDetail(lineInfo) {
            let ecmInventoryIdArr = [];
            if(!lineInfo.ecmInfo){
                return [];
            }
            for(let i = 0; i < lineInfo.ecmInfo.length; i++){
                let ecmInventoryObj = record.create({
                    type: 'customrecord_ecm_inventorydetail',
                    isDynamic: true
                });
                ecmInventoryObj.setValue({fieldId: 'custrecord_id_spline', value: lineInfo.scdLineId});
                ecmInventoryObj.setValue({fieldId: 'custrecord_id_item', value: lineInfo.scdItemId});
                ecmInventoryObj.setValue({fieldId: 'custrecord_id_location', value: lineInfo.location});
                ecmInventoryObj.setValue({fieldId: 'custrecord_id_seriallot', value: lineInfo.ecmInfo[i].inventory_number});
                ecmInventoryObj.setValue({fieldId: 'custrecord_id_quantity', value: lineInfo.ecmInfo[i].inventory_qty});
                ecmInventoryObj.setValue({fieldId: 'custrecord_id_palletno', value: lineInfo.ecmInfo[i].pallet_number});
                ecmInventoryObj.setValue({fieldId: 'custrecord_id_netweight_perpallet', value: lineInfo.ecmInfo[i].per_pallet});
                ecmInventoryObj.setValue({fieldId: 'custrecord_id_palletsize', value: lineInfo.ecmInfo[i].pallet_size});
                ecmInventoryObj.setValue({fieldId: 'custrecord_id_packageno', value: lineInfo.ecmInfo[i].package_number});
                ecmInventoryObj.setValue({fieldId: 'custrecord_id_grossweight', value: lineInfo.ecmInfo[i].gross_weight});
                ecmInventoryObj.setValue({fieldId: 'custrecord_id_netweight', value: lineInfo.ecmInfo[i].net_weight});
                ecmInventoryObj.setValue({fieldId: 'custrecord_id_volume', value: lineInfo.ecmInfo[i].volume});
                ecmInventoryObj.setText({fieldId: 'custrecord_id_productiondate', text: lineInfo.ecmInfo[i].date_production});

                try {
                    ecmInventoryIdArr.push(ecmInventoryObj.save({enableSourcing: true, ignoreMandatoryFields: true}));
                }catch (e){
                    log.error('createEcmInventoryDetail Error', e);
                }
            }

            return ecmInventoryIdArr;
        }

        //scd搜索
        function getSCDData(ssNo) {
            let data = {},
                scIdArr = [];
            let filters = [],
                columns = [];
            filters.push(['custrecord_scd_ss', 'anyof', ssNo]);

            columns.push(search.createColumn({name: 'custrecord_ssc_scnumber', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_incoterm', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_shipping_method', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_order_type', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ss_country_loading', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ss_destilocation', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_scd_warehousestock'}));
            columns.push(search.createColumn({name: 'custrecord_scdline_supplyplanner', join: 'CUSTRECORD_ECM_SCDLINE_SCD'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_bookingemail', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_shippingemail', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_sendemail', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_memo', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_fcl_lcl', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_cubetype1', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_cubetypeqty1', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_cubetype2', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_cubetypeqty2', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_inspection_type', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_third_inctype_remark', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_photo_request', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_photoreq_addremark', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_tagtype', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_tagcontent', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_vendordocs', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_otherdocs_addre', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_poreq_othemark', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_ifbolcorp_name', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_ifbol_vatreg', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_ifbol_address', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_ifbol_contact', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_ifbol_phone', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_ifbol_fax', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_irbol_name', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_irbol_vatreg', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_irbol_address', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_irbol_country', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_irbol_contact', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_irbol_phone', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_irbol_fax', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_isconsignee_vat', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_isconsignee_phone', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_isconsignee_fax', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_notibol_name', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_notibol_vatreg', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_notibol_address', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_notibol_country', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_notibol_contract', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_notibol_phone', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_isshpper_vatreg', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_isshpper_phone', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_isshpper_fax', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_mark', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_bolrequest', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_signway', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_boltype', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_otherrequeest', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_vessel_route', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_destport_req', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_shippapers', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_timeof_freeconta', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_freeconta_remark', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_forward', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_vesselcom_ootreq', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_orderreq', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_deli_comname', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_deli_country', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_deli_city', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_deli_zip', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_deli_email', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_deli_address', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_deli_phone', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ssc_vessel_deadline', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ss_invoice_check', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ss_invoice_original', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ss_invoice_copy', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ss_invoice_elect', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ss_invoice_otherreq', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ss_coa_type', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ss_coa_original', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ss_coa_copy', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ss_coa_elect', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ss_coa_otherreq', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ss_msds_check', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ss_msds_original', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ss_msds_copy', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ss_msds_elect', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ss_msds_otherreq', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ss_pack_check', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ss_pack_original', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ss_pack_copy', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ss_pack_elect', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ss_pack_otherreq', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ss_insu_check', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ss_insu_original', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ss_insu_copy', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ss_insu_elect', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ss_insu_otherreq', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ss_origin_check', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ss_origin_original', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ss_origin_copy', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ss_origin_elect', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ss_origin_certificate', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ss_preferential_certificate', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ss_origin_otherreq', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ss_healthy_check', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ss_healthy_original', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ss_healthy_copy', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ss_healthy_elect', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ss_healthy_otherreq', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ss_shippingadd', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ss_deliveryadd', join: 'CUSTRECORD_SCD_SS'}));
            columns.push(search.createColumn({name: 'custrecord_ss_labelmodel', join: 'CUSTRECORD_SCD_SS'}));

            let mySearchObj = search.create({
                type: 'customrecord_ecm_scd',
                filters: filters,
                columns: columns
            });
            let res = commonApi.getAllData(mySearchObj);

            for(let j = 0; j < res.length;j++){
                let json = {};
                let scId = res[j].getValue(columns[0]);
                if(scIdArr.indexOf(scId) == -1 && scId){
                    for(let i = 1;i < columns.length;i++){
                        json[columns[i].name] = res[j].getValue(columns[i]) || '';
                    }
                    scIdArr.push(scId);
                    data[scId] = json;
                }
            }
            data.scIdArr = scIdArr;

            log.debug('scdData', JSON.stringify(data));
            return data;
        }

        //sc搜索
        function getSCData(scId) {
            if(!scId || scId == ''){
                return '{}';
            }
            let data = {};
            let filters = [],
                columns = [];
            filters.push(['internalid', 'anyof', scId]);
            filters.push('and');
            filters.push(['mainline', 'is', 'F']);
            filters.push('and');
            filters.push(['taxline', 'is', 'F']);

            columns.push(search.createColumn({name: 'internalid'}));
            columns.push(search.createColumn({name: 'entity'}));
            columns.push(search.createColumn({name: 'subsidiary'}));
            columns.push(search.createColumn({name: 'currency'}));
            columns.push(search.createColumn({name: 'custbody_ecm_prepayment_ratio'}));
            columns.push(search.createColumn({name: 'custbody_ecm_prepay_method'}));
            columns.push(search.createColumn({name: 'custbody_ecm_prepay_node'}));
            columns.push(search.createColumn({name: 'custbody_ecm_advance_prepaydays'}));
            columns.push(search.createColumn({name: 'custbody_ecm_balance_prepay_node'}));
            columns.push(search.createColumn({name: 'custbody_ecm_balance_termsdays'}));
            columns.push(search.createColumn({name: 'custbody_ecm_balance_prepay_method'}));
            columns.push(search.createColumn({name: 'custbody_ecm_deliverydate_type'}));
            columns.push(search.createColumn({name: 'custbody_ecm_commissioncurrency', label: 'Currency of Service Fee'}));
            let mySearchObj = search.create({
                type: 'salesorder',
                filters: filters,
                columns: columns
            });
            let res = commonApi.getAllData(mySearchObj);

            let internalIdArr = [];
            for(let j = 0; j < res.length;j++){
                let json = {};
                let internalId = res[j].getValue(columns[0]);
                if(internalIdArr.indexOf(internalId) == -1 && internalId){
                    for(let i = 1;i < columns.length;i++){
                        json[columns[i].name] = res[j].getValue(columns[i]) || '';
                    }
                    internalIdArr.push(internalId);
                    data[internalId] = json;
                }
            }

            log.debug('scData', JSON.stringify(data));
            return data;
        }

        //获取所有的筛选条件
        function getAllSearchJson(user) {
            let searchJson = {};
            let filters = [];
            filters.push(['isinactive', 'is', 'F']);
            filters.push('and');
            filters.push(['custrecord_scd_ss.custrecord_ssc_completescd', 'is', 'T']);
            filters.push('and');
            filters.push(['custrecord_ecm_scdline_scd.custrecord_scdline_sp', 'anyof', '@NONE@']);
            if(user.role != 3){ //用户角色非管理员
                filters.push('and');
                filters.push(['custrecord_scd_sc.custbody_ecm_cusservice', 'anyof', user.id]);
            }
            let mySearchObj = search.create({
                type: 'customrecord_ecm_scd',
                filters: filters,
                columns: [
                    search.createColumn({name: 'custrecord_scd_ss'})
                ]
            });
            let columns = mySearchObj.columns;
            let res = commonApi.getAllData(mySearchObj);
            let columnsList = {};
            for(let i = 0;i < columns.length;i++){ //初始化
                columnsList[i] = {};
                columnsList[i].jsonArr = [];
                columnsList[i].uniqueArr = [];
            }
            res.forEach((value) => {
                for(let i = 0; i < columns.length; i++){
                    let fieldValue = value.getValue(columns[i]),
                        fieldText = value.getText(columns[i]);
                    if(columnsList[i].uniqueArr.indexOf(fieldValue) == -1 && fieldValue){
                        let json = {};
                        json.value = fieldValue;
                        json.text = fieldText ? fieldText : fieldValue;
                        columnsList[i].uniqueArr.push(fieldValue);
                        columnsList[i].jsonArr.push(json);
                    }
                }
            });
            searchJson.ssNoArr = columnsList[0].jsonArr;

            return searchJson;
        }

        //获取所有的SS上信息
        function getAllSSInfo(ssNoArr) {
            let infoList = {};
            let filters = [];
            filters.push(['internalid', 'anyof', ssNoArr]);

            let mySearchObj = search.create({
                type: 'customrecord_shipping_schedule',
                filters: filters,
                columns: [
                    search.createColumn({name: 'custrecord_ssc_shipping_method'}),
                    search.createColumn({name: 'custrecord_ssc_exshipdate'}),
                    search.createColumn({name: 'custrecord_ssc_iscross_border'}),
                    search.createColumn({name: 'custrecord_ssc_loadingport'}),
                    search.createColumn({name: 'custrecord_ssc_destinationport'}),
                    search.createColumn({name: 'custrecord_ssc_country_destination'}),
                    search.createColumn({name: 'department', join: 'custrecord_ssc_scnumber'}),
                ]
            });
            let columns = mySearchObj.columns;
            let res = commonApi.getAllData(mySearchObj);
            if(res && res.length > 0){
                res.forEach((value) => {
                    let json = {};
                    let ssId = value.id;
                    for(let i = 0; i < columns.length; i++) {
                        json[columns[i].name] = value.getValue(columns[i]);
                    }
                    infoList[ssId] = json;
                });
            }

            return infoList;
        }

        // 创建页面
        function createForm(params, ssList, user) {
            let form = serverWidget.createForm({title: 'Create SP', hideNavBar: false});
            let ssIndex = -1;
            let ssInfoList = {};
            form.clientScriptModulePath = './cs_ecm_create_sp_by_ss.js';
            form.addSubmitButton({label: 'Create'});
            form.addButton({id: 'custpage_search', label: 'Search', functionName: 'searchData'});
            form.addFieldGroup({id: 'custpage_field_filters', label: 'Filters'});
            form.addFieldGroup({id: 'custpage_field_main', label: 'Main'});

            let ssNoField = form.addField({id: 'custpage_ssno', label: 'SS NO', type: 'multiselect', container: 'custpage_field_filters'});
            ssNoField.isMandatory = true;
            ssList.ssNoArr.forEach(ssno => {
                ssNoField.addSelectOption({value: ssno.value, text: ssno.text});
            });
            if (params.ssno) {
                ssNoField.defaultValue = params.ssno.split(',');
                ssIndex = params.ssno.split(',')[0];
                ssInfoList = getAllSSInfo(params.ssno.split(','));
            }
            let ssField = form.addField({id: 'custpage_ss', label: 'Customer Service', type: 'select', source: 'employee', container: 'custpage_field_filters'});
            ssField.defaultValue = user.id;
            ssField.updateDisplayType({displayType: serverWidget.FieldDisplayType.DISABLED});

            let transportField = form.addField({id: 'custpage_transport', label: 'MODE OF TRANSPORTATION', type: 'select', source: 'customrecord_ecm_shippingmethod', container: 'custpage_field_main'});
            transportField.updateDisplayType({displayType: serverWidget.FieldDisplayType.DISABLED});

            let shippingDateField = form.addField({id: 'custpage_shipping_date', label: 'Shipping Date', type: 'date', container: 'custpage_field_main'});
            shippingDateField.updateDisplayType({displayType: serverWidget.FieldDisplayType.DISABLED});

            let crossBorderField = form.addField({id: 'custpage_cross_border', label: 'Cross-Border', type: 'checkbox', container: 'custpage_field_main'});
            crossBorderField.updateDisplayType({displayType: serverWidget.FieldDisplayType.DISABLED});

            let departurePortField = form.addField({id: 'custpage_departure_port', label: 'Origin Port', type: 'select', source: 'customrecord_ecm_loaddest_ports', container: 'custpage_field_main'});
            departurePortField.updateDisplayType({displayType: serverWidget.FieldDisplayType.DISABLED});

            let destinationPortField = form.addField({id: 'custpage_destination_port', label: 'Destination Port', type: 'select', source: 'customrecord_ecm_loaddest_ports', container: 'custpage_field_main'});
            destinationPortField.updateDisplayType({displayType: serverWidget.FieldDisplayType.DISABLED});

            let destinationCountryField = form.addField({id: 'custpage_destination_country', label: 'Country of Destination', type: 'select', source: '-159', container: 'custpage_field_main'});
            destinationCountryField.updateDisplayType({displayType: serverWidget.FieldDisplayType.DISABLED});

            let logisticsField = form.addField({id: 'custpage_logistics_operator', label: 'Logistics Specialist', type: 'select', source: 'employee', container: 'custpage_field_main'});
            logisticsField.updateDisplayType({displayType: serverWidget.FieldDisplayType.DISABLED});

            let documentField = form.addField({id: 'custpage_document_officer', label: 'Document Operation', type: 'select', source: 'employee', container: 'custpage_field_main'});
            documentField.updateDisplayType({displayType: serverWidget.FieldDisplayType.DISABLED});

            if(JSON.stringify(ssInfoList) != '{}') {
                transportField.defaultValue = ssInfoList[ssIndex].custrecord_ssc_shipping_method;
                shippingDateField.defaultValue = ssInfoList[ssIndex].custrecord_ssc_exshipdate;
                crossBorderField.defaultValue = ssInfoList[ssIndex].custrecord_ssc_iscross_border ? 'T' : 'F';
                departurePortField.defaultValue = ssInfoList[ssIndex].custrecord_ssc_loadingport;
                destinationPortField.defaultValue = ssInfoList[ssIndex].custrecord_ssc_destinationport;
                destinationCountryField.defaultValue = ssInfoList[ssIndex].custrecord_ssc_country_destination;
                let department = ssInfoList[ssIndex].department;
                if(department){
                    let departSearchObj = search.lookupFields({
                        type: 'department',
                        id: department,
                        columns: ['custrecord_ecm_logistician', 'custrecord_ecm_docofficer']
                    });
                    if(departSearchObj){
                        logisticsField.defaultValue = departSearchObj['custrecord_ecm_logistician'][0].value;
                        documentField.defaultValue = departSearchObj['custrecord_ecm_docofficer'][0].value;
                    }
                }
            }

            // line
            let line = form.addSublist({id: 'custpage_sublist_line', label: 'Line', type: 'list'});
            // let markButton = line.addMarkAllButtons();
            // markButton[0].label = 'Check All';
            // markButton[1].label = 'Uncheck All';
            // line.addField({id: 'custpage_line_select', label: 'Check', type: 'checkbox'});
            if (sublistField && sublistField.length > 0) {
                sublistField.forEach(function (value, index) {
                    let line_field;
                    if (value.type == 'select') {
                        line_field = line.addField({
                            id: value.id,
                            type: value.type,
                            label: value.label,
                            source: value.source
                        });
                    }
                    else {
                        line_field = line.addField({id: value.id, type: value.type, label: value.label});
                    }
                    if (value.displayType) {
                        line_field.updateDisplayType({displayType: value.displayType});
                    }
                    if(index == 9){
                        line_field.updateDisplayType({displayType: serverWidget.FieldDisplayType.DISABLED});
                    }
                });
            }
            if ('T' == params.iss) {
                let data = getLineData(params);
                data.forEach((lineData, index) => {
                    lineData.forEach((value) => {
                        if (value.fieldValue) {
                            line.setSublistValue({id: value.fieldId, line: index, value: value.fieldValue});
                        }
                    });
                });
            }
            return form;
        }

        // 获取明细行内容
        function getLineData(params) {
            let data = [];
            let filters = [], columns = [];
            if (params.ssno) {
                filters.push(['custrecord_scd_ss', 'anyof', params.ssno.split(',')]);
            }

            columns.push(search.createColumn({name: 'custrecord_scd_ss'}));
            columns.push(search.createColumn({name: 'custrecord_scdline_scitem', join: 'CUSTRECORD_ECM_SCDLINE_SCD'}));
            columns.push(search.createColumn({name: 'internalid'}));
            columns.push(search.createColumn({name: 'internalid', join: 'CUSTRECORD_ECM_SCDLINE_SCD'}));
            columns.push(search.createColumn({name: 'custrecord_scdline_item', join: 'CUSTRECORD_ECM_SCDLINE_SCD'}));
            columns.push(search.createColumn({name: 'custrecord_scdline_qty', join: 'CUSTRECORD_ECM_SCDLINE_SCD'}));
            columns.push(search.createColumn({name: 'custrecord_scdline_unit', join: 'CUSTRECORD_ECM_SCDLINE_SCD', label: '单位'}));
            columns.push(search.createColumn({name: 'custrecord_scd_disttype'}));
            columns.push(search.createColumn({name: 'custrecord_scd_location'}));
            let prSearchObj = search.create({
                type: 'customrecord_ecm_scd',
                filters: filters,
                columns: columns
            });
            let res = commonApi.getAllData(prSearchObj);
            if(res && res.length > 0){
                for(let i = 0; i < res.length; i++){
                    let lineData = [];
                    sublistField.forEach((field, index) => {
                        let json = {};
                        json.fieldId = field.id;
                        if(index == 10){ //库存按钮
                            let type = res[i].getValue(columns[7]); //库存类型
                            let location = res[i].getValue(columns[8]) || ''; //发出仓
                            let lineId = res[i].getValue(columns[3]) || ''; //scdline id
                            let itemId = res[i].getValue(columns[4]) || ''; //scditem id
                            let scdQty = res[i].getValue(columns[5]) || ''; //scditem qty
                            if(type == 2 && lineId && location){ //配货类型为仓库发货
                                json.fieldValue = `<button id="custpage_line_inventory_btn_${lineId}" onclick="openDetailPage(${itemId}, ${lineId}, ${location}, ${scdQty})"/>Edit</button>`;
                            }
                        }
                        else if (index == 9 || index == 11 || index == 12){ //库存详细信息, ecm inventory info, average cost
                        }
                        else {
                            json.fieldValue = res[i].getValue(columns[index]);
                        }
                        lineData.push(json);
                    });
                    data.push(lineData);
                }
            }
            // log.debug('data', data);
            return data;
        }

        return {onRequest}

    });
