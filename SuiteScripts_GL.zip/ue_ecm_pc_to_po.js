/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * version      date            author              remark
 * 1.0          2023/03/30      Gino Lu             PC 转 PO【ID1019456】
 * 2.0          2023/03/31      Gino Lu             字段控制逻辑完善
 * 3.0          2023/04/04      Gino Lu             添加遮罩逻辑
 */
define(['N/record', 'N/runtime', 'N/search', 'N/url', '/SuiteScripts/tools/common_api.js'],
    /**
     * @param{record} record
     * @param{runtime} runtime
     * @param{search} search
     * @param{url} url
     * @param commonApi
     */
    (record, runtime, search, url, commonApi) => {
        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {
            addPCcToPoButton(scriptContext);
            disableSublistTab(scriptContext)
        }

        //添加按钮
        const addPCcToPoButton = (scriptContext) => {
            let typeObj = scriptContext.type;
            let newRec = scriptContext.newRecord;
            let curForm = scriptContext.form;

            let type = newRec.getValue('custbody_ecm_ordertype');
            let status = newRec.getValue('status');
            let isLineExist = judgeLineExist(newRec);

            if (typeObj == 'view' && type == 1 && status == 'Closed' && isLineExist) { //type==contract，status==Closed，货品行数量-已创建数量>0
                let pcUrl = url.resolveRecord({
                    recordType: 'purchaseorder',
                    recordId: newRec.id,
                    isEditMode: true
                });
                let copyPc = "window.open('" + pcUrl + "&memdoc=0&cp=T" + "','_self')";
                curForm.addButton({
                    id: "custpage_ecm_pc_to_po_btn",
                    label: "PC TO PO",
                    functionName: copyPc
                });
            }
        }

        //判断货品行是否有符合条件的
        function judgeLineExist(newRec) {
            let lineVerify = false;
            for(let i = 0; i < newRec.getLineCount('item');i++){
                let createdQty = newRec.getSublistValue({sublistId: 'item', fieldId: 'custcol_ecm_creatpoqty', line: i});
                let quantity = newRec.getSublistValue({sublistId: 'item', fieldId: 'quantity', line: i});
                if(Number(quantity) > Number(createdQty)){
                    lineVerify = true;
                    break;
                }
            }
            return lineVerify;
        }

        //控制字段
        const disableSublistTab = (scriptContext) =>{
            let curForm = scriptContext.form;
            let disableField = curForm.addField({
                type: 'inlinehtml',
                label: '遮罩',
                id: `custpage_disable_field`
            });
            disableField.defaultValue = `
            <style>
                #tbl_item_copy {pointer-events: none; cursor: auto; opacity: 0.5;}  
            </style>
            <script>
            </script>`;
        }

        /**
         * Defines the function definition that is executed before record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const beforeSubmit = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {
            if(scriptContext.type == 'delete'){
                return ;
            }
            writeBackPc(scriptContext);
        }

        /**
         * 回写pc
         * @param scriptContext
         */
        const writeBackPc = (scriptContext) => {
            try {
                let objRec = record.load({type: 'purchaseorder', id: scriptContext.newRecord.id});
                let oldLineData = {};
                let pcId = objRec.getValue({fieldId: 'custbody_ecm_pcfrom'});
                if(!pcId){
                    return ;
                }

                let isCreate = true;
                let newLineData = formatLineData(objRec);
                if('create' != scriptContext.type && scriptContext.oldRecord) {
                    oldLineData = formatLineData(scriptContext.oldRecord);
                    isCreate = false;
                }
                log.debug('oldLineData', JSON.stringify(oldLineData));
                log.debug('newLineData', JSON.stringify(newLineData));

                let pcObj = record.load({type: 'purchaseorder', id: pcId});
                let updSo = false;
                /**
                 * 在非create的情况下一定会取oldline上的值：情况1：oldline上有值，newline上也有对应值（修改）；情况2：oldline上有值，newline上无对应值（删除）
                 * 在create的情况下一定会取newline上的值
                 */
                for(let lineNo in (isCreate ? newLineData : oldLineData)) {
                    //如果oldline上的值在newline上被删除或者 newline刚新建
                    if(!newLineData[lineNo] || isCreate){
                        let qty = newLineData[lineNo] ? newLineData[lineNo].qty : Number( 0).sub(Number(oldLineData[lineNo].qty)),
                            index = pcObj.findSublistLineWithValue({sublistId: 'item', fieldId: 'custcol_emc_line_no', value: lineNo});
                        if(-1 != index){
                            updSo = true;
                            let nowQty = pcObj.getSublistValue({sublistId: 'item', fieldId: 'custcol_ecm_creatpoqty', line: index});
                            let newQty = Number(nowQty).add(Number(qty));
                            pcObj.setSublistValue({sublistId: 'item', fieldId: 'custcol_ecm_creatpoqty', value: newQty, line: index});
                        }
                    }
                    else if((oldLineData[lineNo].qty || 0) != (newLineData[lineNo].qty || 0)) { // 判断值是否更新
                        let qtyDiff = Number(newLineData[lineNo].qty || 0).sub(Number(oldLineData[lineNo].qty || 0)),
                            index = pcObj.findSublistLineWithValue({sublistId: 'item', fieldId: 'custcol_emc_line_no', value: lineNo});
                        if(-1 != index) {
                            updSo = true;
                            let nowQty = pcObj.getSublistValue({sublistId: 'item', fieldId: 'custcol_ecm_creatpoqty', line: index});
                            let newQty = Number(nowQty).add(Number(qtyDiff));
                            pcObj.setSublistValue({sublistId: 'item', fieldId: 'custcol_ecm_creatpoqty', value: newQty, line: index});
                        }
                    }
                }
                if(updSo){
                    pcObj.save({ignoreMandatoryFields: true, enableSourcing: true});
                }
            } catch (e) {
                log.error('writeBackPc Error', e);
            }
        }

        //格式化明细行数据
        function formatLineData(obj) {
            let lineData = {};
            let length = obj.getLineCount({sublistId: 'item'});
            for(let i = 0; i < length; i++) {
                let lineNo = obj.getSublistValue({sublistId: 'item', fieldId: 'custcol_emc_line_no', line: i});
                if(typeof lineData[lineNo] != 'object'){ //初始化
                    lineData[lineNo] = {};
                }
                let qty = obj.getSublistValue({sublistId: 'item', fieldId: 'quantity', line: i}),
                    createQty = obj.getSublistValue({sublistId: 'item', fieldId: 'custcol_ecm_creatpoqty', line: i});
                lineData[lineNo].qty = qty;
                lineData[lineNo].createQty = createQty;
            }
            return lineData;
        }

        return {
            beforeLoad,
            // beforeSubmit,
            afterSubmit
        }
    });
