/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 * Version        Date            Author            Remarks
 * 1.0            2023/03/14      Gino Lu           运营发票（序号19.1网站）【ID1019140】
 * 2.0            2023/03/16      Gino Lu           逻辑优化
 * 3.0            2023/03/17      Gino Lu           逻辑优化
 */
define(['N/encode', 'N/file', 'N/format/i18n', 'N/record', 'N/render', 'N/search', 'SuiteScripts/tools/common_api.js'],
    /**
     * @param{encode} encode
     * @param{file} file
     * @param{i18n} i18n
     * @param{record} record
     * @param{render} render
     * @param{search} search
     * @param commonApi
     */
    (encode, file, i18n, record, render, search, commonApi) => {
        /**
         * Defines the Suitelet script trigger point.
         * @param {Object} scriptContext
         * @param {ServerRequest} scriptContext.request - Incoming request
         * @param {ServerResponse} scriptContext.response - Suitelet response
         * @since 2015.2
         */
        const customPrintFormat = {
            WebService_Invoice: 'SuiteScripts/SuiteScripts_GL/WebService Invoice print template.txt',
        }

        const onRequest = (scriptContext) => {
            let request = scriptContext.request;
            let response = scriptContext.response;

            if (request.method == 'GET') {
                let invId = request.parameters.rec_id;
                let invType = request.parameters.rec_type;

                if(!invId){
                    return;
                }
                let invObj = record.load({
                    type: invType,
                    id: invId
                });
                let invoiceNo = invObj.getValue('tranid');
                let timeStamp = new Date().getTime();
                let fileName =  invoiceNo + '-' + timeStamp + '.xls';

                let templateKey = 'WebService_Invoice';

                let fileData = getData(templateKey, invId, invType);
                let xmlStr = getXml(templateKey, fileName, fileData);
                //写文件
                response.writeFile(xmlStr);
            }
        }

        //获取报表关联的记录所涉及字段的data
        function getData(templateKey, recId, recType) {
            let data = {};

            let filters = [];
            filters.push(['internalid', 'anyof', recId]);
            filters.push('and');
            filters.push(['type', 'anyof', 'CustInvc']);
            filters.push('and');
            filters.push(['mainline', 'is', 'F']);
            filters.push('and');
            filters.push(['taxline', 'is', 'F']);

            let columnsList = getColumnsList();
            let columns = Object.values(columnsList);

            let searchObj = search.create({
                type: recType,
                filters: filters,
                columns: columns
            });
            let results = commonApi.getAllData(searchObj);

            if(results && results.length > 0) {
                if(templateKey == 'WebService_Invoice'){
                    data = getWebServiceInvoiceResults(results, columnsList);
                }
            }
            log.debug('data',JSON.stringify(data));

            return data;
        }

        //获取报表文件数据
        function getXml(templateKey, fileName, fileData) {
            let printFormat = customPrintFormat[templateKey];

            let tempFile = file.load({
                id : printFormat
            });

            let t_render = render.create();
            //模板的内容
            t_render.templateContent = tempFile.getContents();

            t_render.addCustomDataSource({
                alias : 'data',
                format : render.DataSource.OBJECT,
                data : fileData
            });

            let excel_str = t_render.renderAsString();

            //将字符串转换为另一种类型的编码
            let fstr = encode.convert({
                string : excel_str,
                inputEncoding : encode.Encoding.UTF_8,
                outputEncoding : encode.Encoding.BASE_64
            });

            let excel = file.create({
                name : fileName,
                fileType : file.Type.EXCEL,
                contents : fstr
            });

            return excel;
        }

        //修改日期输出格式
        function changeDateFormat(date, type){
            if(date == ''){
                return ;
            }
            let dateArr = String(date).match(/\d+/g);
            let month = dateArr[0],
                day = dateArr[1],
                year = dateArr[2];

            if(type == 1){
                let months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                let tempMonth = months[month-1];
                return day + '-' + tempMonth + '-' + year;
            }
            if(type == 2){
                let months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
                let tempMonth = months[month-1];
                return tempMonth + ' ' + day + ', ' + year;
            }
            if(type == 3){
                return year + '/' + month + '/' + day;
            }
            if(type == 4){
                let months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                let tempMonth = months[month-1];
                return tempMonth + ' ' + day + ', ' + year;
            }
            if(type == 5){
                let months = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JULY", "AUG", "SEP", "OCT", "NOV", "DEC"];
                let tempMonth = months[month-1];
                return tempMonth + ' ' + day + ',' + year;
            }
            if(type == 6){
                let years = month,
                    months = day,
                    days = year;
                return years + '/' + months + '/' + days;
            }
            if(type == 7){
                return month + '/' + day + '/' + year;
            }
            if(type == 8){
                let months = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JULY", "AUG", "SEP", "OCT", "NOV", "DEC"];
                let tempMonth = months[month-1];
                return day + ' ' + tempMonth + ' ' + year;
            }
        }

        //如果取值为空则单元格为空
        function isNull(someValue) {
            if(someValue == '' || someValue == null) {
                return '';
            } else {
                if (isNaN(someValue) && someValue.indexOf("&") >= 0) {
                    someValue = someValue.replace(/&/g, "&amp;");
                }
                return someValue;
            }
        }

        //数组去重
        function uniqueArr(arr){
            let newArr = [];
            for (let i = 0; i < arr.length; i++) {
                if (newArr.indexOf(arr[i]) === -1) {
                    newArr.push(arr[i]);
                }
            }
            return newArr;
        }

        //将数组某项元素置于数组开头
        function moveOneUpArr(arr, label, value, index){
            let tempArr = [];
            if(value != '' && (index == '' || !index)){ //如果提供value
                for(let i = 0; i < arr.length;i++){
                    if(label != ''){ //如果是list数组且label不为空
                        if(arr[i][label] == value){
                            tempArr.push(arr[i]);
                            arr.splice(i ,1);
                            break;
                        }
                    }
                    else{
                        if(arr[i] == value){
                            tempArr.push(arr[i]);
                            arr.splice(i, 1);
                            break;
                        }
                    }
                }
            }
            else if(index && index != ''){ //如果提供index
                tempArr.push(arr[index]);
                arr.splice(index ,1);
            }

            return tempArr.concat(arr);
        }

        //在给定日期的基础上增加月
        function setDateByAddMonth(dateOri, num){
            let date = new Date(dateOri);
            date = date.setMonth(Number(date.getMonth()).add(Number(num)));
            date = new Date(date);
            let newDate = Number(date.getMonth()).add(1) + '/' + date.getDate() + '/' + date.getFullYear();

            return newDate;
        }

        // invoice上取搜索columns
        function getColumnsList() {
            let columns = {};
            columns.internalid = search.createColumn({
                name: 'internalid'
            });
            columns.subname_en = search.createColumn({
                name: 'custrecord_ecm_subname_en',
                join: 'subsidiary'
            });
            columns.customername_en = search.createColumn({
                name: 'custentity_ecm_nameen',
                join: 'customerMain'
            });
            columns.contact = search.createColumn({
                name: 'contact',
                join: 'customerMain'
            });
            columns.email = search.createColumn({
                name: 'email',
                join: 'customerMain'
            });
            columns.vatregnumber = search.createColumn({
                name: 'vatregnumber',
                join: 'customerMain'
            });
            columns.tranid = search.createColumn({
                name: 'tranid'
            });
            columns.trandate = search.createColumn({
                name: 'trandate'
            });
            columns.sono = search.createColumn({
                name: 'tranid',
                join: 'createdFrom'
            });
            columns.orderdate = search.createColumn({
                name: 'trandate',
                join: 'createdFrom'
            });
            columns.productname_en = search.createColumn({
                name: 'custitem_ecm_productname_en',
                join: 'item'
            });
            columns.serviceperiod = search.createColumn({
                name: 'custitem_ecm_serviceperiod',
                join: 'item'
            });
            columns.taxrate1 = search.createColumn({
                name: 'rate',
                join: 'taxItem'
            });

            columns.rate = search.createColumn({
                name: 'rate'
            });
            columns.currency = search.createColumn({
                name: 'currency'
            });
            columns.units = search.createColumn({
                name: 'unit',
            });
            columns.amount = search.createColumn({
                name: 'amount',
            });
            columns.taxtotal = search.createColumn({
                name: 'taxtotal',
            });
            columns.total = search.createColumn({
                name: 'total',
            });

            columns.imageid = search.createColumn({
                name: 'custrecord_ecm_trade_electricseal_sign',
                join: 'subsidiary'
            });

            return columns;
        }

        // WebService_Invoice打印模板
        function getWebServiceInvoiceResults(result, columns) {
            let data = {};
            let list = [];//明细行

            let invId = result[0].getValue(columns.internalid);
            let invObj = record.load({
                type: 'invoice',
                id: invId
            });
            let lineCnt = invObj.getLineCount('item');
            let length = lineCnt < result.length && lineCnt > 0 ? lineCnt : result.length;
            for(let i = 0; i < length; i++) {
                if(i == 0) {
                    let subNameEn = result[i].getValue(columns.subname_en);
                    let customerNameEn = result[i].getValue(columns.customername_en);
                    let contact = result[i].getText(columns.contact);
                    let email = result[i].getValue(columns.email);
                    let vatRegNumber = result[i].getValue(columns.vatregnumber);
                    let tranId = result[i].getValue(columns.tranid);
                    let tranDate = result[i].getValue(columns.trandate);
                    let soNo = result[i].getValue(columns.sono);
                    let taxRate = result[i].getValue(columns.taxrate1);

                    let currency = invObj.getText('currency');
                    let taxTotal = invObj.getValue('taxtotal');
                    let total = invObj.getValue('total');
                    let imageId = result[i].getValue(columns.imageid);

                    data.subname_en = isNull(subNameEn);
                    data.customername_en = isNull(customerNameEn);
                    data.contact = isNull(contact);
                    data.email = isNull(email);
                    data.vatregnumber = isNull(vatRegNumber);
                    data.tranid = isNull(tranId);
                    data.trandate = changeDateFormat(isNull(tranDate), 3);
                    data.sono = isNull(soNo);
                    data.currency = isNull(currency);
                    data.taxrate1 = isNull(taxRate);
                    data.taxtotal = isNull(taxTotal);
                    data.total = isNull(total);

                    let picData = '';
                    let picName = 'image03.png';
                    if(imageId){
                        let picFile = file.load({id: imageId});
                        picData = '------=_NextPart_01D95666.B372D300\n' +
                            'Content-Location: file:///C:/213792E5/WebServiceInvoiceprinttemplate.files/' + picName + '\n' +
                            'Content-Transfer-Encoding: base64\n' +
                            'Content-Type: image/png\n\n' + picFile.getContents();
                    }
                    data.picdata1 = picData;
                    data.picname1 = picName;
                }
                let productNameEn = result[i].getValue(columns.productname_en);
                let orderDate = result[i].getValue(columns.orderdate);
                let servicePeriod = result[i].getValue(columns.serviceperiod);

                let lineJson = {
                    'productname_en' : isNull(productNameEn),
                    'serviceperiod' : isNull(orderDate) != '' ? changeDateFormat(orderDate, 3) + '-' + changeDateFormat(setDateByAddMonth(orderDate, servicePeriod), 3) : '',
                }

                if(lineCnt > 0){
                    let rate = invObj.getSublistValue({sublistId: 'item', fieldId: 'rate', line: i});
                    let units = invObj.getSublistValue({sublistId: 'item', fieldId: 'units_display', line: i});
                    let amount = invObj.getSublistValue({sublistId: 'item', fieldId: 'amount', line: i});

                    lineJson.rate = isNull(Number(rate).toFixedNew(2));
                    lineJson.units = isNull(units);
                    lineJson.amount = isNull(amount);
                }

                list.push(lineJson);
            }
            data.list = list;
            return data;
        }

        return {onRequest}

    });
