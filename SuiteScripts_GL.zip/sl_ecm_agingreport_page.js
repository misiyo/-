/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 * version      date            author              remark
 * 1.0          2023/03/28      Gino Lu             库龄表【ID1019425】
 * 2.0          2023/04/12      Gino Lu             增加报表字段
 */
define(['N/config', 'N/encode', 'N/file', 'N/format', 'N/http', 'N/https', 'N/record', 'N/render', 'N/runtime', 'N/search', 'N/task', 'N/ui/serverWidget', 'N/url', '/SuiteScripts/tools/common_api.js'],
    /**
     * @param{config} config
     * @param{encode} encode
     * @param{file} file
     * @param{format} format
     * @param{http} http
     * @param{https} https
     * @param{record} record
     * @param{render} render
     * @param{runtime} runtime
     * @param{search} search
     * @param{task} task
     * @param{serverWidget} serverWidget
     * @param{url} url
     * @param commonApi
     */
    (config, encode, file, format, http, https, record, render, runtime, search, task, serverWidget, url, commonApi) => {
        /**
         * Defines the Suitelet script trigger point.
         * @param {Object} scriptContext
         * @param {ServerRequest} scriptContext.request - Incoming request
         * @param {ServerResponse} scriptContext.response - Suitelet response
         * @since 2015.2
         */
        const customPrintFormat = {
            Aging_Report: 'SuiteScripts/SuiteScripts_GL/ECHEMI_AGING_Report_Template.xml',
        }

        const onRequest = (scriptContext) => {
            let request = scriptContext.request;
            let response = scriptContext.response;
            let params = request.parameters;
            // log.debug('params', params);

            if ('GET' == request.method) {
                let form = createForm(params);
                response.writePage(form);
            }
            else{
                let subsidiary = params.custpage_subsidiary,
                    location = params.custpage_location,
                    date = params.custpage_date;

                let subsidiaryDisplay = '';
                let subsidiarySearchObj = search.lookupFields({
                    type: 'subsidiary',
                    id: subsidiary,
                    columns: ['namenohierarchy']
                });
                if(subsidiarySearchObj){
                    subsidiaryDisplay = subsidiarySearchObj['namenohierarchy'];
                }
                let fileName = 'Echemi Aging Report_' + subsidiaryDisplay + '_' + params.inpt_custpage_location + '_' + date + '.xls';

                let fileData = getData(subsidiary, location, date);
                let xmlStr = getXml(fileName, fileData);
                //写文件
                response.writeFile(xmlStr);
            }
        }

        //获取报表关联的记录所涉及字段的data
        function getData(subsidiary, location, date) {
            let data = {};

            let oriSearchObj = search.load({id: 'customsearch_ecm_agingreport'});
            let filters = oriSearchObj.filters;
            let columns = oriSearchObj.columns;
            filters.push({"name":"subsidiary", "operator":"anyof", "values":[subsidiary], "isor":false, "isnot":false, "leftparens":0, "rightparens":0});
            if(location){
                filters.push({"name":"location", "operator":"anyof", "values":[location], "isor":false, "isnot":false, "leftparens":0, "rightparens":0});
            }
            filters.push({"name":"trandate", "operator":"onorbefore", "values":[date], "isor":false, "isnot":false, "leftparens":0, "rightparens":0});

            let newSearchObj = search.create({
                type: 'transaction',
                filters: filters,
                columns: columns
            });
            let results = commonApi.getAllData(newSearchObj);
            // log.debug('columns', columns);

            if(results && results.length > 0) {
                data = getAgingReportData(results, columns, date);
            }
            // log.debug('data',JSON.stringify(data));

            return data;
        }

        //获取报表Excel文件数据
        function getXml(fileName, fileData) {
            let printFormat = customPrintFormat.Aging_Report;

            let tempFile = file.load({
                id : printFormat
            });

            let t_render = render.create();
            //模板的内容
            t_render.templateContent = tempFile.getContents();

            t_render.addCustomDataSource({
                alias : 'data',
                format : render.DataSource.OBJECT,
                data : fileData
            });

            let excel_str = t_render.renderAsString();

            //将字符串转换为另一种类型的编码
            let fstr = encode.convert({
                string : excel_str,
                inputEncoding : encode.Encoding.UTF_8,
                outputEncoding : encode.Encoding.BASE_64
            });

            let excel = file.create({
                name : fileName,
                fileType : file.Type.EXCEL,
                contents : fstr
            });

            return excel;
        }

        //结果处理
        function getAgingReportData(results, columns, date) {
            let data = {};
            let list = [];//明细行

            let itemIdx = columns.findIndex(function(col) {
                return col.name === "item";
            });
            let serialNumIdx = columns.findIndex(function(col) {
                return col.name === "serialnumbers";
            });
            let statusIdx = columns.findIndex(function(col) {
                return col.name === "status" && col.join === "inventoryDetail";
            });
            results.sort(function (a,b){
                if(a.getValue(columns[itemIdx]) == b.getValue(columns[itemIdx]) && a.getValue(columns[serialNumIdx]) == b.getValue(columns[serialNumIdx])){ //如果item和批次相同
                    return a.getValue(columns[statusIdx]).localeCompare(b.getValue(columns[statusIdx])); //status
                }
                else if(a.getValue(columns[itemIdx]) == b.getValue(columns[itemIdx]) && a.getValue(columns[serialNumIdx]) != b.getValue(columns[serialNumIdx])){ //如果item相同,批次不同
                    return a.getValue(columns[serialNumIdx]).localeCompare(b.getValue(columns[serialNumIdx]));
                }
                else {
                    return a.getValue(columns[itemIdx]).localeCompare(b.getValue(columns[itemIdx]));
                }
            });
            for(let i = 0; i < results.length; i++) {
                let dataJson = {};
                for(let j = 0; j < columns.length;j++){
                    dataJson[(columns[j].join ? columns[j].join + '_' : '') + columns[j].name] = results[i].getText(columns[j]) ? results[i].getText(columns[j]) : results[i].getValue(columns[j]);
                }

                let day = getDaysBetween(dataJson.trandate, date);
                let lineJson = {
                    'subsidiary': isNull(dataJson.subsidiarynohierarchy),
                    'location': isNull(dataJson.location),
                    'item': isNull(dataJson.item),
                    'spu_class': isNull(dataJson.item_custitem_ecm_spuclass),
                    'lot_no' : isNull(dataJson.serialnumbers),
                    'status': isNull(dataJson.inventoryDetail_status),
                    'unit_cost': Number(isNull(dataJson.item_averagecost)).toFixedNew(2),
                    'days_1_30_qty': isNull(hasValue(dataJson.quantity, day, [1, 30])),
                    'days_1_30_amt': isNull(hasValue(dataJson.fxamount, day, [1, 30])),
                    'days_31_60_qty': isNull(hasValue(dataJson.quantity, day, [31, 60])),
                    'days_31_60_amt': isNull(hasValue(dataJson.fxamount, day, [31, 60])),
                    'days_61_90_qty': isNull(hasValue(dataJson.quantity, day, [61, 90])),
                    'days_61_90_amt': isNull(hasValue(dataJson.fxamount, day, [61, 90])),
                    'days_91_120_qty': isNull(hasValue(dataJson.quantity, day, [91, 120])),
                    'days_91_120_amt': isNull(hasValue(dataJson.fxamount, day, [91, 120])),
                    'days_121_180_qty': isNull(hasValue(dataJson.quantity, day, [121, 180])),
                    'days_121_180_amt': isNull(hasValue(dataJson.fxamount, day, [121, 180])),
                    'days_181_365_qty': isNull(hasValue(dataJson.quantity, day, [181, 365])),
                    'days_181_365_amt': isNull(hasValue(dataJson.fxamount, day, [181, 365])),
                    'years_1_2_qty': isNull(hasValue(dataJson.quantity, day, [366, 730])),
                    'years_1_2_amt': isNull(hasValue(dataJson.fxamount, day, [366, 730])),
                    'above2years_qty': isNull(hasValue(dataJson.quantity, day, [731, 99999])),
                    'above2years_amt': isNull(hasValue(dataJson.fxamount, day, [731, 99999])),
                }

                let isNewLine = true;
                for(let k = 0; k < list.length; k++){
                    if(dataJson.item == list[k].item && dataJson.serialnumbers == list[k].lot_no && dataJson.inventoryDetail_status == list[k].status) {
                        isNewLine = false;
                        list[k].days_1_30_qty = Number(list[k].days_1_30_qty).add((Number(lineJson.days_1_30_qty)));
                        list[k].days_31_60_qty = Number(list[k].days_31_60_qty).add((Number(lineJson.days_31_60_qty)));
                        list[k].days_61_90_qty = Number(list[k].days_61_90_qty).add((Number(lineJson.days_61_90_qty)));
                        list[k].days_91_120_qty = Number(list[k].days_91_120_qty).add((Number(lineJson.days_91_120_qty)));
                        list[k].days_121_180_qty = Number(list[k].days_121_180_qty).add((Number(lineJson.days_121_180_qty)));
                        list[k].days_181_365_qty = Number(list[k].days_181_365_qty).add((Number(lineJson.days_181_365_qty)));
                        list[k].years_1_2_qty = Number(list[k].years_1_2_qty).add((Number(lineJson.years_1_2_qty)));
                        list[k].above2years_qty = Number(list[k].above2years_qty).add((Number(lineJson.above2years_qty)));

                        list[k].days_1_30_amt = Number(list[k].days_1_30_amt).add((Number(lineJson.days_1_30_amt)));
                        list[k].days_31_60_amt = Number(list[k].days_31_60_amt).add((Number(lineJson.days_31_60_amt)));
                        list[k].days_61_90_amt = Number(list[k].days_61_90_amt).add((Number(lineJson.days_61_90_amt)));
                        list[k].days_91_120_amt = Number(list[k].days_91_120_amt).add((Number(lineJson.days_91_120_amt)));
                        list[k].days_121_180_amt = Number(list[k].days_121_180_amt).add((Number(lineJson.days_121_180_amt)));
                        list[k].days_181_365_amt = Number(list[k].days_181_365_amt).add((Number(lineJson.days_181_365_amt)));
                        list[k].years_1_2_amt = Number(list[k].years_1_2_amt).add((Number(lineJson.years_1_2_amt)));
                        list[k].above2years_amt = Number(list[k].above2years_amt).add((Number(lineJson.above2years_amt)));
                    }
                }

                if(isNewLine && lineJson.item){
                    list.push(lineJson);
                }
            }
            data.list = list;
            data.len = list.length;

            return data;
        }

        //如果取值为空则单元格为空
        function isNull(someValue) {
            if(someValue == '' || someValue == null) {
                return '';
            } else {
                if (isNaN(someValue) && someValue.indexOf("&") >= 0) {
                    someValue = someValue.replace(/&/g, "&amp;");
                }
                return someValue;
            }
        }

        //获得两个日期之间的天数
        function getDaysBetween(date1, date2) {
            let startDate = Date.parse(date1);
            let endDate = Date.parse(date2);

            if(startDate > endDate){
                return 0;
            }
            else if(startDate == endDate){
                return 1;
            }
            else {
                return Math.ceil((endDate - startDate)/(60*60*24*1000));
            }
        }

        //值区间判定
        function hasValue(value, curNum, numArr) {
            if(typeof numArr != 'object' || numArr.length < 2){
                return 0;
            }
            if(curNum > numArr[0] && curNum < numArr[1]){
                return value;
            }
            return 0;
        }

        //创建页面
        function createForm(params) {
            let form = serverWidget.createForm({title: 'ECHEMI Aging Report', hideNavBar: false});
            form.clientScriptModulePath = './cs_ecm_agingreport_page.js';
            form.addSubmitButton({label: 'Run'});

            let locationArr = [];
            let subsidiaryField = form.addField({id: 'custpage_subsidiary', type: 'select', source: 'subsidiary', label: 'subsidiary'});
            subsidiaryField.isMandatory = true;
            if(params.subsidiary){
                subsidiaryField.defaultValue = params.subsidiary;
                locationArr = getAllLocation(params.subsidiary);
            }
            let locationField = form.addField({id: 'custpage_location', type: 'select', label: 'location'});
            locationField.addSelectOption({value: '', text: ''});
            locationArr.forEach(loc => {
                locationField.addSelectOption({value: loc.value, text: loc.text});
            });
            if(params.location){
                locationField.defaultValue = params.location;
            }

            let dateField = form.addField({id: 'custpage_date', type: 'date', label: 'date'});
            dateField.isMandatory = true;
            if(params.date){
                dateField.defaultValue = params.date;
            }
            else{
                let nowDate = new Date();
                dateField.defaultValue = nowDate;
            }

            return form;
        }

        // 获取所有与subsidiary相关的getAllLocation
        function getAllLocation(subsidiary) {
            let lcArr = [];
            let mySearchObj = search.create({
                type: 'location',
                filters: [
                    ['subsidiary', 'anyof', subsidiary]
                ],
                columns: [
                    search.createColumn({name: 'name', sort: search.Sort.ASC, label: 'Name'}),
                ]
            });
            let columns = mySearchObj.columns;
            let res = commonApi.getAllData(mySearchObj);
            if(res && res.length > 0){
                for(let i = 0;i < res.length;i++){
                    let json = {};
                    json.value = res[i].id;
                    json.text = res[i].getValue(columns[0]);
                    lcArr.push(json);
                }
            }
            return lcArr;
        }

        return {onRequest}

    });
