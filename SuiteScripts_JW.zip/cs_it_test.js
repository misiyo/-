/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */
define(['N/currentRecord', 'N/search'],
/**
 * @param{currentRecord} currentRecord
 */
function(currentRecord,search) {
    var inventorySublistId = 'inventoryassignment';
    var subId = 'inventory';

    /**
     * Function to be executed after page is initialized.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.mode - The mode in which the record is being accessed (create, copy, or edit)
     *
     * @since 2015.2
     */
    function pageInit(scriptContext) {
        if(scriptContext.currentRecord.type == 'transferorder') {
            initToData();
        } else {
            initITDataFromSp();
        }
    }

    function initITDataFromSp() {
        console.log('initSpData=========>');
        var obj = currentRecord.get();
        obj.setValue({fieldId:'custbody_ecm_sp', value:1});
        obj.setText({fieldId: 'trandate', text: '3/3/2023', ignoreFieldChange: false});
        obj.setValue({fieldId: 'subsidiary', value: '30', ignoreFieldChange: false, forceSyncSourcing: true});
        obj.setValue({fieldId: 'memo', value: 12, ignoreFieldChange: true});
        /*setTimeout(function () {
        },300);*/
        obj.setValue({fieldId: 'location', value: 120, forceSyncSourcing: true});
        obj.setValue({fieldId: 'transferlocation', value: 325, forceSyncSourcing: true});
        // console.log(nlapiSetFieldValue('location', 120, false, true));
        // console.log(nlapiSetFieldValue('transferlocation', 325, false, true));
        //var scdLineIdInfo = getScdLine(1);
        var scdLineIdInfo = [
            {item: 1186, batch: 153, qty: 10},
            // {item: 571, batch: 154, qty: 20}
        ];
        for (var i = 0; i < scdLineIdInfo.length; i++) {

            // obj.selectNewLine({sublistId:subId});
            obj.selectLine({sublistId:subId, line: i});
            obj.setCurrentSublistValue({sublistId: subId, fieldId:'item', value: scdLineIdInfo[i].item, forceSyncSourcing:true}); // 货品
            obj.setCurrentSublistValue({sublistId: subId, fieldId:'adjustqtyby', value: scdLineIdInfo[i].qty, forceSyncSourcing: true});  // 待转移数量
            obj.setCurrentSublistValue({sublistId: subId, fieldId:'custcol_ecm_spline', value: 1, forceSyncSourcing: true}); // SCD Line记录
            var inventorydetail = obj.getCurrentSublistSubrecord({ sublistId: subId, fieldId: 'inventorydetail'});
            var invLength = inventorydetail.getLineCount({sublistId: 'inventoryassignment'});
            inventorydetail.selectNewLine({sublistId: 'inventoryassignment'});
            inventorydetail.setSublistValue({sublistId: 'inventoryassignment', fieldId: 'issueinventorynumber', value: scdLineIdInfo[i].batch, line: 0});
            inventorydetail.setSublistValue({sublistId: 'inventoryassignment', fieldId: 'quantity', value: scdLineIdInfo[i].qty, line: 0});
            inventorydetail.commitLine({sublistId: 'inventoryassignment'});
            /*inventorydetail.selectNewLine({sublistId: inventorySublistId});
            inventorydetail.setCurrentSublistValue({sublistId: inventorySublistId, fieldId: 'issueinventorynumber', value: scdLineIdInfo[i].batch});//序号批次号
            inventorydetail.setCurrentSublistValue({sublistId: inventorySublistId, fieldId: 'inventorystatus', value: status, forceSyncSourcing:true});//
            inventorydetail.setCurrentSublistValue({sublistId: inventorySublistId, fieldId: 'toinventorystatus', value: status, forceSyncSourcing:true});//
            inventorydetail.setCurrentSublistValue({sublistId: inventorySublistId, fieldId: 'quantity', value: scdLineIdInfo[i].qty, forceSyncSourcing:true});//数量
            inventorydetail.commitLine({sublistId: inventorySublistId});*/
            obj.commitLine({sublistId: 'inventory'});
        }
    }

    function initToData () {
        var obj = currentRecord.get();
        obj.setValue({fieldId: 'subsidiary', value: '30', ignoreFieldChange: false, forceSyncSourcing: true});
        obj.setValue({fieldId: 'location', value: 120, forceSyncSourcing: true});
        obj.setValue({fieldId: 'transferlocation', value: 325, forceSyncSourcing: true});
        var scdLineIdInfo = [
            {item: 1186, batch: 153, qty: 10},
            // {item: 571, batch: 154, qty: 20}
        ];
        for (var i = 0; i < scdLineIdInfo.length; i++) {
            obj.selectLine({sublistId:'item', line: i});
            obj.setCurrentSublistValue({sublistId: 'item', fieldId:'item', value: scdLineIdInfo[i].item, forceSyncSourcing:true}); // 货品
            obj.setCurrentSublistValue({sublistId: 'item', fieldId:'quantity', value: scdLineIdInfo[i].qty, forceSyncSourcing: true});  // 待转移数量
            // obj.setCurrentSublistValue({sublistId: 'item', fieldId:'custcol_ecm_spline', value: 1, forceSyncSourcing: true}); // SCD Line记录
            var inventorydetail = obj.getCurrentSublistSubrecord({ sublistId: 'item', fieldId: 'inventorydetail'});
            var invLength = inventorydetail.getLineCount({sublistId: inventorySublistId});
            console.log('库存行====' + invLength);
            for(var il = invLength - 1; il >= 0; il--) {
                inventorydetail.removeLine({sublistId: inventorySublistId, line: il});
            }
            inventorydetail.selectNewLine({sublistId: inventorySublistId});
            inventorydetail.setSublistValue({sublistId: inventorySublistId, fieldId: 'issueinventorynumber', value: scdLineIdInfo[i].batch, line: 0});
            inventorydetail.setSublistValue({sublistId: inventorySublistId, fieldId: 'quantity', value: scdLineIdInfo[i].qty, line: 0});
            inventorydetail.commitLine({sublistId: inventorySublistId});
            obj.commitLine({sublistId: 'inventory'});
        }
    }

    /**
     * 查询shipping plan对应的Sales Contract Distribution Line
     * @param spId
     * @returns {[]}
     */
    function getScdLine(spId){
        var myFilters = [];
        myFilters.push(['isinactive', 'is', 'false']);
        myFilters.push('and');
        myFilters.push(['custrecord_scdline_sp', 'anyof', spId]);
        var myColumns = [];
        myColumns.push('internalid');   // scd id
        var mySearch = search.create({
            type:'customrecord_ecm_scd_line',
            filters:myFilters,
            columns:myColumns
        });
        var myResult = mySearch.run().getRange({start:0, end:1000});
        var scdLineIdArr = [];
        if (myResult && myResult.length > 0){
            for (var i = 0; i < myResult.length; i++){
                var scdLineId = myResult[i].getValue(myColumns[0]);
                scdLineIdArr.push(scdLineId);
            }
        }
        log.debug('scdLineIdArr',scdLineIdArr)
        console.log('scdLineIdArr===>'+scdLineIdArr)
        return scdLineIdArr;
    }

    /**
     * Function to be executed when field is changed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
     * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
     *
     * @since 2015.2
     */
    function fieldChanged(scriptContext) {

    }

    /**
     * Function to be executed when field is slaved.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     *
     * @since 2015.2
     */
    function postSourcing(scriptContext) {

    }

    /**
     * Function to be executed after sublist is inserted, removed, or edited.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @since 2015.2
     */
    function sublistChanged(scriptContext) {

    }

    /**
     * Function to be executed after line is selected.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @since 2015.2
     */
    function lineInit(scriptContext) {

    }

    /**
     * Validation function to be executed when field is changed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
     * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
     *
     * @returns {boolean} Return true if field is valid
     *
     * @since 2015.2
     */
    function validateField(scriptContext) {

    }

    /**
     * Validation function to be executed when sublist line is committed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateLine(scriptContext) {

    }

    /**
     * Validation function to be executed when sublist line is inserted.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateInsert(scriptContext) {

    }

    /**
     * Validation function to be executed when record is deleted.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateDelete(scriptContext) {

    }

    /**
     * Validation function to be executed when record is saved.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @returns {boolean} Return true if record is valid
     *
     * @since 2015.2
     */
    function saveRecord(scriptContext) {

    }

    return {
        pageInit: pageInit,
        /*fieldChanged: fieldChanged,
        postSourcing: postSourcing,
        sublistChanged: sublistChanged,
        lineInit: lineInit,
        validateField: validateField,
        validateLine: validateLine,
        validateInsert: validateInsert,
        validateDelete: validateDelete,
        saveRecord: saveRecord*/
    };
    
});
