/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 *
 * Version      Date            Author          Memo
 * 1.0          2022/12/18      John Wang       销售订单创建采购安排CS（1017754）
 */
define(['N/currentRecord', 'N/search', 'N/url'],
/**
 * @param{currentRecord} currentRecord
 * @param{search} search
 */
function(currentRecord, search, url) {
    const SUB_ID = 'hc_list';
    const _PREFIX = 'custpage_';
    const filterFields = [
        {id: 'customer', key: 'customer'},
        {id: 'tranid', key: 'tranid'},
        {id: 'item', key: 'item'}
    ]
    const resultFields = [
        {id: 'l_item', key: 'item'},
        {id: 'l_type', key: 'sctype'},
        {id: 'l_pa_sku', key: 'paItem'},
        {id: 'l_pa_qty', key: 'thisQty'},
        {id: 'l_vendor', key: 'vendor'},
        {id: 'l_location', key: 'location'},
        {id: 'l_sc_customer', key: 'customer'},
        {id: 'l_exp_date', key: 'expdate', isText: true},
        // {id: 'l_usedqty', key: 'usedqty'},
        // {id: 'l_lastqty', key: 'lastqty'},
        {id: 'l_scid', key: 'scid'},
        {id: 'l_lineid', key: 'lineid'},
    ]
    /**
     * Function to be executed after page is initialized.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.mode - The mode in which the record is being accessed (create, copy, or edit)
     *
     * @since 2015.2
     */
    var isEng = false;
    function pageInit(scriptContext) {
        var obj = currentRecord.get();
        var lang = obj.getValue(_PREFIX + 'lang');
        if('zh_CN' != lang) {
            isEng = true;
        }
    }

    /**
     * Function to be executed when field is changed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
     * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
     *
     * @since 2015.2
     */
    function fieldChanged(scriptContext) {
        var fid = scriptContext.fieldId;
        var obj = currentRecord.get();

        if(_PREFIX + 'l_select' == fid) {
            var lineNo = obj.getCurrentSublistIndex({sublistId: SUB_ID});
            obj.selectLine({sublistId: SUB_ID,line: lineNo});
            var select = obj.getCurrentSublistValue({sublistId: SUB_ID, fieldId: fid});
            if(true == select || 'T' == select) {
                var thisQty = obj.getCurrentSublistValue({sublistId: SUB_ID, fieldId: _PREFIX + 'l_pa_qty'}),
                    thisSku = obj.getCurrentSublistValue({sublistId: SUB_ID, fieldId: _PREFIX + 'l_pa_sku'}),
                    thisVendor = obj.getCurrentSublistValue({sublistId: SUB_ID, fieldId: _PREFIX + 'l_vendor'}),
                    thisLocation = obj.getCurrentSublistValue({sublistId: SUB_ID, fieldId: _PREFIX + 'l_location'}),
                    lastQty = obj.getCurrentSublistValue({sublistId: SUB_ID, fieldId: _PREFIX + 'l_lastqty'}),
                    scType = obj.getCurrentSublistValue({sublistId: SUB_ID, fieldId: _PREFIX + 'l_type'});
                if('' == thisQty || '' == thisSku || '' == thisVendor || '' == thisLocation || '' == scType) {
                    alert(isEng ? '请输入以下字段：采购安排SKU/采购安排数量/供应商/仓库/类型！' : '请输入以下字段：采购安排SKU/采购安排数量/供应商/仓库/类型！');
                    obj.setCurrentSublistValue({sublistId: SUB_ID, fieldId: fid, value: false, ignoreFieldChange: true});
                    obj.commitLine(SUB_ID);
                }else if(thisQty <= 0) {
                    alert(isEng ? '本次采购安排数量不可小于0！' : '本次采购安排数量不可小于0!');
                    obj.setCurrentSublistValue({sublistId: SUB_ID, fieldId: fid, value: false, ignoreFieldChange: true});
                    obj.commitLine(SUB_ID);
                } else if(thisQty > lastQty) {
                    alert(isEng ? '本次采购安排数量不可大于' + lastQty + '!' : '本次采购安排数量不可大于' + lastQty + '!');
                    obj.setCurrentSublistValue({sublistId: SUB_ID, fieldId: fid, value: false, ignoreFieldChange: true});
                    obj.commitLine(SUB_ID);
                }
            }
        }
    }

    /**
     * Function to be executed when field is slaved.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     *
     * @since 2015.2
     */
    function postSourcing(scriptContext) {

    }

    /**
     * Function to be executed after sublist is inserted, removed, or edited.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @since 2015.2
     */
    function sublistChanged(scriptContext) {

    }

    /**
     * Function to be executed after line is selected.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @since 2015.2
     */
    function lineInit(scriptContext) {

    }

    /**
     * Validation function to be executed when field is changed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
     * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
     *
     * @returns {boolean} Return true if field is valid
     *
     * @since 2015.2
     */
    function validateField(scriptContext) {

    }

    /**
     * Validation function to be executed when sublist line is committed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateLine(scriptContext) {

    }

    /**
     * Validation function to be executed when sublist line is inserted.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateInsert(scriptContext) {

    }

    /**
     * Validation function to be executed when record is deleted.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateDelete(scriptContext) {

    }

    /**
     * Validation function to be executed when record is saved.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @returns {boolean} Return true if record is valid
     *
     * @since 2015.2
     */
    function saveRecord(scriptContext) {
        var obj = currentRecord.get();
        var length = obj.getLineCount(SUB_ID);
        var selectedData = [];
        for(var i = 0; i < length; i++) {
            var select = obj.getSublistValue({sublistId: SUB_ID, fieldId: _PREFIX + 'l_select', line: i});
            if(select || true == select || 'T' == select) {
                var json = {};
                resultFields.forEach(function (field) {
                    json[field.key] = true == field.isText ? obj.getSublistText({sublistId: SUB_ID, fieldId: _PREFIX + field.id, line: i}) : obj.getSublistValue({sublistId: SUB_ID, fieldId: _PREFIX + field.id, line: i});
                });
                selectedData.push(json);
            }
        }
        if(0 == selectedData) {
            alert(isEng ? '请至少选中一行!' : '请至少选中一行!');
            return false;
        }
        obj.setValue(_PREFIX + 'alldata', JSON.stringify(selectedData));
        console.error(JSON.stringify(selectedData));
        // alert('Testing');
        return true;
    }

    function doSearch() {
        var obj = currentRecord.get();
        if('' == obj.getValue(_PREFIX + 'customer')) {
            alert('请选择客户！');
            return;
        }
        var turl = url.resolveScript({
            scriptId: 'customscript_ecm_so2purarrange_sl',
            deploymentId: 'customdeploy_ecm_so2purarrange_sl'
        });
        filterFields.forEach(function (field) {
            var val = obj.getValue(_PREFIX + field.id);
            if('' != val && -1 != val) {
                turl += '&' + field.key + '=' + encodeURIComponent(val);
            }
        });
        setWindowChanged(window, false);
        window.location.href = turl;
    }

    return {
        pageInit: pageInit,
        fieldChanged: fieldChanged,
        /*postSourcing: postSourcing,
        sublistChanged: sublistChanged,
        lineInit: lineInit,
        validateField: validateField,
        validateLine: validateLine,
        validateInsert: validateInsert,
        validateDelete: validateDelete,*/
        saveRecord: saveRecord,
        doSearch: doSearch
    };
    
});
