/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 *
 * Version      Date            Author          Memo
 * 1.0          2023/02/16      John Wang       SalesContract下推ShippingSchedule（1018529）
 * 2.0          2023/03/01      John Wang       新增明细行带值字段（1018529）
 * 3.0          2023/03/20      John Wang       页面字段变更（1018529）
 * 4.0          2023/03/22      John Wang       sc字段值新增contractType判断（1018529）
 * 5.0          2023/03/30      John Wang       优化：明细行sourcing字段控制不塞值；取消SC客户状态=approved限制（1018529）
 * 6.0          2023/04/05      John Wang       变更：shipVia&loadingPort&destinationPort取值变更（1018529）
 * 6.0          2023/04/05      John Wang       优化：当前用户仅可查看自己的单据（管理员无此限制）（1018529）
 */
define(['N/record', 'N/redirect', 'N/runtime', 'N/search', 'N/task', 'N/query', 'N/ui/serverWidget', '/SuiteScripts/tools/common_api.js'],
    /**
 * @param{record} record
 * @param{redirect} redirect
 * @param{runtime} runtime
 * @param{search} search
 * @param{task} task
 * @param{serverWidget} serverWidget
 */
    (record, redirect, runtime, search, task, query, serverWidget, commonApi) => {
        const prefix = 'custpage_';
        const SS_TYPE = 'customrecord_shipping_schedule';//shipping schedule type
        const SS_SUBID = 'recmachcustrecord_sscd_parent';//shipping schedule sublistid
        const PAGE_OPTIONS = () => {
            const title = 'SC Create Shipping Schedule';
            let bodyFields = [
                {id: `${prefix}sctype`, label: 'SC Type', type: serverWidget.FieldType.SELECT, key: 'sctype', source: 'customlist_ecm_pricetype', isMandatory: true, display: serverWidget.FieldDisplayType.INLINE},
                {id: `${prefix}location`, label: 'Location', type: serverWidget.FieldType.SELECT, key: 'location', optionFunc: 'formatLocationData(${subid})'},
                {id: `${prefix}shipvia`, label: 'Ship Via', type: serverWidget.FieldType.SELECT, key: 'shipvia', source: 'customrecord_ecm_shippingmethod', display: serverWidget.FieldDisplayType.DISABLED},
                {id: `${prefix}shipdate`, label: 'Shipment Date', type: serverWidget.FieldType.DATE},
                {id: `${prefix}port`, label: 'Loading Port', type: serverWidget.FieldType.SELECT, key: 'port', source: 'customrecord_ecm_loaddest_ports', display: serverWidget.FieldDisplayType.DISABLED},
                {id: `${prefix}destination`, label: 'Destination Port', type: serverWidget.FieldType.SELECT, key: 'destination', source: 'customrecord_ecm_loaddest_ports', display: serverWidget.FieldDisplayType.DISABLED},
            ];
            let sublistFields = [
                {id: `${prefix}selected`, label: 'Selected', type: serverWidget.FieldType.CHECKBOX},
                {id: `${prefix}item`, label: 'SKU', type: serverWidget.FieldType.SELECT, source: 'item', key: 'item', displayType: serverWidget.FieldDisplayType.DISABLED},
                {id: `${prefix}unit`, label: 'Unit', type: serverWidget.FieldType.TEXT, source: 'unitstype', key: 'unit', displayType: serverWidget.FieldDisplayType.DISABLED},
                {id: `${prefix}qty`, label: 'SC QTY', type: serverWidget.FieldType.TEXT, key: 'qty'},
                {id: `${prefix}qtycreated`, label: 'SC QTY(Created)', type: serverWidget.FieldType.TEXT, key: 'qtycreated', displayType: serverWidget.FieldDisplayType.DISABLED},
                {id: `${prefix}lastqty`, label: '剩余数量', type: serverWidget.FieldType.TEXT, key: 'lastqty', displayType: serverWidget.FieldDisplayType.HIDDEN},
                {id: `${prefix}thisqty`, label: 'QTY(This Turn)', type: serverWidget.FieldType.FLOAT, displayType: serverWidget.FieldDisplayType.ENTRY},
                {id: `${prefix}isfilm`, label: 'Is Pallet&Stretch Film', type: serverWidget.FieldType.CHECKBOX},
                {id: `${prefix}qty_pricing`, label: 'QTY(Pricing Unit)', type: serverWidget.FieldType.TEXT, displayType: serverWidget.FieldDisplayType.ENTRY},
                {id: `${prefix}capacity`, label: 'Unit Capacity', type: serverWidget.FieldType.TEXT, key: 'capacity', displayType: serverWidget.FieldDisplayType.ENTRY},
                {id: `${prefix}sourcing`, label: 'Sourcing', type: serverWidget.FieldType.SELECT, source: 'employee', key: 'sourcing', displayType: serverWidget.FieldDisplayType.DISABLED},
                {id: `${prefix}lineid`, label: 'Line ID', type: serverWidget.FieldType.TEXT, key: 'lineId'},
                {id: `${prefix}lineno`, label: 'Line NO', type: serverWidget.FieldType.TEXT, key: 'lineNo', displayType: serverWidget.FieldDisplayType.HIDDEN},
                {id: `${prefix}netweight`, label: '净重', type: serverWidget.FieldType.TEXT, key: 'netWeight', displayType: serverWidget.FieldDisplayType.HIDDEN},
                {id: `${prefix}grossweight`, label: '毛重', type: serverWidget.FieldType.TEXT, key: 'grossWeight', displayType: serverWidget.FieldDisplayType.HIDDEN},
                {id: `${prefix}othercost`, label: 'Other Cost', type: serverWidget.FieldType.TEXT, key: 'otherCost', displayType: serverWidget.FieldDisplayType.HIDDEN},
                {id: `${prefix}termcost`, label: 'Term Cost', type: serverWidget.FieldType.TEXT, key: 'termCost', displayType: serverWidget.FieldDisplayType.HIDDEN},
                {id: `${prefix}palletcost`, label: 'Pallet Cost', type: serverWidget.FieldType.TEXT, key: 'palletCost', displayType: serverWidget.FieldDisplayType.HIDDEN},
                {id: `${prefix}profit`, label: 'Profit', type: serverWidget.FieldType.TEXT, key: 'profit', displayType: serverWidget.FieldDisplayType.HIDDEN},
                {id: `${prefix}freight`, label: 'Freight', type: serverWidget.FieldType.TEXT, key: 'freight', displayType: serverWidget.FieldDisplayType.HIDDEN},
                {id: `${prefix}tariff`, label: 'Tariff', type: serverWidget.FieldType.TEXT, key: 'tariff', displayType: serverWidget.FieldDisplayType.HIDDEN},
                {id: `${prefix}ofreight`, label: 'Ocean Freight', type: serverWidget.FieldType.TEXT, key: 'ofreight', displayType: serverWidget.FieldDisplayType.HIDDEN},
                {id: `${prefix}insurancefee`, label: '人保费', type: serverWidget.FieldType.TEXT, key: 'insurancefee', displayType: serverWidget.FieldDisplayType.HIDDEN},
                {id: `${prefix}clearancefee`, label: '清关费', type: serverWidget.FieldType.TEXT, key: 'clearancefee', displayType: serverWidget.FieldDisplayType.HIDDEN},
                {id: `${prefix}storagefee`, label: '仓储费', type: serverWidget.FieldType.TEXT, key: 'storagefee', displayType: serverWidget.FieldDisplayType.HIDDEN},
                {id: `${prefix}certififee`, label: '检验认证费', type: serverWidget.FieldType.TEXT, key: 'certififee', displayType: serverWidget.FieldDisplayType.HIDDEN},
                {id: `${prefix}rate`, label: 'rate', type: serverWidget.FieldType.TEXT, key: 'rate', displayType: serverWidget.FieldDisplayType.HIDDEN},
                {id: `${prefix}taxcode`, label: '税码', type: serverWidget.FieldType.TEXT, key: 'taxcode', displayType: serverWidget.FieldDisplayType.HIDDEN},
                {id: `${prefix}taxrate`, label: '税率', type: serverWidget.FieldType.TEXT, key: 'taxrate', displayType: serverWidget.FieldDisplayType.HIDDEN},
            ];

            let btns = [
                {id: `${prefix}search`, label: 'Search', func: 'doSearch'},
                {id: `${prefix}refresh`, label: 'Refresh', func: 'doRefresh'}
            ];

            return {title, bodyFields, sublistFields, btns};
        }
        /**
         * Defines the Suitelet script trigger point.
         * @param {Object} scriptContext
         * @param {ServerRequest} scriptContext.request - Incoming request
         * @param {ServerResponse} scriptContext.response - Suitelet response
         * @since 2015.2
         */
        const onRequest = (scriptContext) => {
            let request = scriptContext.request,
                response = scriptContext.response;
            let params = request.parameters;
            if('GET' == request.method) {
                let form = createForm(params);
                response.writePage(form);
            } else {
                let allData = params.custpage_alldata,
                    scid = params.custpage_tranid;
                log.debug('params==' + scid, allData);
                try {
                    if(allData && '' != allData) {
                        allData = JSON.parse(allData);
                        let body = allData.body,
                            lines = allData.lines;
                        let obj = record.create({type: SS_TYPE, isDynamic: true});
                        obj.setText({fieldId: 'custrecord_ssc_vessel_deadline', text: body['custrecord_ssc_vessel_deadline']});
                        delete body['custrecord_ssc_vessel_deadline'];
                        for(key in body) {
                            obj.setValue({fieldId: key, value: body[key]});
                        }
                        lines.forEach(function (line, index) {
                            obj.selectNewLine({sublistId: SS_SUBID});
                            for(key in line){
                                obj.setCurrentSublistValue({sublistId: SS_SUBID, fieldId: key, value: line[key]});
                            }
                            obj.commitLine({sublistId: SS_SUBID});
                        });
                        let ssid = obj.save({ignoreMandatoryFields: true, enableSourcing: true});
                        log.debug('soCreateSS===' + scid, ssid);
                        redirect.toRecord({type: SS_TYPE, id: ssid});
                    }
                } catch (e) {
                    log.error('createSSError==>' + scid, e);
                    redirect.toSuitelet({scriptId: 'customscript_ecm_contract2schedule_sl', deploymentId: 'customdeploy_ecm_contract2schedule_sl'});
                }
            }
        }

        /**
         * 根据子公司格式化子公司数据
         * @param subid
         * @return {{}}     {id:name}
         */
        const formatLocationData = subid => {
            var locData = {},
                filters = [], columns = [];
            if(!subid || '' == subid) {
                return locData;
            }
            filters.push(['subsidiary', 'anyof', subid]);
            filters.push('and');
            filters.push(['isinactive', 'is', false]);
            columns.push('name');
            var results = search.create({type: 'location', filters: filters, columns: columns}).run().getRange({start: 0, end: 1000});
            if(results && results.length > 0) {
                results.forEach(function (data) {
                    locData[data.id] = data.getValue(columns[0]);
                });
            }
            return locData;
        }

        const createForm = params => {
            let {title, bodyFields, sublistFields, btns} = PAGE_OPTIONS();
            let form = serverWidget.createForm({title: title});
            form.clientScriptModulePath = '/SuiteScripts/SuiteScripts_JW/cs_scontract_to_shippingschedule_page.js';
            form.addSubmitButton({label: 'Create SS'});
            btns.forEach(function (info) {
                form.addButton({id: info.id, label: info.label, functionName: info.func});
            });

            form.addField({id: `${prefix}alldata`, label: 'All Data', type: serverWidget.FieldType.LONGTEXT}).updateDisplayType({displayType: serverWidget.FieldDisplayType.HIDDEN});
            //filters
            form.addFieldGroup({id: 'cuetpage_gp_filters', label: 'Filters'});
            let contractData = formatSalesContractData();//销售合同数据
            let scnoField = form.addField({id: `${prefix}tranid`, label: 'SC No.', type: serverWidget.FieldType.SELECT, container: 'cuetpage_gp_filters'}),
                customerField = form.addField({id: `${prefix}customer`, label: 'Customer', type: serverWidget.FieldType.SELECT, source: 'customer', container: 'cuetpage_gp_filters'}).updateDisplayType({displayType: serverWidget.FieldDisplayType.DISABLED}),
                subField = form.addField({id: `${prefix}subsidiary`, label: 'Subsidiary', type: serverWidget.FieldType.SELECT, container: 'cuetpage_gp_filters'}).updateDisplayType({displayType: serverWidget.FieldDisplayType.DISABLED});
            let subsidiaryData = formatSubsidiaryData();
            subField.addSelectOption({value: -1, text: ' '});
            for(key in subsidiaryData) {
                subField.addSelectOption({value: key, text: subsidiaryData[key]});
            }
            scnoField.isMandatory = true;
            scnoField.addSelectOption({value: -1, text: ' '});
            contractData.forEach(function (data) {
                scnoField.addSelectOption({value: data.id, text: data.tranid, isSelected: params.scid == data.id ? true : false});
                if(params.scid == data.id) {
                    customerField.defaultValue = data.entity;
                    subField.defaultValue = data.subsidiary;
                }
            });
            form.addFieldGroup({id: 'cuetpage_body_info', label: 'SS Body Info'});
            bodyFields.forEach(function (info) {
                let field = form.addField({id: info.id, label: info.label, type: info.type, source: info.source, container: 'cuetpage_body_info'});
                if(true == info.isMandatory) {
                    field.isMandatory = true;
                }
                if(info.display) {
                    field.updateDisplayType({displayType: info.display});
                }
                if(info.optionFunc) {
                    field.addSelectOption({value: -1, text: ' '});
                    let optData = eval(info.optionFunc.replace('${subid}', params.subid));
                    log.debug('optData', optData);
                    for(key in optData) {
                        field.addSelectOption({value: key, text: optData[key]});
                    }
                }
                if(params[info.key]) {
                    field.defaultValue = params[info.key];
                }
            });
            let sublist = form.addSublist({id: 'ecm_list', label: 'Search Result', type: 'list'});
            sublistFields.forEach(function (info) {
                let thisField = sublist.addField({id: info.id, label: info.label, type: info.type, source: info.source});
                if(info.displayType) {
                    thisField.updateDisplayType({displayType: info.displayType});
                }
                if(`${prefix}capacity` == info.id || `${prefix}qty_pricing` == info.id) {
                    thisField.updateDisplayType({displayType: serverWidget.FieldDisplayType.DISABLED});
                }
            });
            if(params.scid) {
                let scLineData = formatContractLineData(params.scid);
                if(scLineData && scLineData.length > 0) {
                    let sublistValueFields = sublistFields.filter(info => 'undefined' != typeof info.key);
                    scLineData.forEach(function (data, index) {
                        sublistValueFields.forEach(function (info) {
                            if(data[info.key] && '' != data[info.key]) {
                                sublist.setSublistValue({id: info.id, line: index, value: data[info.key] || ' '});
                            }
                        });
                    });
                }
            }
            return form;
        }

        /**
         * 格式化子公司数据
         * @return {{}}             {id：name}
         */
        const formatSubsidiaryData = () => {
            let subData = {};//{id:name}
            let filters = [], columns = [];
            filters.push(['isinactive', 'is', false]);
            columns.push('namenohierarchy');
            let results = search.create({type: 'subsidiary', filters: filters, columns: columns}).run().getRange({start: 0, end: 1000});
            if(results && results.length > 0) {
                results.forEach(function (data) {
                    subData[data.id] = data.getValue(columns[0]);
                });
            }
            return subData;
        }

        /**
         * 格式化销售合同数据
         * @return {[]}                 [{id:soid,tranid:tranid,entity:客户,subsidiary:子公司}]
         */
        const formatSalesContractData = () => {
            let contractData = [],
                filters = [], columns = [],
                typeFilters = [];
            typeFilters.push(['custbody_ecm_contract_type', 'anyof', 6]);//contract type：Stock Up（6）
            typeFilters.push('or');
            typeFilters.push(['custbody_ecm_ordertype', 'anyof', 1]);//contract
            filters.push(typeFilters);
            // filters.push('and');
            // filters.push(['customermain.custentity_ecm_approvalstatus', 'anyof', 3]);
            filters.push('and');
            filters.push(['customermain.isinactive', 'is', false]);
            filters.push('and');
            filters.push(['mainline', 'is', false]);
            filters.push('and');
            filters.push(['taxline', 'is', false]);
            filters.push('and');
            filters.push(["formulanumeric: {quantity}-NVL({custcol_ecm_shipings_qty_created},0)","greaterthan","0"]);
            filters.push('and');
            filters.push(['custbody_ecm_contract_type', 'noneof', '@NONE@']);
            let user = runtime.getCurrentUser();
            if(3 != user.role) {
                filters.push('and');
                filters.push(['salesteammember', 'anyof', user.id]);
            }
            columns.push(search.createColumn({
                name: 'internalid',
                summary: 'GROUP'
            }));
            columns.push(search.createColumn({
                name: 'tranid',
                summary: 'GROUP'
            }));
            columns.push(search.createColumn({
                name: 'entity',
                summary: 'GROUP'
            }));
            columns.push(search.createColumn({
                name: 'subsidiary',
                summary: 'GROUP'
            }));
            let results = search.create({type: 'salesorder', filters: filters, columns: columns}).run().getRange({start: 0, end: 1000});
            if(results && results.length > 0) {
                results.forEach(function (data) {
                    contractData.push({
                        id: data.getValue(columns[0]),
                        tranid: data.getValue(columns[1]),
                        entity: data.getValue(columns[2]),
                        subsidiary: data.getValue(columns[3])
                    });
                });
            }
            log.debug('销售合同数据===>' + contractData.length, contractData);
            return contractData;
        }
        
        /**
         * 格式化SC明细行数据
         * @param scid
         * @return {[]}             [{lineId：行id，item：货品，unit：单位，qty：数量，qtycreated：已下推数量，capacity：''，sourcing：'', lastqty：剩余ss数量，lineNo：行号}]
         */
        const formatContractLineData = scid => {
            let lineData = [],
                filters = [], columns = [];
            //需格式化key
            let formattedKeys = ['capacity', 'netWeight', 'grossWeight', 'otherCost', 'termCost', 'palletCost', 'profit', 'freight' , 'tariff', 'ofreight', 'insurancefee' , 'clearancefee', 'storagefee', 'certififee'];
            filters.push(['mainline', 'is', false]);
            filters.push('and');
            filters.push(['taxline', 'is', false]);
            filters.push('and');
            filters.push(['internalid', 'anyof', scid]);
            filters.push('and');
            filters.push(["formulanumeric: {quantity}-NVL({custcol_ecm_shipings_qty_created},0)",'greaterthan', 0]);

            columns.push('custcol_ecm_uniquekey');
            columns.push('item');
            // columns.push(search.createColumn({name: 'saleunit', join: 'item'}));
            columns.push('unit');
            columns.push('quantity');
            columns.push('custcol_ecm_shipings_qty_created');
            columns.push(search.createColumn({name: 'custitem_ecm_case_package_kg', join: 'item'}));
            columns.push(search.createColumn({name: 'custitem_ecm_specifiedpurchaser', join: 'item'}));
            columns.push('custcol_emc_line_no');
            columns.push('custcol_ecm_other_cost');
            columns.push('custcol_ecm_payment_term_cost');
            columns.push('custcol_ecm_pallet_cost');//10
            columns.push('custcol_ecm_profit');
            columns.push('custcol_ecm_landfreight');
            columns.push('custcol_ecm_tariff');
            columns.push('custcol_ecm_oceanfreight');
            columns.push('custcol_ecm_insurancefee');
            columns.push('custcol_ecm_customs_clearancefee');
            columns.push('custcol_ecm_storagefee');
            columns.push('custcol_ecm_inspe_certifi_fee');
            columns.push('custcol_ecm_net_weight');
            columns.push('custcol_ecm_gross_weight');//20
            columns.push('fxrate');
            columns.push('taxcode');
            columns.push(search.createColumn({
                name: 'rate',
                join: 'taxitem'
            }));
            let results = search.create({type: 'salesorder', filters: filters, columns: columns}).run().getRange({start: 0, end: 1000});
            log.debug('results', results)
            if(results && results.length > 0) {
                results.forEach(function (data) {
                    let json = {
                        lineId: data.getValue(columns[0]),
                        item: data.getValue(columns[1]),
                        unit: data.getValue(columns[2]),
                        qty: data.getValue(columns[3]),
                        qtycreated: data.getValue(columns[4]) || '0',
                        capacity: data.getValue(columns[5]),
                        sourcing: data.getValue(columns[6]),
                        lineNo: data.getValue(columns[7]),
                        otherCost: data.getValue(columns[8]),
                        termCost: data.getValue(columns[9]),
                        palletCost: data.getValue(columns[10]),
                        profit: data.getValue(columns[11]),
                        freight: data.getValue(columns[12]),
                        tariff: data.getValue(columns[13]),
                        ofreight: data.getValue(columns[14]),
                        insurancefee: data.getValue(columns[15]),
                        clearancefee: data.getValue(columns[16]),
                        storagefee: data.getValue(columns[17]),
                        certififee: data.getValue(columns[18]),
                        netWeight: data.getValue(columns[19]),
                        grossWeight: data.getValue(columns[20]),
                        rate: data.getValue(columns[21]),
                        taxcode: data.getValue(columns[22]),
                        taxrate: data.getValue(columns[23])

                    };
                    formattedKeys.forEach(function (key) {
                        if(json[key] < 1) {
                            json[key] = '' + Number(json[key]);
                        }
                    });
                    json.taxrate = json.taxrate.replace('%', '');
                    json.lastqty = Number(json.qty).sub(Number(json.qtycreated));
                    lineData.push(json);
                });
            }
            log.debug('solineData', lineData);
            return lineData;
        }

        return {onRequest}

    });
