/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */
define(['N/currentRecord', 'N/record', 'N/search', 'N/url'],
/**
 * @param{currentRecord} currentRecord
 * @param{record} record
 * @param{search} search
 * @param{url} url
 */
function(currentRecord, record, search, url) {
    const SUB_ID = 'hc_list';
    const _PREFIX = 'custpage_';
    const filterFields = [
        {id: 'pano', key: 'pano'},
        {id: 'item', key: 'item'}
    ]
    const resultFields = [
        {id: 'l_item', key: 'item'},
        {id: 'l_qty', key: 'qty'},
        {id: 'l_coa', key: 'coa'},
        {id: 'l_packinfo', key: 'packinfo'},
        {id: 'l_vendor', key: 'vendor'},
        //{id: 'l_cuy', key: 'cuy'},
        {id: 'l_rate', key: 'rate'},
        {id: 'l_soid', key: 'soid'},
        {id: 'l_palid', key: 'palid'},
        {id: 'l_lineid', key: 'lineid'}
    ]
    /**
     * Function to be executed after page is initialized.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.mode - The mode in which the record is being accessed (create, copy, or edit)
     *
     * @since 2015.2
     */
    var isEng = false;
    function pageInit(scriptContext) {
        var obj = currentRecord.get();
        var lang = obj.getValue(_PREFIX + 'lang');
        if('zh_CN' != lang) {
            isEng = true;
        }
    }

    /**
     * Function to be executed when field is changed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
     * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
     *
     * @since 2015.2
     */
    var testArray = ['valA', 'valB', 'valC'];
    var vendorCurrencysHTML = {};//{vnedorId: {cuyid:cuyname}}
    function fieldChanged(scriptContext) {
        var fieldId = scriptContext.fieldId;
        var obj = currentRecord.get();
        if(_PREFIX + 'l_vendor' == fieldId) {
            try {
                var vendor = obj.getCurrentSublistValue({sublistId: SUB_ID, fieldId: fieldId}),
                    index = obj.getCurrentSublistIndex({sublistId: SUB_ID});
                if(index > -1) {
                    if('' == vendor) {//清空vendor及币种
                        obj.setCurrentSublistValue({sublistId: SUB_ID, fieldId: _PREFIX + 'l_cuy', value: ''});
                        console.log(jQuery('#hc_list_custpage_l_cuy_html' + (index + 1) + '_fs').html('<select id="line_currency' + (index + 1) + '"><option value="-1"></option></select>'))
                    } else {
                        var cuyHtml = vendorCurrencysHTML[vendor];
                        if('undefined' == typeof thisHtml) {
                            cuyHtml = formatVendorCurrencyHtml(vendor, index);
                            vendorCurrencysHTML[vendor] = thisHtml;
                        }
                        var thisHtml = '<select id="line_currency' + (index + 1) + '"><option value="-1"></option>';
                        thisHtml += cuyHtml + '</select>';
                        obj.setCurrentSublistValue({sublistId: SUB_ID, fieldId: _PREFIX + 'l_cuy', value: ''});
                        obj.setCurrentSublistValue({sublistId: SUB_ID, fieldId: _PREFIX + 'l_select', value: false, ignoreFieldChange: true});
                        console.log(jQuery('#hc_list_custpage_l_cuy_html' + (index + 1) + '_fs').html(thisHtml));
                    }
                }
            } catch (e) {
                console.error(JSON.stringify(e));
            }
        } else if(_PREFIX + 'l_select' == fieldId) {
            var vendor = obj.getCurrentSublistValue({sublistId: SUB_ID, fieldId: _PREFIX + 'l_vendor'}),
                rate = obj.getCurrentSublistValue({sublistId: SUB_ID, fieldId: _PREFIX + 'l_rate'}),
                select = obj.getCurrentSublistValue({sublistId: SUB_ID, fieldId: fieldId}),
                index = obj.getCurrentSublistIndex({sublistId: SUB_ID});
            console.log('select====' + select + '|index==>' + index)
            if(true == select || 'T' == select) {
                if('' == vendor) {
                    alert(isEng ? '请选择供应商！' : '请选择供应商！');
                    obj.setCurrentSublistValue({sublistId: SUB_ID, fieldId: fieldId, value: false, ignoreFieldChange: true});
                } else if('' === rate) {
                    alert(isEng ? '请输入采购单价！' : '请输入采购单价！');
                    obj.setCurrentSublistValue({sublistId: SUB_ID, fieldId: fieldId, value: false, ignoreFieldChange: true});
                } else {
                    var cuy = jQuery('#line_currency' + (index + 1)).val();
                    console.log('index==>' + index + '||币种======>' + cuy)
                    if(-1 == cuy) {
                        alert(isEng ? '请选择默认币种！' : '请选择默认币种！');
                        obj.setCurrentSublistValue({sublistId: SUB_ID, fieldId: fieldId, value: false, ignoreFieldChange: true});
                    } else {
                        obj.setCurrentSublistValue({sublistId: SUB_ID, fieldId: _PREFIX + 'l_cuy', value: cuy, ignoreFieldChange: true});
                    }
                }
            }
        }
    }

    /**
     * 格式化供应商币种下拉列表html
     * @param vendor
     * @return {{}}        html
     */
    function formatVendorCurrencyHtml(vendor, index) {
        var thisVendorHtml = '';
        var vendorObj = record.load({type: 'vendor', id: vendor});
        var length = vendorObj.getLineCount('currency');
        for(var i = 0; i < length; i++) {
            var cuyName = vendorObj.getSublistText({sublistId: 'currency', fieldId: 'currency', line: i}),
                cuyId = vendorObj.getSublistValue({sublistId: 'currency', fieldId: 'currency', line: i});
            thisVendorHtml += '<option value="' + cuyId + '">' + cuyName + '</option>';
        }
        return thisVendorHtml;
    }

    /**
     * Function to be executed when field is slaved.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     *
     * @since 2015.2
     */
    function postSourcing(scriptContext) {

    }

    /**
     * Function to be executed after sublist is inserted, removed, or edited.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @since 2015.2
     */
    function sublistChanged(scriptContext) {

    }

    /**
     * Function to be executed after line is selected.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @since 2015.2
     */
    function lineInit(scriptContext) {

    }

    /**
     * Validation function to be executed when field is changed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
     * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
     *
     * @returns {boolean} Return true if field is valid
     *
     * @since 2015.2
     */
    function validateField(scriptContext) {

    }

    /**
     * Validation function to be executed when sublist line is committed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateLine(scriptContext) {

    }

    /**
     * Validation function to be executed when sublist line is inserted.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateInsert(scriptContext) {

    }

    /**
     * Validation function to be executed when record is deleted.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateDelete(scriptContext) {

    }

    /**
     * Validation function to be executed when record is saved.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @returns {boolean} Return true if record is valid
     *
     * @since 2015.2
     */
    function saveRecord(scriptContext) {
        var obj = currentRecord.get();
        var length = obj.getLineCount(SUB_ID);
        var selectedData = [];
        for(var i = 0; i < length; i++) {
            var select = obj.getSublistValue({sublistId: SUB_ID, fieldId: _PREFIX + 'l_select', line: i});
            if(select || true == select || 'T' == select) {
                var json = {};
                resultFields.forEach(function (field) {
                    json[field.key] = obj.getSublistValue({sublistId: SUB_ID, fieldId: _PREFIX + field.id, line: i});
                });
                var cuy = jQuery('#line_currency' + (i + 1)).val();
                json.cuy = cuy;
                json.gkey = json.vendor + '&' + json.cuy;//分组创建po用
                selectedData.push(json);
            }
        }
        if(0 == selectedData) {
            alert(isEng ? '请至少选中一行!' : '请至少选中一行!');
            return false;
        }
        obj.setValue(_PREFIX + 'alldata', JSON.stringify(selectedData));
        console.error(JSON.stringify(selectedData));
        // alert('Testing');
        return true;
    }

    function doSearch() {
        var obj = currentRecord.get();
        var turl = url.resolveScript({
            scriptId: 'customscript_ecm_purarrange2po_sl',
            deploymentId: 'customdeploy_ecm_purarrange2po_sl'
        });
        filterFields.forEach(function (field) {
            var val = obj.getValue(_PREFIX + field.id);
            turl += '&' + field.key + '=' + encodeURIComponent(val);
        });
        setWindowChanged(window, false);
        window.location.href = turl;
    }

    return {
        pageInit: pageInit,
        fieldChanged: fieldChanged,
        /*postSourcing: postSourcing,
        sublistChanged: sublistChanged,
        lineInit: lineInit,
        validateField: validateField,
        validateLine: validateLine,
        validateInsert: validateInsert,
        validateDelete: validateDelete,*/
        saveRecord: saveRecord,
        doSearch: doSearch
    };
    
});
