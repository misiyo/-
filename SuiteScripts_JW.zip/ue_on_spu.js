/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 *
 * Version      Date            Author          Memo
 * 1.0          2023/01/16      John Wang       SPU编码（1018136）
 */
define(['N/record', 'N/runtime', 'N/search'],
    /**
 * @param{record} record
 * @param{runtime} runtime
 * @param{search} search
 */
    (record, runtime, search) => {
        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed before record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const beforeSubmit = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {
            if('delete' == scriptContext.type) {
                return;
            }
            let obj = scriptContext.newRecord;
            if('create' == scriptContext.type) {
                try {
                    spuNumbering(obj);
                } catch (e) {
                    log.debug('spuError====>' + obj.id, e);
                }
            }
        }

        /**
         * SPU编码
         * @param obj
         */
        const spuNumbering = obj => {
            let filters = [], columns = [];
            filters.push(['custrecord_ecm_d_number_type', 'anyof', 1]);//SPU
            columns.push('custrecord_ecm_d_number_length');//编码长度
            columns.push('custrecord_ecm_d_number_now');//当前流水码
            let results = search.create({type: 'customrecord_ecm_data_number', filters: filters, columns: columns}).run().getRange({start: 0, end: 1});
            if(results && results.length > 0) {
                let length = results[0].getValue(columns[0]),
                    nowNumber = results[0].getValue(columns[1]),
                    numberId = results[0].id;
                let spuId = (`0000000000${Number(nowNumber)}`).slice(Number(-1)*Number(length));
                let name = spuId + '_' + obj.getValue({fieldId: 'custrecord_ecm_esi_enabb'}) + '_'
                            + obj.getValue({fieldId: 'custrecord_ecm_esi_cas'});
                log.debug('spu编码===>' + obj.id, `spuid==${spuId}||name==${name}`);
                record.submitFields({
                    type: 'customrecord_ecm_data_number',
                    id: numberId,
                    values: {
                        custrecord_ecm_d_number_now: (Number(nowNumber) + 1)
                    },
                    options: {
                        ignoreMandatoryFields: true
                    }
                });
                record.submitFields({
                    type: 'customrecord_ecm_spu_info',
                    id: obj.id,
                    values: {
                        custrecord_ecm_esi_spuid: spuId,
                        name: name
                    },
                    options: {
                        ignoreMandatoryFields: true
                    }
                });

            }

        }

        return {afterSubmit}

    });
