/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 */
define(['N/https', 'N/query', 'N/record', 'N/redirect', 'N/ui/serverWidget', '/SuiteScripts/tools/hc_edi_interface_tool.js'],
    /**
 * @param{https} https
 * @param{serverWidget} serverWidget
 */
    (https, query, record, redirect, serverWidget, interfaceTool) => {
        /**
         * Defines the Suitelet script trigger point.
         * @param {Object} scriptContext
         * @param {ServerRequest} scriptContext.request - Incoming request
         * @param {ServerResponse} scriptContext.response - Suitelet response
         * @since 2015.2
         */
        const onRequest = (scriptContext) => {
            let request = scriptContext.request,
                response = scriptContext.response;
            if('GET' == request.method) {
                let form = serverWidget.createForm({title: '测试EDI连接'});
                form.addSubmitButton({label: '刷新'});
                let imethodField = form.addField({type: serverWidget.FieldType.TEXT, id: 'custpage_method', label: '接口类型'});
                imethodField.defaultValue = 'getEdiCountryClassify';

                let dataField = form.addField({type: serverWidget.FieldType.LONGTEXT, id: 'custpage_reqdata', label: '请求报文'});
                let reqData = {
                    /*"datas": {
                        "arg1": "1580486400000",
                        "arg0": (new Date()).getTime() + ''
                    },*/
                    "imethod": "getQuotaBalanceInfoByPolicyNo"
                }
                dataField.defaultValue = JSON.stringify(reqData);

                let rtnField = form.addField({type: serverWidget.FieldType.LONGTEXT, id: 'custpage_rtndata', label: '返回报文'});
                let rtn = interfaceTool.requestEdiServer(reqData);
                if(true == rtn.valid && rtn.data && '' != rtn.data.datas) {
                    let rtnData = JSON.parse(rtn.data.datas);
                    rtnField.defaultValue = rtnData ? JSON.stringify(rtnData) : '';
                }
                testAdrSql();
                response.writePage(form);
            } else {
                redirect.toSuitelet({
                    scriptId: 'customscript_ecm_test_edi_sl',
                    deploymentId: 'customdeploy_ecm_test_edi_sl'
                })
            }

        }

        const testAdrSql = () => {
            let obj = record.load({type: 'customer', id: '52447'});
            let length = obj.getLineCount({sublistId: 'addressbook'});
            for(let i = 0; i < length; i++) {
                let checkb = obj.getSublistValue({sublistId: 'addressbook', fieldId: 'defaultbilling', line: i});
                let checks = obj.getSublistValue({sublistId: 'addressbook', fieldId: 'defaultshipping', line: i});
                if(true == checkb && true == checks) {
                    let subrec = obj.getSublistSubrecord({
                        sublistId: 'addressbook',
                        fieldId: 'addressbookaddress',
                        line: i
                    });
                    let cty = subrec.getText({fieldId: 'country'});
                    log.debug('cty==>' + i, cty)
                }
            }
        }

        return {onRequest}

    });
