/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 *
 * Version      Date            Author          Memo
 * 1.0          2023/01/16      John Wang       价格表失效逻辑（1018111）
 * 2.0          2023/02/03      John Wang       变更：失效价格表状态范围改为valid且仅当价格表当前状态为valid执行（1018111）
 */
define(['N/record', 'N/runtime', 'N/search'],
    /**
 * @param{record} record
 * @param{runtime} runtime
 * @param{search} search
 */
    (record, runtime, search) => {
        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed before record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const beforeSubmit = (scriptContext) => {
            if('delete' != scriptContext.type) {
                let obj = scriptContext.newRecord;
                try {
                    let key = formatKey(obj);
                    log.debug('bskey', key);
                    obj.setValue({fieldId: 'custrecord_epl_key', value: key});
                } catch (e) {
                    log.debug('beforeSubmitError', e);
                }
            }
        }

        /**
         * 格式化key
         * @param obj
         * @return {*|string}
         */
        const formatKey = obj => {
            let key = '',
                item = obj.getValue({fieldId: 'custrecord_epl_sku'});
            let itemFields = search.lookupFields({type: 'item', id: item, columns: ['itemid']});
            let itemid = itemFields.itemid;
            key = obj.getValue({fieldId: 'custrecord_epl_subsidiary'})
                + obj.getValue({fieldId: 'custrecord_epl_price_type'})
                + itemid
                + obj.getValue({fieldId: 'custrecord_epl_containers_type'})
                + obj.getValue({fieldId: 'custrecord_epl_loadcing_port'})
                + obj.getValue({fieldId: 'custrecord_epl_currency'})
                + obj.getValue({fieldId: 'custrecord_epl_incoterm'})
                + obj.getValue({fieldId: 'custrecord_epl_ispallet'})
                + obj.getValue({fieldId: 'custrecord_epl_from_qty'});
            return key;
        }

        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {
            if('delete' == scriptContext.type) {
                return;
            }
            let newRecord = scriptContext.newRecord;
            let obj = record.load({type: newRecord.type, id: newRecord.id});
            try {
                let appStatus = obj.getValue({fieldId: 'custrecord_epl_status'});//审批状态：Valid（2）
                if(2 == appStatus) {
                    validatePriceBook(obj);
                }
                if('create' == scriptContext.type || 'copy' == scriptContext.type) {
                    let name = formatName(obj);
                    obj.setValue({fieldId: 'name', value: name});
                    obj.save({ignoreMandatoryFields: true, enableSourcing: true});
                    // record.submitFields({type: obj.type, id: obj.id, values: {name: name}, options: {ignoreMandatoryFields: true, enablesourcing: true}});
                }
            } catch (e) {
                log.error('error====>' + obj.id, e);
            }
        }

        /**
         * 格式化name
         * @param obj
         * @return {string}
         */
        const formatName = obj => {
            let name = '',
                isPallet = obj.getValue({fieldId: 'custrecord_epl_ispallet'}),//true:TPLT/false:FPLT
                region = obj.getValue({fieldId: 'custrecord_epl_sales_region'}),
                port = obj.getValue({fieldId: 'custrecord_epl_loadcing_port'});

            if(region) {
                let regionFields = search.lookupFields({type: 'customrecord_ecm_salesregion', id: region, columns: ['custrecord_es_sales_region_abb']});
                region = regionFields.custrecord_es_sales_region_abb || '';
            }
            if(port) {
                let portFields = search.lookupFields({type: 'customrecord_ecm_loaddest_ports', id: port, columns: ['custrecord_el_code']});
                port = portFields.custrecord_el_code || '';
            }
            name = obj.getText({fieldId: 'custrecord_epl_currency'}) + '_'
                 + obj.getText({fieldId: 'custrecord_epl_incoterm'}) + '_'
                 + port + '_'
                 + obj.getValue({fieldId: 'custrecord_epl_package_unit'}) + '_'
                 + (true == isPallet ? 'TPLT' : 'FPLT') + '_'
                 + region + '_'
                 + obj.id;
            return name;
        }

        /**
         * 失效相同key价格表
         * @param obj
         */
        const validatePriceBook = obj => {
            let filters = [], columns = [],
                key = obj.getValue({fieldId: 'custrecord_epl_key'});
            filters.push(['custrecord_epl_key', 'is', key]);
            filters.push('and');
            filters.push(['custrecord_epl_status', 'anyof', 2]);
            filters.push('and');
            filters.push(['internalid', 'noneof', obj.id]);
            columns.push('internalid');
            let results = search.create({type: 'customrecord_ecm_price_book', filters: filters, columns: columns}).run().getRange({start: 0, end: 1000});
            if(results && results.length > 0) {
                log.debug('失效数据===pbid:' + obj.id, results);
                results.forEach(function (data) {
                    record.submitFields({
                        type: 'customrecord_ecm_price_book',
                        id: data.id,
                        values: {
                            custrecord_epl_status: 3//status=invalid
                        },
                        options: {
                            ignoreMandatoryFields: true
                        }
                    });
                })
            }
        }

        return {beforeLoad, beforeSubmit, afterSubmit}

    });
