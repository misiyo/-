/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 *
 * Version      Date            Author          Memo
 * 1.0          2023/01/16      John Wang       itemSpecDescription拼接（1018108）
 * 2.0          2023/03/22      John Wang       拼接符号变更（1018108）
 * 3.0          2023/04/07      Mark Z          批次货品校验displayName是否重复【1019595】
 */
define(['N/currentRecord', 'N/record', 'N/search'],
/**
 * @param{currentRecord} currentRecord
 * @param{record} record
 * @param{search} search
 */
function(currentRecord, record, search) {
    const SPEC_FIELDS = ['custitem_ecm_specoption1', 'custitem_ecm_specoption2', 'custitem_ecm_specoption3', 'custitem_ecm_specoption4', 'custitem_ecm_specoption5'];

    /**
     * Function to be executed after page is initialized.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.mode - The mode in which the record is being accessed (create, copy, or edit)
     *
     * @since 2015.2
     */
    function pageInit(scriptContext) {

    }

    /**
     * Function to be executed when field is changed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
     * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
     *
     * @since 2015.2
     */
    function fieldChanged(scriptContext) {

    }

    /**
     * Function to be executed when field is slaved.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     *
     * @since 2015.2
     */
    function postSourcing(scriptContext) {

    }

    /**
     * Function to be executed after sublist is inserted, removed, or edited.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @since 2015.2
     */
    function sublistChanged(scriptContext) {

    }

    /**
     * Function to be executed after line is selected.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @since 2015.2
     */
    function lineInit(scriptContext) {

    }

    /**
     * Validation function to be executed when field is changed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     * @param {string} scriptContext.fieldId - Field name
     * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
     * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
     *
     * @returns {boolean} Return true if field is valid
     *
     * @since 2015.2
     */
    function validateField(scriptContext) {

    }

    /**
     * Validation function to be executed when sublist line is committed.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateLine(scriptContext) {

    }

    /**
     * Validation function to be executed when sublist line is inserted.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateInsert(scriptContext) {

    }

    /**
     * Validation function to be executed when record is deleted.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.sublistId - Sublist name
     *
     * @returns {boolean} Return true if sublist line is valid
     *
     * @since 2015.2
     */
    function validateDelete(scriptContext) {

    }

    /**
     * Validation function to be executed when record is saved.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @returns {boolean} Return true if record is valid
     *
     * @since 2015.2
     */
    function saveRecord(scriptContext) {
        var obj = scriptContext.currentRecord,
            specCn = [],
            specEng = [];
        var grade = obj.getValue({fieldId: 'custitem_ecm_grade'});
        if(grade) {
            var gradeFields = search.lookupFields({type: 'customrecord_ecm_grade', id: grade, columns: ['custrecord_eg_grade_desc_cn']});
            if(gradeFields) {
                specCn.push(gradeFields.custrecord_eg_grade_desc_cn);
                specEng.push(obj.getText({fieldId: 'custitem_ecm_grade'}));
            }
        }
        SPEC_FIELDS.forEach(function (fid, index) {
            if(obj.getValue({fieldId: fid})) {
                var valCn = obj.getValue({fieldId: 'custitem_ecm_spec' + (index + 1) + '_cn'}),
                    valEng = obj.getValue({fieldId: 'custitem_ecm_spec' + (index + 1) + '_en'});
                specCn.push(valCn);
                specEng.push(valEng);
            }
        });
        obj.setValue({fieldId: 'custitem_ecm_spec_combine_cn', value: specCn.length > 0 ? specCn.join('；') : ''});
        obj.setValue({fieldId: 'custitem_ecm_spec_combine_en', value: specEng.length > 0 ? specEng.join(';') : ''});

        // 校验displayname是否重复， 重复报错，不允许保存。
        var checkFlag = checkDisplayNameIsRepeated(obj);
        if (true == checkFlag) {
            alert('Field [SKU/DisplayName] cannot be repeated. Please fill in a new Value.');
            return false;
        }

        return true;
    }

    /**
     * 搜索是否存在一样displayName的批次库存货品
     * @param obj
     * @return {boolean}   true: 重复
     */
    function checkDisplayNameIsRepeated(obj) {
        var displayName = obj.getValue('displayname') || '';
        var itemId = obj.id || '';
        if (displayName) {
            var filters = [];
            filters.push(['type', 'anyof', 'InvtPart']);
            filters.push('and');
            filters.push(['islotitem', 'is', 'T']);
            filters.push('and');
            filters.push(['isinactive', 'is', 'F']);
            filters.push('and');
            filters.push(['displayname', 'is', displayName]);
            if (itemId) {
                filters.push('and');
                filters.push(['internalid', 'noneof', itemId]);
            }
            var itemSearchObj = search.create({
                type: 'item',
                filters: filters,
                columns: [
                    search.createColumn({name: 'internalid'})
                ]
            });
            var results = itemSearchObj.run().getRange({start: 0, end: 1});
            if (results && results.length > 0) {
                return true;
            }
        }
        return false;
    }

    return {
        /*pageInit: pageInit,
        fieldChanged: fieldChanged,
        postSourcing: postSourcing,
        sublistChanged: sublistChanged,
        lineInit: lineInit,
        validateField: validateField,
        validateLine: validateLine,
        validateInsert: validateInsert,
        validateDelete: validateDelete,*/
        saveRecord: saveRecord
    };
    
});
