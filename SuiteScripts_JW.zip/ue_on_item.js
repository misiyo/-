/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 *
 * Version      Date            Author          Memo
 * 1.0          2023/01/18      John Wang       货品编码（1018112）
 * 2.0          2023/04/07      Mark Z          CSV导入校验批次货品displayName是否重复【1019595】
 */
define(['N/record', 'N/runtime', 'N/search'],
    /**
 * @param{record} record
 * @param{runtime} runtime
 * @param{search} search
 */
    (record, runtime, search) => {
        const SPU_TYPE = 'customrecord_ecm_spu_info';//SPU type
        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed before record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const beforeSubmit = (scriptContext) => {
            let obj = scriptContext.newRecord;
            let itemType = obj.getValue('itemtype');
            if ('InvtPart' == itemType && runtime.executionContext == runtime.ContextType.CSV_IMPORT) {
                let checkFlag = checkDisplayNameIsRepeated(scriptContext.type, obj);
                if (true == checkFlag) {
                    throw 'Field [SKU/DisplayName] cannot be repeated. Please fill in a new Value.';
                }
            }
            try {
                if('create' == scriptContext.type || 'copy' == scriptContext.type) {
                    let spu = obj.getValue({fieldId: 'custitem_ecm_productoid'}),
                        bussinessType = obj.getValue({fieldId: 'custitem_ecm_businesstype'});//业务类型
                    if(spu && '' != spu) {
                        let spuFields = search.lookupFields({type: SPU_TYPE, id: spu, columns: ['custrecord_ecm_esi_3bit_pipeline_code', 'custrecord_ecm_esi_spuid']});
                        let nowNumber = 1,
                            spuid = '';
                        if(spuFields && spuFields.custrecord_ecm_esi_3bit_pipeline_code) {
                            nowNumber = spuFields.custrecord_ecm_esi_3bit_pipeline_code;
                            spuid = spuFields.custrecord_ecm_esi_spuid;
                        }
                        record.submitFields({type: SPU_TYPE, id: spu, values: {custrecord_ecm_esi_3bit_pipeline_code: Number(nowNumber) + 1}, options: {ignoreMandatoryFields: true}});
                        let itemId = spuid + '-' + ('000' + nowNumber).slice(-3) + '-' + bussinessType;
                        obj.setValue({fieldId: 'itemid', value: itemId});
                    }
                }
            } catch (e) {
                log.error('setItemIdError===' + obj.getValue({fieldId: 'item'}), e);
            }
        }

        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {

        }

        /**
         * 搜索是否存在一样displayName的批次库存货品
         * @param type
         * @param obj
         * @return {boolean}   true: 重复
         */
        const checkDisplayNameIsRepeated = (type, obj) => {
            let displayName = obj.getValue('displayname');
            if (displayName) {
                let filters = [];
                filters.push(['type', 'anyof', 'InvtPart']);
                filters.push('and');
                filters.push(['islotitem', 'is', 'T']);
                filters.push('and');
                filters.push(['isinactive', 'is', 'F']);
                filters.push('and');
                filters.push(['displayname', 'is', displayName]);
                if ('create' != type && 'copy' != type) {
                    filters.push('and');
                    filters.push(['internalid', 'noneof', obj.id]);
                }
                let itemSearchObj = search.create({
                    type: 'item',
                    filters: filters,
                    columns: [
                        search.createColumn({name: 'internalid'})
                    ]
                });
                let results = itemSearchObj.run().getRange({start: 0, end: 1});
                if (results && results.length > 0) {
                    return true;
                }
            }
            return false;
        }

        return {beforeSubmit}

    });
