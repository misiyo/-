/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 */
define(['N/encode', 'N/file', 'N/format', 'N/record', 'N/render', 'N/search', 'SuiteScripts/tools/common_api.js'],
    
    (encode, file, format, record, render, search, commonApi) => {
        /**
         * Defines the Suitelet script trigger point.
         * @param {Object} scriptContext
         * @param {ServerRequest} scriptContext.request - Incoming request
         * @param {ServerResponse} scriptContext.response - Suitelet response
         * @since 2015.2
         */
        const onRequest = (scriptContext) => {
            let request = scriptContext.request;
            let response = scriptContext.response;
            if (request.method == 'GET') {
                let scId = request.parameters.rec_id;
                let xmlStr = getXml(scId);
                //写文件
                response.writeFile(xmlStr);
            }
        }
        function getXml(scId) {
            let printFormat = 'SuiteScripts/SuiteScripts_BR/sc_demo.xml';
            //加载获取模板
            let tempFile = file.load({id: printFormat});
            //创建用于导出的文档
            let templateRenderer = render.create();
            //将模板内容附到导出文档中
            templateRenderer.templateContent = tempFile.getContents();
            let allData = getData(scId);
            templateRenderer.addCustomDataSource({
                alias : 'data',
                format : render.DataSource.OBJECT,
                data : allData
            });
            let excel_str = templateRenderer.renderAsString();
            //将字符串转换为另一种类型的编码
            let fstr = encode.convert({
                string : excel_str,
                inputEncoding : encode.Encoding.UTF_8,
                outputEncoding : encode.Encoding.BASE_64
            });
            let name =  ' sc' + '.xls';
            let excel = file.create({
                name : name,
                fileType : file.Type.EXCEL,
                contents : fstr
            });
            return excel;
        }
        function getData(scId) {
            let data = {};
            let filters = [];
            filters.push(['internalid', 'anyof', scId]);
            filters.push('and');
            filters.push(['mainline', 'is', 'F']);
            let columns = getColumns();
            let mySearch = search.create({
                type: 'salesorder',
                filters: filters,
                columns: columns
            });
            let result = commonApi.getAllData(mySearch);
            log.debug('result',result);
            if(result) {
                data = getResult(result, columns,scId);
            }
            return data;
        }
        function getColumns() {
            let columns = [];
            //公司英文名称 0
            columns.push(search.createColumn({
                name: 'custrecord_ecm_subname_en',
                join: 'subsidiary'
            }));
            //SC订单号 1
            columns.push(search.createColumn({
                name: 'tranid'
            }));
            //PO 2
            columns.push(search.createColumn({
                name: 'otherrefnum'
            }));
            //签约地址 3
            columns.push(search.createColumn({
                name: 'custrecord_ecm_signaddress_en',
                join: 'subsidiary'
            }));
            //签约时间 4
            columns.push(search.createColumn({
                name: 'trandate'
            }));
            //公司地址 5
            columns.push(search.createColumn({
                name: 'custrecord_ecm_subaddress_en',
                join: 'subsidiary'
            }));
            //公司电话 6
            columns.push(search.createColumn({
                name: 'custrecord37',
                join: 'subsidiary'
            }));
            //公司传真 7
            columns.push(search.createColumn({
                name: 'fax',
                join: 'subsidiary'
            }));
            //客户名称EN  8
            columns.push(search.createColumn({
                name: 'companyname',
                join: 'customer'
            }));
            //客户电话  9
            columns.push(search.createColumn({
                name: 'phone',
                join: 'customer'
            }));
            //客户传真  10
            columns.push(search.createColumn({
                name: 'fax',
                join: 'customer'
            }));
            //客户税号  11
            columns.push(search.createColumn({
                name: 'vatregnumber',
                join: 'customer'
            }));
            //币种  12
            columns.push(search.createColumn({
                name: 'currency'
            }));
            //客户联系人 13
            columns.push(search.createColumn({
                name: "email",
                join: "contactPrimary"
            }))
            return columns;
        }
        function getResult(result,columns,scId) {
            let data = {};
            let obj = record.load({
                type: 'salesorder',
                id: scId
            });
            if (result.length > 0) {
                data.company_name_en = result[0].getValue(columns[0]);
                data.sc_no = result[0].getValue(columns[1]);
                data.po_no = result[0].getValue(columns[2]);
                data.sign_location = result[0].getValue(columns[3]);
                data.sign_date = result[0].getValue(columns[4]);
                data.company_address = result[0].getValue(columns[5]);
                data.company_tel = result[0].getValue(columns[6]);
                data.company_fax = result[0].getValue(columns[7]);
                data.customer_name = result[0].getValue(columns[8]);
                data.customer_tel = result[0].getValue(columns[9]);
                data.customer_fax = result[0].getValue(columns[10]);
                data.customer_vat = result[0].getValue(columns[11]);
                data.currency = result[0].getText(columns[12]);
                data.customer_email = result[0].getText(columns[13]);
                var subsidiary = obj.getValue('subsidiary');
                var customerId = obj.getValue('entity');
                var salesRepId = obj.getValue('salesrep');
                let subsidiaryRecord = record.load({
                    type: 'subsidiary',
                    id: subsidiary
                });
                var customerInfo = record.load({
                    type: 'customer',
                    id: customerId
                });
                var object = search.lookupFields({
                    type: 'employee',
                    id: salesRepId,
                    columns: ['email']
                });
                var federalidnumber = subsidiaryRecord.getValue('federalidnumber');
                var defaultaddress = customerInfo.getValue('defaultaddress');
                data.company_vat = federalidnumber;
                data.customer_addr = defaultaddress;
                data.contactsEmail = object.email;
                data.customerEmail = getCustomerEmail(scId);
            }
            var itemSubList = obj.getSublist({
                sublistId: 'item'
            });
            for (let itemSub in itemSubList) {
                    log.debug('item',itemSub);
            }
            return data;
        }
        //获取供应商主要联系人邮箱
        function getCustomerEmail(scId){
           let columns = [
                    search.createColumn({
                        name: "email",
                        join: "contactPrimary",
                        summary: "GROUP",
                        sort: search.Sort.ASC
                    })
                ];
            var salesorderSearchObj = search.create({
                type: "salesorder",
                filters:
                    [
                        ["type","anyof","SalesOrd"],
                        "AND",
                        ["mainline","is","F"],
                        "AND",
                        ["taxline","is","F"],
                        "AND",
                        ["contactprimary.internalid","noneof","@NONE@"],
                        "AND",
                        ["internalid","anyof",scId]
                    ],
                    columns: columns
            });
            var allData = commonApi.getAllData(salesorderSearchObj);
            if (allData.length > 0) {
                return allData[0].getValue(columns[0]);
            }
            return '';
        }
        return {onRequest}

    });

