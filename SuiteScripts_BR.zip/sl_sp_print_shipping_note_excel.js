/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 */
define(['N/encode', 'N/file', 'N/format', 'N/record', 'N/render', 'N/search', 'SuiteScripts/tools/common_api.js'],
    
    (encode, file, format, record, render, search, commonApi) => {
        /**
         * Defines the Suitelet script trigger point.
         * @param {Object} scriptContext
         * @param {ServerRequest} scriptContext.request - Incoming request
         * @param {ServerResponse} scriptContext.response - Suitelet response
         * @since 2015.2
         */
        const onRequest = (scriptContext) => {
            let request = scriptContext.request;
            let response = scriptContext.response;
            if (request.method == 'GET') {
                let scId = request.parameters.rec_id;
                let xmlStr = getXml(scId);
                //写文件
                response.writeFile(xmlStr);
            }
        }
        function getXml(scId) {
            let printFormat = 'SuiteScripts/SuiteScripts_BR/shippingNote.xml';
            //加载获取模板
            let tempFile = file.load({id: printFormat});
            //创建用于导出的文档
            let templateRenderer = render.create();
            //将模板内容附到导出文档中
            templateRenderer.templateContent = tempFile.getContents();
            let data = getData(scId);
            templateRenderer.addCustomDataSource({
                alias : 'data',
                format : render.DataSource.OBJECT,
                data : data
            });
            let excel_str = templateRenderer.renderAsString();
            //将字符串转换为另一种类型的编码
            let fstr = encode.convert({
                string : excel_str,
                inputEncoding : encode.Encoding.UTF_8,
                outputEncoding : encode.Encoding.BASE_64
            });
            let name =  'Shipping_Note' + '.xls';
            let excel = file.create({
                name : name,
                fileType : file.Type.EXCEL,
                contents : fstr
            });
            return excel;
        }
        function getData(scId) {
            let data = {};
            let filters = [];
            filters.push(['internalid', 'anyof', scId]);
            let columns = getColumns();
            let mySearch = search.create({
                type: 'customrecord_ecm_sp',
                filters: filters,
                columns: columns
            });
            let result = commonApi.getAllData(mySearch);
            log.debug('result',result);
            if(result) {
                data = getResult(result, columns,scId);
                log.debug('data',data);
            }
            return data;
        }
        function getColumns() {
            let columns = [];
            //0 发货人公司名称
            columns.push(search.createColumn({
                name: 'custrecord_sp_ifbolcorp_name'
            }));
            //1 发货人地址
            columns.push(search.createColumn({
                name: 'custrecord_sp_ifbol_address'
            }));
            //2 Shipping Plan流水号
            columns.push(search.createColumn({
                name: 'name'
            }));
            //3 发货人电话
            columns.push(search.createColumn({
                name: 'custrecord_sp_ifbol_phone'
            }));
            //4 发货人税号
            columns.push(search.createColumn({
                name: 'custrecord_sp_ifbol_vatreg'
            }));
            //5 发货人传真
            columns.push(search.createColumn({
                name: 'custrecord_sp_ifbol_fax'
            }));
            //6 收货人公司名称
            columns.push(search.createColumn({
                name: 'custrecord_sp_irbol_name'
            }));
            //7 收货人地址
            columns.push(search.createColumn({
                name: 'custrecord_sp_irbol_address'
            }));
            //8 通知人公司名称
            columns.push(search.createColumn({
                name: 'custrecord_sp_notibol_name'
            }));
            //9 通知人地址
            columns.push(search.createColumn({
                name: 'custrecord_sp_notibol_address'
            }));
            //10 起运港
            columns.push(search.createColumn({
                name: 'custrecord_sp_loadingport'
            }));
            //11 目的港
            columns.push(search.createColumn({
                name: 'custrecord_sp_destinationport'
            }));
            //12 标签类型
            columns.push(search.createColumn({
                name: 'custrecord_sp_tag'
            }));
            //13 标签内容
            columns.push(search.createColumn({
                name: 'custrecord_sp_tagcontent'
            }));
            //14 拍照要求
            columns.push(search.createColumn({
                name: 'custrecord_sp_photo_request'
            }));
            //15 拍照要求补充说明
            columns.push(search.createColumn({
                name: 'custrecord_sp_photoreq_addremark'
            }));
            //16 贸易方式
            columns.push(search.createColumn({
                name: 'custrecord_sp_incoterm'
            }));
            //17 发运方式
            columns.push(search.createColumn({
                name: 'custrecord_sp_shipping_method'
            }));
            //18 箱型数量1
            columns.push(search.createColumn({
                name: 'custrecord_sp_cubetypeqty1'
            }));
            //19 箱型1
            columns.push(search.createColumn({
                name: 'custrecord_sp_cubetype1'
            }));
            //20 箱型数量2
            columns.push(search.createColumn({
                name: 'custrecord_sp_cubetypeqty2'
            }));
            //21 箱型2
            columns.push(search.createColumn({
                name: 'custrecord_sp_cubetype2'
            }));
            //22 运输路线
            columns.push(search.createColumn({
                name: 'custrecord_sp_vessel_route'
            }));
            //23 凭证
            columns.push(search.createColumn({
                name: 'custrecord_sp_shippapers'
            }));
            //24 免箱使使用时间
            columns.push(search.createColumn({
                name: 'custrecord_sp_timeof_freeconta'
            }));
            //25 免箱使备注
            columns.push(search.createColumn({
                name: 'custrecord_sp_freeconta_remark'
            }));
            //26 收货人税号
            columns.push(search.createColumn({
                name: 'custrecord_sp_irbol_vatreg'
            }));
            //27 通知人税号
            columns.push(search.createColumn({
                name: 'custrecord_sp_notibol_vatreg'
            }));
            //28 船公司其他要求
            columns.push(search.createColumn({
                name: 'custrecord_sp_vesselcom_ootreq'
            }));
            //29 托书提单要求
            columns.push(search.createColumn({
                name: 'custrecord_sp_boltype'
            }));
            //30 签单方式
            columns.push(search.createColumn({
                name: 'custrecord_sp_signway'
            }));
            //31 提单类型
            columns.push(search.createColumn({
                name: 'custrecord_sp_boltype'
            }));
            //32 币种
            columns.push(search.createColumn({
                name: 'custrecord_sp_sccurrency'
            }));
            //33 贸易方式
            columns.push(search.createColumn({
                name: 'custrecord_sp_incoterm'
            }));
            //34 单证人员名称
            columns.push(search.createColumn({
                name: 'firstname',
                join: 'custrecord_sp_docofficer'
            }));
            //35 单证人员姓氏
            columns.push(search.createColumn({
                name: 'lastname',
                join: 'custrecord_sp_docofficer'
            }));
            //36 单证人员邮箱
            columns.push(search.createColumn({
                name: 'email',
                join: 'custrecord_sp_docofficer'
            }));
            //37 船期截止日
            columns.push(search.createColumn({
                name: 'custrecord_sp_shipto'
            }))
            //38 提货日期
            columns.push(search.createColumn({
                name: 'custrecord_sp_deliverycomdate'
            }))
            //39 余款支付方式
            columns.push(search.createColumn({
                name: 'custrecord_sp_surptype'
            }))
            return columns;
        }
        function getResult(result,columns,spId) {
            let data = {};
            let itemList = [];
            let plannerList = [];
            let sourcingList = [];
            let sumGw = 0;
            let sumVol = 0;
            for (let i = 0; i < result.length; i++) {
                if (i === 0) {
                    data.shipper_name = isNull(result[0].getValue(columns[0]));
                    data.shipper_addr = isNull(result[0].getValue(columns[1]));
                    data.sp_no = isNull(result[0].getValue(columns[2]));
                    data.shipper_phone = isNull(result[0].getValue(columns[3]));
                    data.tax_id = isNull(result[0].getValue(columns[4]));
                    data.shipper_fax = isNull(result[0].getValue(columns[5]));
                    data.consignee_name = isNull(result[0].getValue(columns[6]));
                    data.consignee_addr = isNull(result[0].getValue(columns[7]));
                    data.notifier =isNull( result[0].getValue(columns[8]));
                    data.notifier_addr = isNull(result[0].getValue(columns[9]));
                    if (result[0].getValue(columns[10])) {
                        let portA = record.load({
                            type: 'customrecord_ecm_loaddest_ports',
                            id: result[0].getValue(columns[10])
                        });
                        data.loading_port = isNull(portA.getValue('custrecord_el_name_en'));
                    }
                    if (result[0].getValue(columns[11])) {
                        let portB = record.load({
                            type: 'customrecord_ecm_loaddest_ports',
                            id: result[0].getValue(columns[11])
                        });
                        data.destinationport = isNull(portB.getValue('custrecord_el_name_en'));
                    }
                    data.laber = isNull(result[0].getText(columns[12]));
                    data.label_detail = isNull(result[0].getValue(columns[13]));
                    data.photo_req = isNull(result[0].getText(columns[14]));
                    data.photo_req_remark = isNull(result[0].getValue(columns[15]));
                    data.trade_terms = isNull(result[0].getText(columns[16]));
                    data.shipping_method = isNull(result[0].getText(columns[17]));
                    data.qty1 = isNull(result[0].getValue(columns[18]));
                    data.type1 = isNull(result[0].getText(columns[19]));
                    let qty_type1;
                    if (result[0].getValue(columns[18]) && result[0].getText(columns[19])) {
                        qty_type1 = result[0].getValue(columns[18]) + 'X' + result[0].getText(columns[19])
                    }else {
                        qty_type1 = isNull(result[0].getValue(columns[18])) + isNull(result[0].getText(columns[19]))
                    }
                    let qty_type2;
                    if (result[0].getValue(columns[20]) && result[0].getText(columns[21])) {
                        qty_type2 = result[0].getValue(columns[20]) + 'X' + result[0].getText(columns[21])
                    }else {
                        qty_type2 = result[0].getValue(columns[20]) + result[0].getText(columns[21])
                    }
                    data.qty_type = qty_type1 + ';' + qty_type2
                    data.qty2 = isNull(result[0].getValue(columns[20]));
                    data.type2 = isNull(result[0].getText(columns[21]));
                    data.route = isNull(result[0].getText(columns[22]));
                    data.certificate = result[0].getValue(columns[23]) ? 'YES' : 'NO' ;
                    data.box_free_date = isNull(result[0].getText(columns[24]));
                    data.free_remark = isNull(result[0].getValue(columns[25]));
                    data.consignee_tax = isNull(result[0].getValue(columns[26]));
                    data.notifier_tax = isNull(result[0].getValue(columns[27]));
                    data.other_req = isNull(result[0].getValue(columns[28]));
                    data.bl_req = isNull(result[0].getText(columns[29]));
                    data.signway = isNull(result[0].getText(columns[30]));
                    data.boltype = isNull(result[0].getText(columns[31]));
                    data.currency = isNull(result[0].getText(columns[32]));
                    data.doc_operation = isNull(result[0].getValue(columns[34]));
                    data.doc_email = isNull(result[0].getValue(columns[36]));
                    data.latest_shipping_date = isNull(result[0].getValue(columns[37]));
                    data.pick_date = isNull(result[0].getValue(columns[38]));
                    if ('7' !== result[0].getValue(columns[39])) {
                        data.is_lc = 'Not L/C'
                    }else {
                        data.is_lc = 'L/C'
                    }
                }
            }
            var spInfo = record.load({
                type: 'customrecord_ecm_sp',
                id: spId
            });
            var lineCount = spInfo.getLineCount({
                sublistId: 'recmachcustrecord_scdline_sp'
            });
            for (let i = 0; i < lineCount; i++){
                var subId = spInfo.getSublistValue({
                    sublistId: 'recmachcustrecord_scdline_sp',
                    fieldId: 'id',
                    line: i
                });
                let scdLineInfo = record.load({
                    type: 'customrecord_ecm_scd_line',
                    id: subId
                });
                //获取包装数
                var packageQty = isNull(scdLineInfo.getValue('custrecord_scdline_packing_qty'));
                //获取销售订单ID
                let scId = scdLineInfo.getValue('custrecord_scdline_sc');
                let scdId = scdLineInfo.getValue('custrecord_ecm_scdline_scd');
                let scdInfo = record.load({
                    type: 'customrecord_ecm_scd',
                    id: scdId
                });
                let salesInfo = record.load({
                    type: 'salesorder',
                    id: scId
                });
                //获取销售订单唛头
                let marks = isNull(salesInfo.getValue('custbody_ecm_marks'));
                //查询人员信息
                let supplyPlanner = search.lookupFields({
                    type: 'employee',
                    id: scdLineInfo.getValue('custrecord_scdline_supplyplanner'),
                    columns: ['firstname','lastname','email']
                });
                //获取人员名称
                let plannerName =  isNull(supplyPlanner.firstname) + isNull(supplyPlanner.lastname);
                let plannerInfo  = plannerName + ',' + isNull(supplyPlanner.email);
                if (!plannerList.includes(plannerInfo)) {
                    plannerList.push(plannerInfo);
                }
                let sourcing = search.lookupFields({
                    type: 'employee',
                    id: scdLineInfo.getValue('custrecord_scdline_sourcing'),
                    columns: ['firstname','lastname','email']
                });
                let sourcingName = isNull(sourcing.firstname) + isNull(sourcing.lastname);
                let sourcingInfo = sourcingName + ',' + isNull(sourcing.email)
                if (!sourcingList.includes(sourcingInfo)) {
                    sourcingList.push(sourcingInfo);
                }
                var goodsInfo = record.load({
                    type: 'lotnumberedinventoryitem',
                    id: scdLineInfo.getValue('custrecord_scdline_item')
                })
                //获取主要单位
                var unitstype = goodsInfo.getValue('unitstype');
                //包装英文名称
                var pkgMarks = goodsInfo.getText('custitem_ecm_package_remk_en');
                if (unitstype !== '7') {
                    pkgMarks = goodsInfo.getValue('custitem_ecm_spec_combine_en');
                }
                var gw = Number(isNull(scdLineInfo.getValue('custrecord_scdline_gross_weight')));
                var vol = Number(isNull(scdLineInfo.getValue('custrecord_scdline_volume')));
                sumGw = sumGw + gw;
                sumVol = sumVol + vol;
                let pallet = 'NO'
                log.debug('isdangerous',goodsInfo.getValue('custitem_ecm_esi_isdangerous'))
                log.debug('punch',scdLineInfo.getValue('custrecord_scdline_punch'))
                if (scdLineInfo.getValue('custrecord_scdline_punch')) {
                    pallet = 'YES'
                }
                let isDangerous = 'NO';
                if (goodsInfo.getValue('custitem_ecm_esi_isdangerous')) {
                    isDangerous = 'YES';
                }
                //包装信息
                let pkgInfo = isNull(packageQty) + ' ' + isNull(pkgMarks) + ' ' + isNull(scdLineInfo.getValue('custrecord_scdline_net_weight'));
                let item = {
                    'description' : isNull(scdLineInfo.getValue('custrecord_scdline_enname')),
                    'pkg_info' : pkgInfo,
                    'marks' : marks,
                    'pallet' : pallet,
                    'tradeterms' : isNull(scdInfo.getText('custrecord_scd_tradeterms')),
                    'gw' : isNull(scdLineInfo.getValue('custrecord_scdline_gross_weight')),
                    'vol' : isNull(scdLineInfo.getValue('custrecord_scdline_volume')),
                    'un_no' :  isDangerous + (goodsInfo.getValue('custitem_ecm_unno') ? '|' + goodsInfo.getValue('custitem_ecm_unno') : ''),
                    'hs_code' :  isNull(scdLineInfo.getValue('custrecord_scdline_hs_code')),
                    'pick_addr' :  isNull(scdLineInfo.getValue('custrecord_scdline_deliveryaddress')),
                    'contacts' : isNull(scdLineInfo.getValue('custrecord_scdline_deliverycontact')) + ' ' + isNull(scdLineInfo.getValue('custrecord_scdline_deliveryphone')),
                    'truck_req' : scdLineInfo.getValue('custrecord_scdline_deliveryrequire')

                }
                itemList.push(item)
            }
            data.sumGw = sumGw;
            data.sumVol = sumVol;
            data.supply_planner = plannerList.toString();
            data.sourcing = sourcingList.toString();
            data.itemList = itemList;
            return data;
        }
        function isNull(someValue) {
            if(someValue == '' || someValue == null) {
                return '';
            } else {
                if (isNaN(someValue) && someValue.indexOf("&") >= 0) {
                    someValue = someValue.replace(/&/g, "&amp;");
                }
                return someValue;
            }
        }
        return {onRequest}

    });
