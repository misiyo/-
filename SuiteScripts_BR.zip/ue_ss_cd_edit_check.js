/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 */
define(['N/record', 'N/runtime', 'N/ui/serverWidget'],
    /**
     * @param{record} record
     * @param{runtime} runtime
     * @param{serverWidget} serverWidget
     */
    (record, runtime, serverWidget) => {
        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         // * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {
                try {
                        let form = scriptContext.form;
                        let userRole = runtime.getCurrentUser().role;
                        if (('edit' == scriptContext.type) && '3' != userRole){
                            disableSublistTab(form, 'recmachcustrecord_sscd_parent_form')
                        }
                }catch (e){
                        log.debug('error', e);
                }
        }
            const disableSublistTab = (form,disableObj) =>{
                    try {
                            form.addField({
                                    type: 'inlinehtml',
                                    label: ' &nbsp; ',
                                    id: `custpage_disable_${disableObj}`
                            }).defaultValue = `
                            <script>
                                try{
                                    jQuery(function () {
                                        const hoverdiv = '<div class="disableSublistTab${disableObj}" style="position: absolute; width: 100%; height: 100%; left: 0px; top: 0px; background: #EEEEEE;opacity: 0.5; filter: alpha(opacity=40);z-index:5;"></div>';
                                        jQuery('#recmachcustrecord_sscd_parent_form').wrap('<div class="position:relative;"></div>');
                                        jQuery('#recmachcustrecord_sscd_parent_form').before(hoverdiv);
                                        jQuery('#recmachcustrecord_sscd_parent_form').data("mask",true);
                                    })
                                }catch (e) {
                                  console.log('disableSublistTab Error:' + e.message)
                                }
                            </script>`
                    } catch (ex) {
                            log.error({ title : 'hide view elements error', details : ex });
                    }
            }

        /**
         * Defines the function definition that is executed before record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const beforeSubmit = (scriptContext) => {

        }
        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {

        }

        return {beforeLoad}

    });
