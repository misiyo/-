/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 */
define(['N/encode', 'N/file', 'N/format', 'N/record', 'N/render', 'N/search', 'SuiteScripts/tools/common_api.js', 'SuiteScripts/SuiteScripts_MC/common.js'],

    (encode, file, format, record, render, search, commonApi, common) => {
        /**
         * Defines the Suitelet script trigger point.
         * @param {Object} scriptContext
         * @param {ServerRequest} scriptContext.request - Incoming request
         * @param {ServerResponse} scriptContext.response - Suitelet response
         * @since 2015.2
         */
        const onRequest = (scriptContext) => {
            let request = scriptContext.request;
            let response = scriptContext.response;
            if (request.method == 'GET') {
                let scId = request.parameters.rec_id;
                let xmlStr = getXml(scId);
                //写文件
                response.writeFile(xmlStr);
            }
        }

        function getXml(scId) {
            let printFormat = 'SuiteScripts/SuiteScripts_BR/goodsList.xml';
            //加载获取模板
            let tempFile = file.load({id: printFormat});
            //创建用于导出的文档
            let templateRenderer = render.create();
            //将模板内容附到导出文档中
            templateRenderer.templateContent = tempFile.getContents();
            let data = getData(scId);
            templateRenderer.addCustomDataSource({
                alias: 'data',
                format: render.DataSource.OBJECT,
                data: data
            });
            let excel_str = templateRenderer.renderAsString();
            //将字符串转换为另一种类型的编码
            let fstr = encode.convert({
                string: excel_str,
                inputEncoding: encode.Encoding.UTF_8,
                outputEncoding: encode.Encoding.BASE_64
            });
            let name = 'goodsList' + '.xls';
            let excel = file.create({
                name: name,
                fileType: file.Type.EXCEL,
                contents: fstr
            });
            return excel;
        }

        function getData(scId) {
            let data = {};
            let filters = [];
            filters.push(['internalid', 'anyof', scId]);
            let columns = getColumns();
            let mySearch = search.create({
                type: 'customrecord_ecm_sp',
                filters: filters,
                columns: columns
            });
            let result = commonApi.getAllData(mySearch);
            log.debug('result', result);
            if (result) {
                data = getResult(result, columns, scId);
            }
            return data;
        }

        function getColumns() {
            let columns = [];
            //0 SP NO
            columns.push(search.createColumn({
                name: 'name'
            }));
            //1  离港日期
            columns.push(search.createColumn({
                name: 'custrecord_sp_departuredate'
            }));
            //2 ETA
            columns.push(search.createColumn({
                name: 'custrecord_sp_eta'
            }));

            return columns;
        }

        function getResult(result, columns, spId) {
            let data = {};
            let itemList = [];
            if (result.length > 0) {
                data.sp_no = result[0].getValue(columns[0]);
                data.atd = result[0].getValue(columns[1]);
                data.eta = result[0].getValue(columns[2]);
            }
            var spInfo = record.load({
                type: 'customrecord_ecm_sp',
                id: spId
            });
            var lineCount = spInfo.getLineCount({
                sublistId: 'recmachcustrecord_scdline_sp'
            });
            for (let i = 0; i < lineCount; i++) {
                var subId = spInfo.getSublistValue({
                    sublistId: 'recmachcustrecord_scdline_sp',
                    fieldId: 'id',
                    line: i
                });
                let scdLine = record.load({
                    type: 'customrecord_ecm_scd_line',
                    id: subId
                });
                var goodsId = scdLine.getValue('custrecord_scdline_item');
                //查询商品信息
                let goodsInfo = record.load({
                    type: 'lotnumberedinventoryitem',
                    id: goodsId
                });
                let casePackage = isNull(goodsInfo.getValue('custitem_ecm_case_package_kg'));
                let wgtUnit = isNull(goodsInfo.getText('custitem_ecm_wgt_unit'));
                let packageRemark = isNull(goodsInfo.getText('custitem_ecm_package_remk_en'));
                let package_info = isNull(casePackage) + isNull(wgtUnit) + '/' + isNull(packageRemark);
                let scdLineCount = scdLine.getLineCount({
                    sublistId: 'recmachcustrecord_id_spline'
                });
                for (let j = 0; j < scdLineCount; j++) {
                    let item = {};
                    let ecmId = scdLine.getSublistValue({
                        sublistId: 'recmachcustrecord_id_spline',
                        fieldId: 'id',
                        line: j
                    });
                    let ecmInfo = record.load({
                        type: 'customrecord_ecm_inventorydetail',
                        id: ecmId
                    });
                    item.package_type = package_info;
                    item.lot_no = isNull(ecmInfo.getText('custrecord_id_seriallot'));
                    item.product_name = isNull(scdLine.getValue('custrecord_scdline_enname'));
                    item.hs_code = isNull(scdLine.getValue('custrecord_scdline_hscodedestination'));
                    item.customs_duties = isNull(scdLine.getValue('custrecord_scdline_rateofdestination'));
                    item.pallet = isNull(ecmInfo.getValue('custrecord_id_palletno'));
                    item.pallet_weight = isNull(ecmInfo.getValue('custrecord_id_netweight_perpallet'));
                    item.pallet_size = isNull(ecmInfo.getValue('custrecord_id_palletsize'));
                    item.units = isNull(ecmInfo.getValue('custrecord_id_packageno'));
                    item.gw = isNull(ecmInfo.getValue('custrecord_id_grossweight'));
                    item.nw = isNull(ecmInfo.getValue('custrecord_id_netweight'));
                    item.vol = isNull(ecmInfo.getValue('custrecord_id_volume'));
                    itemList.push(item);
                }
            }
            data.itemList = itemList;
            return data;
        }

        function isNull(someValue) {
            if (someValue == '' || someValue == null) {
                return '';
            } else {
                if (isNaN(someValue) && someValue.indexOf("&") >= 0) {
                    someValue = someValue.replace(/&/g, "&amp;");
                }
                return someValue;
            }
        }

        return {onRequest}

    });
