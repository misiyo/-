/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 */
define(['N/encode', 'N/file', 'N/format', 'N/record', 'N/render', 'N/search', 'SuiteScripts/tools/common_api.js', 'SuiteScripts/SuiteScripts_MC/common.js'],

    (encode, file, format, record, render, search, commonApi, common) => {
        /**
         * Defines the Suitelet script trigger point.
         * @param {Object} scriptContext
         * @param {ServerRequest} scriptContext.request - Incoming request
         * @param {ServerResponse} scriptContext.response - Suitelet response
         * @since 2015.2
         */
        const onRequest = (scriptContext) => {
            let request = scriptContext.request;
            let response = scriptContext.response;
            if (request.method == 'GET') {
                let scId = request.parameters.rec_id;
                let xmlStr = getXml(scId);
                //写文件
                response.writeFile(xmlStr);
            }
        }

        function getXml(scId) {
            let printFormat = 'SuiteScripts/SuiteScripts_BR/selfDelivery.txt';
            //加载获取模板
            let tempFile = file.load({id: printFormat});
            //创建用于导出的文档
            let templateRenderer = render.create();
            //将模板内容附到导出文档中
            templateRenderer.templateContent = tempFile.getContents();
            let data = getData(scId);
            templateRenderer.addCustomDataSource({
                alias: 'data',
                format: render.DataSource.OBJECT,
                data: data
            });
            let excel_str = templateRenderer.renderAsString();
            //将字符串转换为另一种类型的编码
            let fstr = encode.convert({
                string: excel_str,
                inputEncoding: encode.Encoding.UTF_8,
                outputEncoding: encode.Encoding.BASE_64
            });
            let name = 'declaration' + '.xls';
            let excel = file.create({
                name: name,
                fileType: file.Type.EXCEL,
                contents: fstr
            });
            return excel;
        }

        function getData(scId) {
            let data = {};
            let filters = [];
            filters.push(['internalid', 'anyof', scId]);
            let columns = getColumns();
            let mySearch = search.create({
                type: 'customrecord_ecm_sp',
                filters: filters,
                columns: columns
            });
            let result = commonApi.getAllData(mySearch);
            log.debug('result', result);
            if (result) {
                data = getResult(result, columns, scId);
            }
            return data;
        }

        function getColumns() {
            let columns = [];
            //0 收货人
            columns.push(search.createColumn({
                name: 'custrecord_sp_consignee'
            }));
            //1 公司
            columns.push(search.createColumn({
                name: 'custrecord_sp_scsubsidiary'
            }));
            //2 SP NO
            columns.push(search.createColumn({
                name: 'name'
            }))
            //3 审核通过日期
            columns.push(search.createColumn({
                name: 'custrecord_sp_approvedate'
            }))
            //4 客户
            columns.push(search.createColumn({
                name: 'custrecord_sp_customer'
            }))
            //5 收货地址
            columns.push(search.createColumn({
                name: 'custrecord_sp_deliveryadd'
            }))
            //6 目的国
            columns.push(search.createColumn({
                name: 'custrecord_sp_country_destination'
            }))
            //7 发出仓
            columns.push(search.createColumn({
                name: 'custrecord_sp_location'
            }))
            //8 商品
            columns.push(search.createColumn({
                name: 'custrecord_scdline_enname',
                join: 'custrecord_scdline_sp'
            }))
            //9 净重
            columns.push(search.createColumn({
                name: 'custrecord_scdline_net_weight',
                join: 'custrecord_scdline_sp'
            }))
            return columns;
        }

        function getResult(result, columns, spId) {
            let data = {};
            let itemList = [];
            if (result.length > 0) {
                data.consignee = result[0].getValue(columns[0]);
                let subsidiaryRecord = record.load({
                    type: 'subsidiary',
                    id: result[0].getValue(columns[1])
                });
                data.company_name_en = isNull(subsidiaryRecord.getValue('custrecord_ecm_subname_en'));
                data.company_address = isNull(subsidiaryRecord.getValue('custrecord_ecm_subaddress_en'));
                data.inv_no = isNull(result[0].getValue(columns[2]))
                if (result[0].getValue(columns[3])) {
                    data.audit_date = result[0].getValue(columns[3]).substring(0,10);
                }
                let customer = record.load({
                    type: 'customer',
                    id: result[0].getValue(columns[4])
                });
                data.customer_name = isNull(customer.getValue('companyname'))
                data.customer_vat= isNull(customer.getValue('vatregnumber'))
                data.shipping_address = isNull(result[0].getValue(columns[5]));
                data.destination_country = isNull(result[0].getText(columns[6]));
                data.warehouse =  isNull(result[0].getText(columns[7]));
            }
            result.forEach(info => {
                let item = {};
                item.goods_name = isNull(info.getValue(columns[8]));
                item.qty = isNull(info.getValue(columns[9]));
                itemList.push(item);
            })

            data.itemList = itemList;
            return data;
        }

        function isNull(someValue) {
            if (someValue == '' || someValue == null) {
                return '';
            } else {
                if (isNaN(someValue) && someValue.indexOf("&") >= 0) {
                    someValue = someValue.replace(/&/g, "&amp;");
                }
                return someValue;
            }
        }

        return {onRequest}

    });
