/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 */
define(['N/encode', 'N/file', 'N/format', 'N/record', 'N/render', 'N/search', 'SuiteScripts/tools/common_api.js','SuiteScripts/SuiteScripts_MC/common.js'],
    
    (encode, file, format, record, render, search, commonApi,common) => {
        /**
         * Defines the Suitelet script trigger point.
         * @param {Object} scriptContext
         * @param {ServerRequest} scriptContext.request - Incoming request
         * @param {ServerResponse} scriptContext.response - Suitelet response
         * @since 2015.2
         */
        const onRequest = (scriptContext) => {
            let request = scriptContext.request;
            let response = scriptContext.response;
            if (request.method == 'GET') {
                let scId = request.parameters.rec_id;
                let recType = request.parameters.rec_type;
                let xmlStr = getXml(scId,recType);
                //写文件
                response.writeFile(xmlStr);
            }
        }
        function getXml(scId,recType) {
            let printFormat = 'SuiteScripts/SuiteScripts_BR/negotiating.txt';
            if (recType === 'ti') {
                printFormat = 'SuiteScripts/SuiteScripts_BR/taxInfo_tha.txt'
            }else if (recType ==='bs') {
                printFormat = 'SuiteScripts/SuiteScripts_BR/bs.txt'
            }else if (recType === 'neg_os') {
                printFormat = 'SuiteScripts/SuiteScripts_BR/neg_overseas.txt'
            }
            //加载获取模板
            let tempFile = file.load({id: printFormat});
            //创建用于导出的文档
            let templateRenderer = render.create();
            //将模板内容附到导出文档中
            templateRenderer.templateContent = tempFile.getContents();
            let data = getData(scId,recType);
            templateRenderer.addCustomDataSource({
                alias : 'data',
                format : render.DataSource.OBJECT,
                data : data
            });
            let excel_str = templateRenderer.renderAsString();
            //将字符串转换为另一种类型的编码
            let fstr = encode.convert({
                string : excel_str,
                inputEncoding : encode.Encoding.UTF_8,
                outputEncoding : encode.Encoding.BASE_64
            });

            let name =  'negotiation' + '.xls';
            if (recType === 'ti') {
                name =  'Tax Invoice' + '.xls';
            }else if (recType === 'bs') {
                name =  'Billing Statement' + '.xls';
            }
            let excel = file.create({
                name : name,
                fileType : file.Type.EXCEL,
                contents : fstr
            });
            return excel;
        }
        function getData(scId,recType) {
            let data = {};
            let filters = [];
            filters.push(['internalid', 'anyof', scId]);
            let columns = getColumns();
            let mySearch = search.create({
                type: 'customrecord_ecm_sp',
                filters: filters,
                columns: columns
            });
            let result = commonApi.getAllData(mySearch);
            log.debug('result',result);
            if(result) {
                data = getResult(result, columns,scId,recType);
                log.debug('data',data);
            }
            return data;
        }
        function getColumns() {
            let columns = [];
            //0 我司名称
            columns.push(search.createColumn({
                name: 'custrecord_ecm_subname_en',
                join: 'custrecord_sp_scsubsidiary'
            }));
            //1 SP NO
            columns.push(search.createColumn({
                name: 'name'
            }));
           //2 客户名称
            columns.push(search.createColumn({
                name: 'custentity_ecm_nameen',
                join: 'custrecord_sp_customer'
            }));
            //3 交割日期
            columns.push(search.createColumn({
                name: 'custrecord_sp_deliverydate'
            }));
            //4 起运港
            columns.push(search.createColumn({
                name: 'custrecord_sp_loadingport'
            }));
            //5 起运国
            columns.push(search.createColumn({
                name: 'custrecord_sp_country_loading'
            }));
            //6 目的港
            columns.push(search.createColumn({
                name: 'custrecord_sp_destinationport'
            }));
            //7 目的国
            columns.push(search.createColumn({
                name: 'custrecord_sp_country_destination'
            }));
            //8 币种
            columns.push(search.createColumn({
                name: 'custrecord_sp_sccurrency',
            }));
            //9 总净重
            columns.push(search.createColumn({
                name: 'custrecord_sp_gross_net_weight'
            }));
            //10 总毛重
            columns.push(search.createColumn({
                name: 'custrecord_sp_gross_weight'
            }));
            //11 总价
            columns.push(search.createColumn({
                name: 'custrecord_sp_shippingamount'
            }));
            //12 公司地址
            columns.push(search.createColumn({
                name: 'custrecord_ecm_subaddress_en',
                join: 'custrecord_sp_scsubsidiary'
            }));
            //13 公司电话
            columns.push(search.createColumn({
                name: 'custrecord37',
                join: 'custrecord_sp_scsubsidiary'
            }));
            //14 公司传真
            columns.push(search.createColumn({
                name: 'fax',
                join: 'custrecord_sp_scsubsidiary'
            }));
            //15 客户电话
            columns.push(search.createColumn({
                name: 'phone',
                join: 'custrecord_sp_customer'
            }));
            //16 公司Id
            columns.push(search.createColumn({
                name: 'custrecord_sp_scsubsidiary'
            }))
            //17 客户Id
            columns.push(search.createColumn({
                name: 'custrecord_sp_customer'
            }))
            //18 PO NO
            columns.push(search.createColumn({
                name: 'custrecord_sp_pono'
            }))
            //19 可发日期
            columns.push(search.createColumn({
                name: 'custrecord_sp_approvedate'
            }))
            //20 发货日期
            columns.push(search.createColumn({
                name: 'custrecord_sp_deliverycomdate'
            }))
            //21 到货日期
            columns.push(search.createColumn({
                name: 'custrecord_sp_arrivaldate'
            }))
            //22 累计预付款金额
            columns.push(search.createColumn({
                name: 'custrecord_sp_topreamount'
            }))
            //23 累计余款金额
            columns.push(search.createColumn({
                name: 'custrecord_sp_topayamount'
            }))
            //24 发货地址
            columns.push(search.createColumn({
                name: 'custrecord_sp_shippingadd'
            }))
            //25 收货地址
            columns.push(search.createColumn({
                name: 'custrecord_sp_deliveryadd'
            }))
            //26 贸易方式
            columns.push(search.createColumn({
                name: 'custrecord_sp_incoterm'
            }))
            return columns;
        }
        function getResult(result,columns,spId,recType) {
            let data = {};
            let itemList = [];
            let itemInvList = [];
            let sumVol = 0;
            let sum_package_num = 0;
            let tranids = [];
            let soIds = [];
            let paidAmount = 0;
            let total_tax_amount = 0;
            let total_paid_amount = 0;
            let total_balance = 0;
            let loading_port = '';
            let loading_country = '';
            let destination_port = '';
            let destination_country = '';
            if (result && result.length > 0) {
                let resultElement = result[0];
                total_tax_amount = Number(isNull(resultElement.getValue(columns[11])));
                data.company_name = isNull(resultElement.getValue(columns[0]));
                data.sp_id = isNull(resultElement.getValue(columns[1]));
                data.customer_name = isNull(resultElement.getValue(columns[2]));
                data.delivery_date = isNull(resultElement.getValue(columns[3]));
                if (resultElement.getValue(columns[4])) {
                    let portA = record.load({
                        type: 'customrecord_ecm_loaddest_ports',
                        id:resultElement.getValue(columns[4])
                    });
                    loading_port = portA.getValue('custrecord_el_name_en');

                }

                data.loading_port = loading_port
                loading_country = isNull(resultElement.getText(columns[5]));
                data.loading_country = loading_country;
                if (resultElement.getValue(columns[6])) {
                    let portB = record.load({
                        type: 'customrecord_ecm_loaddest_ports',
                        id:resultElement.getValue(columns[6])
                    });
                    destination_port = portB.getValue('custrecord_el_name_en');
                }
                data.destination_port = destination_port;
                destination_country = isNull(resultElement.getText(columns[7]));
                data.destination_country = destination_country;
                data.currency = isNull(resultElement.getText(columns[8]));
                let sum_nw = Number(isNull(resultElement.getValue(columns[9])));
                data.sum_nw = sum_nw;
                let sum_gw = Number(isNull(resultElement.getValue(columns[10])));
                data.sum_gw = sum_gw;
                data.total_tax_amount = total_tax_amount;
                data.company_address = isNull(resultElement.getValue(columns[12]));
                data.company_tel = isNull(resultElement.getValue(columns[13]));
                data.company_fax = isNull(resultElement.getValue(columns[14]));
                data.customer_tel = isNull(resultElement.getValue(columns[15]));
                data.po_no = isNull(resultElement.getValue(columns[18]));
                if (resultElement.getValue(columns[19])) {
                    data.approval_date = resultElement.getValue(columns[19]).substring(0,10);
                }
                data.delivery_com_date = isNull(resultElement.getValue(columns[20]));
                data.receive_date = isNull(resultElement.getValue(columns[21]));
                paidAmount = Number(isNull(resultElement.getValue(columns[22]))) + Number(isNull(resultElement.getValue(columns[23])));
                let companyId = isNull(resultElement.getValue(columns[16]));
                let subsidiaryRecord = record.load({
                    type: 'subsidiary',
                    id: companyId
                });
                let customerId = resultElement.getValue(columns[17]);
                let customer = record.load({
                    type: 'customer',
                    id: customerId
                });
                data.org_type = isNull(customer.getText('custentity_ecm_organizetype'));
                data.customer_vat = isNull(customer.getValue('vatregnumber'));
                data.customer_address = isNull(customer.getValue('defaultaddress'));
                data.company_vat = isNull(subsidiaryRecord.getValue('federalidnumber'));
                var seal = subsidiaryRecord.getValue('custrecord_ecm_signatureseal');
                let pic_name = 'neg';
                var prefix = '------=_NextPart_01D96ED7.D5B28210\n'
                    + 'Content-Location: file:///C:/B133C507/Neg.files/neg\n'
                    + 'Content-Transfer-Encoding: base64\n'
                    + 'Content-Type: image/png\n\n';
                if (recType === 'ti') {
                    prefix = '------=_NextPart_01D96EEC.9B54BF60\n'
                        + 'Content-Location: file:///C:/53215D61/taxInfo_tha.files/tax_inv\n'
                        + 'Content-Transfer-Encoding: base64\n'
                        + 'Content-Type: image/png\n\n';
                    pic_name = 'tax_inv';
                }else if (recType === 'bs') {
                    prefix = '------=_NextPart_01D96EE0.5B9FA8A0\n'
                        + 'Content-Location: file:///C:/8589A0B3/bs.files/bs\n'
                        + 'Content-Transfer-Encoding: base64\n'
                        + 'Content-Type: image/png\n\n';
                    pic_name = 'bs';
                }else if (recType === 'neg_os') {
                    prefix = '------=_NextPart_01D96EEE.929E73F0\n'
                        + 'Content-Location: file:///C:/515B2093/neg_overseas.files/neg_os\n'
                        + 'Content-Transfer-Encoding: base64\n'
                        + 'Content-Type: image/png\n\n';
                    pic_name = 'neg_os';
                }
                if (seal) {
                    let picFile = file.load({ id: seal });
                    data.pic_data = prefix + picFile.getContents();
                    data.pic_name = pic_name;
                }
                let total_nw_en = common.translate(sum_nw).toUpperCase();
                let total_gw_en = common.translate(sum_gw).toUpperCase();
                let total_amount_en = common.translate(total_tax_amount).toUpperCase();
                data.total_nw = sum_nw;
                data.total_nw_en = total_nw_en;
                data.total_gw_en = total_gw_en;
                data.total_amount_en = total_amount_en;

            }
            var spInfo = record.load({
                type: 'customrecord_ecm_sp',
                id: spId
            });
            var lineCount = spInfo.getLineCount({
                sublistId: 'recmachcustrecord_scdline_sp'
            });
            let vat_amount = 0;
            for (let i = 0; i < lineCount; i++) {
                var scdLineId = spInfo.getSublistValue({
                    sublistId: 'recmachcustrecord_scdline_sp',
                    fieldId: 'id',
                    line: i
                });
                let scdLineInfo = record.load({
                    type: 'customrecord_ecm_scd_line',
                    id: scdLineId
                });
                data.vat_rate = scdLineInfo.getValue('custrecord_scdline_taxrate');
                vat_amount = vat_amount + Number(isNull(scdLineInfo.getValue('custrecord_scdline_taxgross')));
                //获取销售订单ID
                let soId = scdLineInfo.getValue('custrecord_scdline_sono1');
                soIds.push(soId);
                let salesInfo = record.load({
                    type: 'salesorder',
                    id: scdLineInfo.getValue('custrecord_scdline_sc')
                });
                //贸易方式
                let incoterm = result[0].getText(columns[26]);
                //发货地址
                let deliveryAddress = result[0].getValue(columns[24]);
                //收货地址
                let shipAddress = result[0].getValue(columns[25]);
                let trade_term;
                if (['FAS', 'FOB'].includes(incoterm)) {
                    trade_term = incoterm + ' ' + isNull(loading_port);
                } else if (['CFR', 'CIF', 'DES', 'DEQ'].includes(incoterm)) {
                    trade_term = incoterm + ' ' + isNull(destination_port);
                } else if (['DDU', 'DDP', 'DAF', 'DAT', 'DAP', 'DPU', 'CPT', 'CIP'].includes(incoterm)) {
                    trade_term = incoterm + ' ' + shipAddress
                } else if (['EXW', 'FCA'].includes(incoterm)) {
                    trade_term = incoterm + ' ' + deliveryAddress
                }
                data.trade_terms = trade_term;
                let from;
                let to;
                if (['EXW', 'FCA'].includes(incoterm)) {
                    from  = deliveryAddress;
                }else {
                    from = isNull(loading_port) + ' ' + isNull(loading_country);
                }
                if (['CPT','CIP','DDU','DDP','DAF','DAT','DAP','DPU'].includes(incoterm)) {
                    to  = shipAddress;
                }else {
                    to = isNull(destination_port) + ' ' + isNull(destination_country);
                }
                data.from = from;
                data.to = to;
                //销售员
                data.sales_man = isNull(salesInfo.getText('salesrep'));
                if (salesInfo.getValue('custbody_ecm_bankinfomation')) {
                    data.bankInfo = salesInfo.getValue('custbody_ecm_bankinfomation').replace(/\n/g, '<br>')
                }
                data.payment_term = salesInfo.getText('custbody_ecm_termsdisplay_en');
                let scdTotalTaxAmount = Number(isNull(scdLineInfo.getValue('custrecord_scdline_grossamt')));
                var tranid = salesInfo.getValue('tranid');
                tranids.push(tranid);
                let paid_amount = paidAmount/total_tax_amount*scdTotalTaxAmount;
                total_paid_amount = total_paid_amount + paid_amount;
                let balance = scdTotalTaxAmount-paidAmount/total_tax_amount*scdTotalTaxAmount;
                total_balance = total_balance + balance;
                //查询商品信息
                let goodsInfo = record.load({
                    type: 'lotnumberedinventoryitem',
                    id: scdLineInfo.getValue('custrecord_scdline_item')
                });
                var unitstype = isNull(goodsInfo.getValue('unitstype'));
                let packageKg = isNull(goodsInfo.getValue('custitem_ecm_case_package_kg'));
                let package_info;
                if (unitstype !== '7') {
                    package_info = isNull(scdLineInfo.getValue('custrecord_scdline_packing_qty'));
                }else {
                    var casePackage = isNull(goodsInfo.getValue('custitem_ecm_case_package_kg'));
                    var wgtUnit = isNull(goodsInfo.getText('custitem_ecm_wgt_unit'));
                    var packageRemark = isNull(goodsInfo.getText('custitem_ecm_package_remk_en'));
                    package_info = isNull(casePackage) + isNull(wgtUnit) + '/' + isNull(packageRemark)
                }
                if ('neg_os' === recType) {
                    var iLineCount = scdLineInfo.getLineCount({
                        sublistId: 'recmachcustrecord_id_spline'
                    });
                    for (let j = 0; j < iLineCount; j++) {
                        var ecmId = scdLineInfo.getSublistValue({
                            sublistId: 'recmachcustrecord_id_spline',
                            fieldId: 'id',
                            line: j
                        });
                        let ecmInfo = record.load({
                            type: 'customrecord_ecm_inventorydetail',
                            id: ecmId
                        });
                        let itemA = {
                            'balance': balance,
                            'paid_amount': paid_amount,
                            'tax_amount': scdTotalTaxAmount,
                            'description' : isNull(scdLineInfo.getValue('custrecord_scdline_enname')),
                            'nw' : isNull(ecmInfo.getValue('custrecord_id_netweight')),
                            'gw' : isNull(ecmInfo.getValue('custrecord_id_grossweight')),
                            'vol' : isNull(ecmInfo.getValue('custrecord_id_volume')),
                            'lot_no': isNull(ecmInfo.getText('custrecord_id_seriallot')),
                            'product_date': isNull(ecmInfo.getText('custrecord_id_productiondate')),
                            'expiration_date': isNull(ecmInfo.getText('custrecord_id_expirationdate')),
                            'package_info' : package_info,
                            'package_num' : isNull(ecmInfo.getValue('custrecord_id_packageno')),
                            'un_tax_price' : Number(isNull(scdLineInfo.getValue('custrecord_scdline_amt')))/packageKg,
                            'unit' : isNull(scdLineInfo.getText('custrecord_scdline_priceunit')),
                            'un_tax_amount' : Number(isNull(scdLineInfo.getValue('custrecord_scdline_grossamt'))) - Number(isNull(scdLineInfo.getValue('custrecord_scdline_taxgross'))),
                            'package_name_en' : isNull(goodsInfo.getValue('custitem_ecm_package_remk_en')),
                            'brand' : isNull(goodsInfo.getValue('custitem_ecm_brand')),
                            'origin' : isNull(goodsInfo.getText('custitem_ecm_origincountry')),
                            'hs_code' :  isNull(scdLineInfo.getValue('custrecord_scdline_hs_code'))
                        }
                        itemList.push(itemA);
                    }
                    let itemC = {
                        'balance': balance,
                        'paid_amount': paid_amount,
                        'tax_amount': scdTotalTaxAmount,
                        'description' : isNull(scdLineInfo.getValue('custrecord_scdline_enname')),
                        'nw' : isNull(scdLineInfo.getValue('custrecord_scdline_net_weight')),
                        'gw' : isNull(scdLineInfo.getValue('custrecord_scdline_gross_weight')),
                        'vol' : isNull(scdLineInfo.getValue('custrecord_scdline_volume')),
                        'package_info' : package_info,
                        'package_num' : isNull(scdLineInfo.getValue('custrecord_scdline_packing_qty')),
                        'un_tax_price' : Number(isNull(scdLineInfo.getValue('custrecord_scdline_amt')))/packageKg,
                        'unit' : isNull(scdLineInfo.getText('custrecord_scdline_priceunit')),
                        'un_tax_amount' : Number(isNull(scdLineInfo.getValue('custrecord_scdline_grossamt'))) - Number(isNull(scdLineInfo.getValue('custrecord_scdline_taxgross'))),
                        'package_name_en' : isNull(goodsInfo.getValue('custitem_ecm_package_remk_en')),
                        'brand' : isNull(goodsInfo.getValue('custitem_ecm_brand')),
                        'origin' : isNull(goodsInfo.getText('custitem_ecm_origincountry')),
                        'hs_code' :  isNull(scdLineInfo.getValue('custrecord_scdline_hs_code'))
                    }
                    itemInvList.push(itemC);
                }else {
                    let itemB = {
                        'balance': balance,
                        'paid_amount': paid_amount,
                        'tax_amount': scdTotalTaxAmount,
                        'description' : isNull(scdLineInfo.getValue('custrecord_scdline_enname')),
                        'nw' : isNull(scdLineInfo.getValue('custrecord_scdline_net_weight')),
                        'gw' : isNull(scdLineInfo.getValue('custrecord_scdline_gross_weight')),
                        'vol' : isNull(scdLineInfo.getValue('custrecord_scdline_volume')),
                        'package_info' : package_info,
                        'package_num' : isNull(scdLineInfo.getValue('custrecord_scdline_packing_qty')),
                        'un_tax_price' : Number(isNull(scdLineInfo.getValue('custrecord_scdline_amt')))/packageKg,
                        'unit' : isNull(scdLineInfo.getText('custrecord_scdline_priceunit')),
                        'un_tax_amount' : Number(isNull(scdLineInfo.getValue('custrecord_scdline_grossamt'))) - Number(isNull(scdLineInfo.getValue('custrecord_scdline_taxgross'))),
                        'package_name_en' : isNull(goodsInfo.getValue('custitem_ecm_package_remk_en')),
                        'brand' : isNull(goodsInfo.getValue('custitem_ecm_brand')),
                        'origin' : isNull(goodsInfo.getText('custitem_ecm_origincountry')),
                        'hs_code' :  isNull(scdLineInfo.getValue('custrecord_scdline_hs_code'))
                    }
                    itemList.push(itemB);
                }
                sum_package_num = sum_package_num + Number(isNull(scdLineInfo.getValue('custrecord_scdline_packing_qty')));
                sumVol = sumVol + Number(isNull(scdLineInfo.getValue('custrecord_scdline_volume')));
            }
            let sc_no = [...new Set(tranids)];
            let so_id = [...new Set(soIds)];
            let sc_no_str;
            sc_no.forEach((sc,index) => {
               if (sc_no_str) {
                   sc_no_str = sc_no_str + '/' + sc
               }else {
                   sc_no_str = sc;
               }
            });
            let invNos = [];
            if (so_id && so_id.length > 0) {
                so_id.forEach(so => {
                    if (so) {
                        let invSearch = search.create({
                            type: 'invoice',
                            filters: [['createdfrom', 'is', so]],
                            columns: [{name: 'tranid'}]
                        });
                        invSearch.run().each(function (result) {
                            if (!invNos.includes(result.getValue('tranid'))) {
                                invNos.push(result.getValue('tranid'));
                            }
                            return true;
                        })
                    }
                })
            }

            log.debug('invNos',invNos.toString());
            let invNoStr;
            invNos.forEach(invNo => {
                if (invNoStr) {
                    invNoStr = invNoStr + '/' + invNo
                }else {
                    invNoStr = invNo;
                }
            });
            data.vat_amount = vat_amount;
            data.total_paid_amount = total_paid_amount;
            data.total_balance = total_balance;
            data.inv_no = invNoStr;
            data.sc_no = sc_no_str;
            data.sum_package_num = sum_package_num;
            data.sum_vol = sumVol;
            data.itemList = itemList;
            data.itemInvList = itemInvList;
            return data;
        }
        function isNull(someValue) {
            if(someValue == '' || someValue == null) {
                return '';
            } else {
                if (isNaN(someValue) && someValue.indexOf("&") >= 0) {
                    someValue = someValue.replace(/&/g, "&amp;");
                }
                return someValue;
            }
        }
        // 修改日期输出格式
        function changeDateFormat(date, type) {
            if(date == ''){
                return ;
            }
            log.debug('date',date);
            let dateArr = date.match(/\d+/g);
            let month = dateArr[0],
                day = dateArr[1],
                year = dateArr[2];
            if(type == 1){
                let months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                let tempMonth = months[month-1];
                return day + '-' + tempMonth + '-' + year;
            }
            if(type == 2){
                let months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
                let tempMonth = months[month-1];
                return tempMonth + ' ' + day + ', ' + year;
            }
            if(type == 3){
                return year + '/' + month + '/' + day;
            }
            if(type == 4){
                let months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                let tempMonth = months[month-1];
                return tempMonth + ' ' + day + ', ' + year;
            }
            if(type == 5){
                let months = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JULY", "AUG", "SEP", "OCT", "NOV", "DEC"];
                let tempMonth = months[month-1];
                return tempMonth + ' ' + day + ',' + year;
            }
            if(type == 6){
                let years = month,
                    months = day,
                    days = year;
                return years + '/' + months + '/' + days;
            }
            if(type == 7){
                return month + '/' + day + '/' + year;
            }
        }
        return {onRequest}

    });
