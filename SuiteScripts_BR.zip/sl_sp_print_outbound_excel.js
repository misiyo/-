/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 */
define(['N/encode', 'N/file', 'N/format', 'N/record', 'N/render', 'N/search', 'SuiteScripts/tools/common_api.js', 'SuiteScripts/SuiteScripts_MC/common.js'],

    (encode, file, format, record, render, search, commonApi, common) => {
        /**
         * Defines the Suitelet script trigger point.
         * @param {Object} scriptContext
         * @param {ServerRequest} scriptContext.request - Incoming request
         * @param {ServerResponse} scriptContext.response - Suitelet response
         * @since 2015.2
         */
        const onRequest = (scriptContext) => {
            let request = scriptContext.request;
            let response = scriptContext.response;
            if (request.method == 'GET') {
                let scId = request.parameters.rec_id;
                let xmlStr = getXml(scId);
                //写文件
                response.writeFile(xmlStr);
            }
        }

        function getXml(scId) {
            let printFormat = 'SuiteScripts/SuiteScripts_BR/outbound.txt';
            //加载获取模板
            let tempFile = file.load({id: printFormat});
            //创建用于导出的文档
            let templateRenderer = render.create();
            //将模板内容附到导出文档中
            templateRenderer.templateContent = tempFile.getContents();
            let data = getData(scId);
            templateRenderer.addCustomDataSource({
                alias: 'data',
                format: render.DataSource.OBJECT,
                data: data
            });
            let excel_str = templateRenderer.renderAsString();
            //将字符串转换为另一种类型的编码
            let fstr = encode.convert({
                string: excel_str,
                inputEncoding: encode.Encoding.UTF_8,
                outputEncoding: encode.Encoding.BASE_64
            });
            let name = 'Outbound_Order' + '.xls';
            let excel = file.create({
                name: name,
                fileType: file.Type.EXCEL,
                contents: fstr
            });
            return excel;
        }

        function getData(scId) {
            let data = {};
            let filters = [];
            filters.push(['internalid', 'anyof', scId]);
            let columns = getColumns();
            let mySearch = search.create({
                type: 'customrecord_ecm_sp',
                filters: filters,
                columns: columns
            });
            let result = commonApi.getAllData(mySearch);
            log.debug('result', result);
            if (result) {
                data = getResult(result, columns, scId);
            }
            return data;
        }

        function getColumns() {
            let columns = [];
            //0 发出仓
            columns.push(search.createColumn({
                name: 'custrecord_sp_location'
            }));
            //1 公司
            columns.push(search.createColumn({
                name: 'custrecord_sp_scsubsidiary'
            }));
            //2 SP NO
            columns.push(search.createColumn({
                name: 'name'
            }))
            //3 商品
            columns.push(search.createColumn({
                name: 'custrecord_scdline_enname',
                join: 'custrecord_scdline_sp'
            }))
            //4 发出仓
            columns.push(search.createColumn({
                name: 'custrecord_sp_location'
            }))
            //5 运输方式
            columns.push(search.createColumn({
                name: 'custrecord_sp_shipping_method'
            }))
            //6 贸易方式
            columns.push(search.createColumn({
                name: 'custrecord_sp_incoterm'
            }))
            //7 收货人
            columns.push(search.createColumn({
                name: 'custrecord_sp_consignee'
            }))
            //8 收货地址
            columns.push(search.createColumn({
                name: 'custrecord_sp_shippingadd'
            }))
            //9 收货联系人
            columns.push(search.createColumn({
                name: 'custrecord_sp_receivingcontact'
            }))
            //10 收货联系方式
            columns.push(search.createColumn({
                name: 'custrecord_sp_recconinfo'
            }))
            //11 船期截至日
            columns.push(search.createColumn({
                name: 'custrecord_sp_shipto'
            }))
            //12 要求到货日
            columns.push(search.createColumn({
                name: 'custrecord_sp_requireddate'
            }))
            return columns;
        }

        function getResult(result, columns, spId) {
            let data = {};
            let itemList = [];
            if (result.length > 0) {
                data.from_warehouse = result[0].getText(columns[0]);
                let subsidiaryRecord = record.load({
                    type: 'subsidiary',
                    id: result[0].getValue(columns[1])
                });
                data.company_name = isNull(subsidiaryRecord.getValue('custrecord_ecm_subname_en'));
                data.sp_no = result[0].getValue(columns[2]);
                const today = getLocalTime();
                log.debug('today',today);
                data.date =  getTime(today);
                if (result[0].getValue(columns[4])) {
                    let location = record.load({
                        type: 'location',
                        id: result[0].getValue(columns[4])
                    });
                    data.warehouse_address = isNull(location.getValue('mainaddress_text'));
                    data.warehouse_contacts = isNull(location.getValue('custrecord_ecm_contactname'));
                    data.contacts_phone = isNull(location.getValue('custrecord_ecm_contacttel'));
                    data.contacts_email = isNull(location.getValue('custrecord_ecm_contactmail'));
                    data.open_time = isNull(location.getValue('custrecord_ecm_open_datetime'));
                }
                data.ship_method =  isNull(result[0].getText(columns[5]));
                data.trade_trems =  isNull(result[0].getText(columns[6]));
                data.consignee =  isNull(result[0].getValue(columns[7]));
                data.shipping_address =  isNull(result[0].getValue(columns[8]));
                data.consignee_contact =  isNull(result[0].getValue(columns[9]));
                data.consignee_phone =  isNull(result[0].getValue(columns[10]));
                data.pick_time =  isNull(result[0].getValue(columns[11]));
                data.arrival_time =  isNull(result[0].getValue(columns[12]));
            }
            var spInfo = record.load({
                type: 'customrecord_ecm_sp',
                id: spId
            });
            var lineCount = spInfo.getLineCount({
                sublistId: 'recmachcustrecord_scdline_sp'
            });
            let sum_pieces = 0;
            let sum_nw = 0;
            let sum_gw = 0;
            let sum_vol = 0;
            let sum_pallet = 0;
            let num = 1;
            for (let i = 0; i < lineCount; i++) {
                var subId = spInfo.getSublistValue({
                    sublistId: 'recmachcustrecord_scdline_sp',
                    fieldId: 'id',
                    line: i
                });
                let scdLine = record.load({
                    type: 'customrecord_ecm_scd_line',
                    id: subId
                });
                var goodsId = scdLine.getValue('custrecord_scdline_item');
                //查询商品信息
                let goodsInfo = record.load({
                    type: 'lotnumberedinventoryitem',
                    id: goodsId
                });
                let casePackage = isNull(goodsInfo.getValue('custitem_ecm_case_package_kg'));
                let wgtUnit = isNull(goodsInfo.getText('custitem_ecm_wgt_unit'));
                let packageRemark = isNull(goodsInfo.getText('custitem_ecm_package_remk_en'));
                let package_info = isNull(casePackage) + isNull(wgtUnit) + '/' + isNull(packageRemark);
                let scdLineCount = scdLine.getLineCount({
                    sublistId: 'recmachcustrecord_id_spline'
                });
                log.debug('lineCount',scdLineCount)
                for (let j = 0; j < scdLineCount; j++) {
                    let item = {};
                    let ecmId = scdLine.getSublistValue({
                        sublistId: 'recmachcustrecord_id_spline',
                        fieldId: 'id',
                        line: j
                    });
                    log.debug('ECMID',ecmId);
                    let ecmInfo = record.load({
                        type: 'customrecord_ecm_inventorydetail',
                        id: ecmId
                    });
                    item.product_name = isNull(scdLine.getValue('custrecord_scdline_enname'));
                    item.lot_no = isNull(ecmInfo.getText('custrecord_id_seriallot'));
                    item.pieces = isNull(ecmInfo.getValue('custrecord_id_packageno'));
                    sum_pieces  = sum_pieces + Number(isNull(ecmInfo.getValue('custrecord_id_packageno')))
                    item.package_info = package_info;
                    item.nw = isNull(ecmInfo.getValue('custrecord_id_netweight'));
                    item.gw = isNull(ecmInfo.getValue('custrecord_id_grossweight'));
                    item.vol = isNull(ecmInfo.getValue('custrecord_id_volume'));
                    item.pallets = isNull(ecmInfo.getValue('custrecord_id_palletno'));
                    item.num = num;
                    num++;
                    sum_nw  = sum_nw + Number(isNull(ecmInfo.getValue('custrecord_id_netweight')))
                    sum_gw  = sum_gw + Number(isNull(ecmInfo.getValue('custrecord_id_grossweight')))
                    sum_vol  = sum_vol + Number(isNull(ecmInfo.getValue('custrecord_id_volume')))
                    sum_pallet  = sum_pallet + Number(isNull(ecmInfo.getValue('custrecord_id_palletno')))
                    itemList.push(item);
                }
            }
            data.sum_pieces = sum_pieces;
            data.sum_nw = sum_nw;
            data.sum_gw = sum_gw;
            data.sum_vol = sum_vol;
            data.sum_pallets = sum_pallet;
            data.itemList = itemList;
            return data;
        }

        function isNull(someValue) {
            if (someValue == '' || someValue == null) {
                return '';
            } else {
                if (isNaN(someValue) && someValue.indexOf("&") >= 0) {
                    someValue = someValue.replace(/&/g, "&amp;");
                }
                return someValue;
            }
        }
        //封装一个获取当前年月日的函数getTime
        function getTime(date) {
            let y = date.getFullYear() //年
            log.debug('year',y)
            let m = date.getMonth() + 1  //月，月是从0开始的所以+1
            log.debug('month',m)
            let d = date.getDate() //日
            log.debug('day',d)
            m = m < 10 ? "0" + m : m //小于10补0
            d = d < 10 ? "0" + d : d //小于10补0
            return m + '/' + d + "/" + y ;
        };
        function getLocalTime(){
            var time=new Date(); //获取时间
            // 获取时间偏移量 getTimezoneOffset 获取格林威治时间   *60000是到毫秒
            var dataOffset=new Date().getTimezoneOffset()*60000
            // 获取格林威治时间
            var utc=time.getTime()+dataOffset;  // 两个时间戳
            // 拿格林威治时间去反推指定地区时间
            var newTime=utc+3600000;  //
            var times=new Date(newTime);
            return times
        }

        return {onRequest}

    });
