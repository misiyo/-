/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 */
define(['N/record', 'N/runtime', 'N/task', 'N/ui/serverWidget', 'N/url'],

    (record, runtime, task, serverWidget, url) => {
        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {
            addSpNegExcelButton(scriptContext);
        }
        const addSpNegExcelButton = (scriptContext) => {
            let typeObj = scriptContext.type;
            let newRec = scriptContext.newRecord;
            let curForm = scriptContext.form;
            let type = newRec.getValue('custrecord_sp_contracttype')
            if (typeObj == 'view') {
                let negUrl = url.resolveScript({
                    scriptId: 'customscript_sl_sp_print_netotiation',
                    deploymentId: 'customdeploy_sl_negotiation_output',
                });
                if (type == 4 || type == 6) {
                    let printNeg = "window.open('" + negUrl + "&rec_id=" + newRec.id + "&rec_type=neg" + "')";
                    curForm.addButton({
                        id: 'custpage_negotiation_doc',
                        label: 'Negotiation Doc',
                        functionName: printNeg
                    });
                } else if (type == 5) {
                    let negOsUrl = url.resolveScript({
                        scriptId: 'customscript_sl_sp_print_netotiation',
                        deploymentId: 'customdeploy_sl_negotiation_output',
                    });
                    let printNegOs = "window.open('" + negOsUrl + "&rec_id=" + newRec.id + "&rec_type=neg_os" + "')";
                    curForm.addButton({
                        id: 'custpage_neg_os',
                        label: 'Negotiation Doc',
                        functionName: printNegOs
                    });
                }
                let printBs = "window.open('" + negUrl + "&rec_id=" + newRec.id + "&rec_type=bs" + "')";
                curForm.addButton({
                    id: 'custpage_billing_statement',
                    label: 'BS',
                    functionName: printBs
                });
                let glUrl = url.resolveScript({
                    scriptId: 'customscript_sl_sp_export_goods_list',
                    deploymentId: 'customdeploy_sl_sp_export_goods_list',
                });
                let printGl = "window.open('" + glUrl + "&rec_id=" + newRec.id + "')";
                curForm.addButton({
                    id: 'custpage_goods_list',
                    label: 'Cargo List',
                    functionName: printGl
                });
                let decUrl = url.resolveScript({
                    scriptId: 'customscript_sl_export_declaration',
                    deploymentId: 'customdeploy_sl_sp_export_declaration',
                });
                let printDecUrl = "window.open('" + decUrl + "&rec_id=" + newRec.id + "')";
                curForm.addButton({
                    id: 'custpage_declaration',
                    label: 'Declaration',
                    functionName: printDecUrl
                });
                let obUrl = url.resolveScript({
                    scriptId: 'customscript_sl_sp_export_outtbound',
                    deploymentId: 'customdeploy_sl_sp_export_outbound',
                });
                let printOb = "window.open('" + obUrl + "&rec_id=" + newRec.id + "')";
                curForm.addButton({
                    id: 'custpage_outbound_order',
                    label: 'Outbound Order',
                    functionName: printOb
                });
                let snUrl = url.resolveScript({
                    scriptId: 'customscript_sl_sp_shipping_note_print',
                    deploymentId: 'customdeploy_sl_sp_shipping_note_print',
                });
                let printSn = "window.open('" + snUrl + "&rec_id=" + newRec.id + "')";
                curForm.addButton({
                    id: 'custpage_shipping_note',
                    label: 'Shipping Note',
                    functionName: printSn
                });
                let tiUrl = url.resolveScript({
                    scriptId: 'customscript_sl_sp_print_netotiation',
                    deploymentId: 'customdeploy_sl_negotiation_output',
                });
                let printTi = "window.open('" + tiUrl + "&rec_id=" + newRec.id + "&rec_type=ti" + "')";
                curForm.addButton({
                    id: 'custpage_tax_invoice_tha',
                    label: 'Tax Inv',
                    functionName: printTi
                });

            }
        }
        /**
         * Defines the function definition that is executed before record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const beforeSubmit = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {

        }

        return { beforeLoad }

    });
